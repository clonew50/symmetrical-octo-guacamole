// ⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽
// 📌 البلاجين: الرسم بالذكاء الاصطناعي Flux
// Developed by: YONO DEV 🪖

import axios from 'axios';
import { join } from 'path';
import { tmpdir } from 'os';
import { createWriteStream, unlinkSync, statSync, mkdirSync, existsSync } from 'fs';
import { pipeline } from 'stream/promises';
import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys';

// صورة GOJO
const GOJO_IMAGE = 'https://files.catbox.moe/2fjios.jpeg';

const STYLES = {
    'انيمي': { suffix: 'anime style, studio ghibli, detailed anime art', emoji: '🌸' },
    'كرتون': { suffix: 'cartoon style, pixar, vibrant colors', emoji: '🎨' },
    'زيتي': { suffix: 'oil painting, classical art, rich textures', emoji: '🖼️' },
    'رصاص': { suffix: 'pencil sketch, black and white, detailed drawing', emoji: '✏️' },
    'ماء': { suffix: 'watercolor painting, soft colors, artistic', emoji: '💧' },
    'ثلاثي': { suffix: '3D render, hyperrealistic, cinema 4D, octane render', emoji: '🎭' },
    'فانتازيا': { suffix: 'fantasy art, magical, epic, concept art', emoji: '🔮' },
    'سايبر': { suffix: 'cyberpunk, neon lights, futuristic, dark atmosphere', emoji: '🌆' },
    'قديم': { suffix: 'vintage, retro, old photo style, sepia', emoji: '📷' },
    'ابيض_اسود': { suffix: 'black and white, monochrome, artistic photography', emoji: '⬛' }
};

// ========== زخرفة GOJO ==========
const box = (title, body) => {
`* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
> *〔 ${title} ┊ ˼‏ 🪖˹ ↶〕*

*🕷️ ──¤﹝الـشـرح ↶ 🎨﹞*
${body}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*GOJO BOT 🥷🏻*`
}

// ========== تخزين مؤقت لأوامر الرسم ==========
const artSessions = new Map();

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const react = async (emoji) => {
        try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }); } catch { }
    };

    // ========== المرحلة 1: المستخدم كتب "ارسم" فقط ==========
    if (!text) {
        await react('🎨');
        return m.reply(box(
            `مـاذا تـريـد أن تـرسـم؟`,
            `> *🔮 اكتب وصف الصورة اللي تريدها*
> *📌 مثال:* ${usedPrefix}${command} قطة لطيفة
> *⚔️ بعدها:* اختار الأستايل من القائمة`
        ));
    }

    // ========== المرحلة 2: المستخدم كتب وصف ==========
    const parts = text.trim().split(/\s+/);
    const firstWord = parts[0]?.toLowerCase();
    const style = STYLES[firstWord];

    if (!style) {
        await react('🎨');
        artSessions.set(m.sender, { prompt: text.trim(), time: Date.now() });

        const rows = Object.entries(STYLES).map(([key, val]) => ({
            title: `${val.emoji} ${key}`,
            description: val.suffix.slice(0, 30) + '...',
            id: `${usedPrefix}${command} ${key} _confirm`
        }));

        const media = await prepareWAMessageMedia(
            { image: { url: GOJO_IMAGE } },
            { upload: conn.waUploadToServer }
        );

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: {
                            text: box(
                                `اخـتـر الأسـتـايـل`,
                                `> *📝 وصفك:* ${text.trim().slice(0, 40)}${text.trim().length > 40? '...' : ''}\n> *🖌️ اختار الأستايل المناسب*`
                            )
                        },
                        footer: { text: '⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽' },
                        header: { hasMediaAttachment: true, imageMessage: media.imageMessage },
                        nativeFlowMessage: {
                            buttons: [{
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: '🎨 اخـتـار الأسـتـايـل',
                                    sections: [{ title: '🖌️ أسـتـايـلات الـرسـم', rows }]
                                })
                            }]
                        }
                    })
                }
            }
        }, { userJid: conn.user.jid, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        return;
    }

    // ========== المرحلة 3: المستخدم اختار أستايل ==========
    const isConfirm = parts[1] === '_confirm';
    let prompt;

    if (isConfirm) {
        const session = artSessions.get(m.sender);
        if (!session || Date.now() - session.time > 300000) {
            artSessions.delete(m.sender);
            return m.reply(box('انـتـهـت الـجـلـسـة', `> *⚔️ ابدأ من جديد:*.${command} <وصف>`));
        }
        prompt = session.prompt;
        artSessions.delete(m.sender);
    } else {
        prompt = parts.slice(1).join(' ');
        if (!prompt) {
            return m.reply(box(
                'تـنـبـيـه',
                `> *📝 اكتب الوصف بعد الأستايل*\n> *📌 مثال:* ${usedPrefix}${command} ${firstWord} قطة لطيفة`
            ));
        }
    }

    // ========== توليد الصورة ==========
    await react('🎨');
    await m.reply(box(
        `جـاري الـرسـم`,
        `> *🖌️ الأستايل:* ${firstWord}\n> *📝 الوصف:* ${prompt.slice(0, 50)}${prompt.length > 50? '...' : ''}\n> *⏳ انتظر 20 ثانية...*`
    ));

    try {
        // ترجمة للإنجليزية
        let englishText = prompt;
        try {
            const trRes = await axios.get(
                `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(prompt)}`,
                { timeout: 8000 }
            );
            const translated = trRes.data?.[0]?.map(x => x?.[0]).filter(Boolean).join('') || prompt;
            if (translated) englishText = translated;
        } catch { }

        const fullPrompt = `${englishText}, ${style.suffix}, high quality, 8k, masterpiece`;

        // رابط Pollinations المصحح
        const encoded = encodeURIComponent(fullPrompt);
        const seed = Math.floor(Math.random() * 999);
        const imageUrl = `https://image.pollinations.ai/prompt/${encoded}?width=1024&height=1024&seed=${seed}&model=flux&enhance=true&nologo=true`;

        const tmpDir = './tmp';
        if (!existsSync(tmpDir)) mkdirSync(tmpDir);
        const filePath = join(tmpDir, `gojo_art_${Date.now()}.jpg`);

        const imgRes = await axios({
            method: 'GET',
            url: imageUrl,
            responseType: 'stream',
            timeout: 120000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        await pipeline(imgRes.data, createWriteStream(filePath));

        const size = statSync(filePath).size;
        if (size < 5000) {
            try { unlinkSync(filePath); } catch { }
            throw new Error('فشل الرسم — السيرفر لم يرجع صورة');
        }

        await conn.sendMessage(m.chat, {
            image: { url: filePath },
            caption: box(
                `تـم الـرسـم!`,
                `> *📝 الوصف:* ${prompt.slice(0, 60)}${prompt.length > 60? '...' : ''}\n> *🖌️ الأستايل:* ${firstWord} ${style.emoji}\n> *📁 الحجم:* ${(size / 1024).toFixed(2)} KB\n> *🤖 الموديل:* Flux AI`
            )
        }, { quoted: m });

        await react('✅');
        setTimeout(() => { try { unlinkSync(filePath) } catch {} }, 3000);

    } catch (err) {
        await react('❌');
        console.error('art error:', err.message);
        m.reply(box(
            'فـشـل الـرسـم',
            `> *❌ الخطأ:* ${err.message}\n> *💡 جرب:* وصف بالانجليزي او أستايل آخر`
        ));
    }
};

handler.help = ['ارسم <وصف>'];
handler.tags = ['الذكاء الاصطناعي'];
handler.command = /^(ارسم|فن|art|draw)$/i;
handler.limit = true;

export default handler;