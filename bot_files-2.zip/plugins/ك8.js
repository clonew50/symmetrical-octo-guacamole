import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'
global.lastMenuVideo = global.lastMenuVideo || null
function getRandomNotSame(a,l){let f=a.filter(v=>v!==l);if(!f.length)f=a;return f[Math.floor(Math.random()*f.length)]}
let handler = async (m,{conn})=>{
let s=(Math.random()*15).toFixed(2); let now=new Date(new Date()+3600000); let locale='ar'; let date=now.toLocaleDateString(locale,{day:'numeric',month:'long',year:'numeric'}); let dayName=now.toLocaleDateString(locale,{weekday:'long'});
const devNumber='212674375708',devName='𝑌𝑂𝑁𝑂 👑';
let menuText=`
* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 قـسـم الـتـسـلـيـة┊ ˼‏ 🎉˹ ↶〕*

*🪖 ──¤﹝بـيـانـات الـقـسـم ↶ 🕸️﹞*
> *🥷🏻┊الـقـسـم:* 〘 الـتـسـلـيـة 〙
> *🥷🏻┊عـدد الاوامـر:* 〘 9 〙
> *🥷🏻┊الـيـوم:* ${dayName}
> *🥷🏻┊الـتـاريـخ:* ${date}
> *🥷🏻┊الـبـنـق:* 〘 ${s}ms 〙

*♣️ ───━ •﹝📌﹞• ━───*
*◌────────────────◌*
*┃ 🪗 اوامــر الـتـسـلـيـه*
*◌────────────────◌*
> *🪇┊زواج*
> *🪇┊طـلاق*
> *🪇┊ورع*
> *🪇┊خـروف*
> *🪇┊حـرب*
> *🪇┊اهـبـل*
> *🪇┊جـمـيـل*
> *🪇┊شـخـصـيـه*
> *🪇┊ريـاضـيـات*
*◌────────────────◌*
 ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`.trim()
conn.sendMessage(m.chat,{react:{text:'🎉',key:m.key}}).catch(()=>{});
const channel='https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r'; const dev=`https://wa.me/${devNumber}`
const vids=['https://files.catbox.moe/jzbdkc.mp4','https://files.catbox.moe/hgkawr.mp4','https://files.catbox.moe/a4axym.mp4']; let rv=getRandomNotSame(vids,global.lastMenuVideo); global.lastMenuVideo=rv; let messa=await prepareWAMessageMedia({video:{url:rv},gifPlayback:true},{upload:conn.waUploadToServer});
let inter={body:{text:menuText},footer:{text:'『 𝐆𝐎𝐉𝐎 ⃝𝐁𝐎𝐓 』'},header:{hasMediaAttachment:true,videoMessage:messa.videoMessage},nativeFlowMessage:{buttons:[{name:'quick_reply',buttonParamsJson:JSON.stringify({display_text:'🔙 رجـوع للـقـائـمـة',id:'.اوامر'})},{name:'quick_reply',buttonParamsJson:JSON.stringify({display_text:'📜 جـمـيـع الاوامـر',id:'.جميع-الاوامر'})},{name:'cta_url',buttonParamsJson:JSON.stringify({display_text:"📢 القناة",url:channel,merchant_url:channel})},{name:'cta_url',buttonParamsJson:JSON.stringify({display_text:`👨‍💻 الـمـطـور ${devName}`,url:dev,merchant_url:dev})}],messageParamsJson:JSON.stringify({limited_time_offer:{text:`⚡ ${s}ms | GOJO`,url:dev,copy_code:`Dev: +${devNumber}`,expiration_time:Date.now()+86400000}})}}
let msg=generateWAMessageFromContent(m.chat,{interactiveMessage:proto.Message.InteractiveMessage.fromObject(inter)},{userJid:conn.user.jid}); await conn.relayMessage(m.chat,msg.message,{messageId:msg.key.id})
}
handler.command=['ك8']; export default handler