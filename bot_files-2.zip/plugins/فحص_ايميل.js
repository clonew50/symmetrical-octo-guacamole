import axios from 'axios';
import * as cheerio from 'cheerio';

const فحص_جيميل = {
  check: async function(email) {
    try {
      const username = email.split('@')[0];
      const { data } = await axios.post('https://gmail-osint.activetk.jp/', new URLSearchParams({ q: username, domain: 'gmail.com' }), {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'GOJO-BOT/1.0.0' }
      });
      const $ = cheerio.load(data);
      const text = $('pre').text();
      return {
        الصورة: this.extract(text, /Custom profile picture!\s*=>\s*(.*)/, 'لا توجد'),
        الايميل: email,
        اخر_تعديل: this.extract(text, /Last profile edit : (.*)/, 'غير معروف'),
        جوجل_id: this.extract(text, /Gaia ID : (.*)/, 'غير معروف'),
        نوع_الحساب: this.extract(text, /User types : (.*)/, 'غير معروف'),
        جوجل_شات: {
          النوع: this.extract(text, /Entity Type : (.*)/, 'غير معروف'),
          كود_العميل: this.extract(text, /Customer ID : (.*)/, 'لا يوجد', true),
        },
        جوجل_بلس: {
          مؤسسة: this.extract(text, /Entreprise User : (.*)/, 'لا'),
        },
        الخرائط: {
          الصفحة: this.extract(text, /Profile page : (.*)/, 'لا توجد'),
        },
        حالة_ip: text.includes('Your IP has been blocked by Google')? 'محظور من Google' : 'سليم',
        التقويم: text.includes('No public Google Calendar')? 'لا يوجد' : 'متاح'
      };
    } catch (error) {
      console.error(error);
      return null;
    }
  },

  extract: function(text, regex, القيمة_الافتراضية = 'لا توجد بيانات', checkNotFound = false) {
    const result = (text.match(regex) || [null, القيمة_الافتراضية])[1].trim();
    return checkNotFound && result === 'Not found.'? 'لا توجد بيانات' : result;
  }
};

let handler = async (m, { conn, text }) => {
  if (!text) {
    return conn.reply(m.chat, '⚠️ *طريقة الاستخدام:*\n.فحص_ايميل example@gmail.com', m);
  }

  if (!text.includes('@gmail.com')) return conn.reply(m.chat, '❌ الايميل لازم يكون @gmail.com', m);

  await conn.reply(m.chat, '⏳ *جاري فحص الايميل... انتظر شوية*', m);
  const result = await فحص_جيميل.check(text);

  if (!result) return conn.reply(m.chat, '❌ فشل في جلب البيانات. الموقع محظور او الايميل غلط', m);

  const الرسالة = `
*🔍 نتائج فحص ايميل Gmail*

📧 *الايميل:* ${result.الايميل}
🖼️ *الصورة الشخصية:* ${result.الصورة}
📅 *اخر تعديل:* ${result.اخر_تعديل}
🆔 *Google ID:* ${result.جوجل_id}
👤 *نوع الحساب:* ${result.نوع_الحساب}
💬 *Google Chat:* ${result.جوجل_شات.النوع}
🏢 *Customer ID:* ${result.جوجل_شات.كود_العميل}
🏛️ *مستخدم مؤسسة:* ${result.جوجل_بلس.مؤسسة}
🗺️ *صفحة الخرائط:* ${result.الخرائط.الصفحة}
🌐 *حالة الـ IP:* ${result.حالة_ip}
📆 *تقويم Google:* ${result.التقويم}
  `;

  return conn.reply(m.chat, الرسالة, m);
};

handler.help = ['فحص_ايميل <الايميل>'];
handler.tags = ['ادوات'];
handler.command = /^(فحص_ايميل)$/i;
handler.limit = true;

export default handler