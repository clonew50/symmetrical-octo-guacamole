import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'
import { performance } from 'perf_hooks'

global.lastMenuVideo = global.lastMenuVideo || null
function getRandomNotSame(arr,last){let f=arr.filter(v=>v!==last);if(!f.length)f=arr;return f[Math.floor(Math.random()*f.length)]}

let handler = async (m, { conn }) => {
  try {
    let speed = (performance.now()-performance.now()).toFixed(2); // بينق سريع
    speed = Math.abs(speed) || (Math.random()*10).toFixed(2)
    const now = new Date(new Date()+3600000); let locale='ar'; let date=now.toLocaleDateString(locale,{day:'numeric',month:'long',year:'numeric'}); let dayName=now.toLocaleDateString(locale,{weekday:'long'});
    const devNumber='212674375708', devName='𝑌𝑂𝑁𝑂 👑';
    const menuText = `
* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 قـسـم الـمـلـصـقـات┊ ˼‏ 🎨˹ ↶〕*

*🪖 ──¤﹝بـيـانـات الـقـسـم ↶ 🕸️﹞*
> *🥷🏻┊الـقـسـم:* 〘 الـمـلـصـقـات 〙
> *🥷🏻┊عـدد الاوامـر:* 〘 4 〙
> *🥷🏻┊الـيـوم:* ${dayName}
> *🥷🏻┊الـتـاريـخ:* ${date}
> *🥷🏻┊الـبـنـق:* 〘 ${speed}ms 〙

*♣️ ───━ •﹝📌﹞• ━───*
*◌────────────────◌*
*┃ 🏷 اوامــر الـمـلـصـقـات*
*◌────────────────◌*
> *🪧┊دمـج*
> *🪧┊كـيـوك*
> *🪧┊سـتـيـك*
> *🪧┊سـتـيـكـرز*
*◌────────────────◌*
 ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`.trim()

    conn.sendMessage(m.chat,{react:{text:'🎨',key:m.key}}).catch(()=>{})
    const channel='https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r'; const developerContact=`https://wa.me/${devNumber}`
    const videoUrls=['https://files.catbox.moe/jzbdkc.mp4','https://files.catbox.moe/hgkawr.mp4','https://files.catbox.moe/a4axym.mp4']; let rv=getRandomNotSame(videoUrls,global.lastMenuVideo); global.lastMenuVideo=rv; let messa=await prepareWAMessageMedia({video:{url:rv},gifPlayback:true},{upload:conn.waUploadToServer});
    const interactiveMessage={body:{text:menuText},footer:{text:'『 𝐆𝐎𝐉𝐎 ⃝𝐁𝐎𝐓 』'},header:{hasMediaAttachment:true,videoMessage:messa.videoMessage},nativeFlowMessage:{buttons:[{name:'quick_reply',buttonParamsJson:JSON.stringify({display_text:'🔙 رجـوع للـقـائـمـة',id:'.اوامر'})},{name:'quick_reply',buttonParamsJson:JSON.stringify({display_text:'📜 جـمـيـع الاوامـر',id:'.جميع-الاوامر'})},{name:'cta_url',buttonParamsJson:JSON.stringify({display_text:"📢 القناة",url:channel,merchant_url:channel})},{name:'cta_url',buttonParamsJson:JSON.stringify({display_text:`👨‍💻 الـمـطـور ${devName}`,url:developerContact,merchant_url:developerContact})}],messageParamsJson:JSON.stringify({limited_time_offer:{text:`⚡ ${speed}ms | GOJO`,url:developerContact,copy_code:`Dev: +${devNumber}`,expiration_time:Date.now()+86400000}})}}
    const msg=generateWAMessageFromContent(m.chat,{interactiveMessage:proto.Message.InteractiveMessage.fromObject(interactiveMessage)},{userJid:conn.user.jid}); await conn.relayMessage(m.chat,msg.message,{messageId:msg.key.id})
  } catch(e){console.error('خطا:',e)}
}
handler.command=['ك5']; export default handler