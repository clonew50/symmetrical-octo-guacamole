import fs from 'fs';
import path from 'path';

function getRandomMediaUrl() {
  try {
    const filePath = path.join(process.cwd(), 'media-links.txt');
    const data = fs.readFileSync(filePath, 'utf-8');
    const links = data.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (links.length === 0) return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
    return links[Math.floor(Math.random() * links.length)];
  } catch (e) {
    console.error('تعذر قراءة media-links.txt:', e.message);
    return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
  }
}

const handler = async (m, { conn }) => {

const imageUrl = getRandomMediaUrl();  

const messageText = `

『 مـرحـبـاً بــك يــا ⌊ ${m.pushName} ⌉ فـي 『 ⚡𝑮𝑬𝑶-bₒₜ 』 』

⌝ قــســم الــفــعــالــيــات ┋🪄⌞ ⇊
⎔ ⋅ ───━ •﹝🩸﹞• ━─── ⋅ ⎔

📝┊⇇『 احـــزر 』
📍┊⇇『 عــلــم 』
🗃️┊⇇『 عــيــن 』
⚽┊⇇『 كـــورة 』
📿┊⇇『 ديــــن 』
✨┊⇇『 تــرتــيــب 』
🧩┊⇇『 تـفـكـيـك 』
❓┊⇇『 ســؤال 』
💡┊⇇『 إيـمـوجـي 』
🤔┊⇇『 لـغــــز 』
🍥┊⇇『 لـغــز-أنــمـي 』
🏅┊⇇『 ريــاضــة 』
🧠┊⇇『 ثـقـافـي 』

✦─━── •﹝🩸﹞• ──━─✦
⟣ ✧ هـذا الـقـسـم قـيـد الـتـطـويـر ✧ ⟢
✦─━── •﹝🩸﹞• ──━─✦

✦ 『 ⚡𝑮𝑬𝑶 』ــوت 💗💛
`.trim();

await conn.sendMessage(m.chat, { text: "*✦ جـــارٍ إرســال الـقـسـم....... 💗*" }, { quoted: m });  

await conn.sendMessage(m.chat, {  
    image: { url: imageUrl },  
    caption: messageText  
}, { quoted: m });  

await conn.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });

};

handler.command = /^قسم-الفعاليات$/i;
handler.tags = ["جــــيـــو"];
handler.help = ["جــــيـــو"];

export default handler;