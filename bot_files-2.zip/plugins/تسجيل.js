import db from '../lib/database.js'
import { createHash } from 'crypto'
import moment from 'moment-timezone'
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys'

let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i

let handler = async function (m, { conn, text, usedPrefix, command }) {
  const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
  const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;
  const myCredit = `*⚜️┊اسـم الـبـوت:* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*`;

  let who = m.sender
  let user = global.db.data.users[who]
  let pushName = m.pushName || 'مستخدم مجهول'
  let perfil = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://i.ibb.co/Jww0n5FY/file.jpg')
  
  // قناة الواتساب الجديدة
  const channelLink = "https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r"

  if (user.registered && !text.includes(pushName)) {
    return await sendSuccessMessage(m, conn, user, perfil, channelLink, startDeco, endDeco, myCredit)
  }

  if (!text) {
    let welcomeTxt = `${startDeco}
> *〔 نـظـام الـتـسـجـيـل┊ ˼‏ 🛡️˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝تـفـعـيـل الـعـضـويـة ↶﹞*
> *〔 👋 〕 مـرحـبـاً:* ${pushName}
> *〔 🎁 〕 الـمـكـافـأة:* 50 💎 + 1000 XP
> *〔 📌 〕 الـمـلاحـظـة:* اختر عمرك من القائمة للتفعيل

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
${myCredit} *🕸️ ───━ •﹝📌﹞• ━───*
${endDeco}`

    const thumb = await prepareWAMessageMedia({ image: { url: perfil } }, { upload: conn.waUploadToServer })
    
    let sections = [
      { title: "🛡️ الفئة العمرية (5 - 20)", rows: Array.from({length: 16}, (_, i) => ({ title: `العمر: ${i + 5}`, id: `${usedPrefix + command} ${pushName}.${i + 5}` })) },
      { title: "🛡️ الفئة العمرية (21 - 35)", rows: Array.from({length: 15}, (_, i) => ({ title: `العمر: ${i + 21}`, id: `${usedPrefix + command} ${pushName}.${i + 21}` })) },
      { title: "🛡️ الفئة العمرية (36 - 50)", rows: Array.from({length: 15}, (_, i) => ({ title: `العمر: ${i + 36}`, id: `${usedPrefix + command} ${pushName}.${i + 36}` })) }
    ]

    let msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: welcomeTxt },
            footer: { text: "© Powered By GOJO 🇲🇦" },
            header: { hasMediaAttachment: true, imageMessage: thumb.imageMessage },
            nativeFlowMessage: { 
                buttons: [{ name: "single_select", buttonParamsJson: JSON.stringify({ title: "📑 فتح قائمة الأعمار", sections }) }]
            }
          }
        }
      }
    }, { userJid: conn.user.jid, quoted: m })

    return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  }

  let [_, namex, splitter, agex] = text.match(Reg) || []
  let age = parseInt(agex)
  if (!age || age > 50 || age < 5) return 

  user.name = namex.trim() + ' ✓'
  user.age = age
  user.regTime = +new Date()
  user.registered = true
  user.limit = (user.limit || 0) + 50 
  user.exp = (user.exp || 0) + 1000

  return await sendSuccessMessage(m, conn, user, perfil, channelLink, startDeco, endDeco, myCredit)
}

async function sendSuccessMessage(m, conn, user, perfil, channelLink, startDeco, endDeco, myCredit) {
  let sn = createHash('md5').update(m.sender).digest('hex').slice(0, 15)
  let shareText = encodeURIComponent(`انضم لأقوى بوت واتساب 🔥\n𝐆𝐎𝐉𝐎-𝐁𝐎𝐓\nرابط القناة: ${channelLink}`)
  let shareBtnUrl = `https://wa.me/?text=${shareText}`

  let confirmTxt = `${startDeco}
> *〔 تـم الاعـتـمـاد┊ ˼‏ ✅˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝تـسـجـيـل نـاجـح ↶﹞*
> *〔 👤 〕 الاسـم:* ${user.name}
> *〔 🎂 〕 الـعـمـر:* ${user.age} عاماً
> *〔 🎁 〕 الـمـكـافـأة:* 50 💎 + 1000 XP
> *〔 🆔 〕 الـمـعـرف:* \`${sn}\`

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
${myCredit} *🕸️ ───━ •﹝📌﹞• ━───*
${endDeco}`

  const thumbConfirm = await prepareWAMessageMedia({ image: { url: perfil } }, { upload: conn.waUploadToServer })
  
  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: confirmTxt },
          footer: { text: "© Powered By GOJO 🇲🇦" },
          header: { hasMediaAttachment: true, imageMessage: thumbConfirm.imageMessage },
          nativeFlowMessage: { 
            buttons: [
              { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "🌐 انضم للقناة الرسمية", url: channelLink }) },
              { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "📤 مشاركة القناة", url: shareBtnUrl }) },
              { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🚀 قائمة الأوامر", id: ".الاوامر" }) }
            ] 
          }
        }
      }
    }
  }, { userJid: conn.user.jid, quoted: m })

  return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.help = ['تسجيل'];
handler.tags = ['🔰 التسجيل 🔰'];
handler.command = ['تسجيل', 'سجل', 'register', 'reg'];

export default handler;