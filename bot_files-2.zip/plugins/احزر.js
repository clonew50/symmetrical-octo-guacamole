// plugins/game-guess.js
// ⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 ⧽v1 - لعبة احزر الشخصية 🎭

import axios from "axios";
import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';

const timeout = 60000;

const nikolasTheme = {
    title: (t) => `* ━ ╼╃ ⌬〔 ${t} 〕⌬ ╄╾ ━ *`,
    line: (t) => `> *〔 ⚔️ 〕 ${t}*`,
    divider: `*♣️ ───━ •﹝📌﹞• ━───*`,
    footer: `𝐆𝐎𝐉𝐎-𝐁𝐎𝐓`
}

let handler = async (m, { conn, command }) => {
    conn.nikolas = conn.nikolas || {};
    let id = m.chat;

    // معالج الإجابة على الأزرار
    if (command.startsWith('جوابي_')) {
        let nik = conn.nikolas[id];

        if (!nik) {
            return conn.reply(m.chat, `${nikolasTheme.title("⚠️ تـنـبـيـه")}
${nikolasTheme.line("لا تـوجـد لـعـبـة نـشـطـة الان")}
${nikolasTheme.divider}
${nikolasTheme.title(" 𝐆𝐎𝐉𝐎 ")}`, m);
        }

        let selectedAnswerIndex = parseInt(command.split('_')[1]);
        if (isNaN(selectedAnswerIndex) || selectedAnswerIndex < 1 || selectedAnswerIndex > 4) {
            return conn.reply(m.chat, `${nikolasTheme.title("❌ خـطـأ")}
${nikolasTheme.line("اخـتـيـار غـيـر صـالـح")}
${nikolasTheme.title(" 𝐆𝐎𝐉𝐎 ")}`, m);
        }

        let selectedAnswer = nik.options[selectedAnswerIndex - 1];
        let isCorrect = nik.correctAnswer === selectedAnswer;

        if (isCorrect) {
            if (!global.db.data.users[m.sender].points) global.db.data.users[m.sender].points = 0;
            global.db.data.users[m.sender].points += 500;

            await conn.reply(m.chat, `${nikolasTheme.title("✅ إجـابـة صـحـيـحـة")}
${nikolasTheme.line("مـبـروك! +500 نـقـطـة 🎉")}
${nikolasTheme.divider}
${nikolasTheme.line(`الإجـابـة: ${nik.correctAnswer}`)}
${nikolasTheme.line(`نـقـاطـك: ${global.db.data.users[m.sender].points}`)}
${nikolasTheme.title(" 𝐆𝐎𝐉𝐎 ")}`, m);

            clearTimeout(nik.timer);
            delete conn.nikolas[id];
        } else {
            nik.attempts -= 1;
            if (nik.attempts > 0) {
                await conn.reply(m.chat, `${nikolasTheme.title("❌ إجـابـة خـاطـئـة")}
${nikolasTheme.line(`الـمـحـاولات الـمـتـبـقـيـة: ${nik.attempts}`)}
${nikolasTheme.divider}
${nikolasTheme.line("حـاول مـرة اخـرى")}
${nikolasTheme.title(" 𝐆𝐎𝐉𝐎 ")}`, m);
            } else {
                await conn.reply(m.chat, `${nikolasTheme.title("❌ انـتـهـت الـمـحـاولـات")}
${nikolasTheme.line(`الإجـابـة الـصـحـيـحـة: ${nik.correctAnswer}`)}
${nikolasTheme.divider}
${nikolasTheme.line("اسـتـخـدم.احزر لـلـعـب مـرة اخـرى")}
${nikolasTheme.title(" 𝐆𝐎𝐉𝐎 ")}`, m);
                clearTimeout(nik.timer);
                delete conn.nikolas[id];
            }
        }
        return;
    }

    // بدء لعبة جديدة
    try {
        if (conn.nikolas[id]) {
            return conn.reply(m.chat, `${nikolasTheme.title("⚠️ تـنـبـيـه")}
${nikolasTheme.line("يـوجـد لـعـبـة سـابـقـة لـم تـنـتـهـي")}
${nikolasTheme.title(" 𝐆𝐎𝐉𝐎 ")}`, m);
        }

        const { data: nikData } = await axios.get('https://gist.githubusercontent.com/Kyutaka101/98d564d49cbf9b539fee19f744de7b26/raw/f2a3e68bbcdd2b06f9dbd5f30d70b9fda42fec14/guessflag');
        const nikItem = nikData[Math.floor(Math.random() * nikData.length)];
        const { img, name } = nikItem;

        let options = [name];
        while (options.length < 4) {
            let randomItem = nikData[Math.floor(Math.random() * nikData.length)].name;
            if (!options.includes(randomItem)) options.push(randomItem);
        }
        options.sort(() => Math.random() - 0.5);

        const media = await prepareWAMessageMedia({ image: { url: img } }, { upload: conn.waUploadToServer });

        // بناء الأزرار
        const buttons = options.map((option, index) => ({
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({
                display_text: `⚔️ ${option}`,
                id: `.جوابي_${index + 1}`
            })
        }));

        const interactiveMessage = {
            body: { text: `${nikolasTheme.divider}
*〔 🎭 〕 لــعــبــة احــزر الـشـخـصـيـة*
*〔 👁️ 〕 مـن هـي هـذه الـشـخـصـيـة؟*

${nikolasTheme.divider}
*〔 ⏰ 〕 الـوقـت:* 60 ثـانـيـة
*〔 💰 〕 الـجـائـزة:* 500 نـقـطـة
*〔 🎯 〕 الـمـحـاولات:* 2
${nikolasTheme.divider}` },
            footer: { text: nikolasTheme.footer },
            header: {
                hasMediaAttachment: true,
                title: "🎭 GOJO GAME",
                imageMessage: media.imageMessage,
            },
            nativeFlowMessage: {
                buttons: buttons,
                messageParamsJson: JSON.stringify({
                    bottom_sheet: {
                        list_title: "🎭 اخـتـر اسـم الـشـخـصـيـة",
                        button_title: "⚔️ الـخـيـارات"
                    }
                })
            }
        };

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject(interactiveMessage)
                }
            }
        }, { userJid: conn.user.jid, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

        conn.nikolas[id] = {
            correctAnswer: name,
            options: options,
            timer: setTimeout(async () => {
                if (conn.nikolas[id]) {
                    await conn.reply(m.chat, `${nikolasTheme.title("⏰ انـتـهى الـوقـت")}
${nikolasTheme.line(`الإجـابـة الـصـحـيـحـة: ${name}`)}
${nikolasTheme.divider}
${nikolasTheme.line("اسـتـخـدم.احزر لـلـعـب مـرة اخـرى")}
${nikolasTheme.title(" 𝐆𝐎𝐉𝐎 ")}`, m);
                    delete conn.nikolas[id];
                }
            }, timeout),
            attempts: 2
        };

    } catch (e) {
        console.error(e);
        conn.reply(m.chat, `${nikolasTheme.title("❌ خـطـأ")}
${nikolasTheme.line("حـدث خـطـأ فـي تـحـمـيـل الـلـعـبـة")}
${nikolasTheme.title(" 𝐆𝐎𝐉𝐎 ")}`, m);
    }
};

handler.help = ['احزر'];
handler.tags = ['game'];
handler.command = /^(احزر|احذر|جوابي_\d+)$/i;

export default handler;