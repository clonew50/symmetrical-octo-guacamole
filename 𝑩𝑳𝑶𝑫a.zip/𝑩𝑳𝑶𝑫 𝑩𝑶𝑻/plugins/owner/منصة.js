import cp, { exec as _exec } from 'child_process';
import { promisify } from 'util';
const exec = promisify(_exec).bind(cp);

const h = async (m, { conn, text, args }) => {
    // التحقق من وجود نص بعد الأمر
    if (!text) return await m.reply('❌ يرجى كتابة الأمر الذي تريد تنفيذه في المنصة.\nمثال: `.منصة npm install archiver`');

    await m.reply('⏳ جاري التنفيذ...');

    let o;
    try {
        // تنفيذ الأمر
        o = await exec(text);
    } catch (e) {
        o = e;
    } finally {
        const { stdout, stderr } = o;
        if (stdout && stdout.trim()) await m.reply(`✅ *الناتج:*\n\n${stdout}`);
        if (stderr && stderr.trim()) await m.reply(`⚠️ *خطأ/تنبيه:*\n\n${stderr}`);
        
        // إذا لم يكن هناك ناتج أبداً
        if (!stdout && !stderr) await m.reply('✅ تم التنفيذ بنجاح (بدون مخرجات).');
    }
};

h.usage = ["منصة"];
h.category = "owner";
h.command = ['منصة', 'terminal', 'cmd']; // الأوامر التي ستكتبها
h.owner = true;

export default h;