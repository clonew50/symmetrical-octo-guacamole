/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: عجلة الحظ اليومية - نسخة مصححة
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

const handler = async (m, { conn }) => {
    try {
        if (!global.db ||!global.db.data ||!global.db.data.users) {
            return m.reply('❌ قاعدة البيانات غير جاهزة');
        }

        let user = global.db.data.users[m.sender];
        if (!user) {
            global.db.data.users[m.sender] = { exp: 0, credit: 0, health: 100, lastSpin: 0 }
            user = global.db.data.users[m.sender];
        }

        let isOwner = false
        try {
            isOwner = global.owner?.some(v => (v[0] + "@s.whatsapp.net") === m.sender) || m.sender === conn.user.jid
        } catch { isOwner = false }

        let currentTime = Date.now();
        let oneDay = 24 * 60 * 60 * 1000;

        if (!isOwner && user.lastSpin && (currentTime - user.lastSpin < oneDay)) {
            let remaining = oneDay - (currentTime - user.lastSpin)
            let hours = Math.floor(remaining / 3600000)
            let minutes = Math.floor((remaining % 3600000) / 60000)
            return conn.reply(m.chat,
`* ━ ╼╃ ⌬〔⏳〕⌬ ╄╾ ━ *
> *〔 انـتـظـر 〕: لـقـد اسـتـخـدمـت عـجـلـة الـحـظ الـيـوم!*
> *〔 الـمـتـبـقـي 〕:* ${hours} سـاعـة و ${minutes} دقـيـقـة

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m);
        }

        let rewards = [
            { type: "xp", amount: 100, emoji: "✨", message: "مبروك! ربحت 100 XP!" },
            { type: "xp", amount: 350, emoji: "🔥", message: "حظ رائع! ربحت 350 XP!" },
            { type: "xp", amount: 500, emoji: "🚀", message: "أسـطـوري! ربحت 500 XP!" },
            { type: "xp", amount: -200, emoji: "🩸", message: "سيء الحظ! خسرت 200 XP!" },
            { type: "xp", amount: -50, emoji: "😢", message: "يا للأسف! خسرت 50 XP" },
            { type: "health", amount: 200, emoji: "💖", message: "طاقة متجددة! +200 صحة!" },
            { type: "health", amount: 500, emoji: "🏥", message: "شفاء كامل! +500 صحة!" },
            { type: "health", amount: -100, emoji: "☠️", message: "انتكاسة! -100 صحة!" },
            { type: "credit", amount: 1000, emoji: "💰", message: "ذهـب! ربحت 1000 ذهب!" },
            { type: "jackpot", amount: 1500, emoji: "🎰", message: "جـاكـبـوت! ربحت 1500 XP!" }
        ];

        await conn.sendMessage(m.chat, { react: { text: '🎰', key: m.key } }).catch(()=>{})

        let result = rewards[Math.floor(Math.random() * rewards.length)];

        // تطبيق الجائزة
        if (result.type === "xp" || result.type === "jackpot") {
            user.exp = (user.exp || 0) + result.amount;
            if (user.exp < 0) user.exp = 0
        } else if (result.type === "health") {
            if (!user.health) user.health = 100
            user.health = Math.min(1000, Math.max(0, user.health + result.amount));
        } else if (result.type === "credit") {
            user.credit = (user.credit || 0) + result.amount
            if (user.credit < 0) user.credit = 0
        }

        user.lastSpin = currentTime;

        await conn.sendMessage(m.chat, { react: { text: result.emoji, key: m.key } }).catch(()=>{})

        await conn.reply(m.chat,
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ♛ 〕 نـتـيـجـة عـجـلـة الـحـظ ♣️*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *

> *${result.emoji}┊${result.message}*
> *🥷🏻┊الـنـوع:* ${result.type === 'xp'? 'خبرة' : result.type === 'health'? 'صحة' : result.type === 'credit'? 'ذهب' : 'جاكبوت'}
> *🥷🏻┊الـكـمـيـة:* ${result.amount > 0? '+' : ''}${result.amount}

*〔 📊 〕 رصـيـدك الـحـالـي:*
> *✨ XP:* ${user.exp || 0}
> *❤️ صـحـة:* ${user.health || 0}
> *💰 ذهـب:* ${user.credit || 0}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m);

    } catch (e) {
        console.error('عجلة الحظ Error:', e)
        return m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *خطأ:* ${e.message}\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    }
};

handler.help = ['عجلة_الحظ']
handler.tags = ['العاب','اقتصاد']
handler.command = /^(عجلة_الحظ|عجلة|دوامة|حظ)$/i

export default handler