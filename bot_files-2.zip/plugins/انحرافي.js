/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO DEV
 * 🤖 البوت: 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓
 * ✅ نسخة مصلحة - تشتغل 100%
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ */

let handler = async (m, { conn, text }) => {
    try {
        let who = m.sender;
        if (m.mentionedJid && m.mentionedJid[0]) who = m.mentionedJid[0];
        else if (m.quoted && m.quoted.sender) who = m.quoted.sender;

        let name = text? text : `@${who.split('@')[0]}`;
        let percent = Math.floor(Math.random() * 101);

        let status = percent <= 20? 'مـلاك بـريء والله 😇'
            : percent <= 40? 'شـويـة انـحـراف بـس مـحـتـرم 😏'
            : percent <= 60? 'نـص نـص، مـرة مـحـتـرم ومـرة لا 😈'
            : percent <= 80? 'مـنـحـرف رسـمـي 😹'
            : 'انـت الـزعـيـم مـال الانـحـراف 👑🔞';

        let caption =
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الأوامــر┊ ˼‏ 🔞˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝فـحـص الانـحـراف ↶ 🔥﹞*
> *🥷🏻┊الـشـخـص:* ${name}
> *🥷🏻┊نـسـبـة الانـحـراف:* *${percent}%*

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
> *⚜️┊الـحـالـة:* *${status}*
> *⚜️┊طـول عـمـرك مـحـتـرم وانـا عـارف*
> *⚜️┊اسـم الـبـوت:* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓* *🕸️ ───━ •﹝📌﹞• ━───*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;

        // بدون أزرار باش ما يطيحش - نسخة خفيفة
        await conn.sendMessage(m.chat, { text: caption, mentions: conn.parseMention(caption) }, { quoted: m });

    } catch (e) {
        console.log(e);
        // فولباك حتى لو طاح
        let p = Math.floor(Math.random() * 100);
        m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *🥷🏻┊نـسـبـة انـحـرافـك هـي ${p}%*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);
    }
}

handler.help = ['انحرافي'];
handler.tags = ['fun'];
handler.command = /^(انحرافي|انحراف)$/i;

export default handler;