import fetch from "node-fetch";
import { Sticker } from "wa-sticker-formatter";

const PACK = `╮┄┄┄┄┄┄┄┄┄┄┄┄╭
𝙽𝚊𝚖𝚎 : ⚡𝐆𝐎𝐉𝐎 𝑩𝑶𝑻🪄
⏱ ࣪𓏲ִ𝚃𝙷𝙴 𝚂𝚃𝙸𝙲𝙺𝙴𝚁 ⊹₊˚𖥔⸼
𝙾𝚠𝚗𝚎𝚛 : .⤹𝑴𝑨𝑬𝑺𝑻𝑬𝑶 ⚡𝐆𝐎𝐉𝐎⤾.
╯┄┄┄┄┄┄┄┄┄┄┄┄╰
⏱`;

const AUTHOR = `⏱
╮┄┄┄┄┄┄┄┄┄┄┄┄╭
꯭✿꯭᪲୭𓍢ִ  𝙱𝚈 →  🗻⸽⃕❬ ⚡𝐆𝐎𝐉𝐎 𝑩𝑶𝑻 ❭ - 🩸🍁⃨፝⃕✰
╯┄┄┄┄┄┄┄┄┄┄┄┄╰`;

function errorTemplate(reason) {
  return `╭─〔 ⚠️ خطأ 〕─╮\n│ ${reason}\n╰───────────────╯`;
}

let handler = async (m, { conn }) => {
  try {
    const sender = m.sender;
    let target = m.mentionedJid && m.mentionedJid[0];
    if (!target && m.quoted?.sender) target = m.quoted.sender;
    if (!target) target = m.sender;

    const res = await fetch("https://api.waifu.pics/sfw/kiss");
    const json = await res.json();
    const imageUrl = json.url;

  
    const senderNumber = sender.split("@")[0];
    const vCard = `BEGIN:VCARD
VERSION:3.0
N:anya;bot;;;
FN:⚡⸽⃕❬ ⚡𝐆𝐎𝐉𝐎 𝑩𝑶𝑻 ❭ - 🩸🍁⃨፝⃕✰
item1.TEL;waid=${senderNumber}:${senderNumber}
item1.X-ABLabel:Ponsel
END:VCARD`;

    const fkontak = {
      key: { participant: "0@s.whatsapp.net", remoteJid: "status@broadcast", id: "Halo" },
      message: { contactMessage: { displayName: "⚡⸽⃕❬ ⚡𝐆𝐎𝐉𝐎 𝑩𝑶𝑻  ❭ - 🩸🍁⃨፝⃕✰", vcard: vCard } },
      participant: "0@s.whatsapp.net"
    };

    const sticker = new Sticker(imageUrl, { type: 'full', pack: PACK, author: AUTHOR, quality: 70 });
    const buffer = await sticker.toBuffer();


    const groupPic = await conn.profilePictureUrl(m.chat, "image").catch(() => "https://telegra.ph/file/bc2b6dbf2eb90e36f0b4b.jpg");
    const forwardInfo = {
      contextInfo: {
        forwardingScore: 9999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363411035938060@newsletter',
          serverMessageId: 777,
          newsletterName: '◜⚡𝐆𝐎𝐉𝐎𝒔┊🩸┊𝐂𝐇𝐀𝐍𝐍𝐄𝐋◞'
        },
        externalAdReply: {
          title: "BY : .⤹𝑴𝑨𝑬𝑹𝑺𝑻𝑹𝑶 ⚡𝐆𝐎𝐉𝐎⤾.",
          body: "◜⚡𝐆𝐎𝐉𝐎 𝐁𝐎𝐓🪄",
          thumbnailUrl: groupPic,
          mediaType: 1,
          renderLargerThumbnail: true,
          showAdAttribution: false
        }
      }
    };

    await conn.sendMessage(m.chat, { sticker: buffer, ...forwardInfo }, { quoted: fkontak });

  } catch (e) {
    console.error("ERROR kiss2:", e);
    m.reply("⚠️ حصل خطأ أثناء إنشاء الملصق.");
  }
};

handler.command = /^(kiss|kissnew|kissx)$/i;
export default handler;