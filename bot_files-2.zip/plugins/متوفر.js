const handler = async function(m, { conn, text }) {
  try {
    const groupId = m.chat;
    const name = text?.trim();

    if (!name) {
      const usage = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 فـحـص تـوفـر الـلـقـب ┊ ˼‏ 🔍˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *🥷🏻┊.متوفر <اللقب>*
> *🥷🏻┊مثال:.متوفر زعيم*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`
      throw usage
    }

    const users = global.db?.data?.users || {};

    let taken = false;
    let owner = '';
    for (let key in users) {
      const user = users[key];
      if (user.groups?.[groupId]?.name?.toLowerCase() === name.toLowerCase()) {
        taken = true;
        owner = key;
        break;
      }
    }

    if (taken) {
      await conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 نـتـيـجـة الـفـحـص ┊ ˼‏ ❌˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *🏷️ اللقب:* ${name}
> *❌ الحالة:* غير متاح
> *👤 محجوز من:* @${owner.split('@')[0]}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`, m, { mentions: [owner] });
    } else {
      await conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 نـتـيـجـة الـفـحـص ┊ ˼‏ ✅˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *🏷️ اللقب:* ${name}
> *✅ الحالة:* متاح للحجز
> *🥷🏻 احجزه الان بـ:*.حجز_لقب ${name}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`, m);
    }

  } catch (err) {
    await conn.reply(m.chat, err, m);
  }
};

handler.admin = false;
handler.group = true;
handler.command = /^(متوفر|available)$/i;
handler.tags = ['مجموعة'];
handler.help = ['متوفر <اللقب>'];

export default handler;