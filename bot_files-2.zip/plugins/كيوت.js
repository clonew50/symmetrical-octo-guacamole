/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: صور كيوت - نيكو
 * 📢 القناة: https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

import fetch from 'node-fetch'
import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

let handler = async (m, { conn, command, usedPrefix }) => {
try {
await m.react('🐾')

let ne = await (await fetch('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/random/anime/neko.txt')).text()
let nek = ne.split('\n').filter(v => v.startsWith('http'))
let neko = nek[Math.floor(Math.random() * nek.length)]

let media = await prepareWAMessageMedia({ image: { url: neko } }, { upload: conn.waUploadToServer })

let caption =
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🐾 〕 N𝐲𝐚𝐰𝐰~ كـيـوت 💗*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
  message: {
   messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
   interactiveMessage: proto.Message.InteractiveMessage.create({
    body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
    footer: proto.Message.InteractiveMessage.Footer.create({ text: "♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | نياوو~" }),
    header: proto.Message.InteractiveMessage.Header.create({ 
        title: "🐱 كـيـوت - Neko",
        hasMediaAttachment: true, 
        imageMessage: media.imageMessage 
    }),
    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
     buttons: [
       {
         name: "quick_reply",
         buttonParamsJson: JSON.stringify({
           display_text: "🔄 الـتـالـي 🆕",
           id: `${usedPrefix}${command}`
         })
       },
       {
         name: "cta_url",
         buttonParamsJson: JSON.stringify({
           display_text: "📢 قـنـاتـنـا الـرسـمـيـة",
           url: "https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r",
           merchant_url: "https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r"
         })
       }
     ]
    })
   })
  }
 }
}, { quoted: m })

await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
await m.react('✅')

} catch (e) {
 console.error(e)
 m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *فـشـل الـتـحـمـيـل: ${e.message}*`)
}
}

handler.command = /^(كيوت|neko)$/i
handler.tags = ['انمي']
handler.help = ['كيوت']

export default handler