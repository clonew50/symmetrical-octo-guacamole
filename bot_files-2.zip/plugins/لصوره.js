// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الـمـلـصـقـات┊ ˼‏ 🖼️˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *𝐆𝐎𝐉𝐎* ──¤﹝تـحـويـل الـمـلـصـق لـصـورة ↶﹞*
// > *〔 🖼️ 〕 الاسـتـخـدام:* .لصورة + رد على ملصق
// *🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
// *🤖┊اسـم الـبـوت:* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*
// *👑┊الـمـطـور:* *𝐘𝐎𝐍𝐎 𝐃𝐄𝐕*
// *📞┊الـرقـم:* *212674375708* *🐣 ───━ •﹝📌﹞• ━───*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

import { webp2png } from '../lib/webp2mp4.js'

let handler = async (m, { conn, usedPrefix, command }) => {
    const usageMessage = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـمـلـصـقـات┊ ˼‏ 🖼️˹ ↶〕* *𝐆𝐎𝐉𝐎*

*📝┊طـريـقـة الاسـتـخـدام:*
*〔 1 〕* أرسـل مـلـصـق 🌀
*〔 2 〕* رد عـلـيـه بـالأمـر: *${usedPrefix + command}*

*📌┊مـثـال:*
أرسـل ملصق ➝ ثم اكتب: *${usedPrefix}لصورة*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`

    const q = m.quoted || m
    const mime = q?.mediaType || ''
    const isAnimated = q?.isAnimated || /animated/.test(JSON.stringify(q))

    if (!/sticker/.test(mime)) {
        return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕يـجـب أن تـرد عـلـى *مـلـصـق* لـتـحـويـلـه*\n\n${usageMessage}`)
    }

    const media = await q.download()
    let out = await webp2png(media).catch(_ => null) || Buffer.alloc(0)

    let extraNote = isAnimated 
        ? "\n\n> *〔 ⚠️ 〕الـمـلـصـق كـان *مـتـحـرك*، تـم تـحـويـلـه لـصـورة ثـابـتـة*"
        : ""

    await conn.sendFile(m.chat, out, 'tokita.png', `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ✅ 〕تـم تـحـويـل الـمـلـصـق إلـى صـورة بـنـجـاح!*${extraNote}\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`, m)
}

handler.help = ['لصورة']
handler.tags = ['sticker']
handler.command = ['toimg', 'img', 'jpg', 'لصوره', 'لصورة']

export default handler