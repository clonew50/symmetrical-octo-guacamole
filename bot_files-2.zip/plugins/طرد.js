let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    let groupMetadata = await conn.groupMetadata(m.chat)
    let participants = groupMetadata.participants

    let botJid = conn.user.jid.split(':')[0] + '@s.whatsapp.net'
    let bot = participants.find(p => p.id === botJid || p.id === conn.user.jid || p.jid === conn.user.jid)
    let isBotAdmin = bot && (bot.admin === 'admin' || bot.admin === 'superadmin')

    let sender = participants.find(p => p.id === m.sender || p.jid === m.sender)
    let isAdmin = sender && (sender.admin === 'admin' || sender.admin === 'superadmin')

    if (!isBotAdmin) return conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *❌ البوت ليس مشرف*\n> *🥷🏻┊عاود دير إزالة مشرف ورجعو*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })
    if (!isAdmin) return conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *❌ خاصك تكون آدمن*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })

    let who
    if (m.mentionedJid && m.mentionedJid[0]) who = m.mentionedJid[0]
    else if (m.quoted) who = m.quoted.sender
    else if (text) {
      let num = text.replace(/[^0-9]/g, '')
      if (!num) throw 'رقم غالط'
      who = num + '@s.whatsapp.net'
    } else {
      return conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 طـريـقـة الـطـرد┊ ˼‏ 🚷˹ ↶〕*\n\n*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*\n> *🥷🏻┊${usedPrefix + command} @منشن*\n> *🥷🏻┊${usedPrefix + command} رد على رسالة*\n> *🥷🏻┊${usedPrefix + command} 2126xxxx*\n\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })
    }

    if (who.includes(conn.user.jid) || who === botJid) return conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *😅 مانقدرش نطرد راسي*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })
    if (who === m.sender) return conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *❌ ماتقدرش تطرد راسك*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })

    let target = participants.find(p => p.id === who || p.jid === who)
    if (!target) target = participants.find(p => who.includes(p.id.split('@')[0]))

    if (!target) return conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *❌ الشخص ماموجودش فالجروب*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })
    if (target.admin === 'superadmin') return conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *❌ ماتقدرش تطرد مالك الجروب*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })

    await conn.groupParticipantsUpdate(m.chat, [target.id], 'remove')
    await conn.sendMessage(m.chat, { react: { text: '🚷', key: m.key } })

    return conn.sendMessage(m.chat, {
      text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 تـم الـطـرد┊ ˼‏ 🚷˹ ↶〕*

*🪖 ──¤﹝بـيـانـات الـعـمـلـيـة ↶ 🕸️﹞*
> *🥷🏻┊الـشـخـص:* @${target.id.split('@')[0]}
> *🥷🏻┊الـحـالـة:* 〘 تـم طـرده 〙
> *🥷🏻┊بـواسـطـة:* @${m.sender.split('@')[0]}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`,
      mentions: [target.id, m.sender]
    }, { quoted: m })

  } catch (e) {
    console.error(e)
    conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *❌ فشل: ${e.message || e}*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })
  }
}

handler.help = ['طرد']
handler.tags = ['group']
handler.command = ['طرد', 'kick', 'اطرد', 'ازالة']
handler.group = true
export default handler