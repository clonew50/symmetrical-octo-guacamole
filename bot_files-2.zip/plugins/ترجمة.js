/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO DEV
 * 🤖 البوت: 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | بزخرفتك المعتمدة
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ */

import axios from 'axios';

const langMap = {
    'العربية':'ar','عربي':'ar','ar':'ar','arabic':'ar',
    'الانجليزية':'en','الانجليزيه':'en','انجليزي':'en','en':'en','english':'en',
    'الفرنسية':'fr','فرنسي':'fr','fr':'fr',
    'التركية':'tr','تركي':'tr','tr':'tr',
    'اليابانية':'ja','ياباني':'ja','ja':'ja',
    'الكورية':'ko','كوري':'ko','ko':'ko',
    'الصينية':'zh','صيني':'zh','zh':'zh',
    'الروسية':'ru','روسي':'ru','ru':'ru',
    'الاسبانية':'es','اسباني':'es','es':'es',
    'الالمانية':'de','الماني':'de','de':'de',
};

async function translateText(text, to, from='auto'){
    try{
        let url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${from}&tl=${to}&dt=t&q=${encodeURIComponent(text)}`;
        let res = await axios.get(url);
        return res.data[0].map(v=>v[0]).join('');
    }catch{ return null; }
}

let handler = async (m, { conn, usedPrefix, command, text }) => {
    let originalText = '';
    let from = 'auto', to = 'ar';

    if (m.quoted?.text) originalText = m.quoted.text;

    if (text) {
        let match = text.match(/^(?:([\u0600-\u06FF\w]+)\s*=\s*([\u0600-\u06FF\w]+))\s*(.+)?$/i);
        if (match) {
            let fromRaw = match[1].trim().toLowerCase();
            let toRaw = match[2].trim().toLowerCase();
            from = langMap[fromRaw] || 'auto';
            to = langMap[toRaw] || 'en';
            if (match[3]) originalText = match[3].trim();
        } else {
            let parts = text.split(' ');
            if (langMap[parts[0].toLowerCase()]) {
                to = langMap[parts[0].toLowerCase()];
                originalText = parts.slice(1).join(' ') || originalText;
            } else {
                originalText = text || originalText;
            }
        }
    }

    if (!originalText) {
        return await conn.sendMessage(m.chat, {
            text:
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الأوامــر┊ ˼‏ 🌐˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝تـرجـمـة فـوريـة↶ 🌐﹞*
> *🥷🏻┊الـتـنـبـيـه:* يـرجـى كـتـابـة الـنـص أو الـرد عـلـى رسـالـة
> *🥷🏻┊الـمـثـال:* \`.ترجمة العربية=الانجليزيه كيف حالك\`
> *🥷🏻┊الـمـثـال:* \`.ترجمة ar=en مرحبا\`

*🪖 ──¤﹝طـريـقـة الاسـتـخـدام↶﹞*
> *⚜️┊\`رد +.ترجمة انجليزي\` ➜ يترجم الرد*
> *⚜️┊\`.ترجمة العربية=الفرنسية نص\` ➜ مباشر*
> *⚜️┊\`.ترجمة اليابانية=العربية こんにちは\`*

*🕸️ ───━ •﹝📌﹞• ━───*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`,
            footer: `𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕`,
            buttons: [
                { buttonId: `${usedPrefix}ترجمة العربية=الانجليزية`, buttonText: { displayText: '🇸🇦 ➜ 🇺🇸 عربي ➜ انجليزي' }, type: 1 },
                { buttonId: `${usedPrefix}ترجمة الانجليزية=العربية`, buttonText: { displayText: '🇺🇸 ➜ 🇸🇦 انجليزي ➜ عربي' }, type: 1 },
            ],
            headerType: 1
        }, { quoted: m });
    }

    await conn.sendMessage(m.chat, { react: { text: '🌐', key: m.key } });
    let translated = await translateText(originalText, to, from);

    if (!translated) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *🥷🏻┊الـتـنـبـيـه:* فـشـلـت الـتـرجـمـة، جـرب لـغـة أخـرى\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);

    let result =
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـنـتـيـجـة┊ ˼‏ 🌐˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝تـمـت الـتـرجـمـة↶ ✅﹞*

> *🥷🏻┊الـنـص الأصـلـي:*
> \`${originalText.slice(0,800)}\`

> *🥷🏻┊الـتـرجـمـة:*
> *${translated}*

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
> *⚜️┊مـن:* \`${from}\` ➜ *إلـى:* \`${to}\`
> *⚜️┊اسـم الـبـوت:* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓* *🕸️ ───━ •﹝📌﹞• ━───*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;

    await conn.sendMessage(m.chat, {
        text: result,
        footer: `اضغط للترجمة العكسية`,
        buttons: [
            { buttonId: `${usedPrefix}ترجمة ${to}=${from} ${translated.slice(0,100)}`, buttonText: { displayText: '🔄 ترجمة عكسية' }, type: 1 },
            { buttonId: `${usedPrefix}ترجمة العربية=الفرنسية ${originalText.slice(0,50)}`, buttonText: { displayText: '🇫🇷 إلى الفرنسية' }, type: 1 },
        ],
        headerType: 1
    }, { quoted: m });
};

handler.help = ['ترجمة'];
handler.tags = ['tools'];
handler.command = /^(ترجمة|translate|tr)$/i;
export default handler;