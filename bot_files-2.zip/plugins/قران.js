/* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO DEV
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | القرآن الكريم 114 سورة
 * 📦 الوظيفة: بحث وتشغيل وتنزيل سور القرآن بصوت
 * 🖼️ الصورة: https://files.catbox.moe/ccygxb.jpeg
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 QURAN PRO 〕⌬ ╄╾ ━
 */

import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const quranSurahs = [
{ id: 1, name: "الفاتحة" },{ id: 2, name: "البقرة" },{ id: 3, name: "آل عمران" },{ id: 4, name: "النساء" },{ id: 5, name: "المائدة" },{ id: 6, name: "الأنعام" },{ id: 7, name: "الأعراف" },{ id: 8, name: "الأنفال" },{ id: 9, name: "التوبة" },{ id: 10, name: "يونس" },{ id: 11, name: "هود" },{ id: 12, name: "يوسف" },{ id: 13, name: "الرعد" },{ id: 14, name: "إبراهيم" },{ id: 15, name: "الحجر" },{ id: 16, name: "النحل" },{ id: 17, name: "الإسراء" },{ id: 18, name: "الكهف" },{ id: 19, name: "مريم" },{ id: 20, name: "طه" },{ id: 21, name: "الأنبياء" },{ id: 22, name: "الحج" },{ id: 23, name: "المؤمنون" },{ id: 24, name: "النور" },{ id: 25, name: "الفرقان" },{ id: 26, name: "الشعراء" },{ id: 27, name: "النمل" },{ id: 28, name: "القصص" },{ id: 29, name: "العنكبوت" },{ id: 30, name: "الروم" },{ id: 31, name: "لقمان" },{ id: 32, name: "السجدة" },{ id: 33, name: "الأحزاب" },{ id: 34, name: "سبأ" },{ id: 35, name: "فاطر" },{ id: 36, name: "يس" },{ id: 37, name: "الصافات" },{ id: 38, name: "ص" },{ id: 39, name: "الزمر" },{ id: 40, name: "غافر" },{ id: 41, name: "فصلت" },{ id: 42, name: "الشورى" },{ id: 43, name: "الزخرف" },{ id: 44, name: "الدخان" },{ id: 45, name: "الجاثية" },{ id: 46, name: "الأحقاف" },{ id: 47, name: "محمد" },{ id: 48, name: "الفتح" },{ id: 49, name: "الحجرات" },{ id: 50, name: "ق" },{ id: 51, name: "الذاريات" },{ id: 52, name: "الطور" },{ id: 53, name: "النجم" },{ id: 54, name: "القمر" },{ id: 55, name: "الرحمن" },{ id: 56, name: "الواقعة" },{ id: 57, name: "الحديد" },{ id: 58, name: "المجادلة" },{ id: 59, name: "الحشر" },{ id: 60, name: "الممتحنة" },{ id: 61, name: "الصف" },{ id: 62, name: "الجمعة" },{ id: 63, name: "المنافقون" },{ id: 64, name: "التغابن" },{ id: 65, name: "الطلاق" },{ id: 66, name: "التحريم" },{ id: 67, name: "الملك" },{ id: 68, name: "القلم" },{ id: 69, name: "الحاقة" },{ id: 70, name: "المعارج" },{ id: 71, name: "نوح" },{ id: 72, name: "الجن" },{ id: 73, name: "المزمل" },{ id: 74, name: "المدثر" },{ id: 75, name: "القيامة" },{ id: 76, name: "الإنسان" },{ id: 77, name: "المرسلات" },{ id: 78, name: "النبأ" },{ id: 79, name: "النازعات" },{ id: 80, name: "عبس" },{ id: 81, name: "التكوير" },{ id: 82, name: "الانفطار" },{ id: 83, name: "المطففين" },{ id: 84, name: "الانشقاق" },{ id: 85, name: "البروج" },{ id: 86, name: "الطارق" },{ id: 87, name: "الأعلى" },{ id: 88, name: "الغاشية" },{ id: 89, name: "الفجر" },{ id: 90, name: "البلد" },{ id: 91, name: "الشمس" },{ id: 92, name: "الليل" },{ id: 93, name: "الضحى" },{ id: 94, name: "الشرح" },{ id: 95, name: "التين" },{ id: 96, name: "العلق" },{ id: 97, name: "القدر" },{ id: 98, name: "البينة" },{ id: 99, name: "الزلزلة" },{ id: 100, name: "العاديات" },{ id: 101, name: "القارعة" },{ id: 102, name: "التكاثر" },{ id: 103, name: "العصر" },{ id: 104, name: "الهمزة" },{ id: 105, name: "الفيل" },{ id: 106, name: "قريش" },{ id: 107, name: "الماعون" },{ id: 108, name: "الكوثر" },{ id: 109, name: "الكافرون" },{ id: 110, name: "النصر" },{ id: 111, name: "المسد" },{ id: 112, name: "الإخلاص" },{ id: 113, name: "الفلق" },{ id: 114, name: "الناس" }
];

let handler = async (m, { conn, usedPrefix, command, text }) => {
    const imageUrl = 'https://files.catbox.moe/ccygxb.jpeg';
    const getMedia = async () => await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer });

    // === 2 - عند اختيار سورة : يرسل أزرار تشغيل جديدة ===
    if (text && text.startsWith('quran_surah|')) {
        let surahId = parseInt(text.split('|')[1]);
        let surah = quranSurahs.find(s => s.id === surahId);
        if (!surah) return;

        let paddedId = String(surahId).padStart(3, '0');
        // سيرفر العفاسي - جودة عالية وثابت
        let audioUrl = `https://server8.mp3quran.net/afs/${paddedId}.mp3`;

        try {
            const media = await getMedia();
            let bodyText = `* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *\n\n> *📖┊السورة:* ${surah.name}\n> *🔢┊رقمها:* ${surah.id}\n> *🎙️┊القارئ:* مشاري العفاسي\n> *⏳┊جاري تحضير الصوت...*\n\n> *اختر طريقة الاستماع بالأسفل* 👇\n\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 QURAN 〕⌬ ╄╾ ━ *`;

            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: { message: {
                    interactiveMessage: {
                        body: { text: bodyText },
                        footer: { text: `『 سورة ${surah.name} | 𝐆𝐎𝐉𝐎 』` },
                        header: { hasMediaAttachment: true,...media },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: `▶️ تشغيل سورة ${surah.name}`, id: `${usedPrefix}${command} play|${surahId}` }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: `📥 تحميل MP3`, id: `${usedPrefix}${command} download|${surahId}` }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔙 رجوع لكل السور", id: `${usedPrefix}${command}` }) },
                                { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "📖 تفسير السورة", url: `https://quran.com/${surahId}`, merchant_url: `https://quran.com/${surahId}` }) }
                            ]
                        }
                    }
                }}
            }, { userJid: m.chat, quoted: m });
            await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        } catch(e) { console.log(e) }
        return;
    }

    // === 3 - تشغيل / تحميل ===
    if (text && (text.startsWith('play|') || text.startsWith('download|'))) {
        let [action, id] = text.split('|');
        let surahId = parseInt(id);
        let surah = quranSurahs.find(s => s.id === surahId);
        let paddedId = String(surahId).padStart(3, '0');
        let audioUrl = `https://server8.mp3quran.net/afs/${paddedId}.mp3`;

        await conn.sendMessage(m.chat, { react: { text: '🎧', key: m.key } });

        if (action === 'play') {
            await conn.sendMessage(m.chat, { audio: { url: audioUrl }, mimetype: 'audio/mpeg', ptt: false, fileName: `${surah.name}.mp3` }, { quoted: m });
            return conn.reply(m.chat, `> *✅ تم تشغيل سورة ${surah.name}*\n> للتحميل اكتب \`${usedPrefix}قران تحميل|${surahId}\``, m);
        }
        if (action === 'download') {
            await conn.sendMessage(m.chat, { document: { url: audioUrl }, mimetype: 'audio/mpeg', fileName: `Quran - ${surah.name} - Afasy.mp3`, caption: `*📖 سورة ${surah.name}*\n*🎙️ العفاسي*\n*🤖 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*` }, { quoted: m });
            return;
        }
    }

    // === بحث بالاسم ===
    if (text &&!text.includes('|') && isNaN(text) && text.length > 2) {
        let search = quranSurahs.filter(s => s.name.includes(text.trim()));
        if (search.length === 0) return m.reply(`*لم أجد سورة باسم "${text}"*`);
        // إذا وجد واحدة شغلها مباشرة
        if (search.length === 1) {
            text = `quran_surah|${search[0].id}`;
            // اعادة توجيه لنفس الهاندلر
            return handler(m, { conn, usedPrefix, command, text });
        }
    }

    // === 1 - القائمة الرئيسية 114 سورة مقسمة ===
    try {
        await conn.sendMessage(m.chat, { react: { text: '📖', key: m.key } });
        const media = await getMedia();

        // تقسيم السور ل 4 قوائم باش ما يفوتش الحد
        let sections = [
            { title: "📖 من الفاتحة إلى الإسراء (1-17)", rows: quranSurahs.slice(0, 17).map(s => ({ header: `سورة ${s.name}`, title: `${s.id} - ${s.name}`, description: `الاستماع لسورة ${s.name}`, id: `${usedPrefix}${command} quran_surah|${s.id}` })) },
            { title: "📖 من الكهف إلى يس (18-36)", rows: quranSurahs.slice(17, 36).map(s => ({ header: `سورة ${s.name}`, title: `${s.id} - ${s.name}`, description: `الاستماع لسورة ${s.name}`, id: `${usedPrefix}${command} quran_surah|${s.id}` })) },
            { title: "📖 من الصافات إلى الذاريات (37-51)", rows: quranSurahs.slice(36, 51).map(s => ({ header: `سورة ${s.name}`, title: `${s.id} - ${s.name}`, description: `الاستماع لسورة ${s.name}`, id: `${usedPrefix}${command} quran_surah|${s.id}` })) },
            { title: "📖 من الطور إلى الناس (52-114)", rows: quranSurahs.slice(51, 114).map(s => ({ header: `سورة ${s.name}`, title: `${s.id} - ${s.name}`, description: `الاستماع لسورة ${s.name}`, id: `${usedPrefix}${command} quran_surah|${s.id}` })) }
        ];

        let bodyText = `* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *\n*〔 ♛ 𝐆𝐎𝐉𝐎 〕 ↜ القرآن الكريم كاملاً ↝* 📖\n\n*------------------------------------------------*\n> *\`↯˹📖˼↯\` ↜ 114 سورة بصوت العفاسي ↝*\n> *“ألا بذكر الله تطمئن القلوب”*\n\n> *👑┊طريقة الاستخدام:*\n> *1-* اختر السورة من القائمة بالأسفل\n> *2-* سيفتح لك أزرار تشغيل وتحميل جديدة شغالة\n> *3-* أو اكتب مباشرة: \`.قران البقرة\`\n\n> *💎┊جودة عالية MP3 - تحميل مباشر*\n*------------------------------------------------*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 QURAN 114 〕⌬ ╄╾ ━*`.trim();

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: { message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: {
                    body: { text: bodyText },
                    footer: { text: '『 📖 القرآن الكريم 114 سورة | 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 』' },
                    header: { hasMediaAttachment: true,...media },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: '📖 اختر سورة (114 سورة)',
                                    sections: sections
                                }),
                            },
                            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🎧 سورة الكهف", id: `${usedPrefix}${command} quran_surah|18` }) },
                            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💎 سورة يس", id: `${usedPrefix}${command} quran_surah|36` }) },
                            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👑 سورة الملك", id: `${usedPrefix}${command} quran_surah|67` }) }
                        ]
                    }
                }
            }}
        }, { userJid: m.chat, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (e) {
        console.error('Quran Error:', e);
        await conn.sendMessage(m.chat, { image: { url: imageUrl }, caption: `*📖 القرآن الكريم*\n\n> اكتب:\n> \`.قران البقرة\` أو \`.قران 2\`\n\n> للتشغيل السريع` }, { quoted: m });
    }
};

handler.help = ['قران', 'القران'];
handler.tags = ['islam', 'quran'];
handler.command = /^(قران|القران|quran|القران_الكريم)$/i;

export default handler;