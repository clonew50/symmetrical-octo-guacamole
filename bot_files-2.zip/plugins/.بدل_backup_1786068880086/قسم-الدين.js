import fs from 'fs';
import path from 'path';

function getRandomMediaUrl() {
  try {
    const filePath = path.join(process.cwd(), 'media-links.txt');
    const data = fs.readFileSync(filePath, 'utf-8');
    const links = data.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (links.length === 0) return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
    return links[Math.floor(Math.random() * links.length)];
  } catch (e) {
    console.error('تعذر قراءة media-links.txt:', e.message);
    return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
  }
}

const handler = async (m, { conn }) => {

    const imageUrl = getRandomMediaUrl();

    const messageText = `
*『 مرحبا بك يا  ⌊ ${m.pushName} ⌉ في جــيـ بـــ⚡_KAISER_ـــوت 』*

*⌝ قسم الدين ┋🕋⌞ ⇊*
*⎔ ⋅ ───━ •﹝🩸﹞• ━─── ⋅ ⎔*
*🕋┊⇇『اذكار-الصباح』*
*🕋┊⇇『اذكار-المساء』*
*🕋┊⇇『اذكار-النوم』*
*🕋┊⇇『دعاء』*
*🕋┊⇇『فيديو-قرآن』*
*🕋┊⇇『مواقيت_الصلاة』*
*🕋┊⇇『خطبة』*
*🕋┊⇇『دعاء-رمضان』*
*🕋┊⇇『الله』*
*🕋┊⇇『حديث』*
*⎔ ⋅ ───━ •﹝🩸﹞• ━─── ⋅ ⎔*

> جــيـ❣ـہ بـــ⚡_KAISER_ت 💗💛
    `.trim();

    await conn.sendMessage(m.chat, { text: "*_جاري إرسال القسم....... 💗📿_*" }, { quoted: m });

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: messageText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '🕋', key: m.key } });
};

handler.command = /^قسم-الدين$/i;
handler.tags = ["جــــيـــو"];
handler.help = ["قسم-الدين"];

export default handler;