// =================================================================
// • الحقوق : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 - مطور 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓
// • الرقم : 212674375708
// • البوت : 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | NIKOLAS BOT
// • القناة : https://whatsapp.com/channel/0029Vb7On131NCrU8Di4Ev1z
// • الوصف : تحميل فيديو فيسبوك بزخرفة عربية
// =================================================================
import axios from 'axios';
import cheerio from 'cheerio';

const DECO_TOP = `* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *`
const DECO_BOTTOM = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`

async function facebookDownload(url) {
    try {
        const form = new URLSearchParams();
        form.append("q", url);
        form.append("vt", "home");

        const response = await axios.post('https://yt5s.io/api/ajaxSearch', form, {
            headers: {
                "Accept": "application/json",
                "X-Requested-With": "XMLHttpRequest",
                "Content-Type": "application/x-www-form-urlencoded",
            },
        });

        if (response.data.status === "ok") {
            const $ = cheerio.load(response.data.data);
            const videoQualities = [];
            $('table tbody tr').each((index, element) => {
                const quality = $(element).find('.video-quality').text().trim();
                const downloadLink = $(element).find('a.download-link-fb').attr("href");
                if (quality && downloadLink) {
                    videoQualities.push({ quality, downloadLink });
                }
            });

            // أولاً نبحث عن فيديو HD، ثم SD
            const hdVideo = videoQualities.find(v => v.quality.toLowerCase().includes('hd'));
            const sdVideo = videoQualities.find(v => v.quality.toLowerCase().includes('sd'));
            const videoUrl = hdVideo ? hdVideo.downloadLink : sdVideo ? sdVideo.downloadLink : null;

            if (!videoUrl) throw new Error("لا يوجد رابط تحميل للفيديو.");
            return { videoUrl };
        } else {
            throw new Error("فشل تحميل الفيديو: " + response.data.message);
        }
    } catch (error) {
        throw error;
    }
}

const facebookHandler = async (m, { conn, text }) => {
    try {
        if (!text) {
            return await conn.sendMessage(m.chat, { 
                text: `${DECO_TOP}\n\n> *📥 تحميل فيسبوك*\n>\n> *أرسل الرابط هكذا:*\n> \`.فيسبوك https://fb.watch/xxx\`\n\n${DECO_BOTTOM}` 
            }, { quoted: m });
        }

        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

        const result = await facebookDownload(text);

        if (result.videoUrl) {
            await conn.sendMessage(m.chat, { 
                video: { url: result.videoUrl }, 
                mimetype: 'video/mp4',
                caption: `${DECO_TOP}\n\n> *✅ تم التحميل بنجاح*\n> *🎬 فيسبوك - 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*\n\n${DECO_BOTTOM}`
            }, { quoted: m });
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
        } else {
            throw "فشل تحميل الفيديو.";
        }
    } catch (error) {
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        await conn.sendMessage(m.chat, { 
            text: `${DECO_TOP}\n\n> *❌ خطأ:*\n> ${error.message || error}\n\n${DECO_BOTTOM}` 
        }, { quoted: m });
    }
};

facebookHandler.help = ['فيسبوك <رابط>']
facebookHandler.command = ['فيسبوك', 'فيس', 'الفيسبوك']
facebookHandler.tags = ['downloader']

export default facebookHandler;