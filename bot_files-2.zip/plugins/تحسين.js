// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الـتـعـديـل┊ ˼‏ 🖼️˹ ↶〕* *𝐆𝐎𝐉𝐎* ──¤﹝نـظـام تـحـسـيـن الـصـور ↶﹞*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

import Jimp from 'jimp';

const colorOptions = [
  { name: 'أحمر', color: '#FF0000' },
  { name: 'أخضر', color: '#00FF00' },
  { name: 'أزرق', color: '#0000FF' },
  { name: 'أصفر', color: '#FFFF00' },
  { name: 'برتقالي', color: '#FFA500' },
  { name: 'بنفسجي', color: '#800080' },
  { name: 'رمادي', color: '#808080' },
];

const operations = [
  { name: 'تغيير الحجم', operation: (image) => image.resize(800, Jimp.AUTO) },
  { name: 'زيادة الحدة', operation: (image) => image.convolute([[0,-1,0],[-1,5,-1],[0,-1,0]]) },
  { name: 'تحسين السطوع', operation: (image) => image.brightness(0.1) },
  { name: 'تحسين التباين', operation: (image) => image.contrast(0.3) },
  { name: 'أبيض وأسود', operation: (image) => image.grayscale() },
  { name: 'تنعيم', operation: (image) => image.blur(5) },
  { name: 'تدوير', operation: (image) => image.rotate(90) },
  { name: 'تغيير الألوان', operation: null },
  { name: 'شفافية', operation: (image) => image.opacity(0.8) },
  { name: 'إضافة نص', operation: null },
  { name: 'قص الصورة', operation: null },
  { name: 'إطار مشوش', operation: null },
  { name: 'بورتريه', operation: null },
  { name: 'HD', operation: (image) => image.resize(Jimp.AUTO, 1080) },
  { name: 'ضبابية', operation: (image) => image.blur(10) },
  { name: 'كرتوني', operation: (image) => image.convolute([[-1,-1,-1],[-1,9,-1],[-1,-1,-1]]) },
  { name: 'ظل', operation: (image) => { const s=image.clone().opacity(0.5).blur(5); return image.composite(s,10,10) } },
  { name: 'زيتي', operation: (image) => image.color([{apply:'mix',params:['#8B4513',100]}]) },
  { name: 'HDR', operation: (image) => image.convolute([[0,-1,0],[-1,5,-1],[0,-1,0]]).contrast(0.3).brightness(0.1) },
  { name: 'فيلم', operation: (image) => image.color([{apply:'mix',params:['#000000',50]}]) },
  { name: 'تشويش', operation: (image) => image.blur(3) },
  { name: 'تعتيم', operation: (image) => image.opacity(0.5) },
];

const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    let q = m.quoted? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || "";
    if (!mime ||!mime.startsWith("image")) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 🖼️ 〕رد عـلـى صـورة*\n> *اسـتـخـدم:* *${usedPrefix + command} <رقم>*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m);

    let img = await q.download?.();
    if (!img) return conn.reply(m.chat, `*〔 ❌ 〕مـا قـدرتـش نـحـمـل الـصـورة*`, m);

    if (!text) {
      let list = operations.map((op,i)=>`> *${i+1}╎* ${op.name}`).join('\n');
      let colors = colorOptions.map((c,i)=>`${i+1}-${c.name}`).join(' | ');
      return conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🖼️ 〕قـائـمـة الـتـأثـيـرات*

${list}

*📌┊الاسـتـخـدام:*
*${usedPrefix+command} 1*
*${usedPrefix+command} 8 2* ↜ تغيير لون ${colors}
*${usedPrefix+command} 10 مرحبا GOJO*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`, m);
    }

    const inputArray = text.split(' ');
    const operationNumber = parseInt(inputArray[0]) - 1;
    const secondInput = inputArray.slice(1).join(' ');

    if (isNaN(operationNumber) || operationNumber < 0 || operationNumber >= operations.length) {
      return conn.reply(m.chat, `*〔 ❌ 〕رقـم غـيـر صـحـيـح*`, m);
    }

    await conn.reply(m.chat, `*〔 ♻️ 〕جـاري مـعـالـجـة الـصـورة ↜ ${operations[operationNumber].name}*`, m);

    const image = await Jimp.read(img);

    if (operations[operationNumber].name === 'بورتريه' || operations[operationNumber].name === 'تحويل إلى بورتريه') {
      const portraitWidth = image.bitmap.height * (9 / 16);
      await image.resize(portraitWidth, image.bitmap.height);
      await image.crop(0, 0, portraitWidth, image.bitmap.height);
    }

    if (operations[operationNumber].name.includes('تغيير الألوان')) {
      if (secondInput) {
        const colorIndex = parseInt(secondInput) - 1;
        if (colorIndex < 0 || colorIndex >= colorOptions.length) return conn.reply(m.chat, `*اختر رقم لون صحيح 1-${colorOptions.length}*`, m);
        image.color([{ apply: 'mix', params: [colorOptions[colorIndex].color, 100] }]);
      } else {
        const colorList = colorOptions.map((col,i)=>`${i+1}. ${col.name}`).join('\n');
        return conn.reply(m.chat, `*اختر اللون:*\n\n${colorList}\n\n*مثال:* ${usedPrefix+command} 8 1`, m);
      }
    }

    if (operations[operationNumber].name.includes('إضافة نص')) {
      if (!secondInput) return conn.reply(m.chat, `*أدخل النص بعد الرقم*\n*${usedPrefix+command} 10 GOJO*`, m);
      const font = await Jimp.loadFont(Jimp.FONT_SANS_64_WHITE);
      const textWidth = Jimp.measureText(font, secondInput);
      const textHeight = Jimp.measureTextHeight(font, secondInput, image.bitmap.width);
      image.print(font, (image.bitmap.width/2)-(textWidth/2), image.bitmap.height - textHeight - 20, secondInput);
    }

    if (operations[operationNumber].name.includes('إطار مشوش')) {
      const blurredImage = image.clone().blur(10);
      const bw = image.bitmap.width * 2; const bh = image.bitmap.height * 2;
      blurredImage.resize(bw,bh);
      blurredImage.composite(image, (bw - image.bitmap.width)/2, (bh - image.bitmap.height)/2);
      const buf = await blurredImage.getBufferAsync(Jimp.MIME_JPEG);
      return await conn.sendFile(m.chat, buf, 'tokita.jpg', `*✅ تم تطبيق ↜ إطار مشوش*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m);
    }

    if (operations[operationNumber].name.includes('قص')) {
      const w=image.bitmap.width, h=image.bitmap.height;
      const cw=h/2, ch=h; const x=(w/2)-(cw/2), y=(h/2)-(ch/2);
      image.crop(x,y,cw,ch);
    }

    const opFn = operations[operationNumber].operation;
    if (opFn && typeof opFn === 'function') await opFn(image);

    const processedImageBuffer = await image.getBufferAsync(Jimp.MIME_JPEG);
    await conn.sendFile(m.chat, processedImageBuffer, 'tokita.jpg', `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *✅ تـم ↜ ${operations[operationNumber].name}*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`, m);

  } catch (error) {
    console.error(error);
    conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕خـطـأ:* ${error.message}\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m);
  }
};

handler.help = ["تحسين"]
handler.tags = ["tools"]
handler.command = ["تحسين","hd","تعديل"]

export default handler