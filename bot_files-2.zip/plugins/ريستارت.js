// ════════════════════════════
// 🔮 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | 𝐑𝐄𝐒𝐓𝐀𝐑𝐓 𝐒𝐘𝐒𝐓𝐄𝐌 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕
// ════════════════════════════
import fs from 'fs'

let handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(m.chat, { react: { text: '🔄', key: m.key } });
    
    const message = `* ━ ╼╃ ⌬〔 🔄 〕⌬ ╄╾ ━ *
> *〔 اعـادة تـشـغـيـل الـنـظـام ┊ ˼‏ ⚙️˹ ↶〕*
> *🥷🏻┊* جـاري اعـادة تـشـغـيـل الـبـوت 🍷
> *🥷🏻┊* انـتـظـر بـضـع ثـوانـي مـن فـضـلـك 🕐
> *🥷🏻┊* بـواسـطـة: *GOJO BOT*
* ━ ╼╃ ⌬〔 GOJO BOT 〕⌬ ╄╾ ━ *`.trim();
    
    await m.reply(message)

    // نحفظ الشات باش نرسل فيه "تم التشغيل"
    fs.writeFileSync('./restarting.txt', m.chat)

    setTimeout(() => {
      process.exit(1) // باش pm2 يعاود يشغلو
    }, 3000)

  } catch (error) {
    console.error(error)
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    conn.reply(m.chat, `* ━ ╼╃ ⌬〔 ❌ 〕⌬ ╄╾ ━ *
> *〔 خـطـأ فـي اعـادة الـتـشـغـيـل ┊ ˼‏ ⚠️˹ ↶〕*
> *🥷🏻┊* ${error.message}
* ━ ╼╃ ⌬〔 GOJO BOT 〕⌬ ╄╾ ━ *`, m)
  }
}

// هاد الكود كيخدم منين البوت كيعاود يتشعل
setTimeout(async () => {
  try {
    const path = './restarting.txt'
    if (fs.existsSync(path)) {
      const chatId = fs.readFileSync(path, 'utf-8')
      await global.conn?.sendMessage?.(chatId, {
        text: `* ━ ╼╃ ⌬〔 ✅ 〕⌬ ╄╾ ━ *
> *〔 تـم تـشـغـيـل الـبـوت مـن جـديـد ┊ ˼‏ 🎉˹ ↶〕*
> *🥷🏻┊* شـكـراً عـلـى انـتـظـارك 🙏
> *🥷🏻┊* *GOJO BOT* مـسـتـعـد لـلـعـمـل ⚡
* ━ ╼╃ ⌬〔 GOJO BOT 〕⌬ ╄╾ ━ *`.trim()
      }).catch(console.error)
      fs.unlinkSync(path) // نمسحو الملف
    }
  } catch {}
}, 5000)

handler.help = ['restart']
handler.tags = ['👑 المالك']
handler.command = ['ريستارت', 'اعادة', 'إعادة', 'restart', 'rt']
handler.rowner = true // غير المالك

export default handler