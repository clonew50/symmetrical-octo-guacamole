// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ * GOJO FIX LID V23
let handler = async (m, { conn, args }) => {
  if (!m.chat.endsWith('@g.us')) return m.reply('للجروبات فقط')

  try {
    const meta = await conn.groupMetadata(m.chat)

    // فحص أدمن المستخدم بطريقة مضمونة
    let userAdmin = meta.participants.find(v => {
      let id = v.id || v.jid
      return id.includes(m.sender.split('@')[0]) && (v.admin === 'admin' || v.admin === 'superadmin')
    })

    // سمح للمطور يتجاوز الفحص
    let isOwner = global.owner?.map(v=>v[0]).some(n=> m.sender.includes(n))
    if (!userAdmin &&!isOwner) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 👑 〕خاصك تكون آدمن*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)

    if (!args[0]) return m.reply('*.قبول الكل*\n*.قبول 10*')

    let list = await conn.groupRequestParticipantsList(m.chat).catch(_=>null)
    if (!list?.length) return m.reply('> *〔 📭 〕مافيش طلبات*')

    let count = args[0] === 'الكل' || args[0] === 'all'? list.length : parseInt(args[0]) || 0
    if (count <= 0) return m.reply('رقم غلط')
    if (count > list.length) count = list.length

    let toApprove = list.slice(0, count).map(x => x.jid)

    // هنا الحل : ما نفحصش واش البوت آدمن، نحاول نيشان
    try {
      await conn.groupRequestParticipantsUpdate(m.chat, toApprove, 'approve')
      return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ✅ 〕تم قبول ${count}*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 〕⌬ ╄╾ ━ *`)
    } catch (e) {
      // إلا فشل هنا عاد فعلا البوت ماشي آدمن
      if (e.message.includes('not-authorized') || e.message.includes('forbidden')) {
        return m.reply(`*〔 ❌ 〕البوت فعلا ماشي آدمن، ارفعني آدمن وعاود*`)
      } else {
        throw e
      }
    }

  } catch (e) {
    console.log(e)
    return m.reply(`خطأ: ${e.message}`)
  }
}

handler.command = ['قبول','اقبل']
handler.group = true
export default handler