// plugins/stickers-pack.js
import fetch from 'node-fetch'
import { writeFileSync, unlinkSync, readFileSync, existsSync } from 'fs'
import { execSync } from 'child_process'
import crypto from 'crypto'
import https from 'https'
import axios from 'axios'
import { Sticker, StickerTypes } from 'wa-sticker-formatter'

const PINTEREST_BASE = 'https://www.pinterest.com'
const PINTEREST_SEARCH_PATH = '/resource/BaseSearchResource/get/'
const PINTEREST_HEADERS = {
   accept: 'application/json, text/javascript, */*, q=0.01',
   referer: 'https://www.pinterest.com/',
   'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
   'x-app-version': 'a9522f',
   'x-pinterest-appstate': 'active',
   'x-pinterest-pws-handler': 'www/[username]/[slug].js',
   'x-requested-with': 'XMLHttpRequest'
}

const UA = 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36'

// ─── كوكيز Pinterest ──────────────────────────────────────────────────────────
async function getPinterestCookies() {
   try {
      const res = await axios.get(PINTEREST_BASE, { timeout: 15000 })
      const setCookies = res.headers['set-cookie']
      if (!setCookies) return null
      return setCookies.map(c => c.split(';')[0].trim()).join('; ')
   } catch {
      return null
   }
}

// ─── جلب صور ثابتة فقط من Pinterest ──────────────────────────────────────────────
async function searchPinterestStatic(query, needed = 15) {
   const results = []
   const cookies = await getPinterestCookies()
   if (!cookies) return results

   let bookmarks = ['']
   let attempts = 0

   while (results.length < needed && bookmarks.length && attempts < 10) {
      attempts++
      try {
         const params = {
            source_url: `/search/pins/?q=${encodeURIComponent(query)}`,
            data: JSON.stringify({
               options: { isPrefetch: false, query, scope: 'pins', bookmarks, page_size: 50 },
               context: {}
            }),
            _: Date.now()
         }
         const { data } = await axios.get(`${PINTEREST_BASE}${PINTEREST_SEARCH_PATH}`, {
            headers: {...PINTEREST_HEADERS, cookie: cookies },
            params,
            timeout: 15000
         })
         const pins = data?.resource_response?.data?.results?.filter(v => v?.images?.orig?.url) || []
         if (!pins.length) break
         for (const r of pins) {
            const url = r.images.orig.url
            if (!url.endsWith('.gif') &&!url.endsWith('.mp4')) results.push(url)
            if (results.length >= needed) break
         }
         const nextBookmark = data?.resource_response?.bookmark
         if (!nextBookmark || nextBookmark === '-end-') break
         bookmarks = [nextBookmark]
      } catch { break }
   }

   return [...new Set(results)].slice(0, needed)
}

// ─── tray و thumbnail للـ Pack ──────────────────────────────────────────────
async function makeTrayWebp(buffer) {
   const ts = Date.now()
   const inp = `./tmp_tray_${ts}`
   const out = `./tmp_tray_${ts}.webp`
   try {
      writeFileSync(inp, buffer)
      execSync(`ffmpeg -y -err_detect ignore_err -i "${inp}" -vf "scale=252:252:force_original_aspect_ratio=decrease,pad=252:252:(ow-ih)/2:(oh-ih)/2:color=0x00000000" -q:v 80 "${out}"`, { stdio: 'pipe' })
      return readFileSync(out)
   } catch {
      return await makeBlankTrayWebp()
   } finally {
      try { if (existsSync(inp)) unlinkSync(inp) } catch {}
      try { if (existsSync(out)) unlinkSync(out) } catch {}
   }
}

async function makeBlankTrayWebp() {
   const ts = Date.now()
   const out = `./tmp_tray_blank_${ts}.webp`
   try {
      execSync(`ffmpeg -y -f lavfi -i "color=c=black@0:s=252x252:r=1" -frames:v 1 "${out}"`, { stdio: 'pipe' })
      return readFileSync(out)
   } finally {
      try { if (existsSync(out)) unlinkSync(out) } catch {}
   }
}

async function makeThumbnailJpeg(buffer) {
   const ts = Date.now()
   const inp = `./tmp_thumb_${ts}.webp`
   const out = `./tmp_thumb_${ts}.jpg`
   try {
      writeFileSync(inp, buffer)
      execSync(`ffmpeg -y -err_detect ignore_err -i "${inp}" -vf "scale=252:252:force_original_aspect_ratio=decrease,pad=252:252:(ow-iw)/2:(oh-ih)/2" "${out}"`, { stdio: 'pipe' })
      return readFileSync(out)
   } finally {
      try { if (existsSync(inp)) unlinkSync(inp) } catch {}
      try { if (existsSync(out)) unlinkSync(out) } catch {}
   }
}

// ─── مساعدات التشفير ─────────────────────────────────────────────────────────
function sha256(buffer) {
   return crypto.createHash('sha256').update(buffer).digest()
}

function toB64Url(buffer) {
   return Buffer.from(buffer).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
}

function crc32(buf) {
   let crc = 0xFFFFFFFF
   for (const byte of buf) {
      crc ^= byte
      for (let j = 0; j < 8; j++)
         crc = (crc >>> 1) ^ (crc & 1? 0xEDB88320 : 0)
   }
   return (crc ^ 0xFFFFFFFF) >>> 0
}

function buildZip(files) {
   const localHeaders = []
   const centralDirs = []
   let offset = 0

   const now = new Date()
   const dosTime = ((now.getHours() & 0x1f) << 11) | ((now.getMinutes() & 0x3f) << 5) | ((now.getSeconds() >> 1) & 0x1f)
   const dosDate = (((now.getFullYear() - 1980) & 0x7f) << 9) | (((now.getMonth() + 1) & 0x0f) << 5) | (now.getDate() & 0x1f)

   for (const file of files) {
      const nameBytes = Buffer.from(file.name, 'utf8')
      const crc = crc32(file.data)

      const local = Buffer.allocUnsafe(30 + nameBytes.length)
      local.writeUInt32LE(0x04034b50, 0)
      local.writeUInt16LE(20, 4)
      local.writeUInt16LE(0, 6)
      local.writeUInt16LE(0, 8)
      local.writeUInt16LE(dosTime, 10)
      local.writeUInt16LE(dosDate, 12)
      local.writeUInt32LE(crc, 14)
      local.writeUInt32LE(file.data.length, 18)
      local.writeUInt32LE(file.data.length, 22)
      local.writeUInt16LE(nameBytes.length, 26)
      local.writeUInt16LE(0, 28)
      nameBytes.copy(local, 30)
      localHeaders.push(Buffer.concat([local, file.data]))

      const central = Buffer.allocUnsafe(46 + nameBytes.length)
      central.writeUInt32LE(0x02014b50, 0)
      central.writeUInt16LE(20, 4)
      central.writeUInt16LE(20, 6)
      central.writeUInt16LE(0, 8)
      central.writeUInt16LE(0, 10)
      central.writeUInt16LE(dosTime, 12)
      central.writeUInt16LE(dosDate, 14)
      central.writeUInt32LE(crc, 16)
      central.writeUInt32LE(file.data.length, 20)
      central.writeUInt32LE(file.data.length, 24)
      central.writeUInt16LE(nameBytes.length, 28)
      central.writeUInt16LE(0, 30)
      central.writeUInt16LE(0, 32)
      central.writeUInt16LE(0, 34)
      central.writeUInt16LE(0, 36)
      central.writeUInt32LE(0, 38)
      central.writeUInt32LE(offset, 42)
      nameBytes.copy(central, 46)
      centralDirs.push(central)

      offset += 30 + nameBytes.length + file.data.length
   }

   const centralBuf = Buffer.concat(centralDirs)
   const eocd = Buffer.allocUnsafe(22)
   eocd.writeUInt32LE(0x06054b50, 0)
   eocd.writeUInt16LE(0, 4)
   eocd.writeUInt16LE(0, 6)
   eocd.writeUInt16LE(files.length, 8)
   eocd.writeUInt16LE(files.length, 10)
   eocd.writeUInt32LE(centralBuf.length,12)
   eocd.writeUInt32LE(offset, 16)
   eocd.writeUInt16LE(0, 20)

   return Buffer.concat([...localHeaders, centralBuf, eocd])
}

// ─── رفع الملف إلى خوادم واتساب ──────────────────────────────────────────────
async function uploadToServer(conn, buffer, { hkdf, mediaPath, mediaKey = crypto.randomBytes(32) }) {
   const expanded = Buffer.from(crypto.hkdfSync('sha256', mediaKey, Buffer.alloc(32), Buffer.from(hkdf), 112))
   const iv = expanded.subarray(0, 16)
   const cipherKey = expanded.subarray(16, 48)
   const macKey = expanded.subarray(48, 80)
   const cipher = crypto.createCipheriv('aes-256-cbc', cipherKey, iv)
   const encrypted = Buffer.concat([cipher.update(buffer), cipher.final()])
   const mac = crypto.createHmac('sha256', macKey).update(iv).update(encrypted).digest().subarray(0, 10)
   const encBuffer = Buffer.concat([encrypted, mac])
   const fileSha256 = sha256(buffer)
   const fileEncSha256 = sha256(encBuffer)

   const iq = await conn.query({
      tag: 'iq', attrs: { id: conn.generateMessageTag?.()?? Date.now().toString(), to: 's.whatsapp.net', type: 'set', xmlns: 'w:m' },
      content: [{ tag: 'media_conn', attrs: {} }]
   })

   const mediaConn = iq.content?.find(v => v.tag === 'media_conn')
   if (!mediaConn) throw new Error('media_conn غير موجود')
   const auth = mediaConn.attrs?.auth
   if (!auth) throw new Error('auth غير موجود')

   const hosts = (mediaConn.content || []).filter(v => v.tag === 'host').map(v => v.attrs?.hostname).filter(Boolean)
   if (!hosts.length) throw new Error('لا يوجد host للرفع')

   const token = encodeURIComponent(fileEncSha256.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, ''))
   let lastError

   for (const host of hosts) {
      try {
         const json = await new Promise((resolve, reject) => {
            const url = new URL(`https://${host}${mediaPath}/${token}?auth=${encodeURIComponent(auth)}&token=${token}`)
            const req = https.request({
               hostname: url.hostname, port: 443, path: url.pathname + url.search, method: 'POST',
               headers: { Origin: 'https://web.whatsapp.com', Referer: 'https://web.whatsapp.com/', 'Content-Type': 'application/octet-stream', 'Content-Length': encBuffer.length }
            }, (res) => {
               let body = ''
               res.on('data', c => body += c)
               res.on('end', () => {
                  if (res.statusCode < 200 || res.statusCode >= 300) return reject(new Error(`فشل الرفع ${res.statusCode}`))
                  try { resolve(JSON.parse(body)) } catch { reject(new Error('رد غير JSON')) }
               })
            })
            req.on('error', reject)
            req.write(encBuffer)
            req.end()
         })
         const directPath = json.direct_path?? json.directPath?? json.url?? json.path
         if (!directPath) throw new Error('directPath غير موجود')
         return { mediaKey, fileLength: buffer.length, fileSha256, fileEncSha256, directPath,...json }
      } catch (e) { lastError = e }
   }
   throw lastError?? new Error('جميع محاولات الرفع فشلت')
}

// ─── إرسال حزمة الملصقات ─────────────────────────────────────────────────────
async function sendStickerPack(conn, m, pack, query) {
   const zipFiles = []
   const stickersMetadata = []

   for (const item of pack) {
      const fileName = `${toB64Url(sha256(item.buffer))}.webp`
      zipFiles.push({ name: fileName, data: item.buffer })
      stickersMetadata.push({
         fileName,
         isAnimated: false,
         emojis: ['✨'],
         accessibilityLabel: '',
         isLottie: false,
         mimetype: 'image/webp'
      })
   }

   const trayIconFileName = 'tray_icon.webp'
   const traySource = pack[0]?.buffer
   const trayBuffer = traySource? await makeTrayWebp(traySource) : await makeBlankTrayWebp()
   zipFiles.push({ name: trayIconFileName, data: trayBuffer })

   const archive = buildZip(zipFiles)

   const packUpload = await uploadToServer(conn, archive, { hkdf: 'WhatsApp Sticker Pack Keys', mediaPath: '/mms/sticker-pack' })
   const thumbnailBuffer = await makeThumbnailJpeg(trayBuffer)
   const thumbUpload = await uploadToServer(conn, thumbnailBuffer, { hkdf: 'WhatsApp Sticker Pack Thumbnail Keys', mediaPath: '/mms/thumbnail-sticker-pack', mediaKey: packUpload.mediaKey })

   await conn.relayMessage(m.chat, {
      messageContextInfo: { messageSecret: crypto.randomBytes(32) },
      stickerPackMessage: {
         stickerPackId: 'Pack_' + crypto.randomBytes(8).toString('hex'),
         name: `✨ GOJO`,
         publisher: 'GOJO',
         packDescription: `حزمة ملصقات بواسطة GOJO - ${query}`,
         stickers: stickersMetadata,
         fileLength: packUpload.fileLength,
         fileSha256: packUpload.fileSha256,
         fileEncSha256: packUpload.fileEncSha256,
         mediaKey: packUpload.mediaKey,
         directPath: packUpload.directPath,
         mediaKeyTimestamp: Math.floor(Date.now() / 1000),
         stickerPackSize: packUpload.fileLength,
         stickerPackOrigin: 2,
         trayIconFileName,
         thumbnailDirectPath: thumbUpload.directPath,
         thumbnailSha256: thumbUpload.fileSha256,
         thumbnailEncSha256: thumbUpload.fileEncSha256,
         thumbnailHeight: 252,
         thumbnailWidth: 252,
         imageDataHash: thumbUpload.fileSha256.toString('base64')
      }
   }, { quoted: m })
}

// ─── تحويل الصورة مع دمج EXIF الموثوق بواسطة wa-sticker-formatter ────────
async function makeWebp(buffer) {
   const sticker = new Sticker(buffer, {
      pack: '✨ GOJO',
      author: 'GOJO',
      type: StickerTypes.FULL,
      categories: ['✨'],
      quality: 70
   })
   const webpBuffer = await sticker.toBuffer()
   return { buffer: webpBuffer, isAnimated: false }
}

// ═══════════════════════════════════════════════════════════════════════════════
let handler = async (m, { conn, text, usedPrefix, command }) => {

   if (!text) {
      return m.reply(`✨ ${usedPrefix + command} <بحث> <عدد>\n💡 مثال: ${usedPrefix + command} anime 10`)
   }

   let query = text
   let count = 10
   const parts = text.split(' ')
   const lastPart = parts[parts.length - 1]
   if (!isNaN(lastPart) && parts.length > 1) {
      count = Math.min(50, Math.max(1, parseInt(lastPart)))
      query = parts.slice(0, -1).join(' ')
   }

   let statusMsg = await m.reply(`⏳ جاري البحث عن ملصقات بحقوق GOJO لـ "${query}"...`)

   try {
      const staticUrls = await searchPinterestStatic(query, count)

      if (staticUrls.length === 0) {
         try { await conn.sendMessage(m.chat, { delete: statusMsg.key }) } catch {}
         return m.reply(`❌ لا توجد نتائج لـ "${query}"`)
      }

      const pack = []

      for (let i = 0; i < staticUrls.length && pack.length < count; i++) {
         try {
            const res = await fetch(staticUrls[i], { headers: { 'User-Agent': UA }, timeout: 10000 })
            if (!res.ok) continue
            const webpItem = await makeWebp(Buffer.from(await res.arrayBuffer()))
            pack.push(webpItem)
         } catch {}
      }

      if (pack.length === 0) {
         try { await conn.sendMessage(m.chat, { delete: statusMsg.key }) } catch {}
         return m.reply(`❌ تعذر معالجة أي صورة وتحويلها لملصق`)
      }

      try { await conn.sendMessage(m.chat, { delete: statusMsg.key }) } catch {}

      await sendStickerPack(conn, m, pack, query)

   } catch (e) {
      console.error(e)
      try { await conn.sendMessage(m.chat, { delete: statusMsg.key }) } catch {}
      m.reply(`❌ خطأ: ${e.message}`)
   }
}

handler.command = ['ملصقات', 'باكج', 'stickerpack', 'pack', 'حزمة', 'حزمه']
handler.help = ['باكج [بحث] [عدد]']
handler.tags = ['sticker']

export default handler