import axios from "axios";
import cheerio from "cheerio";

async function ghTrending() {
    try {
        const url = "https://github.com/trending";
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        const repositories = [];

        $(".Box-row").each((index, element) => {
            const title = $(element).find("h2 a").text().trim().replace(/\s+/g, " ");
            const repoLink = "https://github.com" + $(element).find("h2 a").attr("href");
            const description = $(element).find("p").text().trim();
            const stars = $(element).find("a[href$='/stargazers']").text().trim();

            const numbers = $(element).find("a.Link--muted").map((i, el) => $(el).text().trim()).get();
            const forks = numbers.length > 1? numbers[1] : "0";

            const language = $(element).find("[itemprop='programmingLanguage']").text().trim();

            repositories.push({
                title,
                repoLink,
                description,
                stars,
                forks,
                language: language || "غير معروف",
            });
        });

        return repositories;
    } catch (error) {
        return [];
    }
}

const handler = async (m, { conn }) => {
    try {
        const repos = await ghTrending();
        if (!repos.length) return m.reply("❌ فشل في جلب بيانات GitHub Trending.");

        let message = `*🔥 ترند GitHub اليوم 🔥*\n\n`;
        repos.slice(0, 5).forEach((repo, index) => {
            message += `*${index + 1}. ${repo.title}*\n`;
            message += `📦 *الرابط:* ${repo.repoLink}\n`;
            message += `⭐ *النجوم:* ${repo.stars} | 🍴 *الفوركس:* ${repo.forks}\n`;
            message += `💻 *اللغة:* ${repo.language}\n`;
            message += `📝 *الوصف:* ${repo.description || "لا يوجد وصف"}\n\n`;
        });

        await conn.sendMessage(m.chat, { text: message });

    } catch (error) {
        m.reply("⚠️ حدث خطأ أثناء جلب بيانات GitHub Trending.");
    }
};

handler.help = ["githubtrend", "ترند"];
handler.tags = ["tools", "ادوات"];
handler.command = /^(githubtrend|ترند)$/i;

export default handler