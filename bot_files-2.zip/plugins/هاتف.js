/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * امر: هاتف
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━
 * By : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 212775630435
 */

import cheerio from 'cheerio';
import fetch from 'node-fetch';

let activeChats = {};

const handler = async (m, { conn, text }) => {
    const userKey = m.chat + m.sender;

    if (!text) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ خـطـأ┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـطـريـقـة ↶ 🕸️﹞*
> *🥷🏻┊* .هاتف اسـم_الـهـاتـف

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`);
    
    await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ⏳ جـاري الـبـحـث┊ ˼‏ 🔍˹ ↶〕*

*🪖 ──¤﹝الـمـعـلـومـة ↶ 🕸️﹞*
> *🥷🏻┊* جاري البحث يا اخي، المرجو التحلي بالصبر...

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`);

    try {
        let res = await fetchAndParseData(text);
        let teks = res.map((item, index) => {
            return `*〔 ${index + 1} 〕*
*🪖 ──¤﹝الـنـتـيـجـة ↶ 🕸️﹞*
> *🥷🏻┊* الـعـنـوان: ${item.title}
> *🥷🏻┊* رد على هذه الرسالة بالرقم ${index + 1} ليتم إرسال التفاصيل`;
        }).filter(v => v).join("\n\n* ━ ╼╃ ⌬〔🔮〕⌬ ╄╾ ━ *\n\n");

        await conn.sendMessage(m.chat, { text: teks }, { quoted: m });
        activeChats[userKey] = { res, optionsSent: true };
    } catch (e) {
        await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ خـطـأ┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـسـبـب ↶ 🕸️﹞*
> *🥷🏻┊* حدثت مشكلة أثناء البحث يا اخي

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`);
    }
};

const responseHandler = async (m, { conn }) => {
    const userKey = m.chat + m.sender;

    if (activeChats[userKey] && activeChats[userKey].optionsSent) {
        const choice = parseInt(m.text.trim());
        const { res } = activeChats[userKey];
        delete activeChats[userKey];

        if (choice > 0 && choice <= res.length) {
            try {
                let obje = await ambilKontenDenganLink(res[choice - 1].link);
                await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ✅ تـفـاصـيـل الـهـاتـف┊ ˼‏ 📱˹ ↶〕*

${obje}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`);
            } catch (e) {
                await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ خـطـأ┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـسـبـب ↶ 🕸️﹞*
> *🥷🏻┊* حدث خطأ أثناء جلب المحتوى

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`);
            }
        } else {
            m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ خـطـأ┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـتـنـبـيـه ↶ 🕸️﹞*
> *🥷🏻┊* لم يتم العثور على نتيجة، الرقم غير صحيح

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`);
        }
    }
};

handler.before = responseHandler;
handler.command = /^(هاتف)$/i;
handler.help = ['هاتف'];
handler.tags = ['🔍 بحث'];

export default handler;

async function fetchAndParseData(q) {
    try {
        const response = await fetch('https://raqamitv.com/?s=' + q);
        const html = await response.text();
        const $ = cheerio.load(html);

        const posts = $('.post-item').map((index, element) => {
            const title = $(element).find('.post-title a').text();
            const link = $(element).find('.post-title a').attr('href');
            return { title, link };
        }).get();

        return posts;
    } catch (error) {
        console.error('Error fetching data:', error);
        throw error;
    }
}

async function ambilKontenDenganLink(url) {
    try {
        const response = await fetch(url);
        const html = await response.text();
        const $ = cheerio.load(html);

        const semuaKontenDenganLink = [];
        $('p').each((index, element) => {
            const teksP = $(element).text();
            if (teksP) {
                semuaKontenDenganLink.push(teksP);
            }
        });

        return semuaKontenDenganLink.join('\n\n');
    } catch (error) {
        console.error('حدث خطأ:', error);
        return null;
    }
}