/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: كانيكي - زر القناة يفتح مباشرة
 * 📢 القناة: https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

import axios from 'axios'
import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

let handler = async (m, { conn, usedPrefix, command }) => {
try {
let { data } = await axios.get('https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/anime-keneki.json')
let url = data[Math.floor(Math.random() * data.length)]

let media = await prepareWAMessageMedia({ image: { url } }, { upload: conn.waUploadToServer })

let caption = 
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🖤 〕 كـانـيـكـي - 𝐊𝐀𝐍𝐄𝐊𝐈 ♣️*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *

> *📢 الـقـنـاة بـالأسـفـل تـدخـلـك مـبـاشـرة*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
  message: {
   messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
   interactiveMessage: proto.Message.InteractiveMessage.create({
    body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
    footer: proto.Message.InteractiveMessage.Footer.create({ text: "♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓" }),
    header: proto.Message.InteractiveMessage.Header.create({ 
        title: "🖤 TOKYO GHOUL",
        subtitle: "KANeki Ken",
        hasMediaAttachment: true, 
        imageMessage: media.imageMessage 
    }),
    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
     buttons: [
       {
         name: "quick_reply",
         buttonParamsJson: JSON.stringify({
           display_text: "⚡ الـتـالـي",
           id: `${usedPrefix}${command}`
         })
       },
       {
         name: "cta_url",
         buttonParamsJson: JSON.stringify({
           display_text: "📢 قـنـاتـنـا الـرسـمـيـة",
           url: "https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r",
           merchant_url: "https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r"
         })
       }
     ]
    })
   })
  }
 }
}, { quoted: m })

await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

} catch (e) {
  console.error(e)
  m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *فشل: ${e.message}*`)
}
}

handler.help = ['كانيكي']
handler.tags = ['انمي']
handler.command = /^(keneki|كانيكي|كانكي)$/i

export default handler