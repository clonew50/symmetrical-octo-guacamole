if (!global._sortGames) global._sortGames = {}

const WORDS = [
  'كرة القدم', 'مرمى', 'هدف', 'تسديدة', 'ركلة', 'ملعب', 'حكم', 'بطولة',
  'مدرب', 'لاعب', 'دفاع', 'هجوم', 'تمريرة', 'ركنية', 'جزاء', 'شباك',
  'برشلونة', 'ريال مدريد', 'ليفربول', 'مانشستر', 'يوفنتوس', 'بايرن',
  'رونالدو', 'ميسي', 'نيمار', 'مبابي', 'صلاح', 'بنزيما', 'مودريتش',
  'كأس العالم', 'دوري الأبطال', 'الميلان', 'تشيلسي', 'أرسنال',
  'ناروتو', 'سوكونا', 'جوجو', 'ديمون', 'اتاك', 'بليتش', 'دراغون',
  'انيمي', 'مانغا', 'سيف', 'قوة', 'شياطين', 'ساحر', 'قتال',
  'كمبيوتر', 'هاتف', 'انترنت', 'برنامج', 'شاشة', 'لوحة', 'ذاكرة',
  'مصر', 'السعودية', 'المغرب', 'تونس', 'الجزائر', 'الامارات', 'قطر',
  'شمس', 'قمر', 'نجوم', 'سماء', 'بحر', 'جبل', 'صحراء', 'نهر',
  'أسد', 'نمر', 'فيل', 'زرافة', 'دلفين', 'ثعبان', 'طاووس',
  'موزة', 'تفاحة', 'برتقال', 'مانجو', 'فراولة', 'عنب', 'بطيخ'
]

const CREDIT = `╭─────────────⊹\n│ 👑⌁ ⚡𝑮𝑬𝑶 𝑻𝑯𝑬 𝑨𝑩𝑺𝑶𝑳𝑼𝑻𝑬 ⌁👑\n╰─────────────⊹ 🔱⚡`

function shuffleWord(word) {
  const chars = word.split('')
  for (let i = chars.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [chars[i], chars[j]] = [chars[j], chars[i]]
  }
  const shuffled = chars.join('')
  return shuffled === word ? shuffleWord(word) : shuffled
}

const handler = async (m, { conn }) => {
  const chatId = m.chat
  const userId = m.sender
  const gameKey = `${chatId}_${userId}`

  if (global._sortGames[gameKey]) {
    return m.reply('❗ عندك سؤال شغال دلوقتي! جاوب عليه قبل ما تبدأ سؤال جديد.')
  }

  const correct = WORDS[Math.floor(Math.random() * WORDS.length)]
  const shuffled = shuffleWord(correct)

  await conn.sendMessage(chatId, {
    text:
      `🔀 *لعبة ترتيب الحروف!*\n\n` +
      `❓ رتب الكلمة دي:\n` +
      `*${shuffled}*\n\n` +
      `⏱️ عندك 60 ثانية\n` +
      `💰 الجائزة: 5000 XP\n\n` +
      CREDIT,
    mentions: [userId]
  }, { quoted: m })

  global._sortGames[gameKey] = {
    answer: correct,
    shuffled,
    starter: userId,
    chatId,
    timeout: setTimeout(() => {
      if (global._sortGames[gameKey]) {
        conn.sendMessage(chatId, {
          text:
            `⏰ *انتهى الوقت يا @${userId.split('@')[0]}!*\n\n` +
            `✅ *الإجابة الصحيحة:* ${correct}\n\n` +
            `🎯 استخدم .ترتيب للعب مرة أخرى\n\n` +
            CREDIT,
          mentions: [userId]
        })
        delete global._sortGames[gameKey]
      }
    }, 60000)
  }
}

handler.before = async function (m) {
  const chatId = m.chat
  const userId = m.sender

  let activeGameKey = null
  let activeGame = null

  for (const key in global._sortGames) {
    const game = global._sortGames[key]
    if (game.starter === userId && game.chatId === chatId) {
      activeGameKey = key
      activeGame = game
      break
    }
  }

  if (!activeGame) return false
  if (!m.text) return false
  if (/^[.!#](ترتيب)$/i.test(m.text.trim())) return false

  const userAnswer = m.text.trim()
  const isCorrect = userAnswer === activeGame.answer

  if (!isCorrect) {
    await this.sendMessage(chatId, {
      text:
        `❌ *إجابة غلط يا @${userId.split('@')[0]}!*\n\n` +
        `✅ الإجابة الصحيحة: *${activeGame.answer}*\n\n` +
        `💡 حاول تاني المرة الجاية\n\n` +
        CREDIT,
      mentions: [userId]
    })
    clearTimeout(activeGame.timeout)
    delete global._sortGames[activeGameKey]
    return false
  }

  clearTimeout(activeGame.timeout)

  if (!global.db?.data?.users?.[userId]) {
    if (global.db?.data?.users) global.db.data.users[userId] = { exp: 0 }
  }
  if (global.db?.data?.users?.[userId]) {
    global.db.data.users[userId].exp = (global.db.data.users[userId].exp || 0) + 5000
  }

  await this.sendMessage(chatId, {
    text:
      `✅ *إجابة صحيحة من @${userId.split('@')[0]}!*\n\n` +
      `🏆 *الكلمة:* ${activeGame.answer}\n` +
      `💰 *ربحت:* 5000 XP\n\n` +
      `🎯 استخدم .ترتيب للعب مرة أخرى\n\n` +
      CREDIT,
    mentions: [userId]
  })

  delete global._sortGames[activeGameKey]
  return false
}

handler.help    = ['ترتيب']
handler.tags    = ['games']
handler.command = /^(ترتيب)$/i

export default handler