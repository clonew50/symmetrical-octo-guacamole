/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * ▲ حـقـوق الـتـطـويـر والـتـعـديـل ▲
 * 👤 المطور: YONO
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: بحث يوتيوب بالأزرار
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

import yts from 'yt-search'
import { generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'

let handler = async (m, { conn, text }) => {
    if (!text) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔⚠️〕⌬ ╄╾ ━ *
*〔 خـطـأ 〕: اكـتـب اسـم الـفـيـديـو*
*〔 مـثـال: 〕* \`.يوتيوب Souldking\`
* ━ ╼╃ ⌬〔 ⚜️ 〕⌬ ╄╾ ━ *`, m)

    await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } })
    let res = await yts(text)
    let videos = res.videos.slice(0, 10)
    if (!videos.length) return m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *
*〔 نـتـيـجـة 〕: مـا لـقـيـت والـو بـهـاد الاسـم*
* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ *`)

    // نخلي القائمة فيها خيارين لكل فيديو
    let allRows = []
    videos.forEach((v, i) => {
        allRows.push({
            title: `🎧 صـوت | ${v.title.slice(0, 25)}`,
            description: `⏱️ ${v.timestamp} | ${v.ago} - تـحـمـيـل MP3`,
            id: `.ytmp3 ${v.url}`
        })
        allRows.push({
            title: `🎥 فـيـديـو | ${v.title.slice(0, 25)}`,
            description: `⏱️ ${v.timestamp} | ${v.ago} - تـحـمـيـل MP4`,
            id: `.ytmp4 ${v.url}`
        })
    })

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: `* ━ ╼╃ ⌬〔📺〕⌬ ╄╾ ━ *
*〔 ♛ 〕 نـتـائـج الـبـحـث فـي يـوتـيـوب ♣️*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *

*〔 🔎 〕 الـبـحـث:* ${text}
*〔 📊 〕 الـنـتـائـج:* ${videos.length}

*〔 📌 〕 اخـتـر مـن الـقـائـمـة نـوع الـتـحـمـيـل 👇*
* ━ ╼╃ ⌬〔 ⚜️ 〕⌬ ╄╾ ━ *`
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: '『 ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 - 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 ♣️ 』'
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: '〔 نتائج البحث 〕',
                        hasMediaAttachment: false
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    title: "📂 اضـغـط لـعـرض الـنـتـائـج",
                                    sections: [{
                                        title: "〔 اخـتـر نـوع الـتـحـمـيـل 〕",
                                        rows: allRows
                                    }]
                                })
                            }
                        ]
                    })
                })
            }
        }
    }, { quoted: m })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.help = ['يوتيوب'];
handler.tags = ['بحث'];
handler.command = ['play', 'yts'];
handler.footer = '* ━ ╼╃ ⌬〔 ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 - 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 ♣️ 〕⌬ ╄╾ ━ *'

export default handler