// groups-handler.js
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

/**
 * عدّل القيم التالية حسب حاجتك:
 * - GROUP_OWNER_ID: (اختياري) معرف صاحب البوت أو مالك ثابت
 * - GROUP_DEVELOPERS: مصفوفة JID للمطورين (مثال: ['2012xxxxxxx@s.whatsapp.net'])
 * - imgUrl: رابط الصورة المستخدمة في الرسالة التفاعلية
 * - wm: نص الفوتر (watermark) في الرسالة
 */
const GROUP_OWNER_ID = '9647882860837@s.whatsapp.net'; // مثال
const GROUP_DEVELOPERS = ['9647882860837@s.whatsapp.net', '9647882860837@s.whatsapp.net']; // ضع JIDs هنا
const imgUrl = 'https://files.catbox.moe/q1mes3.jpg';
const wm = 'Bot • حقوق'; // عدّل أو اجعلها '' إذا لم تحتاج

const handler = async (m, { text = '', conn, usedPrefix = '', command = '' }) => {
  try {
    // لو لم يُعطَ نص، إظهار قائمة المجموعات التفاعلية
    if (!text || text.trim() === '') {
      // جلب المجموعات من conn.chats (التي تنتهي بـ @g.us)
      const groups = Object.entries(conn.chats || {}).filter(([jid, chat]) => jid.endsWith('@g.us') && (chat?.isChats ?? true));
      const totalGroups = groups.length;

      // نكوّن صفوف لكل مجموعة
      const rows = await Promise.all(groups.map(async ([jid]) => {
        let groupMetadata = conn.chats[jid]?.metadata;
        if (!groupMetadata) {
          try {
            groupMetadata = await conn.groupMetadata(jid);
          } catch (e) {
            groupMetadata = { subject: await conn.getName(jid).catch(() => jid), participants: [] };
          }
        }
        const participants = groupMetadata.participants || [];
        // البحث عن البوت بين المشاركين
        const botParticipant = participants.find(p => (conn.decodeJid ? conn.decodeJid(p.id) : p.id) === (conn.user?.jid || conn.user)) || {};
        const isBotAdmin = !!(botParticipant?.admin);
        const totalParticipants = participants.length;
        return createGroupRows(conn, jid, isBotAdmin, totalParticipants, usedPrefix, command);
      }));

      // إنشاء الرسالة التفاعلية وإرسالها
      const msg = await createInteractiveMessage(m, conn, totalGroups, rows, imgUrl);
      await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
      return;
    }

    // إذا صيغ النص كـ "سحب-<jid>" أو "اسحب-<jid>" أو "تصفيه-<jid>" أو "مغادرة-<jid>"
    const trimmed = text.trim();
    const [actionRaw, idgruRaw] = trimmed.split('-').map(s => s && s.trim());
    if (!actionRaw || !idgruRaw) {
      return conn.sendMessage(m.chat, { text: '❗️ الصيغة الصحيحة: سحب-<jid> أو تصفيه-<jid> أو مغادرة-<jid>' }, { quoted: m });
    }

    // توحيد الأسماء (بالعربي قد يكتب المستخدم "اسحب" بدلاً من "سحب")
    const action = (actionRaw === 'اسحب') ? 'سحب' : actionRaw;

    const idgru = idgruRaw.includes('@g.us') ? idgruRaw : idgruRaw + '@g.us';

    // جلب بيانات المجموعة
    let groupMetadata;
    try {
      groupMetadata = await conn.groupMetadata(idgru);
    } catch (e) {
      console.error('groupMetadata error', e);
      return conn.sendMessage(m.chat, { text: '⚠️ خطأ في جلب بيانات المجموعة. تأكد أن البوت موجود في المجموعة والمعرف صحيح.' }, { quoted: m });
    }

    const owner = groupMetadata?.owner;
    const participants = groupMetadata?.participants || [];

    // Helper: تحويل عناصر المشاركين إلى JIDs موحدة
    const participantJids = participants.map(p => (conn.decodeJid ? conn.decodeJid(p.id) : p.id));

    // دوال تحقق مساعدة
    const isBotDeveloper = jid => GROUP_DEVELOPERS.includes(jid);
    const isOwner = jid => owner && (owner === jid || (conn.decodeJid && conn.decodeJid(owner) === jid));

    if (action === 'سحب') {
      // خفض كل المشرفين (admin) عدا المالك، البوت، والمطورين
      const toDemote = participants
        .filter(p => !!p.admin)
        .map(p => conn.decodeJid ? conn.decodeJid(p.id) : p.id)
        .filter(jid => jid !== (conn.user?.jid || conn.user) && !isOwner(jid) && !isBotDeveloper(jid));

      // ترقية المطورين إذا لم يكونوا أدمن
      const toPromote = participants
        .map(p => conn.decodeJid ? conn.decodeJid(p.id) : p.id)
        .filter(jid => isBotDeveloper(jid));

      // تنفيذ العمليات مع التحقق من وجود عناصر
      if (toDemote.length > 0) {
        try {
          await conn.groupParticipantsUpdate(idgru, toDemote, 'demote');
        } catch (e) {
          console.error('demote error', e);
        }
      }

      if (toPromote.length > 0) {
        try {
          await conn.groupParticipantsUpdate(idgru, toPromote, 'promote');
        } catch (e) {
          console.error('promote error', e);
        }
      }

      const cap2 = `تسجيل سحب المجموعة بواسطة مطور/ة\nمطوّر: @${m.sender.split('@')[0]}\nشكراً لاستضافتكم.`;
      await conn.sendMessage(idgru, { text: cap2, mentions: [m.sender] }, { quoted: m }).catch(() => null);
      await conn.sendMessage(m.chat, { text: '*تم سحب المجموعة بنجاح.*', mentions: [m.sender] }, { quoted: m }).catch(() => null);
      return;
    }

    if (action === 'تصفيه' || action === 'تصفية') {
      // طرد كل الأعضاء عدا المالك، البوت، والمطورين
      const toKick = participants
        .map(p => conn.decodeJid ? conn.decodeJid(p.id) : p.id)
        .filter(jid => jid !== (conn.user?.jid || conn.user) && !isOwner(jid) && !isBotDeveloper(jid));

      // ترقية المطورين
      const toPromote = participants
        .map(p => conn.decodeJid ? conn.decodeJid(p.id) : p.id)
        .filter(jid => isBotDeveloper(jid));

      if (toKick.length > 0) {
        try {
          await conn.groupParticipantsUpdate(idgru, toKick, 'remove');
        } catch (e) {
          console.error('remove error', e);
        }
      }

      if (toPromote.length > 0) {
        try {
          await conn.groupParticipantsUpdate(idgru, toPromote, 'promote');
        } catch (e) {
          console.error('promote error', e);
        }
      }

      const cap3 = `تسجيل تصفية المجموعة بواسطة مطور/ة\nمطوّر: @${m.sender.split('@')[0]}\nشكراً لاستضافتكم.`;
      await conn.sendMessage(idgru, { text: cap3, mentions: [m.sender] }, { quoted: m }).catch(() => null);
      await conn.sendMessage(m.chat, { text: '*تم تصفية المجموعة بنجاح.*', mentions: [m.sender] }, { quoted: m }).catch(() => null);
      return;
    }

    if (action === 'مغادرة') {
      const cap2 = `تسجيل خروجي بواسطة مطور/ة\nمطوّر: @${m.sender.split('@')[0]}\nشكراً لاستضافتكم.`;
      await conn.sendMessage(idgru, { text: cap2, mentions: [m.sender] }, { quoted: m }).catch(() => null);
      try {
        await conn.groupLeave(idgru);
      } catch (e) {
        console.error('groupLeave error', e);
        return conn.sendMessage(m.chat, { text: '❗️ حدث خطأ أثناء الخروج من المجموعة.' }, { quoted: m });
      }
      await conn.sendMessage(m.chat, { text: '*تمت العملية: خرجت من المجموعة.*', mentions: [m.sender] }, { quoted: m }).catch(() => null);
      return;
    }

    // إذا لم يُعرف الإجراء
    return conn.sendMessage(m.chat, { text: '❗️ الإجراء غير مفهوم. استخدم: سحب-<jid> أو تصفيه-<jid> أو مغادرة-<jid>' }, { quoted: m });

  } catch (err) {
    console.error('handler error', err);
    return conn.sendMessage(m.chat, { text: '❗️ حصل خطأ غير متوقع. تفقد السجل (console) للمزيد.' }, { quoted: m });
  }
};

handler.help = ['groups', 'grouplist'];
handler.tags = ['info'];
handler.command = ['المجموعات', 'الجروبات']; // أو الأسماء التي تفضلها
handler.owner = true;

export default handler;


/**
 * دوال المساعدة لبناء الصفوف والرسالة التفاعلية
 */
const createGroupRows = async (conn, jid, isBotAdmin, totalParticipants, usedPrefix, command) => {
  const groupName = await conn.getName(jid).catch(() => jid);
  return {
    header: `مجموعة: ${groupName}`,
    title: `البوت أدمن: ${isBotAdmin ? 'نعم' : 'لا'} • المشاركين: ${totalParticipants}`,
    description: 'قائمة خيارات المجموعة',
    id: `${usedPrefix || ''}${command || ''} ${jid}`
  };
};

const createInteractiveMessage = async (m, conn, totalGroups, rows, imgUrl) => {
  // تحضير الوسائط
  let mediaMessage = {};
  try {
    mediaMessage = await prepareWAMessageMedia({ image: { url: imgUrl } }, { upload: conn.waUploadToServer });
  } catch (e) {
    console.error('prepareWAMessageMedia error', e);
    mediaMessage = {};
  }

  const caption = `قائمة المجموعات المشارك بها البوت\nالعدد: ${totalGroups}`;

  // بناء رسالة تفاعلية بسيطة (قد تحتاج تعديل طفيف حسب نسخة Baileys لديك)
  const interactive = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: caption },
          footer: { text: wm || '' },
          header: {
            hasMediaAttachment: !!mediaMessage?.imageMessage,
            imageMessage: mediaMessage?.imageMessage
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                  title: 'قائمة المجموعات',
                  sections: [
                    {
                      title: '「 المجموعات 」',
                      highlight_label: '🗃️',
                      rows: rows
                    }
                  ]
                })
              }
            ]
          }
        }
      }
    }
  };

  return generateWAMessageFromContent(m.chat, interactive, { userJid: conn.user?.jid || conn.user, quoted: m });
};