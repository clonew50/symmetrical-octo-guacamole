// plugins/kick.js
// ✧ Raiden Shogun ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ - أمر الطرد 🚫

import { theme } from '../core/theme.js';

let handler = async (m, { conn }) => {
  
  const developerNumbers = ['201090224383@s.whatsapp.net', '201002435466@s.whatsapp.net']

  let user = m.mentionedJid?.[0] || m.quoted?.sender;
  
  if (!user) {
    return conn.reply(m.chat, theme.build([
      { type: 'title', text: '🚫 2B: "وحدة الطرد"' },
      { type: 'subtitle', text: 'قم بمنشن الهدف المراد طرده' },
      { type: 'divider' },
      { type: 'line', text: '⚔️ مثال: .طرد @user' },
      { type: 'line', text: '⚔️ أو قم بالرد على رسالة الهدف' }
    ]), m);
  }

  if (developerNumbers.some(dev => {
    let devClean = dev.replace(/[^0-9]/g, '');
    let userClean = user.replace(/[^0-9]/g, '');
    return userClean === devClean;
  })) {
    return conn.reply(m.chat, theme.build([
      { type: 'title', text: '⚠️ 2B: "تحذير"' },
      { type: 'subtitle', text: 'لا يمكنك طرد قادة YoRHa' }
    ]), m, { mentions: [user] });
  }

  await conn.groupParticipantsUpdate(m.chat, [user], 'remove')

  await conn.reply(m.chat, theme.build([
    { type: 'title', text: '✅ 2B: "تم تنفيذ مهمة الطرد"' },
    { type: 'divider' },
    { type: 'info', label: '🎯 الهدف', value: '@' + user.split('@')[0] },
    { type: 'info', label: '👤 المنفذ', value: '@' + m.sender.split('@')[0] },
    { type: 'divider' },
    { type: 'line', text: '🚫 تم إخراج الهدف من المجموعة' }
  ]), m, { mentions: [m.sender, user] });
}

handler.help = ['kick @user']
handler.tags = ['group']
handler.command = ['kick', 'طرد']
handler.admin = true
handler.group = true
handler.botAdmin = true

export default handler;