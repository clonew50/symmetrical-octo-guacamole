// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الـتـتـبـع┊ ˼‏ 🌍˹ ↶〕* *𝐆𝐎𝐉𝐎* ──¤﹝نـظـام تـتـبـع عـنـوان IP ↶﹞*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

import axios from 'axios'

const ipinfoToken = '882ffefc502ce1'; // مفتاحك

async function getIPInfo(ip) {
    try {
        const { data } = await axios.get(`https://ipinfo.io/${ip}/json?token=${ipinfoToken}`);
        return data;
    } catch (e) {
        console.log(e.message); return null;
    }
}

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❗ 〕إدخـال خـاطـئ*

*🌍┊طـريـقـة الاسـتـخـدام:*
*${usedPrefix + command} 8.8.8.8*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);

    await m.react('🕒')

    let ipInfo = await getIPInfo(text.trim())
    
    if (!ipInfo || ipInfo.error) {
        await m.react('❌')
        return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕لـم أتـمـكـن مـن جـلـب بـيـانـات* *${text}*\n> *تـأكـد مـن صـحـة الـ IP*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    }

    await m.react('✅')

    let msg = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـتـتـبـع┊ ˼‏ 🌍˹ ↶〕* *𝐆𝐎𝐉𝐎*

*🌐┊عـنـوان IP:* *${ipInfo.ip || 'مجهول'}*
*🖥️┊اسـم الـمـضـيـف:* *${ipInfo.hostname || 'غير معروف'}*
*🏙️┊الـمـديـنـة:* *${ipInfo.city || 'غير معروف'}*
*🗺️┊الـمـنـطـقـة:* *${ipInfo.region || 'غير معروف'}*
*🏳️┊الـبـلـد:* *${ipInfo.country || 'غير معروف'}*
*📮┊الـرمـز الـبـريـدي:* *${ipInfo.postal || 'غير معروف'}*
*🏢┊الـمـنـظـمـة:* *${ipInfo.org || 'غير معروف'}*
*⏰┊الـتـوقـيـت:* *${ipInfo.timezone || 'غير معروف'}*
*📍┊الإحـداثـيـات:* *${ipInfo.loc || 'غير معروف'}*

*🔗┊خـريـطـة:* https://www.google.com/maps/search/${ipInfo.loc || ''}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`

    return m.reply(msg)
}

handler.help = ['تتبع-ايبي']
handler.tags = ['ادوات']
handler.command = /^(trackip|getipinfo|تتبع-الاي-بي|اي-بي)$/i

export default handler