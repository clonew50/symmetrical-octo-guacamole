import fetch from 'node-fetch';

let regexRepo = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/([^\/:]+)(?:\/tree\/[^\/]+|\/blob\/[^\/]+)?(?:\/(.+))?/i;
let regexGist = /https:\/\/gist\.github\.com\/([^\/]+)\/([a-zA-Z0-9]+)/i;
let regexRawGitHub = /https:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/([^\/]+)\/(.+)/i;

let handler = async (m, { conn, args }) => {
    if (!args[0]) return m.reply(`*⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽*\n\n⚠️ *المرجو إدخال رابط GitHub*\n\n*مثال:*\n.gitclone https://github.com/user/repo`)

    let isRepo = regexRepo.test(args[0]);
    let isGist = regexGist.test(args[0]);
    let isRawGitHub = regexRawGitHub.test(args[0]);

    if (!isRepo &&!isGist &&!isRawGitHub) return m.reply('❌ *رابط غير صالح!*\nخاصو يكون رابط Repo او Gist او ملف Raw')

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    try {
        if (isRepo) {
            let [, user, repo] = args[0].match(regexRepo) || [];
            repo = repo.replace(/.git$/, '');
            let url = `https://api.github.com/repos/${user}/${repo}/zipball`;
            let res = await fetch(url, { method: 'HEAD' });
            let filename = res.headers.get('content-disposition').match(/attachment; filename=(.*)/)[1];

            await m.reply(`*📦 جاري تحميل المستودع...*\n*${user}/${repo}*`);
            await conn.sendMessage(m.chat, {
                document: { url: url },
                fileName: filename,
                mimetype: "application/zip",
                caption: `*⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽*\n\n*📁 المستودع:* ${user}/${repo}\n*🔗 المصدر:* ${args[0]}\n\n*© Developed by YONO DEV 🪖*`
            }, { quoted: m });

        } else if (isGist) {
            let [, user, gistId] = args[0].match(regexGist) || [];
            let url = `https://gist.github.com/${user}/${gistId}/download`;

            await m.reply(`*📝 جاري تحميل Gist...*\n*${gistId}*`);
            await conn.sendMessage(m.chat, {
                document: { url: url },
                fileName: `${gistId}.zip`,
                mimetype: "application/zip",
                caption: `*⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽*\n\n*📝 Gist:* ${gistId}\n*👤 المستخدم:* ${user}\n*🔗 المصدر:* ${args[0]}\n\n*© Developed by YONO DEV 🪖*`
            }, { quoted: m });

        } else if (isRawGitHub) {
            let [, user, repo, branch, filepath] = args[0].match(regexRawGitHub) || [];
            let url = `https://raw.githubusercontent.com/${user}/${repo}/${branch}/${filepath}`;
            let filename = filepath.split('/').pop();

            await m.reply(`*📄 جاري تحميل الملف...*\n*${filename}*`);
            await conn.sendMessage(m.chat, {
                document: { url: url },
                fileName: filename,
                mimetype: "application/octet-stream",
                caption: `*⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽*\n\n*📄 الملف:* ${filename}\n*📁 المستودع:* ${user}/${repo}\n*🌿 الفرع:* ${branch}\n*🔗 المصدر:* ${args[0]}\n\n*© Developed by YONO DEV 🪖*`
            }, { quoted: m });
        }
    } catch (e) {
        console.log(e)
        m.reply('❌ *فشل في التحميل*\nتأكد ان الرابط صحيح او المستودع عام')
    }
};

handler.help = ['gitclone <الرابط>'];
handler.tags = ['تحميل'];
handler.command = /^(gitclone|تحميل_قتهاب)$/i;
handler.limit = true;

export default handler