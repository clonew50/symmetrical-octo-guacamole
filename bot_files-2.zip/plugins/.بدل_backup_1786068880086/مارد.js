/*
كود لعبة المارد الازرق v2
by : ⚡_KAISER_
https://whatsapp.com/channel/0029Va8Y2DcLY6dENF4Jry0u
*/

import axios from "axios";
import pkg from "@whiskeysockets/baileys";
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg;

let handler = async function (m, { text, conn }) {
  if (!conn.aki) conn.aki = {};
  const sessionKey = `${m.chat}-${m.sender}`;
  const session = conn.aki[sessionKey];

  const api_obito = "https://obito-mr-apis.vercel.app/api/game";

  if (!text) {
    const buttons = [
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "📘 المساعدة", id: ".مارد المساعدة" }),
      },
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "🎮 بدء اللعبة", id: ".مارد ابدا" }),
      },
    ];

    const msg = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: proto.Message.InteractiveMessage.create({
              body: proto.Message.InteractiveMessage.Body.create({
                text: "🧞‍♂️ هل تريد بدء لعبة المارد؟",
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: "اختر احد الخيارات التالية :",
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false,
                title: "لعبة المارد الازرق..🧞\n\nBY: .⤹𝗔𝗕𝗗𝗢 𝗗𝗘𝗩 𝗘𝗟 𝗬𝗢𝗨𝗧𝗨𝗕𝗘𝗥⤾.",
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons,
              }),
            }),
          },
        },
      },
      {}
    );

    return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  }

  if (text === "المساعدة") {
    return m.reply(`📘 شرح أوامر لعبة مارد :\n\n🎮 .مارد ابدا → بدء اللعبة\n✅ .مارد نعم → إجابة نعم\n❌ .مارد لا → إجابة لا\n🤔 .مارد لا أعرف → إجابة لا أعرف\n💭 .مارد ربما → إجابة ربما\n🚫 .مارد ربما لا → إجابة ربما لا\n↩️ .مارد رجوع → الرجوع للسؤال السابق\n🗑️ .مارد حذف → حذف الجلسة الحالية`);
  }

  if (text === "ابدا") {
    try {
      const response = await axios.get(`${api_obito}/akinator_start`, {
        timeout: 30000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });

      let gameData;
      if (response.data.data) {
        gameData = response.data.data;
      } else if (response.data.session) {
        gameData = response.data;
      } else {
        throw new Error('هيكل بيانات غير معروف من API');
      }

      if (!gameData.session || !gameData.signature) {
        throw new Error('بيانات الجلسة غير مكتملة');
      }

      conn.aki[sessionKey] = {
        session: gameData.session,
        signature: gameData.signature,
        step: gameData.step || "0",
        progression: gameData.progression || "0",
        startedAt: Date.now()
      };

      return await sendQuestionWithButtons(m.chat, gameData.question, gameData.akitude_url || null, m, conn);

    } catch (err) {
      console.error('خطأ بدء اللعبة:', err.response?.data || err.message);
      return m.reply("❌ حدث خطأ أثناء بدء اللعبة. حاول مرة أخرى.");
    }
  }

  if (text === "حذف") {
    if (!session) return m.reply("⚠️ لا توجد جلسة نشطة");
    delete conn.aki[sessionKey];
    return m.reply("✅ تم حذف الجلسة بنجاح");
  }

  if (text === "رجوع") {
    if (!session) return m.reply("⚠️ لا توجد جلسة نشطة");
    try {
      const { data } = await axios.post(`${api_obito}/akinator_back`, {
        session: session.session,
        signature: session.signature,
        step: session.step,
        progression: session.progression,
        cm: "false",
      }, {
        timeout: 30000
      });

      if (data.step) conn.aki[sessionKey].step = data.step;
      if (data.progression) conn.aki[sessionKey].progression = data.progression;

      return await sendQuestionWithButtons(m.chat, data.question, data.akitude_url || null, m, conn);
    } catch (err) {
      console.error('خطأ الرجوع:', err.response?.data || err.message);
      return m.reply("❌ لا يمكن الرجوع حالياً.");
    }
  }

  const answers = { 
    "نعم": 0, 
    "لا": 1, 
    "لا أعرف": 2, 
    "ربما": 3, 
    "ربما لا": 4 
  };

  if (answers.hasOwnProperty(text)) {
    if (!session) return m.reply("⚠️ لا توجد جلسة نشطة حالياً، ابدأ جلسة عبر .مارد ابدا");

    try {
      const { data } = await axios.post(`${api_obito}/akinator_answer`, {
        session: session.session,
        signature: session.signature,
        step: session.step,
        progression: session.progression,
        answer: answers[text],
        cm: "false",
        sid: "NaN",
        question_filter: "string",
      }, {
        timeout: 30000
      });

      if (data.name_proposition) {
        delete conn.aki[sessionKey];
        
        let resultMessage = `🧞‍♂️ على ما أظن انك تفكر في:\n\n` +
                          `👤 **${data.name_proposition}**\n` +
                          `📝 ${data.description_proposition || "لا يوجد وصف"}`;
        
        if (data.photo) {
          return conn.sendMessage(
            m.chat,
            {
              image: { url: data.photo },
              caption: resultMessage,
            },
            { quoted: m }
          );
        } else {
          return m.reply(resultMessage);
        }
      }

      if (data.step) conn.aki[sessionKey].step = data.step;
      if (data.progression) conn.aki[sessionKey].progression = data.progression;

      return await sendQuestionWithButtons(m.chat, data.question, data.akitude_url || null, m, conn);
    } catch (err) {
      console.error('خطأ الإجابة:', err.response?.data || err.message);
      return m.reply("❌ حدث خطأ أثناء الإجابة.");
    }
  }

  return m.reply(`⚠️ أمر غير معروف. استخدم .مارد المساعدة للأوامر.`);
};

async function sendQuestionWithButtons(jid, question, imgUrl, quoted, conn) {
  try {
    const buttons = [
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "✅ نعم", id: ".مارد نعم" }),
      },
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "❌ لا", id: ".مارد لا" }),
      },
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "🤔 لا أعرف", id: ".مارد لا أعرف" }),
      },
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "💭 ربما", id: ".مارد ربما" }),
      },
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "🚫 ربما لا", id: ".مارد ربما لا" }),
      },
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "↩️ رجوع", id: ".مارد رجوع" }),
      },
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "🗑️ حذف", id: ".مارد حذف" }),
      },
    ];

    const msg = generateWAMessageFromContent(
      jid,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: proto.Message.InteractiveMessage.create({
              body: proto.Message.InteractiveMessage.Body.create({
                text: `🧞‍♂️ ${question}`,
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: "اختر الإجابة المناسبة:\n\nBY: ⚡_KAISER_🩸",
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false,
                title: "لعبة المارد الازرق..🧞",
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons,
              }),
            }),
          },
        },
      },
      {}
    );

    return await conn.relayMessage(jid, msg.message, { messageId: msg.key.id });

  } catch (e) {
    console.error('خطأ إرسال السؤال:', e);
    return conn.sendMessage(jid, { 
      text: `🧞‍♂️ ${question}\n\nاستخدم:\n.مارد نعم / لا / لا أعرف / ربما / ربما لا` 
    }, { quoted });
  }
}

handler.command = /^مارد$/i;
export default handler;