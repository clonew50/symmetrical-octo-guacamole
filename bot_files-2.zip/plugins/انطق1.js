// plugins/tts-nikolas.js
// ⧼ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚔️ ⧽

import axios from 'axios';
import delay from 'delay';
import { generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';

const TTS_LIST_API = 'https://obito-mr-apis.vercel.app/api/tts/voice/list';
const TTS_GEN_API = 'https://obito-mr-apis.vercel.app/api/tts/voice/tts';

const T = { 
    s: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`,
    d: `*♣️ ───━ •﹝📌﹞• ━───*`, 
    e: `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, 
    l: (t) => `> *〔 ⚔️ 〕 ${t}*` 
}

async function fetchArabicVoices() {
  try {
    const { data } = await axios.get(TTS_LIST_API, { timeout: 10000 });
    if (!data?.success) return [];
    return data.languages.filter(l => l.code.startsWith('ar-')).flatMap(lang => 
      lang.voices.map(v => ({ id: v.id, name: v.name, gender: v.gender === 'ذكر'? '♂️' : '♀️', langName: lang.name }))
    );
  } catch { return []; }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    if (command === 'انطق1') {
      if (!text) return m.reply(`${T.s}\n${T.l(`الاسـتـخـدام: ${usedPrefix}انطق1 النص`)}\n${T.e}`);
      await m.reply(`${T.s}\n${T.l("⏳ جـاري جـلـب الاصـوات...")}\n${T.e}`);
      const voices = await fetchArabicVoices(); 
      if (!voices.length) throw 'لـم اجـد اصـوات عـربـيـة';
      
      const rows = voices.slice(0, 10).map(v => ({ title: `${v.name} ${v.gender}`, description: v.langName, id: `${usedPrefix}اختر_لهجة ${v.id}|${encodeURIComponent(text)}` }));
      const msg = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: { text: `${T.s}\n${T.l("اخـتـر الـلـهـجـة")}\n${T.l(`"${text}"`)}\n${T.e}` },
          footer: { text: '𝐆𝐎𝐉𝐎-𝐁𝐎𝐓' },
          nativeFlowMessage: { buttons: [{ name: 'single_select', buttonParamsJson: JSON.stringify({ title: '⚔️ اخـتـر صـوت', sections: [{ title: '🎙️ الاصـوات الـعـربـيـة', rows }] }) }] }
      }) } } }, { userJid: conn.user.jid, quoted: m });
      return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }
    
    if (command === 'اختر_لهجة') {
      if (!text) return; 
      const [voiceId, encodedText] = text.split('|'); 
      const originalText = decodeURIComponent(encodedText);
      await m.react('⏳');
      await m.reply(`${T.s}\n${T.l("⏳ جـاري تـولـيـد الـصـوت...")}\n${T.e}`);
      
      const { data } = await axios.get(`${TTS_GEN_API}?txt=${encodeURIComponent(originalText)}&voice=${voiceId}`, { timeout: 20000 });
      if (!data?.success ||!data?.data?.audio_url) throw 'فـشـل تـولـيـد الـصـوت';
      
      await delay(1000); // انتظار 1ث باش السيرفر يرفع الصوت
      await conn.sendMessage(m.chat, { audio: { url: data.data.audio_url }, mimetype: 'audio/mpeg', ptt: true, fileName: `GOJO_TTS.mp3` }, { quoted: m });
      await m.react('✅');
    }
  } catch (err) { 
    await m.react('❌'); 
    m.reply(`${T.s}\n${T.l(`❌ ${err.message}`)}\n${T.e}`); 
  }
};

handler.help = ['انطق1 <النص>']; 
handler.tags = ['tools']; 
handler.command = /^(انطق1|اختر_لهجة)$/i;
export default handler;