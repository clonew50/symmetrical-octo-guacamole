// =================================================================
// • Plugin Name : التحقق من رقم واتساب
// • Bot Name : 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | غوجو بوت
// • Developer : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 — 212674375708
// • Version : v1.0.0
// • Channel : https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
// • Credit : izana, uncel shawaza
// =================================================================

import axios from 'axios'

const API_BASE = 'https://engez.a7a.online/api/v1'

async function checkNumber(number) {
    try {
        const params = new URLSearchParams()
        params.append('num', number)

        const response = await axios.get(`${API_BASE}/tools/checknum?${params.toString()}`, {
            timeout: 30000
        })

        if (!response.data?.success) {
            throw new Error(response.data?.error || 'فشل التحقق')
        }

        return response.data.response
    } catch (error) {
        throw new Error(error.message || 'فشل الاتصال')
    }
}

function formatNumber(num) {
    if (!num) return 'غير معروف'
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ')
}

const handler = async (m, { conn, text }) => {
    const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
    const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;
    const myCredit = `*🤖┊اسـم الـبـوت:* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*\n*👑┊الـمـطـور:* *𝐘𝐎𝐍𝐎 𝐃𝐄𝐕*\n*📢┊الـقـنـاة:* https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r`;

    if (!text) {
        return m.reply(`${startDeco}
🪖 ──¤﹝الـتـحـقـق مـن رقـم واتـسـاب ↶﹞
> *〔 📱 〕 الاسـتـخـدام:* .رقم 201222784295
> *〔 💡 〕 الـمـثـال:* .رقم 2126xxxxxxxx

> *〔 📌 〕 الـمـلاحـظـة:* دخـل الـرقـم بـدون + او اصفار
${myCredit}
${endDeco}`)
    }

    // تنظيف الرقم
    const cleanNumber = text.replace(/[^0-9]/g, '')

    if (!cleanNumber || cleanNumber.length < 10) {
        return m.reply(`${startDeco}\n> *〔 ❌ 〕 رقـم غـيـر صـحـيـح*\n> *يـرجـى ادخـال رقـم مـن 10 ارقـام عـلـى الاقـل*\n${endDeco}`)
    }

    await m.react('⏳')

    try {
        const result = await checkNumber(cleanNumber)

        let message = `${startDeco}
🪖 ──¤﹝نـتـيـجـة الـتـحـقـق ↶﹞
> *〔 📞 〕 الـرقـم:* ${result.e164 || result.phone || cleanNumber}
> *〔 🌍 〕 الـدولـة:* ${result.country || 'غـيـر مـعـروف'}
> *〔 🗣️ 〕 الـلـغـة:* ${result.language || 'غـيـر مـعـروف'}
> *〔 📊 〕 الـحـالـة:* ${result.status === 'registered' ? '🟢 مـسـجـل عـلـى واتـسـاب' : '🔴 غـيـر مـسـجـل'}`;

        if (result.message) {
            message += `\n\n> *〔 📝 〕 مـلاحـظـة:* ${result.message}`
        }

        if (result.raw?.summary?.fallback_methods) {
            const methods = result.raw.summary.fallback_methods
            message += `\n\n> *〔 🔐 〕 طـرق الـتـحـقـق الـمـتـاحـة:*`
            const methodNames = {
                'passkey': '🔑 مـفـتـاح مـرور',
                'wa_old': '📱 واتـسـاب قـديـم',
                'email_otp': '📧 كـود الـبـريـد',
                'flash': '⚡ فـلاش',
                'sms': '📨 رسـالـة نـصـيـة',
                'voice': '🎤 مـكـالـمـة صـوتـيـة'
            }
            methods.forEach(method => {
                message += `\n> • ${methodNames[method] || method}`
            })
        }

        message += `\n\n${myCredit}\n${endDeco}`

        await m.reply(message)
        await m.react('✅')

    } catch (error) {
        await m.react('❌')
        return m.reply(`${startDeco}\n> *〔 ❌ 〕 خـطـأ:* ${error.message}\n${endDeco}`)
    }
}

handler.command = ['رقم', 'checknum', 'تحقق-رقم']
handler.help = ['رقم <الرقم>']
handler.tags = ['🇲🇦الادوات🇲🇦']

export default handler