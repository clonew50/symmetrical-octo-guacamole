import axios from 'axios';
import { generateWAMessageFromContent, prepareWAMessageMedia } from '@whiskeysockets/baileys';

const regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i;
const GH_IMG = "https://i.ibb.co/Qj75sSjT/gojo-1784553039843.jpg";

const FRAME_TOP = `⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞
≪  ❪ ♾️ ⚡_KAISER_ 𝑩𝑶𝑻 ✅ ♾️ ❫ ≫
      ⛩️ ⚡_KAISER_ ・ 𝑩𝑶𝑻 ⛩️
≪ ━ ❪ 🩸 𝐆𝐈𝐓𝐇𝐔𝐁 𝐇𝐔𝐍𝐓𝐄𝐑 🩸 ❫ ━ ≫
⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞`;

const FRAME_BOTTOM = `⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞
╰─── ≪ ❪ 🩸 ♾️ 🩸 ❫ ≫ ───╯
◜⏤͟͟͞͞ ⚡_KAISER_ ⚡ 𝑩𝑶𝑻 ˖࣪⃟🩸 ◞`;

// ✅ **البحث في GitHub**
const searchGitHub = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return conn.sendMessage(m.chat, {
    image: { url: GH_IMG },
    caption: `${FRAME_TOP}
╟「 🚨 」↬ يرجى إدخال اسم المشروع للبحث في GitHub
╟「 📌 」↬ مثال: ${usedPrefix + command} WhatsApp-Bot
${FRAME_BOTTOM}`
  }, { quoted: m });

  await conn.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

  try {
    const url = `https://api.github.com/search/repositories?q=${encodeURIComponent(text)}&per_page=100`;
    const { data } = await axios.get(url);

    if (!data.items.length) throw "لم يتم العثور على أي مستودع مطابق";

    let sections = data.items.map((repo) => ({
      title: `⏤͟͟͞͞💠⏤͟͟͞͞ ${repo.name} ⏤͟͟͞͞💠⏤͟͟͞͞`,
      rows: [
        {
          title: "╟「 📥 」↬ تحميل المستودع",
          description: `╟「 ⭐ 」↬ ${repo.stargazers_count}  ╟「 🍴 」↬ ${repo.forks_count}  ╟「 👤 」↬ ${repo.owner.login}`,
          id: `${usedPrefix}جيتهاب2 ${repo.html_url}`
        }
      ]
    }));

    const listMedia = await prepareWAMessageMedia(
      { image: { url: GH_IMG } },
      { upload: conn.waUploadToServer }
    );

    const interactiveMessage = {
      body: { text: `${FRAME_TOP}\n╟「 🔎 」↬ تم العثور على ${data.items.length} مستودع\n╟「 📂 」↬ اختر المستودع المطلوب للتحميل\n${FRAME_BOTTOM}` },
      footer: { text: "⏤͟͟͞͞💠⏤͟͟͞͞ ⚡_KAISER_ 𝑩𝑶𝑻 ・ 𝑮𝒊𝒕𝑯𝒖𝒃 𝑺𝒆𝒂𝒓𝒄𝒉 ⏤͟͟͞͞💠⏤͟͟͞͞" },
      header: { hasMediaAttachment: true, ...listMedia },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
              title: '⏤͟͟͞͞💠⏤͟͟͞͞ ≪❪🩸 قائمة المستودعات 🩸❫≫ ⏤͟͟͞͞💠⏤͟͟͞͞',
              sections
            })
          }
        ],
        messageParamsJson: ''
      }
    };

    let msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: { message: { interactiveMessage } }
    }, { userJid: conn.user.jid, quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  } catch (error) {
    conn.sendMessage(m.chat, {
      image: { url: GH_IMG },
      caption: `${FRAME_TOP}
╟「 ❌ 」↬ حدث خطأ أثناء البحث في GitHub
╟「 ⚠️ 」↬ التفاصيل: ${error.message || error}
${FRAME_BOTTOM}`
    }, { quoted: m });
  }
};

// ✅ **تحميل المستودع مباشرة**
const downloadGitHubRepo = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) return conn.sendMessage(m.chat, {
    image: { url: GH_IMG },
    caption: `${FRAME_TOP}
╟「 🚨 」↬ يرجى إدخال رابط المستودع للتحميل
╟「 📌 」↬ مثال: ${usedPrefix + command} https://github.com/user/repo
${FRAME_BOTTOM}`
  }, { quoted: m });

  if (!regex.test(args[0])) throw "الرابط المدخل غير صحيح، تأكد من أنه رابط GitHub صالح";

  let [_, user, repo] = args[0].match(regex) || [];
  repo = repo.replace(/.git$/, '');
  const url = `https://api.github.com/repos/${user}/${repo}/zipball`;

  try {
    await conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } });

    await conn.sendMessage(m.chat, {
      document: { url },
      mimetype: 'application/zip',
      fileName: `${repo}.zip`,
      caption: `${FRAME_TOP}
╟「 📂 」↬ تم تحميل المستودع من GitHub
╟「 🔗 」↬ الرابط: ${args[0]}
${FRAME_BOTTOM}`
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '✔️', key: m.key } });

  } catch (error) {
    conn.sendMessage(m.chat, {
      image: { url: GH_IMG },
      caption: `${FRAME_TOP}
╟「 ❌ 」↬ حدث خطأ أثناء تحميل المستودع
╟「 ⚠️ 」↬ التفاصيل: ${error.message || error}
${FRAME_BOTTOM}`
    }, { quoted: m });
  }
};

// ✅ **دمج أوامر البحث والتحميل**
const handler = async (m, context) => {
  const { usedPrefix, command } = context;
  if (command === 'جيتهاب') return searchGitHub(m, context);
  if (command === 'جيتهاب2') return downloadGitHubRepo(m, context);
};

handler.command = /^(جيتهاب|جيتهاب2)$/i;
export default handler;