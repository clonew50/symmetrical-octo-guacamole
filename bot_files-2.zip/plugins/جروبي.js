/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: جروبي - بصورة المجموعة الحقيقية
 * 📢 القناة: https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

let handler = async (m, { conn }) => {
    if (!m.isGroup) return m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *للمجموعات فقط*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)

    try {
        let metadata = await conn.groupMetadata(m.chat)
        let participants = metadata.participants
        
        let ppUrl
        try {
            // هادي كتجيب صورة المجموعة الحقيقية
            ppUrl = await conn.profilePictureUrl(m.chat, 'image')
        } catch {
            ppUrl = null
        }

        let chat = global.db.data.chats[m.chat] || {}

        let list = {
            "الترحيب": chat.welcome,
            "انتي لينك": chat.antiLink,
            "انتي سبام": chat.antiSpam,
            "انتي فيروس": chat.antiVirtex,
            "انتي بوت": chat.antiBot,
            "الكشف": chat.detect,
            "الالعاب": chat.game,
            "الاقتصاد": chat.economy
        }

        let txtList = Object.entries(list).map(([k,v]) => 
            `> *${v ? '🟢 مـفـعـل' : '🔴 مـعـطـل'}┊* ${k}`
        ).join('\n')

        let caption = 
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 👥 〕 ${metadata.subject}*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *

> *🆔┊الايدي:* ${metadata.id}
> *👥┊العدد:* ${participants.length} عضو
> *👑┊المشرفين:* ${participants.filter(a=>a.admin).length}
> *📝┊الوصف:* ${metadata.desc ? metadata.desc.slice(0,100) : 'لا يوجد'}

* ━ ╼╃ ⌬〔 ⚙️ 〕⌬ ╄╾ ━ *
${txtList}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`

        if (ppUrl) {
            await conn.sendFile(m.chat, ppUrl, 'pp.jpg', caption, m)
        } else {
            // إلا المجموعة ما عندهاش صورة
            await conn.reply(m.chat, caption + `\n\n> *⚠️┊المجموعة بدون صورة*`, m)
        }

    } catch (e) {
        console.log(e)
        m.reply(`❌ خطأ: ${e.message}`)
    }
}

handler.help = ['جروبي']
handler.tags = ['جروب']
handler.command = /^(جروبي|جروب|grouppic)$/i
handler.group = true

export default handler