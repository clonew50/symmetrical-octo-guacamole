// plugins/bot.js
// ♡ Raiden Shogun - Plane of Euthymia - Bot Info 🔘

import { ButtonV2 } from '../core/NIXCODE.js'

let handler = async (m, { conn }) => {

    const imageUrl = 'https://file.garden/aauvg01sjleV_ic1/8f3a25b845b67600e281e41fa981dbb3.jpg'

    await new ButtonV2(conn)
        .setBody(global.botName)
        .setFooter(global.watermark)
        .setThumbnail(imageUrl)
        .addButton('📂 الـقـائـمـة', '.اوامر')
        .addButton('👑 الـمـطـور', '.المطور')
        .send(m.chat)

}

handler.customPrefix = /^(\.)?(بوت|bot)$/i
handler.command = new RegExp()

export default handler