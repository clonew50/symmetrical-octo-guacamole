/*▲ حـقـوق الـتـطـويـر والـتـعـديـل ▲
 * 👤 المالك والمطور: SONIC EL GHADAR (محمد)
 * 👤 المطور الثانوي: Zyro core (الياس) 🦇
 * 🎯 المشروع: SonicBot-MD v1.8.3
 * 📝 الوظيفة: إضافة Meta AI مع معالجة ذكية لخطأ تقييد الحساب (account_reachout_restricted)
 * 📢 القناة: https://whatsapp.com/channel/0029Vb7On131NCrU8Di4Ev1z
 */

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    const groupJid = m.chat;

    if (!groupJid.endsWith("@g.us")) {
      return m.reply("❌ *هذا الأمر يعمل داخل المجموعات فقط!*");
    }

    // إرسال تفاعل الانتظار
    await m.react('⏳');

    // محاولة إضافة Meta AI
    const res = await conn.groupParticipantsUpdate(
      groupJid,
      ["867051314767696@bot"],
      "add"
    );

    await m.react('✅');
    m.reply("🏯 *تمت إضافة Meta AI إلى المجموعة بنجاح!* ✅");

  } catch (e) {
    console.error(e);
    await m.react('❌');

    const errorStr = String(e?.stack || e);

    if (errorStr.includes("account_reachout_restricted")) {
      return m.reply(
`╭━━━━━━━ 〔 ⚠️ تـقـيـيـد الـحـسـاب 〕 ━━━━━━━╮

❌ *فشل الإجراء بسبب قيود الحماية من واتساب!*

💡 *السبب:* حساب البوت الخاص بك لديه تقييد مؤقت من واتساب يمنعه من إضافة الأرقام أو البوتات الرسمية مباشرة لتجنب السبام (Spam).

🛠️ *الحل:* 
1️⃣ جرب جعل البوت مشرفاً (Admin) في المجموعة أولاً ثم أعد المحاولة.
2️⃣ إذا لم ينجح، انتظر بضع ساعات حتى ترفع واتساب القيود التلقائية عن رقمك.

╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`
      );
    }

    // في حال وجود أي خطأ آخر
    m.reply(`❌ *حدث خطأ غير متوقع:*\n\`\`\`${e.message || e}\`\`\``);
  }
};

handler.command = /^(addmeta|ضيف-ميتا)$/i;
handler.help = ['ضيف-ميتا'];
handler.tags = ['group'];
export default handler;