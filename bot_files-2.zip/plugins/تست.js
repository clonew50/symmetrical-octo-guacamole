import { generateWAMessageContent } from "@whiskeysockets/baileys";
import axios from 'axios';
import fs from 'fs';

const neura = async (m, { conn }) => {
    try {
        await conn.sendMessage(m.chat, { react: { text: '🕷️', key: m.key } })

        // 6 فيديوهات عشوائية
        const videos = [
            'https://files.catbox.moe/jzbdkc.mp4',
            'https://files.catbox.moe/hgkawr.mp4',
            'https://files.catbox.moe/5687tr.mp4',
            'https://files.catbox.moe/0e0jlx.mp4',
            'https://files.catbox.moe/x8kpz1.mp4',
            'https://files.catbox.moe/9frc5p.mp4'
        ];

        const videoUrl = videos[Math.floor(Math.random() * videos.length)];
        
        const response = await axios({
            method: 'get',
            url: videoUrl,
            responseType: 'arraybuffer'
        });
        
        const tempPath = './temp_video.mp4';
        fs.writeFileSync(tempPath, Buffer.from(response.data));
        
        const msg = await generateWAMessageContent({
            video: { url: tempPath }
        }, {
            upload: conn.waUploadToServer
        });
        
        msg.videoMessage.contextInfo = {
            isForwarded: true,
            forwardingScore: 999,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363428598542954@newsletter',
                serverMessageId: 1,
                newsletterName: '🕷️⃝⃕𝆺𝅥 CHANLE 𝗕𝗢𝗧 𝆹َ𝅥🕷️',
            }
        }

        await conn.relayMessage(m.chat, {
            ptvMessage: msg.videoMessage
        }, {});
        
        fs.unlinkSync(tempPath);
        
    } catch (error) {
        console.error('خطأ:', error);
        try {
            if (fs.existsSync('./temp_video.mp4')) {
                fs.unlinkSync('./temp_video.mp4');
            }
        } catch (e) {}
    }
};

neura.help = ['تست'];
neura.tags = ['tester_plugins'];

neura.customPrefix = /^(تست|تيست|test)$/i
neura.command = new RegExp

export default neura;