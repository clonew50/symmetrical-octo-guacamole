/* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO DEV
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | نظام البلاغات الاحترافي
 * 📦 الوظيفة: ابلاغ عن مشكلة / شخص / اقتراح / خطأ
 * 🖼️ الصورة الجديدة: https://files.catbox.moe/zus936.jpeg
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 REPORT SYSTEM 〕⌬ ╄╾ ━
 */

import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

let handler = async (m, { conn, usedPrefix, command, text, args }) => {
    const imageUrl = 'https://files.catbox.moe/zus936.jpeg';
    const developerJid = '212674375708@s.whatsapp.net';
    const channelLink = 'https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r';

    // --- 1 - إذا كتب بلاغ مباشر:.ابلاغ مشكلة في امر الطقس ---
    if (text &&!text.includes('ابلاغ_نوع')) {
        let reportContent = text.trim();
        if (reportContent.length < 10) return m.reply(`* ━ ╼╃ ⌬〔 ❌ 〕⌬ ╄╾ ━ *\n\n> *البلاغ قصير جداً، اشرح المشكلة أكثر (10 أحرف على الأقل)*\n\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);

        let reportId = Math.floor(100000 + Math.random() * 900000);
        let date = new Date().toLocaleString('ar-MA', { timeZone: 'Africa/Casablanca' });

        // رسالة للمطور
        let devText = `* ━ ╼╃ ⌬〔 بلاغ جديد 🚨 〕⌬ ╄╾ ━ *\n\n` +
            `> *🆔┊رقم البلاغ:* \`#${reportId}\`\n` +
            `> *📅┊التاريخ:* ${date}\n` +
            `> *👤┊المبلغ:* @${m.sender.split('@')[0]}\n` +
            `> *📱┊الرقم:* wa.me/${m.sender.split('@')[0]}\n` +
            `> *💬┊نص البلاغ:*\n> ${reportContent}\n\n` +
            `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 REPORT 〕⌬ ╄╾ ━ *`;

        await conn.sendMessage(developerJid, { text: devText, mentions: [m.sender] }).catch(() => {});
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        return await conn.reply(m.chat,
            `* ━ ╼╃ ⌬〔 تم استلام بلاغك ✅ 〕⌬ ╄╾ ━ *\n\n` +
            `> *🆔┊رقم البلاغ:* \`#${reportId}\`\n` +
            `> *📌┊الحالة:* قيد المراجعة من طرف المطور\n` +
            `> *⏰┊سيتم الرد عليك قريباً*\n\n` +
            `> *شكراً لمساهمتك في تطوير 𝐆𝐎𝐉𝐎* 💎\n\n` +
            `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`, m);
    }

    // --- 2 - إذا اختار نوع من القائمة ---
    if (text && text.includes('ابلاغ_نوع')) {
        let type = text.split('|')[1]?.trim() || 'عام';
        return await conn.reply(m.chat,
            `* ━ ╼╃ ⌬〔 📝 كتابة البلاغ 〕⌬ ╄╾ ━ *\n\n` +
            `> *اخترت نوع:* \`${type}\`\n\n` +
            `> الآن أرسل بلاغك بهذه الصيغة:\n` +
            `> \`${usedPrefix}ابلاغ ${type} - وصف المشكلة هنا\`\n\n` +
            `> *مثال:*\n> \`${usedPrefix}ابلاغ ${type} - البوت ما يرد في قروب كذا\`\n\n` +
            `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m);
    }

    // --- 3 - عرض لوحة البلاغات الاحترافية ---
    try {
        await conn.sendMessage(m.chat, { react: { text: '🚨', key: m.key } });

        const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer });

        let bodyText =
            `* ━ ╼╃ ⌬〔 🚨 〕⌬ ╄╾ ━ *\n` +
            `*〔 ♛ 𝐆𝐎𝐉𝐎 〕 ↜ مركز البلاغات والاقتراحات ↝* 👑\n\n` +
            `*------------------------------------------------*\n` +
            `*\`↯˹💎˼↯\` ↜ صوتك مهم جداً ↝*\n` +
            `> *“كل بلاغ منك هو خطوة نحو بوت أسطوري خالٍ من الأخطاء.”*\n\n` +
            `> *👥┊عزيزي المستخدم:*\n` +
            `> واجهت مشكلة؟ خطأ في أمر؟ شخص يزعج؟\n` +
            `> عندك اقتراح رهيب؟ نحن نسمعك.\n` +
            `> اختر نوع البلاغ من الأسفل وسيصل للمطور مباشرة.\n\n` +
            `> *⚠️┊تنبيه:* البلاغات الكاذبة يعاقب عليها بحظر\n` +
            `*------------------------------------------------*\n` +
            `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 REPORT SYSTEM 〕⌬ ╄╾ ━*`.trim();

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: {
                        body: { text: bodyText },
                        footer: { text: '『 🚨 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | REPORT CENTER | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 💎 』' },
                        header: { hasMediaAttachment: true,...media },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: 'single_select',
                                    buttonParamsJson: JSON.stringify({
                                        title: '🚨 اختر نوع البلاغ',
                                        sections: [{
                                            title: '📋 أنواع البلاغات المتاحة',
                                            highlight_label: '𝐆𝐎𝐉𝐎 PRO',
                                            rows: [
                                                { header: '🐛 خلل تقني', title: 'ابلاغ عن خطأ في البوت', description: 'أمر لا يعمل، تعليق، خطأ', id: `${usedPrefix}${command} ابلاغ_نوع|🐛 خلل تقني` },
                                                { header: '👤 بلاغ مستخدم', title: 'الابلاغ عن شخص مسيء', description: 'سب، إزعاج، تخريب', id: `${usedPrefix}${command} ابلاغ_نوع|👤 مستخدم مسيء` },
                                                { header: '💡 اقتراح', title: 'اقتراح ميزة جديدة', description: 'عندك فكرة رهيبة للبوت؟', id: `${usedPrefix}${command} ابلاغ_نوع|💡 اقتراح جديد` },
                                                { header: '⏰ تأخير / بطء', title: 'البوت بطيء أو لا يرد', description: 'تأخر في الاستجابة', id: `${usedPrefix}${command} ابلاغ_نوع|⏰ بطء في الرد` },
                                                { header: '🔞 محتوى مخالف', title: 'محتوى غير لائق', description: 'صور أو كلام مخالف', id: `${usedPrefix}${command} ابلاغ_نوع|🔞 محتوى مخالف` },
                                                { header: '📝 بلاغ عام', title: 'بلاغ عام / آخر', description: 'أي شيء آخر', id: `${usedPrefix}${command} ابلاغ_نوع|📝 بلاغ عام` }
                                            ]
                                        }]
                                    }),
                                },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👨🏻‍💻 تواصل مباشر مع YONO", id: ".المطور" }) },
                                { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "📢 قناة الدعم", url: channelLink, merchant_url: channelLink }) }
                            ]
                        }
                    }
                }
            }
        }, { userJid: m.chat, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: `*🚨 مركز البلاغات - 𝐆𝐎𝐉𝐎* 👑\n\n> لعمل بلاغ اكتب:\n> \`.ابلاغ وصف مشكلتك هنا\`\n\n> مثال:\n> \`.ابلاغ امر الصورة لا يعمل\``,
        }, { quoted: m });
    }
};

handler.help = ['ابلاغ', 'بلاغ'];
handler.tags = ['main', 'support'];
handler.command = /^(ابلاغ|بلاغ|report|ابلغ)$/i;

export default handler;