const config = {

  botName: "𝖩𝗎𝗇𝖩𝗂𝗎𝗎 - 𝖻𝗈𝗍",
  botVersion: "2.0.0",
  botOwner: "𝐽𝑢𝑛𝑛𝑍𝑖𝑦𝑎",
  ownerNumber: ["6283878929540"], // Ganti nomor owner
  ownerName: "𝖛𝖎𝖙𝖆𝖆 - 𝖎𝖒𝖚𝖙",
  
  prefix: ".",
  sessionName: "vita-session",
  pairingNumber: "6285143871865", // Ganti nomor pairing
  usePairingCode: true,
  
  timezone: "Asia/Jakarta",
  locale: "id",
  
  maxDownloadSize: 100, // MB
  maxGroupMember: 1024,
  antiSpam: true,
  antiSpamTime: 3000, // ms
  antiLink: true,
  antiFlood: true,
  
  database: {
    users: "./database/users.json",
    groups: "./database/groups.json",
    stats: "./database/stats.json",
    afk: "./database/afk.json",
    warn: "./database/warn.json",
    economy: "./database/economy.json",
    rpg: "./database/rpg.json",
  },
  
  apis: {
    
    openaiProxy: "https://api.openai-proxy.com/v1",         
    blackboxAI: "https://www.blackbox.ai/api/chat",         
    geminiProxy: "https://generativelanguage.googleapis.com", 
    groqFree: "https://api.groq.com/openai/v1",    
    
    pollinations: "https://image.pollinations.ai/prompt/",     
    lexica: "https://lexica.art/api/v1/search",             
    
    tikwm: "https://www.tikwm.com/api/",                     
    ssytmp3: "https://ssyoutube.com/api/",                 
    cobalt: "https://cobalt.tools/api/json",               
    wttr: "https://wttr.in/",                                 
    exchangeRate: "https://api.exchangerate-api.com/v4/latest/", 
    ipapi: "https://ipapi.co/",      
    
    jikan: "https://api.jikan.moe/v4/",                     
    kitsu: "https://kitsu.io/api/edge/",                 
    removeBg: "https://www.remove.bg/api/v1.0/",             
    stickerApi: "https://sticker-api.onrender.com/",         
    
    equran: "https://equran.id/api/v2/",                       
    aladhan: "https://api.aladhan.com/v1/",                   
    
    danbooru: "https://danbooru.donmai.us/",                 
    waifu: "https://api.waifu.pics/",                         
    nekosia: "https://api.nekosia.cat/api/v1/",             
    
    lastfm: "https://ws.audioscrobbler.com/2.0/",             
    
    gnews: "https://gnews.io/api/v4/",                      
    
    github: "https://api.github.com/",                        
    catFact: "https://catfact.ninja/fact",               
    dogApi: "https://dog.ceo/api/",                    
    advice: "https://api.adviceslip.com/advice",        
    joke: "https://official-joke-api.appspot.com/",      
    quote: "https://api.quotable.io/",                
    hoaxBuster: "https://hoax-buster.vercel.app/api/",
    sirekap: "https://sirekap-obj-data.kpu.go.id/",
  },
  
  groqApiKey: "gsk_FREE_REGISTER_AT_GROQ_COM",
  
  colors: {
    primary: "#FF69B4",    
    secondary: "#9B59B6", 
    success: "#2ECC71",
    error: "#E74C3C",
    warning: "#F39C12",
    info: "#3498DB",
  },
  
  footer: "𝘃𝗶𝘁𝗮𝗮 - 𝗠𝗗",
  header: "╭─「 *VITA BOT* 」\n",
  
  features: {
    autoRead: false,
    autoTyping: true,
    autoRecording: false,
    autoReject: false,
    autoAcceptInvite: false,
    selfReply: false,
    logToOwner: true,
  },
  
  reacts: {
    wait: "⏳",
    success: "✅",
    error: "❌",
    love: "🌸",
    cool: "😎",
  }
}

module.exports = config