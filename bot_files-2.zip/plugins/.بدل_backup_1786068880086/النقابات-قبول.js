import fs from 'fs'
import fetch from 'node-fetch'
import { jidDecode } from '@whiskeysockets/baileys'

const decode = jid => {
  try {
    const d = jidDecode(jid)
    if (d && d.user) return d.user + '@s.whatsapp.net'
  } catch (e) {}
  return (jid || '').split('@')[0] + '@s.whatsapp.net'
}

let handler = async (m, { conn, args, config }) => {
  try {
    const sender = decode(m.sender) // ex: 12345@s.whatsapp.net
    const senderId = sender.split('@')[0]

    const channelId = (config && (config.cenel?.id || config.channel?.id)) || '120363411035938060@newsletter'
    const channelName = (config && (config.cenel?.name || config.channel?.name)) || '◜⚡_KAISER_┊🩸┊𝐂𝐇𝐀𝐍𝐍𝐄𝐋◞'
    const thumbnailUrl = config?.img?.nekobot || 'https://files.catbox.moe/f92wmw.jpg'

    const fk = {
      key: { participant: '0@s.whatsapp.net', remoteJid: 'status@broadcast', id: 'Anya' },
      message: {
        contactMessage: {
          displayName: '✦˚₊·—̳͟͞🌀  ⚡_KAISER_ ⃝🩸☠️︎̳͟͞—·₊˚✦',
          vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Rem Bot\nitem1.TEL;waid=${senderId}:${senderId}\nEND:VCARD`
        }
      }
    }

    const send = async (chat, text) => {
      return await conn.sendMessage(chat,
        { text, contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            forwardingScore: 9999,
            forwardedNewsletterMessageInfo: {
              newsletterJid: channelId,
              serverMessageId: 20,
              newsletterName: channelName
            },
            externalAdReply: {
              title: "◜⚡_KAISER_┊🩸┊𝐁𝐎𝐓◞",
              body: "BY :.⤹𝗔𝗕𝗗𝗢 𝗗𝗘𝗩 𝗘𝗟 𝗬𝗢𝗨𝗧𝗨𝗕𝗘𝗥⤾.",
              thumbnailUrl,
              mediaType: 1
            }
        } },
        { quoted: fk }
      )
    }

    if (!m.chat || !m.chat.endsWith('@g.us')) 
      return await send(m.chat, 'يسطا انت جاي في الخاص؟')

    const meta = await conn.groupMetadata(m.chat)
  
    const mePart = meta.participants.find(p => (p.id === sender) || (decode(p.id) === sender) || (p.jid === sender))
    const isAdmin = mePart && (mePart.admin === 'admin' || mePart.admin === 'superadmin' || mePart.isAdmin || mePart.isSuperAdmin || mePart.admin === true)

    if (!isAdmin)
      return await send(m.chat, '.')

    if (!args || !args[0])
      return await send(m.chat, 'استخدم:\n.قبول الكل\n.قبول 10')

   
    if (typeof conn.groupRequestParticipantsList !== 'function' || typeof conn.groupRequestParticipantsUpdate !== 'function') {
      console.error('Baileys: missing groupRequestParticipantsList or groupRequestParticipantsUpdate methods on conn')
      return await send(m.chat, '❌ نسخة البايليز ما تدعم دوال قبول الطلبات بهذه الطريقة')
    }

    let requests = await conn.groupRequestParticipantsList(m.chat)
    if (!requests || !requests.length)
      return await send(m.chat, '❌ مفيش طلبات انضمام يا عم.')

    let count = 0
    if (args[0] === 'الكل' || args[0] === 'الكلّ' || args[0] === 'all') count = requests.length
    else count = parseInt(args[0].replace(/[^0-9]/g, '')) || 0

    if (count <= 0)
      return await send(m.chat, '❌ رقم غلط')

    if (count > requests.length) count = requests.length

    const accept = requests.slice(0, count).map(v => v.jid || v) 

    await conn.groupRequestParticipantsUpdate(m.chat, accept, 'approve')
    return await send(m.chat, `✅ اتقبل (${count}) طلب`)

  } catch (e) {
    console.error('Handler error:', e)
    return await conn.sendMessage(m.chat, { text: `❌ خطأ: ${e.message || e}` }, { quoted: m })
  }
}

handler.command = ['قبول', 'اقبل', 'اقبل_طلبات_انضمام']
export default handler