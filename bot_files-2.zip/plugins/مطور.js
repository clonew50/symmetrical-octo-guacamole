import { generateWAMessageContent, proto, generateWAMessageFromContent } from "@whiskeysockets/baileys"
import axios from 'axios'
import fs from 'fs'

let handler = async (m, { conn }) => {
    try {
        await conn.sendMessage(m.chat, { react: { text: '👑', key: m.key } })

        const ownerNumber = '212674375708'
        const ownerName = 'YONO DEV 🪖'
        const channelLink = 'https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r'
        const channelJid = '120363428598542954@newsletter'

        // ===== 1 - كرت موثق =====
        const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${ownerName}
ORG:YONO DEV;
TEL;type=CELL;type=VOICE;waid=${ownerNumber}:+${ownerNumber}
X-WA-BIZ-NAME:${ownerName}
END:VCARD`.trim()

        await conn.sendMessage(m.chat, {
            contacts: { displayName: ownerName, contacts: [{ vcard }] },
            contextInfo: {
                isForwarded: true,
                forwardingScore: 999,
                forwardedNewsletterMessageInfo: { newsletterJid: channelJid, newsletterName: 'GOJO BOT 🕷️', serverMessageId: 1 },
                businessMessageForwardInfo: { businessOwnerJid: `${ownerNumber}@s.whatsapp.net` },
                verifiedBizName: ownerName
            }
        }, { quoted: m })

        await new Promise(r => setTimeout(r, 600))

        // ===== 2 - ptv =====
        const videoUrl = 'https://files.catbox.moe/9nhidm.mp4'
        const res = await axios.get(videoUrl, { responseType: 'arraybuffer' })
        const tmp = './temp_ptv.mp4'
        fs.writeFileSync(tmp, Buffer.from(res.data))
        const ptv = await generateWAMessageContent({ video: { url: tmp } }, { upload: conn.waUploadToServer })
        ptv.videoMessage.contextInfo = {
            isForwarded: true,
            forwardingScore: 999,
            forwardedNewsletterMessageInfo: { newsletterJid: channelJid, newsletterName: ownerName, serverMessageId: 1 },
            businessMessageForwardInfo: { businessOwnerJid: `${ownerNumber}@s.whatsapp.net` },
            verifiedBizName: ownerName
        }
        await conn.relayMessage(m.chat, { ptvMessage: ptv.videoMessage }, {})
        try { fs.unlinkSync(tmp) } catch {}

        await new Promise(r => setTimeout(r, 700))

        // ===== 3 - الرسالة الأخيرة - بزخرفة GOJO BOT =====
        const zkhrafa_top = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`
        const zkhrafa_bottom = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`

        const textInfo = `${zkhrafa_top}
> *〔 مـعـلـومـات الـمـطـور┊ ˼‏ 🪖˹ ↶〕*

*🪖 ──¤﹝الـمـطـور الـوحـيـد ↶ 💀﹞*
> *🥷🏻┊.الاسم: YONO DEV*
> *🥷🏻┊.الرقم: +${ownerNumber}*
> *🥷🏻┊.البوت: GOJO BOT 🕷️*
> *🥷🏻┊.الدولة: Morocco 🇲🇦*
> *🥷🏻┊.الحالة: مطور موثق ✅*

${zkhrafa_bottom}
> اضغط على الأزرار بالأسفل ⬇️`

        let content = {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: textInfo }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: '🪖 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 - By YONO DEV ✅' }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📢 قناة المطور",
                                        url: channelLink
                                    })
                                },
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: `📞 رقم المطور +${ownerNumber}`,
                                        url: `https://wa.me/${ownerNumber}`
                                    })
                                }
                            ]
                        }),
                        contextInfo: {
                            isForwarded: false,
                            businessMessageForwardInfo: { businessOwnerJid: `${ownerNumber}@s.whatsapp.net` },
                            verifiedBizName: ownerName
                        }
                    })
                }
            }
        }

        let msg = generateWAMessageFromContent(m.chat, content, { quoted: m, userJid: m.chat })
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

    } catch (e) {
        console.log(e)
        // fallback
        try {
            await conn.sendMessage(m.chat, {
                text: `*🪖 𝐆𝐎𝐉𝐎 𝐃𝐄𝐕*\n📞 +212674375708\n\n📢 القناة: ${channelLink}\n📞 رقمي: https://wa.me/${ownerNumber}`,
            }, { quoted: m })
        } catch {}
    }
}

handler.help = ['المطور','مطور']
handler.tags = ['main']
handler.command = /^(المطور|مطور|owner|dev)$/i
export default handler