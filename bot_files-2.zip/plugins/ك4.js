import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'
import { performance } from 'perf_hooks'

global.lastMenuVideo = global.lastMenuVideo || null

function getRandomNotSame(arr, last) {
    let filtered = arr.filter(v => v!== last)
    if(filtered.length === 0) filtered = arr
    return filtered[Math.floor(Math.random() * filtered.length)]
}

let handler = async (m, { conn }) => {
  try {
    let old = performance.now()
    let neww = performance.now()
    let speed = (neww - old).toFixed(2)

    const now = new Date(new Date() + 3600000)
    let locale = 'ar';
    let date = now.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
    let dayName = now.toLocaleDateString(locale, { weekday: 'long' });

    const devNumber = '212674375708';
    const devName = '𝑌𝑂𝑁𝑂 👑';

    const menuText = `
* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 قـسـم الـبـحـث┊ ˼‏ 🔍˹ ↶〕*

*🪖 ──¤﹝بـيـانـات الـقـسـم ↶ 🕸️﹞*
> *🥷🏻┊الـقـسـم:* 〘 الـبـحـث 〙
> *🥷🏻┊عـدد الاوامـر:* 〘 6 〙
> *🥷🏻┊الـيـوم:* ${dayName}
> *🥷🏻┊الـتـاريـخ:* ${date}
> *🥷🏻┊الـبـنـق:* 〘 ${speed}ms 〙

*♣️ ───━ •﹝📌﹞• ━───*
*◌────────────────◌*
*┃ 🗃 اوامــر الـبـحـث*
*◌────────────────◌*
> *🔎┊جـوجـل*
> *🔎┊انـمـي*
> *🔎┊حـزمـه*
> *🔎┊بـيـنـتـر*
> *🔎┊تـيـكـتـوك*
> *🔎┊يـوتـيـوب*
*◌────────────────◌*
 ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`.trim()

    conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } }).catch(() => {})

    const channel = 'https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r'
    const developerContact = `https://wa.me/${devNumber}`

    const videoUrls = [
        'https://files.catbox.moe/jzbdkc.mp4',
        'https://files.catbox.moe/hgkawr.mp4',
        'https://files.catbox.moe/a4axym.mp4'
    ];
    const randomVideo = getRandomNotSame(videoUrls, global.lastMenuVideo);
    global.lastMenuVideo = randomVideo
    var messa = await prepareWAMessageMedia({ video: { url: randomVideo }, gifPlayback: true }, { upload: conn.waUploadToServer });

    const interactiveMessage = {
      body: { text: menuText },
      footer: { text: '『 𝐆𝐎𝐉𝐎 ⃝𝐁𝐎𝐓 』' },
      header: {
        hasMediaAttachment: true,
        videoMessage: messa.videoMessage
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({ display_text: '🔙 رجـوع للـقـائـمـة', id: '.اوامر' })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({ display_text: '📜 جـمـيـع الاوامـر', id: '.جميع-الاوامر' })
          },
          {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({ display_text: "📢 القناة", url: channel, merchant_url: channel })
          },
          {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({ display_text: `👨‍💻 الـمـطـور ${devName}`, url: developerContact, merchant_url: developerContact })
          }
        ],
        messageParamsJson: JSON.stringify({
          limited_time_offer: {
            text: `⚡ ${speed}ms | GOJO`,
            url: developerContact,
            copy_code: `Dev: +${devNumber}`,
            expiration_time: Date.now() + 86400000
          }
        })
      }
    }

    const msg = generateWAMessageFromContent(m.chat, { 
      interactiveMessage: proto.Message.InteractiveMessage.fromObject(interactiveMessage) 
    }, { userJid: conn.user.jid })
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (e) {
    console.error('خطا:', e)
    await conn.sendMessage(m.chat, { text: `*حدث خطأ*`, quoted: m })
  }
}

handler.help = ['ك4']
handler.tags = ['main']
handler.command = ['ك4']

export default handler