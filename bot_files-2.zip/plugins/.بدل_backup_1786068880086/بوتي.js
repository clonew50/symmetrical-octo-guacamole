import fetch from "node-fetch";

let handler = async (m, { conn }) => {
  let name = conn.getName(m.sender);

  let teks = `
${pickRandom([`*مطوري😗🩸*`])}
`.trim();

  const thumb = await (await fetch('https://files.catbox.moe/80dv0b.jpg')).buffer(); 
  const verifiedMessage = {
    key: {
      participants: "0@s.whatsapp.net",
      fromMe: false,
      id: "𝐢𝐭𝐚𝐜𝐡𝐢_VERIFIED"
    },
    message: {
      locationMessage: {
        name: "🖤⸽⃕❬ ⚡_KAISER_ . 𝐛𝐨𝐭 ❭ - 🩸🌋⃨፝⃕✰",
        jpegThumbnail: thumb,
        vcard: `BEGIN:VCARD
VERSION:3.0
N:;⚡_KAISER_ 𝐁𝐎𝐓🪄
FN:⚡_KAISER_ 𝐁𝐎𝐓🪄
ORG: SYSTEM ⚡_KAISER_
TITLE:
item1.TEL;waid=19709001746:+9647882860837
item1.X-ABLabel: SUPPORT ⚡_KAISER_ 
X-WA-BIZ-DESCRIPTION:Official 𝐢𝐭𝐚𝐜𝐡𝐢 Bot Verified Service
X-WA-BIZ-NAME:⚡_KAISER_ . 𝐛𝐨𝐭
END:VCARD`
      }
    },
    participant: "0@s.whatsapp.net"
  };

 
  conn.reply(m.chat, teks, verifiedMessage, { mentions: { mentionedJid: [m.sender] } });
};

handler.customPrefix = /(بوتي)/i;
handler.command = new RegExp;
handler.rowner = true;

export default handler;

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}