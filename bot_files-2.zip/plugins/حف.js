let handler = async (m, { conn, isBotAdmin }) => {
  // 1. تحقق أن الأمر داخل جروب
  if (!m.isGroup) return m.reply('🪖 هذا الأمر للجروبات فقط')

  // 2. تأكد من أن البوت مشرف - بالطريقة الصحيحة
  if (!isBotAdmin) return m.reply('❌ يجب أن أكون مشرفًا لحذف الرسائل.')

  // 3. تأكد من وجود رسالة مردود عليها
  if (!m.quoted) return m.reply('❗ قم بالرد على الرسالة التي تريد حذفها')

  // 4. نفذ الحذف
  try {
    await conn.sendMessage(m.chat, {
      delete: m.quoted.key // اسهل طريقة ومضمونة
    })
    m.reply('✅ تم حذف الرسالة')
  } catch (e) {
    console.error(e)
    m.reply('⚠️ فشل حذف الرسالة. السبب: فاتت 2 دقايق او الرسالة قديمة جدا')
  }
}

handler.help = ['حذف']
handler.tags = ['group']
handler.command = /^حذف$/i
handler.group = true
handler.admin = false // اي واحد يقدر يديره
handler.botAdmin = true // شرط البوت يكون ادمين

export default handler