/* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *
 * 👤 المـطـور : 𝒀𝑶𝑵𝑶 𝑫𝑬𝑽
 * 🤖 الـبـوت : ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓
 * 📦 الـوظـيـفـة : 𝒆𝒛𝒅𝒂𝒅 𝒎𝒘𝒂𝒓𝒅 𝒃𝒎𝒏𝒔𝒉𝒏
 * ✨ الـنـسـخـة : 𝑻𝑬𝑿𝑻 𝑶𝑵𝑳𝒀 - 𝑵𝑶 𝑰𝑴𝑨𝑮𝑬 - 𝑭𝑨𝑺𝑻
 * ━ ╼╃ ⌬〔 𝒁𝑨𝑲𝑯𝑹𝑨𝑭𝑨 𝑷𝑹𝑶 〕⌬ ╄╾ ━
 */

let handler = async (m, { conn, usedPrefix, command, text, args }) => {
    const isOwner = global.owner?.map(v => v[0] + '@s.whatsapp.net').includes(m.sender) || m.sender.includes('212674375708');
    if (!isOwner) return m.reply(`*⛔╎𝒐𝒉 𝒔𝒐𝒓𝒚 𝒃𝒓𝒐.. 𝒉𝒂𝒅𝒂 𝒍𝒍𝒎𝒕𝒘𝒓 𝑭𝒒𝒕 👑*`);

    // 〔 زخرفة العناصر 〕
    const items = {
        'جواهر': { name: 'الـجـواهـر', emoji: '💎', key: 'joاهر', z: '𝒋𝒘𝒂𝒉𝒓' },
        'فلوس': { name: 'الـفـلـوس', emoji: '💰', key: 'money', z: '𝒇𝒍𝒐𝒔' },
        'ذهب': { name: 'الـذهـب', emoji: '🪙', key: 'ذهب', z: '𝒅𝒂𝒉𝒂𝒃' },
        'اكس': { name: 'الاكـس بـي', emoji: '✨', key: 'exp', z: '𝒙𝒑' },
        'ليميت': { name: 'اللـيـمـيـت', emoji: '🎟️', key: 'limit', z: '𝒍𝒊𝒎𝒊𝒕' },
        'نقاط': { name: 'الـنـقـاط', emoji: '🏆', key: 'point', z: '𝒑𝒐𝒊𝒏𝒕' },
    };

    let target = m.mentionedJid?.[0] || (m.quoted? m.quoted.sender : null);

    // ═══════════════════════════════════════
    // ❸ - الـتـأكـيـد الـنـهـائـي
    // ═══════════════════════════════════════
    if (text && text.startsWith('do_give|')) {
        let [_, itemId, amount, targetJid] = text.split('|');
        let item = items[itemId];
        let count = parseInt(amount);

        if (!global.db.data.users[targetJid]) global.db.data.users[targetJid] = {};
        let user = global.db.data.users[targetJid];

        // يدعم كل المفاتيح
        let dbKey = item.key;
        if (user[dbKey] === undefined) {
            if (itemId === 'جواهر' && user['diamond']!== undefined) dbKey = 'diamond';
            else if (itemId === 'فلوس' && user['فلوس']!== undefined) dbKey = 'فلوس';
            else { user[dbKey] = 0; }
        }

        user[dbKey] = (user[dbKey] || 0) + count;

        let txt =
`╭── ⋅ ⋅ ── ♛ ── ⋅ ⋅ ──╮
   *𓆩 تـمـت الـعـمـلـيـة بـنـجـاح 𓆪* ✅
╰── ⋅ ⋅ ── ♛ ── ⋅ ⋅ ──╯

*꒷︶꒷꒦︶꒷꒦︶꒷꒦︶꒷꒦︶꒷*

> *𓏲 𝑰𝒕𝒆𝒎 𓂃* ${item.emoji} *${item.name}*
> *𓏲 𝑨𝒎𝒐𝒖𝒏𝒕 𓂃* *${count.toLocaleString()}*
> *𓏲 𝑻𝒐 𓂃* @${targetJid.split('@')[0]}
> *𓏲 𝑵𝒆𝒘 𝑩𝒂𝒍𝒂𝒏𝒄𝒆 𓂃* *${user[dbKey].toLocaleString()}*

*꒷︶꒷꒦︶꒷꒦︶꒷꒦︶꒷꒦︶꒷*

> *𓆩 𝐆𝐎𝐉𝐎 - 𝐁𝐎𝐓 𓆪 💎👑*`;

        await conn.sendMessage(m.chat, { text: txt, mentions: [targetJid] });
        await conn.sendMessage(targetJid, { text: `*╭── ⋅ 🎉 ⋅ ──╮\n*𓆩 𝒋𝒂𝒕𝒌 𝒉𝒅𝒊𝒚𝒂 𓆪*\n*╰── ⋅ 🎉 ⋅ ──╯*\n\n> *𝒂𝒉𝒅𝒂𝒌 𝑨𝒍-𝒎𝒕𝒘𝒓 𝒀𝑶𝑵𝑶 ${item.emoji} ${count.toLocaleString()} ${item.name} 👑*` }).catch(()=>{});
        return;
    }

    // ═══════════════════════════════════════
    // ❷ - اخـتـيـار الـكـمـيـة - ازرار عادية
    // ═══════════════════════════════════════
    if (text && text.startsWith('amount_list|')) {
        let [_, itemId, targetJid] = text.split('|');
        let item = items[itemId];

        let amounts = [100, 500, 1000, 5000, 10000, 50000, 100000, 1000000];

        let listRows = amounts.map(a => [
            `*${item.emoji} ${a.toLocaleString()} ${item.name}*`,
            `${usedPrefix}${command} do_give|${itemId}|${a}|${targetJid}`
        ]);

        let caption =
`╭── ⋅ ⋅ ── ♛ ── ⋅ ──╮
   *𓆩 ${item.emoji} ${item.name} ${item.emoji} 𓆪*
╰── ⋅ ⋅ ── ♛ ── ⋅ ⋅ ──╯

*𓏲 𝑻𝒂𝒓𝒈𝒆𝒕 𓂃* @${targetJid.split('@')[0]}
*𓏲 𝑰𝒕𝒆𝒎 𓃃* ${item.emoji} ${item.z}

*꒷︶꒷ اخـتـر الـكـمـيـة مـن الأسـفـل ꒷︶꒷*

> *𝒂𝒌𝒕𝒃 𝒌𝒎𝒊𝒂 𝒎𝒌𝒉𝒔𝒔𝒂 :*
> *\`${usedPrefix}اعطاء @منشن ${itemId} 9999\`*`;

        // ازرار عادية سريعة - تشتغل 100%
        return await conn.sendMessage(m.chat, {
            text: caption,
            mentions: [targetJid],
            footer: `*𓆩 𝐆𝐎𝐉𝐎 𝐆𝐈𝐕𝐄 𓆪*`,
            buttons: listRows.slice(0,4).map(v => ({ buttonId: v[1], buttonText: { displayText: v[0] }, type: 1 })),
            headerType: 1,
            viewOnce: true
        }, { quoted: m });
    }

    // ═══════════════════════════════════════
    // ❶ - اخـتـيـار الـعـنـصـر
    // ═══════════════════════════════════════
    if (target) {
        let caption =
`╭── ⋅ ⋅ ── ♛ ── ⋅ ⋅ ──╮
   *𓆩 𝒍𝒘𝒉ـة 𝑬𝒛𝒅𝒂𝒅 𝑨𝒍-𝒎𝒘𝒂𝒓𝒅 𓆪* 🎁
╰── ⋅ ⋅ ── ♛ ── ⋅ ⋅ ──╯

*✦ 𝑻𝒂𝒓𝒈𝒆𝒕 𓂃* @${target.split('@')[0]}

*꒷︶꒷꒦︶꒷اخـتـر الـعـنـصـر الـذي تـريـد ازداده꒷︶꒷꒦︶꒷*

${Object.keys(items).map(k => `> *${items[k].emoji} ${items[k].name} 𓂃 ${k}*`).join('\n')}

*꒷︶꒷꒦︶꒷꒦︶꒷꒦︶꒷꒦︶꒷*

> *𓆩 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 𓆪 👑*`;

        let buttons = Object.keys(items).map(k => ({
            buttonId: `${usedPrefix}${command} amount_list|${k}|${target}`,
            buttonText: { displayText: `${items[k].emoji} ${items[k].name}` },
            type: 1
        }));

        return await conn.sendMessage(m.chat, {
            text: caption,
            mentions: [target],
            footer: `*اضـغـط عـلـى الـعـنـصـر 👇*`,
            buttons: buttons.slice(0,5), // واتساب يسمح 5 ازرار عادية فقط
            headerType: 1
        }, { quoted: m });
    }

    // أمر مباشر
    if (args[0] && args[1] &&!isNaN(args[1]) && target) {
        //.اعطاء @منشن 5000 جواهر - يفهمها حتى لو مقلوبة
        let amount = parseInt(args[1]);
        let itemId = args[2] || 'جواهر';
        let item = items[itemId] || items['جواهر'];
        text = `do_give|${itemId}|${amount}|${target}`;
        return handler(m, { conn, usedPrefix, command, text });
    }

    if (args[1] && args[0]) {
        let itemName = args[0].toLowerCase();
        let amount = parseInt(args[1]);
        let item = Object.keys(items).find(k => k === itemName);
        if (item &&!isNaN(amount) && target) {
            text = `do_give|${item}|${amount}|${target}`;
            return handler(m, { conn, usedPrefix, command, text });
        }
    }

    // رسالة المساعدة مزخرفة
    return conn.sendMessage(m.chat, {
        text:
`╭── ⋅ ⋅ ── ♛ ── ⋅ ⋅ ──╮
   *𓆩 𝒏ـظـام 𝑬𝒛𝒅𝒂𝒅 𝑨𝒍-𝒎𝒘𝒂𝒓𝒅 𓆪*
╰── ⋅ ⋅ ── ♛ ── ⋅ ⋅ ──╯

*╭─ 𓏲 𝑻𝒓𝒊𝒒𝒂 𝑨𝒍-𝒊𝒔𝒕𝒌𝒉𝒅𝒂𝒎 𓂃*

*│ ❶ 𝒃𝒂𝒍𝒂𝒛𝒓𝒂𝒓 :*
*│ \`${usedPrefix}اعطاء @منشن\`*

*│ ❷ 𝒎𝒃𝒂𝒔𝒉𝒓 :*
*│ \`${usedPrefix}اعطاء @منشن جواهر 5000\`*
*│ \`${usedPrefix}اعطاء @منشن فلوس 1000000\`*
*│ \`${usedPrefix}اعطاء @منشن ذهب 500\`*

*╰────────────────*

*𓏲 𝑨𝒍-𝒄𝒏𝒂𝒔𝒓 𝑨𝒍-𝒎𝒕𝒂𝒉𝒂 :*
> *💎 جواهر 💰 فلوس 🪙 ذهب*
> *✨ اكس 🎟️ ليميت 🏆 نقاط*

*꒷︶꒷꒦︶꒷꒦︶꒷꒦︶꒷꒦︶꒷*

> *𓆩 𝒍𝒍𝒎𝒕𝒘𝒓 𝑭𝒒𝒕 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 𓆪* 👑`,
        footer: `*اضغط.اعطاء @منشن للبدء*`,
        buttons: [
            { buttonId: `${usedPrefix}قائمتي`, buttonText: { displayText: '💼 قائمتي' }, type: 1 },
            { buttonId: `${usedPrefix}توب`, buttonText: { displayText: '🏆 التوب' }, type: 1 }
        ],
        headerType: 1
    }, { quoted: m });
};

handler.help = ['اعطاء'];
handler.tags = ['owner'];
handler.command = /^(اعطاء|اعط|give|زيد|اضف)$/i;
handler.owner = true;

export default handler;