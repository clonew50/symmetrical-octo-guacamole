import axios from 'axios';

// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// ♛ GOJO BOT ♛ | WRITER
// ✧ كتابة على الورق 📝
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *

const BOT_NAME = '⃟𝐆𝐎𝐉𝐎 𖠲';
const DEVELOPER = '⃟👁️ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⃝';
const NEWSLETTER_JID = '120363302823421@newsletter';

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
  const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;

  try {
    // التحقق من وجود نص
    if (!text) {
      return conn.sendMessage(m.chat, {
        text: `${startDeco}
> *〔 الـكـتـابـة┊ ˼‏ 📝˹ ↶〕* *⚔️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝الـكـتـابـة عـلـى الـورق ↶﹞*
> *〔 ✍️ 〕 الاسـتـخـدام:* ${usedPrefix + command} النص
> *〔 💡 〕 الـمـثـال:* ${usedPrefix + command} مرحبا بك في بوت GOJO

*🧣 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
*👁️┊اسـم الـبـوت:* *${BOT_NAME}*
*🐣 ───━ •﹝📌﹞• ━───*
${endDeco}`,
        footer: `© Powered By ${DEVELOPER}`
      }, { quoted: m });
    }

    // إرسال حالة "جاري الكتابة"
    await conn.sendPresenceUpdate('composing', m.chat);
    
    // التفاعل مع الرسالة
    await m.react('📝');

    // رابط الـ API
    const url = `https://apis.xditya.me/write?text=${encodeURIComponent(text)}`;
    
    // جلب الصورة باستخدام axios كبفر
    const response = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 });
    const buffer = Buffer.from(response.data);

    if (!buffer || buffer.length === 0) throw new Error('فشل توليد الصورة');

    // إرسال الصورة الناتجة
    await conn.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: `${startDeco}
> *〔 تـم الـتـنـفـيـذ┊ ˼‏ ✅˹ ↶〕* *⚔️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝الـكـتـابـة عـلـى الـورق ↶﹞*
> *〔 📝 〕 الـنـص:* ${text}
> *〔 👁️ 〕 بـواسـطـة:* ${BOT_NAME}

*🧣 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
*👁️┊الـمـطـور:* ${DEVELOPER}
*🐣 ───━ •﹝📌﹞• ━───*
${endDeco}`,
        footer: `© Powered By ${DEVELOPER}`
      },
      { quoted: m }
    );
    
    await m.react('✅');
  } catch (e) {
    console.error('[GOJO-WRITE]', e);
    await m.react('❌');
    conn.sendMessage(
      m.chat,
      {
        text: `${startDeco}
> *〔 خـطـأ┊ ˼‏ ❌˹ ↶〕* *⚔️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝فـشـل الـتـنـفـيـذ ↶﹞*
> *〔 ❌ 〕 الـسـبـب:* ${e.message || 'حدث خطأ في الخادم'}
> *〔 ⏰ 〕 الـحـل:* يرجى المحاولة لاحقا

*🧣 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
*👁️┊الـمـطـور:* ${DEVELOPER}
*🐣 ───━ •﹝📌﹞• ━───*
${endDeco}`,
        footer: `© Powered By ${DEVELOPER}`
      },
      { quoted: m }
    );
  }
};

handler.help = ['ورق <النص>'];
handler.tags = ['♛ gojo ♛'];
handler.command = /^(ورق|write|اكتب)$/i;
handler.limit = false;

export default handler;