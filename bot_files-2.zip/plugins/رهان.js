/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: لعبة الروليت رهان أحمر/أسود
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

let rouletteBets = {}
let rouletteTimeout = {}

const handler = async (m, { conn, args, usedPrefix, command }) => {
    let chatId = m.chat
    let users = global.db.data.users[m.sender]
    if (!users) return m.reply('❌ المستخدم غير موجود')

    // --- تحويل الألوان ---
    const colorMap = {
        'احمر': 'red', 'أحمر': 'red', 'red': 'red', 'r': 'red',
        'اسود': 'black', 'أسود': 'black', 'black': 'black', 'b': 'black'
    }

    if (args.length < 2) {
        return conn.reply(m.chat,
`* ━ ╼╃ ⌬〔⚠️〕⌬ ╄╾ ━ *
> *〔 طـريـقـة الـلـعـب 〕*
> \`${usedPrefix + command} المبلغ اللون\`
> *〔 مـثـال 〕* \`${usedPrefix + command} 500 احمر\`
> *〔 الألـوان 〕* 🔴 احمر / ⚫ اسود
> *〔 الـحـد 〕* 500 - 100000 ذهب

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m)
    }

    let amount = parseInt(args[0])
    let rawColor = args[1]?.toLowerCase()
    let color = colorMap[rawColor]

    if (isNaN(amount) || amount < 500) return m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *الحد الأدنى للرهان 500 ذهب*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    if (amount > 100000) return m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *لا يمكنك المراهنة بأكثر من 100000*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    if (!color) return m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *اللون غير صالح، اختر: احمر أو اسود*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    if (users.credit < amount) return m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *ذهبك لا يكفي! رصيدك: ${users.credit}*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)

    if (!rouletteBets[chatId]) rouletteBets[chatId] = []

    // منع نفس الشخص يراهن مرتين في نفس الجولة
    if (rouletteBets[chatId].find(b => b.user === m.sender)) {
        return m.reply(`*⏳ أنت راهنت already، انتظر انتهاء الجولة*`)
    }

    rouletteBets[chatId].push({ user: m.sender, amount, color, name: conn.getName(m.sender) })

    await conn.reply(m.chat,
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ♛ 〕 تـم وضـع الـرهـان ♣️*
> *🥷🏻┊الـلاعـب:* @${m.sender.split('@')[0]}
> *🥷🏻┊الـمـبـلـغ:* ${amount} ذهب
> *🥷🏻┊الـلـون:* ${color === 'red'? '🔴 احمر' : '⚫ اسود'}
> *🥷🏻┊الـمـجـمـوع:* ${rouletteBets[chatId].length} لاعبين

> *الـرولـيـت سـتـدور بـعـد 10 ثـوانـي...* 🎰
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m, { mentions: [m.sender] })

    // شغل التايمر مرة واحدة فقط
    if (!rouletteTimeout[chatId]) {
        rouletteTimeout[chatId] = setTimeout(() => {
            resolveRoulette(chatId, conn)
        }, 10000)
    }
}

function resolveRoulette(chatId, conn) {
    if (!rouletteBets[chatId] || rouletteBets[chatId].length === 0) {
        delete rouletteTimeout[chatId]
        return
    }

    let colores = ['red', 'black']
    let colour = colores[Math.floor(Math.random() * colores.length)]
    let colourAr = colour === 'red'? '🔴 أحمر' : '⚫ أسود'

    let resultMessage = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 🎰 〕 نـتـيـجـة الـرولـيـت ♣️*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *\n\n> *🎯 الـكـرة هـبـطـت عـلـى:* ${colourAr}\n\n`
    let winners = []
    let losers = []

    for (let bet of rouletteBets[chatId]) {
        let userData = global.db.data.users[bet.user]
        if (!userData) continue

        if (colour === bet.color) {
            userData.credit += bet.amount
            winners.push(`> ✅ @${bet.user.split('@')[0]} فاز +${bet.amount}`)
        } else {
            userData.credit -= bet.amount
            losers.push(`> ❌ @${bet.user.split('@')[0]} خسر -${bet.amount}`)
        }
    }

    if (winners.length) resultMessage += `*〔 🎉 الـفـائـزيـن 〕*\n${winners.join('\n')}\n\n`
    else resultMessage += `*〔 😢 لا يـوجـد فـائـزيـن 〕*\n\n`

    if (losers.length) resultMessage += `*〔 💸 الـخـاسـريـن 〕*\n${losers.join('\n')}\n\n`

    resultMessage += `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`

    let allMentions = rouletteBets[chatId].map(b => b.user)
    conn.reply(chatId, resultMessage, null, { mentions: allMentions })

    delete rouletteBets[chatId]
    delete rouletteTimeout[chatId]
}

handler.help = ['رهان']
handler.tags = ['العاب','اقتصاد']
handler.command = /^(رهان|روليت|roulette)$/i
handler.group = true

export default handler