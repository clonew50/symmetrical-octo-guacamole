/* حقوق حرب مطور بوت انيا المظه و بوت حرب 

https://whatsapp.com/channel/0029VbBh4ku8aKvPx1m0l822
لاتحذف السطرين دول بالحب 🩸♥️
*/
import axios from 'axios'
import crypto from 'crypto'
import sharp from 'sharp'
import webp from 'node-webpmux'
import fs from 'fs'

const PACK = `╮┄┄┄┄┄┄┄┄┄┄┄┄╭
𝙽𝚊𝚖𝚎 : ⚡_KAISER_ 𝐁𝐎𝐓🪄
⏱ ࣪𓏲ִ𝚃𝙷𝙴 𝚂𝚃𝙸𝙲𝙺𝙴𝚁 ⊹₊˚𖥔⸼
𝙾𝚠𝚗𝚎𝚛 : .⤹𝗔𝗕𝗗𝗢 𝗗𝗘𝗩 𝗘𝗟 𝗬𝗢𝗨𝗧𝗨𝗕𝗘𝗥⤾.
╯┄┄┄┄┄┄┄┄┄┄┄┄╰
⏱`

const AUTHOR = `⏱
╮┄┄┄┄┄┄┄┄┄┄┄┄╭
꯭✿꯭᪲୭𓍢ִ  𝙱𝚈 →  ⚡_KAISER_ 𝐁𝐎𝐓🪄
╯┄┄┄┄┄┄┄┄┄┄┄┄╰`

function errorTemplate(reason) {
  return `╭─〔 ⚠️ خطأ 〕─╮\n│ ${reason}\n╰───────────────╯`
}

function generateStickerID() {
  return crypto.randomBytes(16).toString('hex')
}

function buildExifBuffer(packname, author, id, emojis = ['🥺']) {
  const raw = {
    'sticker-pack-id': id,
    'sticker-pack-name': packname,
    'sticker-pack-publisher': author,
    emojis
  }
  const data = Buffer.from(JSON.stringify(raw), 'utf8')
  const header = Buffer.from([
    0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x16, 0x00, 0x00, 0x00
  ])
  const exif = Buffer.concat([header, data])
  exif.writeUIntLE(data.length, 14, 4)
  return exif
}

async function addExifToWebp(webpBuffer, packname, author) {
  const img = new webp.Image()
  await img.load(webpBuffer)
  const id = generateStickerID()
  img.exif = buildExifBuffer(packname, author, id)
  return await img.save(null)
}

async function convertToWebp(imageBuffer) {
  return await sharp(imageBuffer)
    .resize({ width: 512, height: 512, fit: 'inside' })
    .webp({ quality: 100 })
    .toBuffer()
}

let handler = async (m, { conn, text }) => {
  const sender = m.sender
  const jid = m.chat
  const textMsg = text?.trim()

  const senderNumber = sender.split('@')[0]
  const vCard = `BEGIN:VCARD\nVERSION:3.0\nN:anya;bot;;;\nFN:anya bot\nitem1.TEL;waid=${senderNumber}:${senderNumber}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`

  const fkontak = {
    key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
    message: { contactMessage: { vcard: vCard } },
    participant: '0@s.whatsapp.net'
  }

  let groupPic
  try { groupPic = await conn.profilePictureUrl(m.chat, 'image') } 
  catch { 
    try { groupPic = await conn.profilePictureUrl(conn.user.jid, 'image') } 
    catch { groupPic = 'https://telegra.ph/file/bc2b6dbf2eb90e36f0b4b.jpg' } 
  }
  const forwardInfo = {
    contextInfo: {
      forwardingScore: 9999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363411035938060@newsletter',
        serverMessageId: 777,
        newsletterName: '◜⚡_KAISER_┊🩸┊𝐂𝐇𝐀𝐍𝐍𝐄𝐋◞'
      },
      externalAdReply: {
        title: "BY : .⤹𝗔𝗕𝗗𝗢 𝗗𝗘𝗩 𝗘𝗟 𝗬𝗢𝗨𝗧𝗨𝗕𝗘𝗥⤾.",
        body: "◜⚡_KAISER_ 𝐁𝐎𝐓🪄◞",
        thumbnailUrl: groupPic,
        mediaType: 1,
        renderLargerThumbnail: true,
        showAdAttribution: false
      }
    }
  }
  if (!textMsg) {
    return conn.sendMessage(jid, { text: errorTemplate('❗أدخل كلمة للبحث.\nمثال: *.بحث-ملصق 5 انمي*'), ...forwardInfo }, { quoted: fkontak })
  }

  const parts = textMsg.split(' ')
let count = 5
let query = ''

if (!isNaN(parseInt(parts[0])) && parseInt(parts[0]) > 0) {

  if (parseInt(parts[0]) > 20) {
    return conn.sendMessage(
      jid,
      { text: errorTemplate('❗ الحد الأقصى للملصقات هو 20 فقط'), ...forwardInfo },
      { quoted: fkontak }
    )
  }
  count = parseInt(parts[0])
  query = parts.slice(1).join(' ')
} else {
  query = parts.join(' ')
}


if (!query || query.trim() === '') {
  return conn.sendMessage(
    jid,
    { text: errorTemplate('❗أدخل كلمة للبحث بعد الرقم.\nمثال: *.بحث-ملصق 5 قطط*'), ...forwardInfo },
    { quoted: fkontak }
  )
}


  await conn.sendMessage(jid, { text: '```⏳ جاري البحث عن الصور...```', ...forwardInfo }, { quoted: fkontak })


  let results = []
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(query)}`)
    results = res.data?.data?.filter(i => i.image_url) || []
  } catch (e) {
    return conn.sendMessage(jid, { text: errorTemplate('❗ حدث خطأ أثناء الاتصال بمصدر البحث، حاول لاحقًا.'), ...forwardInfo }, { quoted: fkontak })
  }

  if (results.length === 0) {
    return conn.sendMessage(jid, { text: errorTemplate(`لم يتم العثور على نتائج لـ "${query}"`), ...forwardInfo }, { quoted: fkontak })
  }

  const selected = results.sort(() => 0.5 - Math.random()).slice(0, count)
  let successCount = 0

  for (let item of selected) {
    try {
      const response = await axios.get(item.image_url, { responseType: 'arraybuffer' })
      const imgBuffer = Buffer.from(response.data, 'binary')
      const webpBuffer = await convertToWebp(imgBuffer)
      const stickerBuffer = await addExifToWebp(webpBuffer, PACK, AUTHOR)
      await conn.sendMessage(jid, { sticker: stickerBuffer, ...forwardInfo }, { quoted: fkontak })
      successCount++
    } catch {}
  }


  await conn.sendMessage(
    jid,
    { text: `✅ تم إنشاء ${successCount} ملصق عن "${query}" بنجاح 🎨`, ...forwardInfo },
    { quoted: fkontak }
  )
}

handler.help = ['بحث-ملصق']
handler.tags = ['tools']
handler.command = /^(بحث-ملصق)$/i
export default handler