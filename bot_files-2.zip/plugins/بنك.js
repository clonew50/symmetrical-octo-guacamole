let handler = async (m, { conn }) => {
    try {
        let userId = m.sender
        if (!global.db) global.db = { data: { users: {} } }
        if (!global.db.data) global.db.data = { users: {} }
        if (!global.db.data.users) global.db.data.users = {}
        if (!global.db.data.users[userId]) {
            global.db.data.users[userId] = { money: 0, diamond: 0, exp: 0, level: 1, lastDaily: 0, lastWeekly: 0, bank: 0 }
        }
        let user = global.db.data.users[userId]

        let money = user.money || 0
        let diamond = user.diamond || 0
        let exp = user.exp || 0
        let level = user.level || Math.floor(exp / 1000) + 1
        let bank = user.bank || 0
        let total = money + bank

        // حساب الوقت المتبقي
        let now = Date.now()
        let dailyLeft = (user.lastDaily || 0) + 86400000 - now
        let weeklyLeft = (user.lastWeekly || 0) + 604800000 - now

        let dailyStatus = dailyLeft > 0? `⏳ بـاقـي ${Math.floor(dailyLeft/3600000)} سـاعـة` : "✅ جـاهـز الان"
        let weeklyStatus = weeklyLeft > 0? `⏳ بـاقـي ${Math.floor(weeklyLeft/86400000)} يـوم` : "✅ جـاهـز الان"

        // تحديد الرتبة حسب الفلوس
        let rank = "فقير 😢"
        if (total >= 1000) rank = "مبتدئ 🌱"
        if (total >= 5000) rank = "متوسط 💰"
        if (total >= 15000) rank = "غني 🤑"
        if (total >= 50000) rank = "مليونير 💎"
        if (total >= 100000) rank = "اسطورة 👑"
        if (total >= 500000) rank = "امبراطور GOJO 🏦"

        let txt = `
* ━ ╼╃ ⌬〔🏦〕⌬ ╄╾ ━ *
*〔 ♛ 〕 بـنـك 𝐆𝐎𝐉𝐎 الـمـركـزي*
* ━ ╼╃ ⌬〔 💳 〕⌬ ╄╾ ━ *

*〔 👤 〕 الـعـمـيـل :* @${userId.split('@')[0]}
*〔 🎖️ 〕 الـرتـبـة :* ${rank}
*〔 📈 〕 الـمـسـتـوى :* ${level}

* ━ ╼╃ ⌬〔💰〕⌬ ╄╾ ━ *
*〔 💵 〕 الـفـلـوس الـكـاش :* ${money.toLocaleString()}
*〔 🏛️ 〕 الـفـلـوس فـالـبـنـك :* ${bank.toLocaleString()}
*〔 💎 〕 الالـمـاس :* ${diamond.toLocaleString()} 💠
*〔 🏯 〕 الـخـبـرة :* ${exp.toLocaleString()} XP
*〔 💼 〕 اجـمـالـي الـثـروة :* ${total.toLocaleString()} 💰

* ━ ╼╃ ⌬〔📅〕⌬ ╄╾ ━ *
*〔 🎁 〕 الـيـومـي :* ${dailyStatus}
*〔 👑 〕 الاسـبـوعـي :* ${weeklyStatus}

* ━ ╼╃ ⌬〔💡〕⌬ ╄╾ ━ *
*• اكـتـب.يـومـي لـلـجـائـزة الـيـومـيـة*
*• اكـتـب.اسـبـوعـي لـلـجـائـزة الـكـبـرى*
*• اكـتـب.ايـداع + الـمـبـلـغ لـحـفـظ فـلـوسـك*
*• اكـتـب.سـحـب + الـمـبـلـغ لـسـحـب فـلـوسـك*

* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`.trim()

        await conn.sendMessage(m.chat, {
            text: txt,
            mentions: [userId]
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 خـطـأ:* ' + e.message }, { quoted: m })
    }
}

handler.help = ['بنك']
handler.tags = ['economy']
handler.command = ['بنك', 'bank', 'رصيدي', 'فلوسي', 'محفظتي']
handler.group = false

export default handler