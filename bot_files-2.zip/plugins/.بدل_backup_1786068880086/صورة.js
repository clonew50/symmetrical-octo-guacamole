import fetch from 'node-fetch'

let handler = async (m, { conn, args, usedPrefix, command }) => {
  // استخراج الرابط من الوسائط المرفقة أو المقتبسة أو النص
  let text = args[0] ? args[0] : (m.quoted && m.quoted.text ? m.quoted.text : '')
  let urlMatch = text.match(/https?:\/\/[^\s]+/i)
  let url = urlMatch ? urlMatch[0] : null

  if (!url) {
    return m.reply(
      `❌ *يرجى إضافة رابط الصورة أو الرد على رسالة تحتوي على رابط!*\n\n` +
      `📌 *مثال:*\n` +
      `• \`${usedPrefix + command} https://i.ibb.co/example.jpg\``
    )
  }

  await m.reply('⏳ *جاري جلب الصورة وعرضها...*')

  try {
    // 1. تنزيل الصورة مباشرة كـ Buffer مع دعم الـ User-Agent
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      },
      timeout: 15000
    })

    if (!res.ok) throw new Error(`السيرفر رد بكود خطأ: ${res.status}`)

    const buffer = await res.buffer()

    // 2. التحقق من صحة وحجم الصورة
    if (!buffer || buffer.length < 500) {
      throw new Error('الملف المستلم غير صالح كصورة أو حجمه صغير جداً.')
    }

    const fileSizeKB = (buffer.length / 1024).toFixed(2)

    // 3. إرسال الصورة كـ معاينة مباشرة
    await conn.sendMessage(m.chat, {
      image: buffer,
      caption: 
`✅ *تم جلب الصورة بنجاح!*

🔗 *الرابط:* ${url}
💾 *الحجم:* ${fileSizeKB} KB

👑 ⚡_KAISER_ 𝕭𝖔𝖙`
    }, { quoted: m })

  } catch (error) {
    console.error('[GetImg Error]:', error)
    return m.reply(`❌ *فشل جلب الصورة*\n\nالسبب: ${error.message || 'الرابط غير صالح'}`)
  }
}

handler.help    = ['صورة <الرابط>']
handler.tags    = ['tools']
handler.command = /^(getimg|getpic|صورة|رابط-صورة)$/i

export default handler