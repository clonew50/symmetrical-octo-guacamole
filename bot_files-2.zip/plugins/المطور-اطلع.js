// Handler: الخروج من المجموعات (مُعدل — شخصية توكيتا كورليوني)
let handler = async (m, { conn, args, command, text }) => {
  // الأرقام المصرح لها بتنفيذ الأمر
  const allowedNumbers = [
    '212674375708@s.whatsapp.net', // الرقم الأول
    '212674375708@s.whatsapp.net'  // الرقم الثاني
  ]

  // فحص السماح
  if (!allowedNumbers.includes(m.sender)) {
    return m.reply(`👻 سيدي... هذا القرار ليس بيدك.\nفقط رجال العائلة الموثوقون يملكون هذا الامتياز.\n\n𝐆𝐎𝐉o ぽ ​​​⚴ 𝐁𝐎𝐓 👻`)
  }

  // تحديد المجموعة الهدف (المكتوبة أو الحالية)
  let group = text ? text : m.chat

  // صياغة رسالة الوداع حسب الأمر المستعمل
  let farewellMsg = ''
  switch (command) {
    case 'leavegc':
    case 'out':
      farewellMsg = `👻 لقد حان وقت الرحيل يا أصدقائي...\nأستودعكم الله.\n\n𝐆𝐎𝐉o ぽ ​​​⚴ 𝐁𝐎𝐓 👻`
      break
    case 'غادر':
    case 'اطلع':
      farewellMsg = `👻 كما يقولون... كل لقاء له نهاية.\nالآن، عليَّ أن أترككم.\n\n𝐆𝐎𝐉o ぽ ​​​⚴ 𝐁𝐎𝐓 👻`
      break
    case 'المجموعات':
      farewellMsg = `👻 يا سيدي، هذا الأمر مخصص لترك المجموعات فقط.\n\n𝐆𝐎𝐉o ぽ ​​​⚴ 𝐁𝐎𝐓 👻`
      break
    default:
      farewellMsg = `👻 وداعًا... سأغادر بهدوء.\n\n𝐆𝐎𝐉o ぽ ​​​⚴ 𝐁𝐎𝐓 👻`
  }

  // إرسال رسالة الوداع
  await conn.reply(group, farewellMsg, null)

  // مغادرة المجموعة (إلا إذا كان الأمر "المجموعات" فهو للعرض فقط)
  if (!/المجموعات/i.test(command)) {
    await conn.groupLeave(group)
  }
}

// المساعدة والأوامر
handler.help = ['leavegc', 'out', 'غادر', 'اطلع', 'المجموعات']
handler.tags = ['owner']
handler.command = /^(leavegc|out|غادر|اطلع)$/i
handler.owner = true

export default handler