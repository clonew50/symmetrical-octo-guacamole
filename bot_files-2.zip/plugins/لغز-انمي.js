/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO (فكرة GEO)
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: لغز انمي - مع نظام .ج
 * 📢 القناة: https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

const riddles = [
  { q: '🎌 من هو الشخص الذي يحمل دفتراً يقتل كل من يُكتب اسمه فيه؟', a: ['لايت', 'light yagami', 'لايت يوغامي','ياغامي لايت'] },
  { q: '🎌 ما اسم الأنمي الذي بطله يموت ويرجع للحياة من نقطة معينة؟', a: ['ريزيرو', 're zero', 'ابدأ من الصفر', 'rezero','ري زيرو'] },
  { q: '🎌 من هو حارس القرية الخفية للرمل وأصبح كازيكاجي؟', a: ['غارا', 'gaara'] },
  { q: '🎌 من هو المحقق العبقري الذي يجلس بطريقة غريبة ويحب الحلوى؟', a: ['l', 'ال', 'إل','lawliet'] },
  { q: '🎌 من هو أقوى ساحر في جوجوتسو كايسن؟', a: ['غوجو', 'gojo', 'ساتورو غوجو','ساتورو'] },
  { q: '🎌 من هو بطل أنمي "رجل اللكمة الواحدة"؟', a: ['سايتاما', 'saitama'] },
  { q: '🎌 من هو معلم ناروتو وساسكي وساكورا؟', a: ['كاكاشي', 'kakashi','هاتاكي'] },
  { q: '🎌 من هو الشيطان الذي يسكن في إيتادوري يوجي؟', a: ['سوكونا', 'sukuna', 'ريومن سوكونا'] },
  { q: '🎌 ما اسم القوة الخاصة في هانتر × هانتر؟', a: ['نن', 'nen'] },
  { q: '🎌 من هو الشخص الذي يقاتل بثلاثة سيوف في ون بيس؟', a: ['زورو', 'zoro','رورونوا'] },
  { q: '🎌 من هو بطل أنمي "بليتش"؟', a: ['إيشيغو', 'ichigo', 'ايشيغو','كوروساكي'] },
  { q: '🎌 ما اسم الفاكهة التي أكلها لوفي؟', a: ['غوم غوم', 'gum gum', 'غومو غومو','هيتو هيتو'] },
  { q: '🎌 من هو قائد فيلق الاستطلاع الأقوى؟', a: ['ليفاي', 'levi', 'ليفي'] },
  { q: '🎌 ما اسم شيطان المنشار؟', a: ['بوشيتا', 'pochita','دينجي'] },
  { q: '🎌 ما اسم الأنمي الذي تقاتل فيه شياطين بسيوف خاصة؟', a: ['قاتل الشياطين', 'demon slayer', 'كيميتسو'] },
];

if (!global._tokitaAnimeRiddle) global._tokitaAnimeRiddle = new Map();

const normalize = s => s.trim().toLowerCase().replace(/\s+/g,'').replace(/[أإآا]/g,'ا').replace(/[ةه]/g,'ه').replace(/[يى]/g,'ي')

let handler = async (m, { conn, usedPrefix, command, text }) => {
const chatId = m.chat
let data = global._tokitaAnimeRiddle.get(chatId)

// ── أمر الجواب .ج ──
if (/^(ج|جواب|حل)$/i.test(command) || (text && /^(ج|جواب)\s+/i.test(m.text || ''))) {
  let userAnswer = text?.trim()
  if(!userAnswer && m.text?.includes(' ')) userAnswer = m.text.split(' ').slice(1).join(' ').trim()

  if (!data) return m.reply(
`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *
> *مـفـيـش لـغـز نـشـط!*
> *اكـتـب \`${usedPrefix}لغز-انمي\` لـلـبـدء*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
  )
  if (!userAnswer) return m.reply(`> *❌ اكـتـب إجـابـتـك! مـثـال: \`${usedPrefix}ج غوجو\`*`)

  const isCorrect = data.riddle.a.some(ans => normalize(userAnswer) === normalize(ans) || normalize(userAnswer).includes(normalize(ans)) || normalize(ans).includes(normalize(userAnswer)))

  if (isCorrect) {
    clearTimeout(data.timer)
    global._tokitaAnimeRiddle.delete(chatId)
    if(!global.db?.data?.users?.[m.sender]) global.db.data.users[m.sender]={exp:0}
    global.db.data.users[m.sender].exp += 3500

    return conn.sendMessage(chatId, {
      text:
`* ━ ╼╃ ⌬〔✅〕⌬ ╄╾ ━ *
> *〔 🎉 〕 إجـابـة صـحـيـحـة!*

> *👤 الـفـائـز:* @${m.sender.split('@')[0]}
> *✅ الإجـابـة:* *${data.riddle.a[0]}*
> *💰 الـجـائـزة:* 3500 XP

> *اكـتـب \`${usedPrefix}لغز-انمي\` لـلـغـز جـديـد!*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`,
      mentions: [m.sender]
    })
  } else {
    return m.reply(
`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *
> *إجـابـة خـاطـئـة يـا @${m.sender.split('@')[0]}*
> *حـاول تـانـي!*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`,
    null, { mentions:[m.sender] })
  }
}

// ── لغز جديد ──
if (data) return m.reply(
`* ━ ╼╃ ⌬〔⚠️〕⌬ ╄╾ ━ *
> *فـيـه لـغـز لـسـه مـا تـجـاوبـش!*
> *${data.riddle.q}*
> *💬 جـاوب بـ: \`${usedPrefix}ج <الإجابة>\`*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
)

const riddle = riddles[Math.floor(Math.random()*riddles.length)]

const timer = setTimeout(async () => {
  if (global._tokitaAnimeRiddle.has(chatId)) {
    global._tokitaAnimeRiddle.delete(chatId)
    await conn.sendMessage(chatId, {
      text:
`* ━ ╼╃ ⌬〔⏰〕⌬ ╄╾ ━ *
> *انـتـهـى الـوقـت!*
> *✅ الإجـابـة كـانـت:* *${riddle.a[0]}*
> *🎌 اكـتـب \`${usedPrefix}لغز-انمي\` لـلـغـز جـديـد*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
    })
  }
}, 60000)

global._tokitaAnimeRiddle.set(chatId, { riddle, timer })

return conn.sendMessage(chatId, {
text:
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🎌 〕 لـغـز الأنـمـي - 𝐆𝐎𝐉𝐎 ♛*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *

> *${riddle.q}*

> *⏳ عـنـدك 60 ثـانـيـة*
> *💬 جـاوب بـ: \`${usedPrefix}ج <الإجابة>\`*

* ━ ╼╃ ⌬〔 🧠 〕⌬ ╄╾ ━ *`
})
}

handler.help = ['لغز-انمي','ج']
handler.tags = ['العاب','انمي']
handler.command = /^(لغز-انمي|لغزانمي|انمي-لغز|ج|جواب|حل)$/i

export default handler