// =================================================================
// • الحقوق : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 - مطور 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓
// • القناة : https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
// • الوصف : مواقيت الصلاة - قائمة دول تفاعلية
// • الإصدار : v2.0 DECORATED & FIXED
// =================================================================
import axios from 'axios';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const DECO_TOP = `* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *`
const DECO_BOTTOM = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`

function format12HourTime(time24) {
  if(!time24) return 'غير محدد'
  const [hours, minutes] = time24.split(':');
  let period = 'ص';
  let h = parseInt(hours, 10);
  if (h >= 12) { period = 'م'; if (h > 12) h -= 12; }
  if (h === 0) h = 12
  return `${h}:${minutes} ${period}`;
}

const handler = async (m, { text, usedPrefix, command, conn }) => {
  const wm = `𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 👑`

  const rows = [
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "الــقــاهــره", id: `${usedPrefix + command} القاهره` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "الرياض", id: `${usedPrefix + command} الرياض` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "الدار البيضاء", id: `${usedPrefix + command} الدار البيضاء` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "دبي", id: `${usedPrefix + command} دبي` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "بيروت", id: `${usedPrefix + command} بيروت` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "تونس", id: `${usedPrefix + command} تونس` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "الجزائر", id: `${usedPrefix + command} الجزائر` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "بغداد", id: `${usedPrefix + command} بغداد` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "عمان", id: `${usedPrefix + command} عمان` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "الخرطوم", id: `${usedPrefix + command} الخرطوم` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "دمشق", id: `${usedPrefix + command} دمشق` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "طرابلس", id: `${usedPrefix + command} طرابلس` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "مسقط", id: `${usedPrefix + command} مسقط` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "الدوحة", id: `${usedPrefix + command} الدوحة` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "المنامة", id: `${usedPrefix + command} المنامة` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "الكويت", id: `${usedPrefix + command} الكويت` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "جدة", id: `${usedPrefix + command} جدة` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "مكة", id: `${usedPrefix + command} مكة` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "المدينة", id: `${usedPrefix + command} المدينة` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "الشارقه", id: `${usedPrefix + command} الشارقة` },
    { header: '⌈ الصلاة اليوم في مدينة: ⌋', title: "الرباط", id: `${usedPrefix + command} الرباط` }
  ];

  const images = [
    'https://ar.prayerinislam.com/wp-content/uploads/المشروع-في-المسجد.jpg',
    'https://islamonline.net/wp-content/uploads/2023/02/الإمام-والمؤذن-صلاة-الجماعة.jpg',
    'https://daleelalmasjed.com/upload/3021162680-258.png'
  ];
  const randomImage = images[Math.floor(Math.random() * images.length)];
  
  try {
    const mediaMessage = await prepareWAMessageMedia({ image: { url: randomImage } }, { upload: conn.waUploadToServer });

    if (text) {
      const prayerResponse = await axios.get(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(text)}&country=Morocco`);
      const prayerData = prayerResponse.data.data.timings;

      const prayerMessage = `${DECO_TOP}

> *〔 مواقيت الصلاة┊ 🕌˹ ↶〕* *${text}*

> *🪽┊الـفـجــر:* \`${format12HourTime(prayerData.Fajr)}\`
> *🪽┊الـشـروق:* \`${format12HourTime(prayerData.Sunrise)}\`
> *🪽┊الـظـهـر:* \`${format12HourTime(prayerData.Dhuhr)}\`
> *🪽┊الـعـصـر:* \`${format12HourTime(prayerData.Asr)}\`
> *🪽┊الـمـغـرب:* \`${format12HourTime(prayerData.Maghrib)}\`
> *🪽┊الـعـشـاء:* \`${format12HourTime(prayerData.Isha)}\`

${DECO_BOTTOM}`;

      const mediaPrayer = await prepareWAMessageMedia({ image: { url: randomImage } }, { upload: conn.waUploadToServer });
      const msgWithPrayer = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: { text: prayerMessage },
              footer: { text: wm },
              header: { hasMediaAttachment: true, imageMessage: mediaPrayer.imageMessage },
              nativeFlowMessage: {
                buttons: [{ name: 'single_select', buttonParamsJson: JSON.stringify({ title: '🌍 تغيير المدينة', sections: [{ title: '「 الــدول 🕌 」', highlight_label: '𝐆𝐎𝐉𝐎', rows: rows }] }) }]
              }
            }
          }
        }
      }, { userJid: conn.user.jid, quoted: m });
      await conn.relayMessage(m.chat, msgWithPrayer.message, { messageId: msgWithPrayer.key.id });

    } else {
      const caption = `${DECO_TOP}\n\n> *مــرحــبـا يــا* @${m.pushName?.split('@')[0] || 'صديقي'} 🌙\n> *اخــتــر مـدينـتـك من القائمة*\n\n${DECO_BOTTOM}`;
      const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: { text: caption },
              footer: { text: wm },
              header: { hasMediaAttachment: true, imageMessage: mediaMessage.imageMessage },
              nativeFlowMessage: {
                buttons: [{ name: 'single_select', buttonParamsJson: JSON.stringify({ title: '🕌 قــائــمــة الــدول', sections: [{ title: '「 الــدول 🌙 」', highlight_label: 'اختر مدينتك', rows: rows }] }) }]
              }
            }
          }
        }
      }, { userJid: conn.user.jid, quoted: m });
      await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }
  } catch (error) {
    console.error(error);
    m.reply(`${DECO_TOP}\n\n> *❌┊لم أتمكن من جلب مواقيت* \`${text}\`\n> *تأكد من كتابة اسم المدينة صحيح*\n\n${DECO_BOTTOM}`);
  }
}

handler.command = ['الصلاة', 'اذان', 'الصلاه', 'صلاة'];
handler.tags = ['islamic'];
handler.help = ['الصلاة <المدينة>'];

export default handler;