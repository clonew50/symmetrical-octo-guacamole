import { prepareWAMessageMedia } from '@whiskeysockets/baileys';
import { xpRange } from '../lib/levelling.js';
import fetch from 'node-fetch';

function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms % 3600000 / 60000);
    let s = Math.floor(ms % 60000 / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

global.lastMenuVideo = global.lastMenuVideo || null
global.lastMenuAudio = global.lastMenuAudio || null

function getRandomNotSame(arr, last) {
    let filtered = arr.filter(v => v!== last)
    if(filtered.length === 0) filtered = arr
    return filtered[Math.floor(Math.random() * filtered.length)]
}

const handler = async (m, { conn }) => {
    let d = new Date(new Date() + 3600000);
    let locale = 'ar';
    let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
    let dayName = d.toLocaleDateString(locale, { weekday: 'long' });
    let time = d.toLocaleTimeString(locale, { hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: true });
    let _uptime = process.uptime() * 1000;
    let uptime = clockString(_uptime);

    let user = global.db.data.users[m.sender];
    const devNumber = '212674375708';
    const devName = '𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 👑';
    const botName = '🔮 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓';
    let isCreator = m.sender.includes(devNumber);
    let { exp, level, role, limit } = user;
    let { min, max } = xpRange(level, global.multiplier);
    let displayLevel = isCreator? '♾️ [ MAX ]' : level;
    let displayRole = isCreator? '☠️ حـاكـم الـنـظـام' : (role || 'عابر سبيل');
    let progress = isCreator? 100 : Math.min(100, Math.max(0, ((exp - min) / (max - min) * 100))).toFixed(0);
    let taguser = '@' + m.sender.split("@s.whatsapp.net")[0];

    await conn.sendMessage(m.chat, { react: { text: '🪖', key: m.key } });

    // ✅ توثيق احترافي للقائمة
    const verifiedMenu = {
        key: { fromMe: false, participant: "0@s.whatsapp.net", remoteJid: "status@broadcast" },
        message: {
            contactMessage: {
                displayName: `〔 ${botName} ┊ ˼‏ 🔮˹ ↶〕`,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${botName};;;\nFN:${botName}\nORG:${botName};\nTITLE:Official System\nitem1.TEL;waid=${devNumber}:+${devNumber}\nitem1.EMAIL:support@gojo.bot\nURL:https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r\nEND:VCARD`,
                jpegThumbnail: await (await fetch('https://files.catbox.moe/39kria.jpg')).buffer()
            }
        }
    };

    // ✅ توثيق الصوت القديم
    const verifiedAudio = {
        key: { participants: "0@s.whatsapp.net", fromMe: false, id: "OFFICIAL_VERIFIED_SERVICE" },
        message: {
            locationMessage: {
                name: `〔 ${botName} ┊ ˼‏ 🔮˹ ↶〕`,
                jpegThumbnail: await (await fetch('https://files.catbox.moe/39kria.jpg')).buffer(),
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${devName};;;\nFN:${devName}\nORG:${botName};\nTITLE:Developer\nitem1.TEL;waid=${devNumber}:+${devNumber}\nEND:VCARD`
            }
        },
        participant: "0@s.whatsapp.net"
    };

    const videoUrls = ['https://files.catbox.moe/jzbdkc.mp4','https://files.catbox.moe/hgkawr.mp4','https://files.catbox.moe/a4axym.mp4'];
    const randomVideo = getRandomNotSame(videoUrls, global.lastMenuVideo);
    global.lastMenuVideo = randomVideo
    var messa = await prepareWAMessageMedia({ video: { url: randomVideo }, gifPlayback: true }, { upload: conn.waUploadToServer });

    let menuText = `
* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 📜 قـائـمـة اوامـر ${botName}┊ ˼‏ 🔮˹ ↶〕*

*🪖 ──¤﹝بـيـانـات الـمـسـتـخـدم ↶ 🕸️﹞*
> *🥷🏻┊* الـمـسـتـخـدم: ${taguser}
> *🥷🏻┊* الـمـسـتـوى: 〘${displayLevel}〙
> *🥷🏻┊* الـخـبـرة: 〘${progress}%〙
> *🥷🏻┊* الـرصـيـد: 〘${isCreator? '∞' : (limit || 0)}〙
> *🥷🏻┊* الـرتبـة: ${displayRole}

*🪖 ──¤﹝مـعـلـومـات الـنـظـام ↶ 🕸️﹞*
> *⚜️┊* اسـم الـبـوت: *${botName}*
> *⚜️┊* الـمـسـتـضـيـف: 〘Linux VPS Ubuntu〙
> *⚜️┊* الـبـادئـة: 〘.〙

*🪖 ──¤﹝مـعـلـومـات الـوقـت ↶ 🕸️﹞*
> *🏯┊* الـيـوم: ${dayName}
> *🏯┊* الـتـاريـخ: ${date}
> *🏯┊* الـوقـت: ${time}
> *🏯┊* مـدة الـتـشـغـيـل: 〘${uptime}〙

*🪖 ──¤﹝تـوجـيـهـات ↶ 🕸️﹞*
> *🥷🏻┊* لضمان استجابة سريعة ضع نقطة. قبل كل امر
> *🥷🏻┊* للابلاغ عن مشكلة:.ابلاغ

* ━ ╼╃ ⌬〔 ${botName} 〕⌬ ╄╾ ━ *`.trim();

    await conn.relayMessage(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: menuText },
                    footer: { text: '🔮 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ✦ 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕' },
                    header: { hasMediaAttachment: true, videoMessage: messa.videoMessage },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: "〔 🗃️ الاقـسـام الـرئـيـسـيـة ┊ ˼‏ 🔮˹ ↶〕",
                                    sections: [{
                                        title: "〔 اخـتـر الـقـسـم الـمـطـلـوب ┊ ˼‏ 🕸️˹ ↶〕",
                                        rows: [
                                            {
                                              title: "〔 👑 قـسـم الادمـن ┊ ˼‏ ☠️˹ ↶〕",
                                              description: "〘 23 امـر ↶ حـذف، طـرد، تـرقـيـة، تـحـذيـر، قـفـل الـجـروب 〙",
                                              id: ".ك1"
                                            },
                                            {
                                              title: "〔 📥 قـسـم الـتـحـمـيـل ┊ ˼‏ 📡˹ ↶〕",
                                              description: "〘 18 امـر ↶ يـوتـيـوب، تـيـك، انـسـتـا، صـوت، فـيـديـو HD 〙",
                                              id: ".ك2"
                                            },
                                            {
                                              title: "〔 🎮 قـسـم الالـعـاب ┊ ˼‏ 🎲˹ ↶〕",
                                              description: "〘 15 امـر ↶ مـزاد، تـخـمـيـن، XO، تـحـدي، نـقـاط 〙",
                                              id: ".ك3"
                                            },
                                            {
                                              title: "〔 🔍 قـسـم الـبـحـث ┊ ˼‏ 🌐˹ ↶〕",
                                              description: "〘 12 امـر ↶ جـوجـل، صـور، اخـبـار، تـرجـمـة، ويـكـي 〙",
                                              id: ".ك4"
                                            },
                                            {
                                              title: "〔 🎨 قـسـم الـمـلـصـقـات ┊ ˼‏ 🖼️˹ ↶〕",
                                              description: "〘 14 امـر ↶ سـتـيـكـر، تـكـسـت، دائـري، مـتـحـرك، تـعـديـل 〙",
                                              id: ".ك5"
                                            },
                                            {
                                              title: "〔 🕌 قـسـم الـديـن ┊ ˼‏ 📿˹ ↶〕",
                                              description: "〘 10 امـر ↶ قـران، اذكـار، احـاديـث، ادعـيـة، قـبـلـة 〙",
                                              id: ".ك6"
                                            },
                                            {
                                              title: "〔 🏦 قـسـم الـبـنـك ┊ ˼‏ 💰˹ ↶〕",
                                              description: "〘 16 امـر ↶ رصـيـد، تـحـويـل، سـرقـة، مـحـفـظـة، راتـب 〙",
                                              id: ".ك7"
                                            },
                                            {
                                              title: "〔 🎉 قـسـم الـتـسـلـيـه ┊ ˼‏ 😂˹ ↶〕",
                                              description: "〘 20 امـر ↶ بـوسـتـات، نـكـت، اقـتـبـاسـات، صـور عـشـوائـيـة 〙",
                                              id: ".ك8"
                                            },
                                            {
                                              title: "〔 🤖 قـسـم الـذكـاء ┊ ˼‏ 🧠˹ ↶〕",
                                              description: "〘 8 اوامـر ↶ GPT، Qwen، Grok، تـصـمـيـم، تـلـخـيـص، بـرمـجـة 〙",
                                              id: ".ك9"
                                            }
                                        ]
                                    }]
                                })
                            },
                            { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '〔 📜 جـمـيـع الاوامـر ┊ ˼‏ 📑˹ ↶〕', id: '.جميع-الاوامر' }) },
                            { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: "〔 📢 قـنـاة الـبـوت ┊ ˼‏ 🔮˹ ↶〕", url: 'https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r', merchant_url: 'https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r' }) },
                            { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: `〔 👨‍💻 الـمـطـور ${devName} ┊ ˼‏ 👑˹ ↶〕`, id: '.المطور' }) }
                        ],
                        messageParamsJson: JSON.stringify({
                            limited_time_offer: { text: `GOJO BOT`, url: 'https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r', copy_code: `Prefix: GOJO BOT`, expiration_time: Date.now() + 86400000 },
                            bottom_sheet: { in_thread_buttons_limit: 1, list_title: "〔 📂 اقـسـام الـبـوت ┊ ˼‏ 🔮˹ ↶〕", button_title: "〔 🔮 عــرض الاقــســام ┊ ˼‏ 🕸️˹ ↶〕" }
                        })
                    }
                }
            }
        }
    }, { quoted: verifiedMenu });

    const audioUrls = ['https://files.catbox.moe/a4axym.mp4','https://files.catbox.moe/jzbdkc.mp4','https://files.catbox.moe/hgkawr.mp4'];
    const randomAudio = getRandomNotSame(audioUrls, global.lastMenuAudio);
    global.lastMenuAudio = randomAudio
    await conn.sendMessage(m.chat, { audio: { url: randomAudio }, mimetype: 'audio/mp4', ptt: true }, { quoted: verifiedAudio });
};

handler.command = ['اوامر', 'الاوامر', 'س', 'اوامرو', 'الوامر'];
export default handler;