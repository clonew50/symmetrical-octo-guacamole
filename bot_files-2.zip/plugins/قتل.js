let handler = async (m, { conn }) => {
    let isGroup = m.chat?.endsWith('@g.us') || m.isGroup || false
    if (!isGroup) {
        try { await conn.groupMetadata(m.chat); isGroup = true } catch { isGroup = false }
    }
    if (!isGroup) return conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 هـاد الأمـر خـاص بـالـمـجـمـوعـات فـقـط!*\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })

    try {
        let groupMetadata = await conn.groupMetadata(m.chat)
        let participants = groupMetadata.participants.map(v => v.id || v.jid || v)
        let users = participants.filter(v => v!== conn.user.jid && v!== conn.user.id)

        if (users.length < 2) return conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 خـاصـنـا 2 ديـال الاعـضـاء عـلـى الاقـل!*\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })

        let shuffled = users.sort(() => 0.5 - Math.random())
        let killer = shuffled[0]
        let victim = shuffled[1]

        let murderWeapons = [
            "قـتـلـه بـمـلـعـقـة مـسـمـومـة 🥄",
            "قـتـلـه بـضـحـكـة شـريـرة حـتـى مـات مـن الـخـوف 😱",
            "قـتـلـه بـسـلـك الـشـاحـن الاصـلـي 🔌",
            "قـتـلـه بـ 1000 سـتـيـكـر فـي ثـانـيـة 💥",
            "قـتـلـه بـريـمـوت الـتـلـفـاز 📺",
            "قـتـلـه بـصـنـدلـة طـائـرة مـن بـعـيـد 🩴",
            "قـتـلـه بـقـنـيـنـة مـاء بـاردة 🧊",
            "قـتـلـه بـقـطـع الـويـفـي عـنـه لـلأبـد 📵",
            "قـتـلـه بـمـوسـيـقـى حـزيـنـة لـمـدة 10 سـاعـات 🎧",
            "قـتـلـه بـنـظـرة حـقـد مـبـاشـرة 👁️",
            "قـتـلـه بـحـجـة انـه سـرق الـحـلـوى 🍬",
            "قـتـلـه بـسـبـب انـه مـا دارش لايـك لـلـبـوسـت ديـالـو 👍"
        ]

        let crimeScenes = [
            "فـي الـمـطـبـخ اثـنـاء سـرقـة الـطـعـام",
            "فـي الـمـجـمـوعـة وامـام الـجـمـيـع",
            "فـي الـخـاص بـدون شـهـود",
            "تـحـت الـبـطـانـيـة فـي لـيـلـة بـاردة",
            "فـوق سـطـح الـمـنـزل",
            "داخـل الـحـمـام وهـو كـيـغـنـي",
            "فـي الـمـقـهـى وهـو كـيـشـرب قـهـوة"
        ]

        let weapon = murderWeapons[Math.floor(Math.random() * murderWeapons.length)]
        let scene = crimeScenes[Math.floor(Math.random() * crimeScenes.length)]
        let imageUrl = 'https://files.catbox.moe/x8k0sq.jpg'

        let txt = `
* ━ ╼╃ ⌬〔🔪〕⌬ ╄╾ ━ *
*〔 ♛ 〕 مـحـكـمـة الـجـرائـم 𝐆𝐎𝐉𝐎*
* ━ ╼╃ ⌬〔 🩸 〕⌬ ╄╾ ━ *

*〔 😈 〕 الـقـاتـل :* @${killer.split('@')[0]}
*〔 ☠️ 〕 الـضـحـيـة :* @${victim.split('@')[0]}

*〔 🗡️ 〕 اداة الـجـريـمـة :*
*› ${weapon}*

*〔 📍 〕 مـكـان الـجـريـمـة :*
*› ${scene}*

*〔 🚨 〕 الـحـالـة :*
*› تـم الـقـتـل بـنـجـاح والـقـاتـل هـرب*

* ━ ╼╃ ⌬〔 📌 〕⌬ ╄╾ ━ *
*⚠️ تـنـبـيـه : هـادا الـكـود عـشـوائـي 100% لـلـتـرفـيـه فـقـط*
*لا يـوجـد قـتـل حـقـيـقـي حـنـا غـيـر كـنـضـحـكـو 😹*
* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`.trim()

        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: txt,
            mentions: [killer, victim]
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 خـطـأ:* ' + e.message + '\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })
    }
}

handler.help = ['قتل']
handler.tags = ['fun']
handler.command = ['قتل', 'جريمة', 'قاتل']
handler.group = true

export default handler