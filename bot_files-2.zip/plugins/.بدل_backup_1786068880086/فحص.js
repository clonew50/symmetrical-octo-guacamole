import { promises as fs } from 'fs';
import path from 'path';

// ──────────────────────────────────────────────
// دالة التنسيق المزخرف — حقوق GEO BOT
// ──────────────────────────────────────────────
function adamStyle(title, lines = [], footer = '◜⏤͟͟͞͞ ⚡_KAISER_ ⚡ 𝑩𝑶𝑻 ˖࣪⃟🩸 ◞') {
  const top =
    `⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞\n` +
    `≪  ❪ ♾️ ${title} ♾️ ❫ ≫\n` +
    `      ⛩️ ⚡_KAISER_ ・ 𝑩𝑶𝑻 ⛩️\n` +
    `≪ ━ ❪ 🩸 𝐓𝐇𝐄 𝐎𝐍𝐄 𝐀𝐁𝐎𝐕𝐄 𝐀𝐋𝐋 🩸 ❫ ━ ≫\n` +
    `⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞`;
  const mid = lines.map(l => `╟「 ${l.icon} 」↬ ${l.text}`).join('\n');
  const bot = `╰─── ≪ ❪ 🩸 ♾️ 🩸 ❫ ≫ ───╯\n${footer}`;
  return `${top}\n${mid}\n\n${bot}`;
}

// نسخة بمحتوى حر (للتقرير الديناميكي اللي بيتبني سطر بسطر)
function adamWrap(title, bodyText, footer = '◜⏤͟͟͞͞ ⚡_KAISER_ ⚡ 𝑩𝑶𝑻 ˖࣪⃟🩸 ◞') {
  const top =
    `⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞\n` +
    `≪  ❪ ♾️ ${title} ♾️ ❫ ≫\n` +
    `      ⛩️ ⚡_KAISER_ ・ 𝑩𝑶𝑻 ⛩️\n` +
    `≪ ━ ❪ 🩸 𝐓𝐇𝐄 𝐎𝐍𝐄 𝐀𝐁𝐎𝐕𝐄 𝐀𝐋𝐋 🩸 ❫ ━ ≫\n` +
    `⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞`;
  const bot = `╰─── ≪ ❪ 🩸 ♾️ 🩸 ❫ ≫ ───╯\n${footer}`;
  return `${top}\n${bodyText}\n\n${bot}`;
}

let handler = async (m, { conn, usedPrefix, command }) => {
  const pluginsDir = path.join(process.cwd(), 'plugins');
  let report = "";
  let foundIssues = false;
  let affectedFiles = new Set();

  try {
    // 1. التحقق من وجود المجلد لتجنب انهيار الكود مبكراً
    try {
      await fs.access(pluginsDir);
    } catch {
      return m.reply(adamStyle('ERROR', [
        { icon: '⚠️', text: 'مجلد الإضافات (plugins) غير موجود!' }
      ]));
    }

    // 2. قراءة أسماء الملفات بشكل غير متزامن (Async)
    const files = (await fs.readdir(pluginsDir)).filter(file => file.endsWith('.js'));

    if (files.length === 0) {
      return m.reply(adamStyle('NO FILES FOUND', [
        { icon: '⚠️', text: 'لا توجد ملفات بصيغة .js لفحصها' }
      ]));
    }

    await m.reply(adamStyle('SCANNING...', [
      { icon: '⏳', text: 'جاري الفحص السريع لجميع الملفات' }
    ]));

    // 3. الفحص المتوازي (Parallel Execution) - يقرأ كل الملفات في نفس اللحظة مما يضاعف السرعة
    await Promise.all(files.map(async (file) => {
      try {
        const filePath = path.join(pluginsDir, file);
        const content = await fs.readFile(filePath, 'utf-8');

        if (content.includes('emoji')) {
          const lines = content.split('\n');
          let fileReport = "";

          lines.forEach((line, index) => {
            if (line.includes('emoji')) {
              // قص السطر لو كان طويل جداً عشان رسالة الواتساب متكبرش وتعمل لاج
              const snippet = line.trim().substring(0, 60);
              fileReport += `📟 *السطر:* ${index + 1} | \`${snippet}...\`\n`;
              affectedFiles.add(file);
            }
          });

          if (fileReport) {
            report += `📂 *الملف:* ${file}\n${fileReport}─ ─ ─ ─ ─ ─ ─ ─ ─ ─\n`;
            foundIssues = true;
          }
        }
      } catch (readErr) {
        // إذا فشل قراءة ملف واحد، لن يتوقف الفحص! سيتخطاه بصمت ويكمل الباقي
        console.error(`❌ خطأ في قراءة الملف ${file}:`, readErr);
      }
    }));

    if (!foundIssues) {
      return m.reply(adamStyle('SCAN COMPLETE ✅', [
        { icon: '✅', text: 'لا يوجد أي ملف يستخدم كلمة emoji' },
        { icon: '🛡️', text: 'البوت في أمان!' }
      ]));
    }

    // 4. إرسال التقرير النهائي
    await m.reply(adamWrap('SCAN RESULTS 🔍', report + '\n💡 *جاري إرسال الملفات المصابة تباعاً... 📂*'));

    // 5. إرسال الملفات مع حماية ضد الحظر (Anti-Spam / Rate Limit)
    for (const file of affectedFiles) {
      try {
        const filePath = path.join(pluginsDir, file);
        const fileBuffer = await fs.readFile(filePath);

        await conn.sendMessage(m.chat, {
          document: fileBuffer,
          fileName: file,
          mimetype: 'application/javascript'
        }, { quoted: m });

        // تأخير زمني بسيط (نصف ثانية) بين كل ملف والآخر لمنع الواتساب من حظر البوت بسبب "السبام"
        await new Promise(resolve => setTimeout(resolve, 500));

      } catch (sendErr) {
        // لو فشل إرسال ملف، البوت مش هيعطل، هيبعت رسالة ويكمل اللي بعده
        console.error(`❌ خطأ في إرسال الملف ${file}:`, sendErr);
        await conn.sendMessage(m.chat, {
          text: adamStyle('SEND FAILED', [
            { icon: '⚠️', text: `فشل إرسال الملف: ${file}` }
          ])
        }, { quoted: m });
      }
    }

    await m.reply(adamStyle('ALL FILES SENT ✅', [
      { icon: '✅', text: 'تم الانتهاء من إرسال جميع الملفات' }
    ]));

  } catch (err) {
    console.error("خطأ عام في الفحص:", err);
    m.reply(adamStyle('UNEXPECTED ERROR', [
      { icon: '⚠️', text: 'حدث خطأ غير متوقع أثناء الفحص العام' }
    ]));
  }
};

handler.help = ['افحص'];
handler.tags = ['owner'];
handler.command = ['فحص', 'فحص_الاكواد', 'افحص'];
handler.owner = true;

export default handler