// ⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽
// 📌 البلاجين: تصويت مزيف مع منشن للكل
// Developed by: YONO DEV 🪖
// حقوق النشر محفوظة © 2026 GOJO BOT

let handler = async (m, { conn, participants, text }) => {
  if (!m.isGroup) return m.reply('⚠️ *هذا الامر خاص بالمجموعات فقط*')
  
  let users = participants.map(u => u.id)

  // السؤال ديال التصويت - تقدر تبدلو بالرسالة
  let pesan = text || "هل نبحث عن منصات استضافة اخرى؟ | Do you want more hosting platforms?"

  const content = {
    pollResultSnapshotMessage: {
      pollVotes: [
        {
          optionName: "نعم نريد المزيد | Yes we need",
          optionVoteCount: 9123456
        },
        {
          optionName: "لا هذا يكفي | No that's enough",
          optionVoteCount: 9345678
        },
        {
          optionName: "😑 فين غادي نلقاوهم؟ | Where?",
          optionVoteCount: 9876543
        }
      ],
      name: pesan,
      contextInfo: {
        mentionedJid: users,
        forwardingScore: 127,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363285847738492@newsletter",
          serverMessageId: 0,
          newsletterName: "⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽"
        },
        forwardOrigin: 0
      },
      pollType: 0
    }
  }

  await conn.relayMessage(m.chat, content, { mentions: users })
  await conn.sendMessage(m.chat, { react: { text: '📊', key: m.key } })
}

handler.help = ['hidetagfakepoll <السؤال>'];
handler.tags = ['المجموعة'];
handler.command = /^(hidetagfakepoll|تصويت_مزيف|منشن_تصويت)$/i;
handler.group = true;
handler.admin = true;

export default handler