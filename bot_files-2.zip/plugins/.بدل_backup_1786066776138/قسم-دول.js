import fetch from 'node-fetch';

import fs from 'fs';
import path from 'path';

function getRandomMediaUrl() {
  try {
    const filePath = path.join(process.cwd(), 'media-links.txt');
    const data = fs.readFileSync(filePath, 'utf-8');
    const links = data.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (links.length === 0) return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
    return links[Math.floor(Math.random() * links.length)];
  } catch (e) {
    console.error('تعذر قراءة media-links.txt:', e.message);
    return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
  }
}


const handler = async (m, { conn }) => {
    const imageUrl = getRandomMediaUrl();

    const messageText = `
*『 مـــۅرآحـبـاً بـــك يـــآ ⌊ ${m.pushName} ⌉ فـي 𓆩⚡⚡𝑮𝑬𝑶⚡𓆪 بـــوت 』*

*⌝ قـــســـم آلـــاڛـطـۿـآرآت دول ┋🎭⌞ ⇊*
*⎔ ⋅ ───━ •﹝🩸﹞• ━─── ⋅ ⎔*

🇲🇦┊⇇『 ا͠ل͠م͠غ͠ر͠ب͠ 』
🇵🇸┊⇇『 ف͢ل͢س͢ط͢ي͢ن͢ 』
🇾🇪┊⇇『 آلـيـمـن 』
🇯🇴┊⇇『 آلآردن 』
🇸🇦┊⇇『 آلسـعـۈديـه 』
🇮🇶┊⇇『 آلـعـراق 』
🇦🇪┊⇇『 آلإمــآرآت 』
🇸🇩┊⇇『 آلــســۈدآن 』
🇸🇾┊⇇『 ســۈريــآ 』
🇪🇬┊⇇『 مــصــر 』

*⎔ ⋅ ───━ •﹝🩸﹞• ━─── ⋅ ⎔*
> ✦ 𓆩⚡⚡𝑮𝑬𝑶-bₒₜ⚡𓆪 ✦ 💗💛
    `.trim();

    await conn.sendMessage(m.chat, { text: "*⟢ جـــآري إيــرڛــآل آلــقــســم....... 💗*" }, { quoted: m });

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: messageText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
};

handler.command = /^قسم-دول$/i;
handler.tags = ["𓆩⚡⚡𝑮𝑬𝑶⚡𓆪"];
handler.help = ["قسم-الترفيه"];

export default handler;