import { default as baileys } from '@whiskeysockets/baileys'

let handler = m => m

handler.before = async function (m, { conn, participants, groupMetadata }) {
  if (!m.messageStubType || !m.isGroup) return

  if (conn.isZarfRunning) return
  
  const fkontak = { 
    key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' }, 
    message: { 
      contactMessage: { 
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      }
    }, 
    participant: '0@s.whatsapp.net'
  }

  let usuario = `@${m.sender.split('@')[0]}`
  let pp = await conn.profilePictureUrl(m.chat, 'image').catch(_ => null) || 'https://files.catbox.moe/2oj0as.jpg'

  // الرسائل (نستخدم placeholders، لكن حالة الرابط هتتعامل لوحدها)
  let nombre = `《🩸》${usuario} غيّر اسم المجموعة 🐦‍⬛\n\n> ✧ الاسم الجديد:\n> *${m.messageStubParameters?.[0] || ''}*.`
  let foto = `《🩸》تم تغيير صورة المجموعة 🪷\n\n> ✧ تم التغيير بواسطة:\n> » ${usuario}`
  let edit = `《🩸》تم تغيير إعدادات الجروب 🪶\n\n> ✧ الآن فقط *${m.messageStubParameters?.[0] == 'on' ? 'الأدمنز' : 'الكل'}* يمكنهم تعديل معلومات الجروب.\n\n> ✧ تم التغيير بواسطة:\n> » ${usuario}`
  let status = `《🩸》الجروب تم ${m.messageStubParameters?.[0] == 'on' ? '*إغلاقه*' : '*فتحه*'} بواسطة ${usuario}\n\n> ✧ الآن ${m.messageStubParameters?.[0] == 'on' ? '*الأدمن فقط*' : '*الكل*'} يمكنه إرسال رسائل.`
  let admingp = `《🩸》@${m.messageStubParameters?.[0]?.split('@')[0]} تمت ترقيته 👏🐤\n\n> ✧ تم التغيير بواسطة:\n> » ${usuario}`
  let noadmingp =  `《🩸》@${m.messageStubParameters?.[0]?.split('@')[0]} تم خفضه من الإدارة 🐦\n\n> ✧ تم التغيير بواسطة:\n> » ${usuario}`
  let desc = `《🩸》تم تغيير وصف الجروب بواسطة:\n> » ${usuario}\n\n> ✧ الوصف الجديد:\n> ${m.messageStubParameters?.[0] || ''}`
  let kick = `💃🏻 تم طرد العضو بنجاح.✅️  ✨\n\n> ✧ العضو المجود من قروبنا:\n> @${m.messageStubParameters?.[0]?.split('@')[0] || '???'}\n\n> ✧ بواسطة:\n> » ${usuario}`

  // Helper: يحاول يجيب رابط الدعوة بطريقة ذكية
  const getInviteLink = async () => {
    try {
      // 1) جرب نلاقي رابط كامل في الـ params
      const param = m.messageStubParameters?.[0] || ''
      const linkMatch = param.match(/(https?:\/\/)?chat\.whatsapp\.com\/[0-9A-Za-z_-]{15,50}/i)
      if (linkMatch) {
        // لو في بروتوكول ناقص، خليه كامل
        let link = linkMatch[0]
        if (!/^https?:\/\//i.test(link)) link = 'https://' + link
        return { ok: true, link }
      }

      // 2) جرب لو الـ param نفسه كود الدعوة (20-24 حرف/رقم عادة)
      const codeMatch = param.match(/[0-9A-Za-z]{20,24}/)
      if (codeMatch) {
        return { ok: true, link: `https://chat.whatsapp.com/${codeMatch[0]}` }
      }

      // 3) لو مفيش، حاول تستدعي conn.groupInviteCode (مهم: البوت لازم يبقى أدمن علشان ينجح)
      try {
        const inviteCode = await conn.groupInviteCode(m.chat)
        if (inviteCode) return { ok: true, link: `https://chat.whatsapp.com/${inviteCode}` }
      } catch (e) {
        // فشل في جلب الكود (غالبًا البوت مش أدمن) — هنتعامل بعد اللوب
        // console.log('groupInviteCode error', e)
      }

      // 4) لو فشلنا في كل حاجة رجع فشل مع رسالة مفسرة
      return { ok: false, error: 'لم أستطع جلب الرابط الجديد. تأكد أني أدمن أو أن الرابط/الكود وصلني في الـ params.' }
    } catch (err) {
      return { ok: false, error: 'حصل خطأ غير متوقع أثناء جلب الرابط.' }
    }
  }

  switch (m.messageStubType) {
    case 21: // تغيير الاسم
      await conn.sendMessage(m.chat, { text: nombre, mentions: [m.sender] }, { quoted: fkontak })
      break

    case 22: // تغيير الصورة
      await conn.sendMessage(m.chat, { image: { url: pp }, caption: foto, mentions: [m.sender] }, { quoted: fkontak })
      break

    case 23: { // تغيير الرابط — هنا نستخدم الـ helper
      const result = await getInviteLink()
      if (result.ok) {
        const newlinkMsg = `《🩸》تم تغيير رابط الجروب 🔗\n\n> ✧ الرابط الجديد:\n> ${result.link}\n\n> ✦ تم التغيير بواسطة: ${usuario}`
        await conn.sendMessage(m.chat, { text: newlinkMsg, mentions: [m.sender] }, { quoted: fkontak })
      } else {
        const failMsg = `《🩸》تم تغيير رابط الجروب 🔗\n\n> ✧ لكن: ${result.error}\n\n> ✦ تم التغيير بواسطة: ${usuario}`
        await conn.sendMessage(m.chat, { text: failMsg, mentions: [m.sender] }, { quoted: fkontak })
      }
      break
    }

    case 25: // تغيير إعدادات الجروب (مين يعدل المعلومات)
      await conn.sendMessage(m.chat, { text: edit, mentions: [m.sender] }, { quoted: fkontak })
      break

    case 26: // فتح/قفل الجروب
      await conn.sendMessage(m.chat, { text: status, mentions: [m.sender] }, { quoted: fkontak })
      break

    case 29: // ترقية
      await conn.sendMessage(m.chat, { text: admingp, mentions: [`${m.sender}`,`${m.messageStubParameters?.[0]}`] }, { quoted: fkontak })
      break

    case 30: // خفض من الأدمنية
      await conn.sendMessage(m.chat, { text: noadmingp, mentions: [`${m.sender}`,`${m.messageStubParameters?.[0]}`] }, { quoted: fkontak })
      break

    case 24: // تغيير الوصف
      await conn.sendMessage(m.chat, { text: desc, mentions: [m.sender] }, { quoted: fkontak })
      break

    case 28: // طرد عضو
      await conn.sendMessage(m.chat, { text: kick, mentions: [`${m.sender}`,`${m.messageStubParameters?.[0]}`] }, { quoted: fkontak })
      break

    default:
      if (m.messageStubType == 2) return
      console.log({
        messageStubType: m.messageStubType,
        messageStubParameters: m.messageStubParameters,
        type: baileys.WAMessageStubType[m.messageStubType]
      })
  }
}

export default handler