import fetch from 'node-fetch';

import fs from 'fs';
import path from 'path';

function getRandomMediaUrl() {
  try {
    const filePath = path.join(process.cwd(), 'media-links.txt');
    const data = fs.readFileSync(filePath, 'utf-8');
    const links = data.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (links.length === 0) return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
    return links[Math.floor(Math.random() * links.length)];
  } catch (e) {
    console.error('تعذر قراءة media-links.txt:', e.message);
    return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
  }
}


const handler = async (m, { conn }) => {
    const imageUrl = getRandomMediaUrl();

    const messageText = `
*『 ✧ مـرحبـاً بـك يا ⌊ ${m.pushName} ⌉ ✧ 』*  
*فـي قـسم ┇ التـرفيه 🎭 داخـل بـوت 𓆩⚡_KAISER_𓆪*

╭───━ • ✦ • ━───╮  
   ⟡ ˚ ༘ ⋆｡𖦹  
   ˚⌝ قـسم الـتـرفيه 🎉⌞ ˚  
╰───━ • ✦ • ━───╯  

👥┊⇇『 ✧ أصحـاب ✧ 』  
⚔️┊⇇『 ✧ إعـدام ✧ 』  
🏆┊⇇『 ✧ تــوب ✧ 』  
🎭┊⇇『 ✧ الشخـصية ✧ 』  
🗣️┊⇇『 ✧ الصـراحة ✧ 』  
⚽┊⇇『 ✧ الكـورة ✧ 』  
😈┊⇇『 ✧ إنحـرافي ✧ 』  
🎸┊⇇『 ✧ إيـمو ✧ 』  
🐾┊⇇『 ✧ بوسـتات ✧ 』  
📝┊⇇『 ✧ بوسـت ✧ 』  
🚔┊⇇『 ✧ بــوليس ✧ 』  
💎┊⇇『 ✧ بيبضنـي ✧ 』  
❤️┊⇇『 ✧ بيحبنـي ✧ 』  
💔┊⇇『 ✧ بيكرهـني ✧ 』  
👑┊⇇『 ✧ تــاج ✧ 』  
💣┊⇇『 ✧ تفجيـر ✧ 』  
🔠┊⇇『 ✧ حـروف ✧ 』  
🍀┊⇇『 ✧ حظـي ✧ 』  
🐏┊⇇『 ✧ خـروف ✧ 』  
💍┊⇇『 ✧ خطـوبة ✧ 』  
🧠┊⇇『 ✧ ذكـاء ✧ 』  
🦾┊⇇『 ✧ رجـولتي ✧ 』  
🧑‍🤝‍🧑┊⇇『 ✧ رفـيق ✧ 』  
🎭┊⇇『 ✧ شخـصية ✧ 』  
🤝┊⇇『 ✧ صديـق ✧ 』  
🎤┊⇇『 ✧ صراحـتي ✧ 』  
💔┊⇇『 ✧ طـلاق ✧ 』  
💞┊⇇『 ✧ علاقـة ✧ 』  
❓┊⇇『 ✧ فزورة ✧ 』  
🎥┊⇇『 ✧ فيلـم ✧ 』  
🔪┊⇇『 ✧ قـتل ✧ 』  
🖤┊⇇『 ✧ قـطة ✧ 』  
📖┊⇇『 ✧ مقـولات ✧ 』  
🎲┊⇇『 ✧ نـرد ✧ 』  
📊┊⇇『 ✧ نـوعية ✧ 』  
🔍┊⇇『 ✧ هـذا ✧ 』  
❔┊⇇『 ✧ هـل ✧ 』  
⚰️┊⇇『 ✧ وفاتـي ✧ 』  

╭───━ • ✦ • ━───╮  
 > ✧ هذا القسم قيد التطوير ✧  
╰───━ • ✦ • ━───╯  

> جــيـ بـــ⚡_KAISER_ـــوت 🕷️💗
    `.trim();

    await conn.sendMessage(m.chat, { text: "*_⏳ جاري إرسال قسم الترفيه... 🎭_*" }, { quoted: m });

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: messageText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '🎭', key: m.key } });
};

handler.command = /^قسم-الترفيه$/i;
handler.tags = ["جــــيـــو"];
handler.help = ["قسم-الترفيه"];

export default handler;