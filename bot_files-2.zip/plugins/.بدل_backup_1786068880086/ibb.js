import fetch from 'node-fetch'
import FormData from 'form-data'
import { downloadContentFromMessage } from '@whiskeysockets/baileys'

// 🔑 مفاتيح API الخاصة بك (يتم التنقل بينها تلقائياً عند الحاجة)
const IMGBB_KEYS = [
  '7a38ad69727561d8adb5fcbbc7080e09',
  '33ab161c1a9ae4c282fa49fd77ac5b89'
]

/**
 * ==========================================================
 * GEO BOT - ADVANCED IMAGE UPLOADER MODULE
 * ==========================================================
 * Helper: Extract image message safely from current context or reply
 */
function extractImageMessage(m) {
  try {
    const context = m.quoted ? m.quoted : m
    if (!context) return null

    if (context.mtype === 'imageMessage' || context.mediaType === 'image' || context.type === 'image') {
      return context.msg || context.message?.imageMessage || context
    }

    const mime = context.mimetype || context.msg?.mimetype || ''
    if (mime.startsWith('image/')) {
      return context.msg || context
    }

    const rootMsg = context.message || context.msg || context
    if (rootMsg) {
      if (rootMsg.imageMessage) return rootMsg.imageMessage
      if (rootMsg.viewOnceMessage?.message?.imageMessage) return rootMsg.viewOnceMessage.message.imageMessage
      if (rootMsg.viewOnceMessageV2?.message?.imageMessage) return rootMsg.viewOnceMessageV2.message.imageMessage
      if (rootMsg.ephemeralMessage?.message?.imageMessage) return rootMsg.ephemeralMessage.message.imageMessage
      if (rootMsg.documentMessage && (rootMsg.documentMessage.mimetype || '').startsWith('image/')) {
        return rootMsg.documentMessage
      }
    }
  } catch (error) {
    console.error('[GEO UPLOADER] Error extracting image message:', error)
  }
  return null
}

/**
 * Helper: Download media stream into Buffer safely
 */
async function getMediaBuffer(imgMsg, m) {
  if (m.quoted && typeof m.quoted.download === 'function') {
    try {
      const buffer = await m.quoted.download()
      if (buffer && buffer.length > 500) return buffer
    } catch (e) {
      console.log('[GEO UPLOADER] Primary download method failed, trying stream fallback...')
    }
  }

  try {
    const stream = await downloadContentFromMessage(imgMsg, 'image')
    let bufferList = []
    for await (const chunk of stream) {
      bufferList.push(chunk)
    }
    const finalBuffer = Buffer.concat(bufferList)
    if (finalBuffer && finalBuffer.length > 500) return finalBuffer
  } catch (e) {
    console.error('[GEO UPLOADER] Stream download error:', e)
  }

  return null
}

/**
 * Upload using ImgBB Official API Key
 */
async function uploadToImgBB(buffer, apiKey) {
  try {
    const base64Image = buffer.toString('base64')
    const form = new FormData()
    form.append('image', base64Image)

    const response = await fetch(`https://api.imgbb.com/1/upload?key=${apiKey}`, {
      method: 'POST',
      body: form
    })

    const data = await response.json()
    if (data && data.success && data.data && data.data.url) {
      return data.data.url
    }
  } catch (err) {
    console.error(`[GEO UPLOADER] ImgBB error with key ${apiKey.substring(0, 5)}...:`, err.message)
  }
  return null
}

/**
 * Fallback Provider: Pixeldrain API
 */
async function uploadToPixeldrain(buffer) {
  try {
    const form = new FormData()
    form.append('file', buffer, { filename: 'media_' + Date.now() + '.jpg' })

    const response = await fetch('https://pixeldrain.com/api/file', {
      method: 'POST',
      body: form
    })

    const data = await response.json()
    if (data && data.id) {
      return `https://pixeldrain.com/api/file/${data.id}`
    }
  } catch (err) {
    console.error('[GEO UPLOADER] Pixeldrain fallback error:', err.message)
  }
  return null
}

/**
 * Main Command Handler Function
 */
let handler = async (m, { conn, usedPrefix, command }) => {
  const targetMsg = extractImageMessage(m)

  if (!targetMsg) {
    return m.reply(
      `❌ *لم يتم العثور على صورة!*\n\n` +
      `📌 *كيفية الاستخدام:*\n` +
      `قم بالرد على أي صورة أو أرسل صورة مع كتابة الأمر التالي:\n` +
      `• \`${usedPrefix + command}\``
    )
  }

  await m.reply('⏳ *جاري الرفع باستخدام المفاتيح الرسمية...*')

  try {
    // 1. Download Buffer
    const imageBuffer = await getMediaBuffer(targetMsg, m)

    if (!imageBuffer || imageBuffer.length < 500) {
      throw new Error('فشل تنزيل ملف الصورة من الواتساب.')
    }

    let uploadedUrl = null
    let selectedProvider = ''

    // 2. Try ImgBB Key #1
    uploadedUrl = await uploadToImgBB(imageBuffer, IMGBB_KEYS[0])
    if (uploadedUrl) {
      selectedProvider = 'ImgBB API (Primary Key)'
    } else {
      // 3. Try ImgBB Key #2 if Key #1 failed
      console.log('[GEO UPLOADER] Primary key failed, switching to backup key...')
      uploadedUrl = await uploadToImgBB(imageBuffer, IMGBB_KEYS[1])
      if (uploadedUrl) {
        selectedProvider = 'ImgBB API (Backup Key)'
      }
    }

    // 4. Try Pixeldrain as ultimate fallback
    if (!uploadedUrl) {
      console.log('[GEO UPLOADER] All ImgBB keys failed, falling back to Pixeldrain...')
      uploadedUrl = await uploadToPixeldrain(imageBuffer)
      if (uploadedUrl) {
        selectedProvider = 'Pixeldrain Engine'
      }
    }

    if (!uploadedUrl) {
      throw new Error('فشل الرفع على جميع الخوجـيـو والمفاتيح المتاحة.')
    }

    // 5. Build Caption & Response
    const fileSizeKB = (imageBuffer.length / 1024).toFixed(2)
    const captionText = 
`✅ *تم رفع الصورة بنجاح!*

⚙️ *المحرك:* ${selectedProvider}
💾 *الحجم:* ${fileSizeKB} KB

🔗 *الرابط المباشر:*
${uploadedUrl}

👑 ⚡_KAISER_ 𝕭𝖔𝖙 — Uploader Engine`

    // Send final preview image with caption
    await conn.sendMessage(
      m.chat, 
      { 
        image: imageBuffer, 
        caption: captionText 
      }, 
      { quoted: m }
    )

  } catch (error) {
    console.error('[GEO UPLOADER ERROR]:', error)
    return m.reply(`❌ *حدث خطأ أثناء تنفيذ الأمر*\n\n🔎 *التفاصيل:* ${error.message || 'خطأ غير معروف'}`)
  }
}

handler.help    = ['ibb']
handler.tags    = ['tools']
handler.command = /^(ibb|upload|رفع|رفع-صورة)$/i

export default handler