/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * امر: احفظ
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━
 * By : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 212674375708
 */

import fs from 'fs'
import path from 'path'
import { generateWAMessageFromContent } from '@whiskeysockets/baileys'

let handler = async (m, { conn, text, usedPrefix, command }) => {
   // 1. التحقق من إدخال اسم الملف
   if (!text) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ خـطـأ فـي الاسـتـخـدام┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـطـريـقـة ↶ 🕸️﹞*
> *🥷🏻┊* ${usedPrefix + command} اسـم_الـمـلـف
> *🥷🏻┊* رد على الكود الذي تريد حفظه

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)

   // 2. التحقق من الرسالة المقتبسة
   const quoted = m.quoted? m.quoted : m.msg?.contextInfo?.quotedMessage
   if (!quoted) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ لـم تـتـم الـعـمـلـيـة┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـتـنـبـيـه ↶ 🕸️﹞*
> *🥷🏻┊* يجب الرد على الكود او النص المراد حفظه

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)

   const quotedMessage = m.quoted?.text ||
                         m.quoted?.msg ||
                         m.quoted?.conversation ||
                         (typeof m.quoted === 'string'? m.quoted : null)

   if (!quotedMessage || typeof quotedMessage!== 'string') {
      return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ لـم يـتـم الـتـعـرف عـلـى الـنـص┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـمـلاحـظـة ↶ 🕸️﹞*
> *🥷🏻┊* تأكد ان الرسالة نصية وتحتوي على كود

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
   }

   // 3. تنظيف اسم الملف وحماية
   let fileName = text.trim().replace(/\s+/g, '_')
   if (!fileName.endsWith('.js') &&!fileName.endsWith('.json')) {
      fileName += '.js'
   }

   // حماية: منع../
   if (fileName.includes('..')) {
      return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ مـمـنـوع┊ ˼‏ 🔒˹ ↶〕*

*🪖 ──¤﹝الـحـمـايـة ↶ 🕸️﹞*
> *🥷🏻┊* لا يمكن الحفظ خارج مجلد plugins

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
   }

   const pluginsDir = path.join(process.cwd(), 'plugins')
   const filePath = path.join(pluginsDir, fileName)
   const normalizedPath = `/home/container/plugins/${fileName}`

   const botJid = conn.user?.id?.includes(':')? conn.user.id.split(':')[0] + '@s.whatsapp.net' : conn.user?.id
   const botMeta = {
      isForwarded: true,
      forwardingScore: 999,
      forwardedAiBotMessageInfo: { botJid: '867051314767696@bot' },
      forwardOrigin: 4
   }

   const sendRich = async (richMessage) => {
      const msg = await generateWAMessageFromContent(m.chat, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
                  body: { text: richMessage.richResponseMessage.submessages[0].messageText },
                  footer: { text: '🔮 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓' },
                  contextInfo: botMeta,
                  nativeFlowMessage: {
                     buttons: [
                        {
                           name: 'quick_reply',
                           buttonParamsJson: JSON.stringify({ display_text: '📂 عرض الملفات', id: `${usedPrefix}باتش` })
                        },
                        {
                           name: 'quick_reply',
                           buttonParamsJson: JSON.stringify({ display_text: '🗑️ حذف الملف', id: `${usedPrefix}م ${fileName.replace('.js','')}` })
                        }
                     ]
                  }
               }
            }
         }
      }, { userJid: botJid, quoted: m })

      return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
   }

   try {
      if (!fs.existsSync(pluginsDir)) {
         fs.mkdirSync(pluginsDir, { recursive: true })
      }

      fs.writeFileSync(filePath, quotedMessage, 'utf-8')
      await m.react('✅')

      // رسالة النجاح بالزخرفة
      return sendRich({
         richResponseMessage: {
            submessages: [
               {
                  messageText: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ✅ تـم الـحـفـظ بـنـجـاح┊ ˼‏ 📂˹ ↶〕*

*🪖 ──¤﹝تـفـاصـيـل الـمـلـف ↶ 🕸️﹞*
> *🥷🏻┊* اسـم الـمـلـف: ${fileName}
> *🥷🏻┊* الـمـسـار: ${normalizedPath}
> *🥷🏻┊* الـمـطـور: 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`
               }
            ]
         }
      })

   } catch (e) {
      console.error(e)
      await m.react('❌')
      return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ خـطـأ┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـسـبـب ↶ 🕸️﹞*
> *🥷🏻┊* ${e.message}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
   }
}

handler.help = ['احفظ'];
handler.command = /^(ح)$/i;
handler.tags = ['👑 المالك'];
handler.owner = true;
handler.register = true;

export default handler;