// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ * GOJO ADMIN FIX FINAL V25

// دالة فحص الآدمن الصحيحة ضد LID
async function isAdminCheck(conn, chatId, userJid) {
  const meta = await conn.groupMetadata(chatId)
  const userNum = userJid.split('@')[0].split(':')[0]

  for (let p of meta.participants) {
    let pId = (p.id || p.jid || '').split('@')[0].split(':')[0]
    let pPhone = (p.phoneNumber || '').split('@')[0].split(':')[0]

    // كيقلب فـ id و phoneNumber بجوج باش يلقاك وخا تكون LID
    if ((pId === userNum || pPhone === userNum) && (p.admin === 'admin' || p.admin === 'superadmin')) {
      return true
    }
    // حالة خاصة: إلا كان sender هو LID
    if (userJid.includes('@lid') && p.id === userJid && p.admin) return true
  }
  return false
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!m.chat.endsWith('@g.us')) return

  // فحص آدمن مضمون
  let senderIsAdmin = await isAdminCheck(conn, m.chat, m.sender)
  let isOwner = global.owner?.some(v => m.sender.includes(v[0]))

  if (!senderIsAdmin &&!isOwner) {
    return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 👑 〕خاصك تكون آدمن باش تنفد.${command}*\n> *〔 🆔 〕الايدي ديالك:* ${m.sender}\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
  }

  let who;
  if (m.mentionedJid?.[0]) who = m.mentionedJid[0]
  else if (m.quoted) who = m.quoted.sender
  else {
    let n = text?.match(/\d{8,15}/)
    if (n) who = n[0] + '@s.whatsapp.net'
  }

  if (!who) return m.reply(`منشن الشخص: ${usedPrefix+command} @user`)

  if (!global.db.data.users[who]) global.db.data.users[who] = { warn: 0 }
  let user = global.db.data.users[who]
  let reason = text?.replace(/@\d+/g,'').trim() || 'بدون سبب'
  user.warn++

  await conn.sendMessage(m.chat, {
    text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ⚠️ 〕تحذير @${who.split('@')[0]}*\n*السبب:* ${reason}\n*التحذيرات:* ${user.warn}/3\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`,
    mentions: [who]
  }, { quoted: m })

  if (user.warn >= 3) {
    user.warn = 0
    try {
      await conn.groupParticipantsUpdate(m.chat, [who], 'remove')
      await m.reply(`تم طرد @${who.split('@')[0]} بعد 3 تحذيرات`)
    } catch {
      await m.reply(`مقدرتش نطردو، واش أنا آدمن؟`)
    }
  }
}

handler.command = /^(تحذير|warn|انذار|قبول|اقبل)$/i
handler.group = true
handler.admin = false
handler.botAdmin = false
export default handler