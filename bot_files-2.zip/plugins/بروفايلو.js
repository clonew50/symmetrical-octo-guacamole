// • 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 - بروفايلو FIXED 100%
import { xpRange } from '../lib/levelling.js'

let handler = async (m, { conn, usedPrefix }) => {
  let who = m.mentionedJid && m.mentionedJid[0]? m.mentionedJid[0] : m.quoted? m.quoted.sender : null

  if (!who) {
    return conn.reply(m.chat, `* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *

> *❌┊خاصك تمنشن*

> *الطريقة:*
> > \`${usedPrefix}بروفايلو @الشخص\`
> > *او رد على رسالتو*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m)
  }

  try {
    let user = global.db.data.users[who]
    if (!user) user = global.db.data.users[who] = { exp: 0, limit: 10, level: 1, role: 'عضو', name: 'مجهول', registered: false }

    let pp = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://telegra.ph/file/24fa902ead26340f3df2c.png')
    let { level, exp, role, name } = user
    let { min, xp, max } = xpRange(level, global.multiplier)
    let realName = await conn.getName(who)

    let text = `* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *

> *〔 بروفايلو┊ 👤 〕* *${realName}*

> *🪪┊الاسم:* ${name || realName}
> *📱┊الرقم:* wa.me/${who.split('@')[0]}
> *⭐┊المستوى:* ${level}
> *🏅┊الرتبة:* ${role}
> *✨┊الخبرة:* ${exp - min}/${xp}
> *💎┊الباقي:* ${max - exp}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *
> *طلب بواسطة:* @${m.sender.split('@')[0]}`

    await conn.sendMessage(m.chat, { image: { url: pp }, caption: text, mentions: [who, m.sender] }, { quoted: m })

  } catch (e) {
    console.log(e)
    await conn.reply(m.chat, `> *❌┊خطأ:* ${e.message}`, m)
  }
}

handler.command = /^(بروفايلو|برفايلو)$/i
handler.tags = ['group']
handler.help = ['بروفايلو @منشن']
export default handler