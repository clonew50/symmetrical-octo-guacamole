import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const handler = async (m, { conn }) => {
    const imageUrl = "https://i.ibb.co/KpDnSFq0/gojo-1784466176992.jpg"; // رابط الصورة المصغرة
    const link1 = "https://https://https://wa.me/9647882860837"; // الرابط الأول (اتصال مع المطور)
    const link2 = "https://chat.whatsapp.com/I7geb2k5vN78nDmaARVyM8?s=cl&p=a&ilr=1&amv=1"; // الرابط الثاني (القناة)

    // تجهيز الصورة المصغرة
    const media = await prepareWAMessageMedia(
        { image: { url: imageUrl } },
        { upload: conn.waUploadToServer }
    );

    // إنشاء الرسالة التفاعلية
    const interactiveMessage = {
        body: { text: "مـرحـبـا اسـمـي جـيـو مـطـوري جـيـو المز ✳️ اسـتـخـدم امـر (.اوامـر) لطلب القائمة" },
        footer: { text: "｢♡┆𝙱𝙾𝚃-⚡𝑮𝑬𝑶┆♡｣" },
        header: { 
            title: "❪🩸┇𝙱𝙾𝚃-⚡𝑮𝑬𝑶┇🎤❫", 
            hasMediaAttachment: true, 
            imageMessage: media.imageMessage 
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "｢🍷┊لـلـمـطـور┊🍷｣",
                        url: link1
                    })
                },
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "｢🍷┊القناة┊🍷｣",
                        url: link2
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "⌈🚀╎اوامر╎🚀⌋",
                        id: ".اوامر"
                    })
                }
            ]
        }
    };

    // إرسال الرسالة
    let msg = generateWAMessageFromContent(
        m.chat,
        { viewOnceMessage: { message: { interactiveMessage } } },
        { userJid: conn.user.jid, quoted: m }
    );

    conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

handler.command = /^بوت$/i; // تشغيل الكود عند كتابة ".بوت"

export default handler;