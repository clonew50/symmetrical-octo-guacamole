import { createHash } from 'crypto';

const handler = async function(m, { conn, text, usedPrefix, command }) {
  const groupId = m.chat;
  let users = global.db.data.users;

  // تأكد من وجود بيانات المستخدم
  if (!users[m.sender]) users[m.sender] = {};
  if (!users[m.sender].groups) users[m.sender].groups = {};

  const user = users[m.sender];

  try {
    if (command === 'حجز_لقب') {
      if (!text) {
        const usage = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 طـريـقـة حـجـز الـلـقـب ┊ ˼‏ 👑˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *🥷🏻┊${usedPrefix + command} <اللقب>*
> *🥷🏻┊مثال: ${usedPrefix + command} زعيم*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`
        throw usage
      }

      // التأكد مما إذا كان لديه لقب محجوز مسبقًا
      if (user.groups[groupId]?.name) {
        throw `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 خـطـأ ┊ ˼‏ ❌˹ ↶〕*
> *🥷🏻 لديك لقب محجوز بالفعل:*
> *👑 ${user.groups[groupId].name}*
> *لإلغائه استخدم: ${usedPrefix}الغاء_حجز*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`
      }

      // التأكد مما إذا كان اللقب محجوزًا بالفعل من شخص آخر
      for (let key in users) {
        if (users[key].groups?.[groupId]?.name?.toLowerCase() === text.toLowerCase()) {
          throw `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 خـطـأ ┊ ˼‏ ❌˹ ↶〕*
> *🥷🏻 هذا اللقب محجوز بالفعل من قبل شخص آخر*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`
        }
      }

      // تسجيل اللقب للمستخدم
      user.groups[groupId] = { name: text, regTime: Date.now(), registered: true };
      users[m.sender] = user;

      await conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 تـم الـحـجـز ┊ ˼‏ ✅˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *👑 تم حجز اللقب بنجاح*
> *🏷️ اللقب:* ${text}
> *👤 العضو:* @${m.sender.split('@')[0]}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`, m, { mentions: [m.sender] });

    } else if (command === 'الالقاب_المحجوزه') {
      let reservedNames = [];

      for (let key in users) {
        const u = users[key];
        if (u.groups?.[groupId]?.name) {
          reservedNames.push(`> *🥷🏻┊${u.groups[groupId].name}* @${key.split('@')[0]}\n> *📅 منذ:* ${formatDate(u.groups[groupId].regTime)}`);
        }
      }

      if (reservedNames.length === 0) {
        throw `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الألـقـاب الـمـحـجـوزة ┊ ˼‏ 👑˹ ↶〕*
> *🥷🏻 لا توجد ألقاب محجوزة في هذه المجموعة*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`
      }

      const body = `> *📌 المجموعة:* ${await conn.groupMetadata(groupId).then(g => g.subject)}\n> *👑 عدد الألقاب:* ${reservedNames.length}\n\n${reservedNames.join('\n━━━━━━━━━━━━\n')}`

      await conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الألـقـاب الـمـحـجـوزة ┊ ˼‏ 👑˹ ↶〕*

*🪖 ──¤﹝الـقـائـمـة ↶ 🕸️﹞*
${body}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`, m, { mentions: Object.keys(users).filter(k => users[k].groups?.[groupId]?.name) });

    } else if (command === 'الغاء_حجز') {
      // التأكد مما إذا كان لديه لقب محجوز
      if (!user.groups?.[groupId]?.name) {
        throw `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 خـطـأ ┊ ˼‏ ❌˹ ↶〕*
> *🥷🏻 ليس لديك أي لقب محجوز لإلغائه*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`
      }

      const oldName = user.groups[groupId].name;
      delete user.groups[groupId];
      users[m.sender] = user;

      await conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 تـم الإلـغـاء ┊ ˼‏ 🗑️˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *🗑️ تم إلغاء حجز اللقب*
> *🏷️ اللقب:* ${oldName}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`, m);
    }

  } catch (err) {
    await conn.reply(m.chat, err, m);
  }
};

function formatDate(timestamp) {
  const date = new Date(timestamp);
  return `${date.toLocaleDateString('ar-EG')} - ${date.toLocaleTimeString('ar-EG')}`;
}

handler.help = ['حجز_لقب <الاسم>', 'الالقاب_المحجوزه', 'الغاء_حجز'];
handler.tags = ['مجموعة'];
handler.command = /^(حجز_لقب|الالقاب_المحجوزه|الغاء_حجز)$/i;
handler.group = true;

export default handler;