/*
 * 🎨 morph_edit.js - تعديل الصور بالذكاء الاصطناعي (Geo Morph AI)
 * 👤 الأوامر : .مورف | .تعديل | .morph
 * 👨🏻‍💻 الـمُـطَـوِّر: ⚡𝑮𝑬𝑶 𝑫𝑬𝑽⃢҉ جـــيـــو
 * 🎯 الـبُـوت: ⃟꙰⃢  ⚡𝑮𝑬𝑶➥𝙱ᝪᝨ ❯ |‌⃟🇲🇦‌|‌
 */

import axios from 'axios'
import fetch from 'node-fetch'
import FormData from 'form-data'
import { fileTypeFromBuffer } from 'file-type'

// دالة الانتظار
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

let handler = async (m, { conn, text, usedPrefix, command }) => {
   const q = m.quoted ? m.quoted : m
   const mime = (q.msg || q).mimetype || ''

   // 1. الفحص إن تم التفاعل مع صورة
   if (!/image/.test(mime)) {
      return m.reply(
         `⚠️ *يرجى إرسال أو الرد على صورة لتعديلها!*\n\n` +
         `📌 *مثال الاستخدام:*\n` +
         `قم بالرد على صورة واكتب: \`${usedPrefix + command} Make the character pink\``
      )
   }

   // 2. الفحص إن تم إدخال الوصف والتعديل المطلوب
   if (!text) {
      return m.reply(
         `⚠️ *يرجى كتابة التعديل المطلوب تطبيقه على الصورة!*\n\n` +
         `📌 *مثال:* \`${usedPrefix + command} Make the background a sunset\``
      )
   }

   await m.reply('🎨 *جاري رفع الصورة وتعديلها بالذكاء الاصطناعي (Geo Morph AI)...* ⏳')

   try {
      // 3. تنزيل الصورة ورفعها إلى Uguu للحصول على رابط مباشر
      const media = await q.download()
      const { ext } = await fileTypeFromBuffer(media)
      const imageUrl = await uploadToUguu(media, ext)

      // 4. إرسال الطلب إلى API الجديد
      const apiUrl = `https://sonic-dev-api.vercel.app/api/morph` +
         `?imageUrl=${encodeURIComponent(imageUrl)}` +
         `&prompt=${encodeURIComponent(text)}`

      const { data } = await axios.get(apiUrl, {
         headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json'
         },
         timeout: 45000
      })

      // التحقق من الاستجابة بحسب بنية API الجديد (data.ok و data.resultImage)
      if (!data || !data.ok || !data.resultImage) {
         return m.reply('❌ فشل في تعديل الصورة، يرجى المحاولة بوصف آخر أو صورة أوضح.')
      }

      const resultImageUrl = data.resultImage

      // 5. الانتظار وجلب الصورة كـ Buffer مع تكرار المحاولة لضمان اكتمال رفعها في السيرفر
      const imageBuffer = await fetchImageWithRetry(resultImageUrl, 5, 2000)

      let caption = `✨ *تم تعديل الصورة بنجاح (Geo Morph AI)!*\n\n`
      caption += `📝 *التعديل:* ${text}\n`
      caption += `👨🏻‍💻 *المطور:* ${data.creator || '⚡𝑮𝑬𝑶 𝑫𝑬𝑽⃢҉'}`

      // 6. إرسال الصورة الجاهزة للواتساب
      return await conn.sendMessage(
         m.chat,
         {
            image: imageBuffer,
            caption: caption.trim()
         },
         { quoted: m }
      )

   } catch (e) {
      console.error(e)
      return m.reply(`❌ حدث خطأ أثناء عملية المعالجة:\n${e.message}`)
   }
}

handler.help = ['مورف']
handler.command = /^(مورف|تعديل|morph|morphai)$/i
handler.tags = ['ai']

export default handler

// --- دالة تجلب الصورة وتتأكد من جاهزيتها على السيرفر ---
const fetchImageWithRetry = async (url, retries = 5, delayMs = 2000) => {
   for (let i = 0; i < retries; i++) {
      try {
         await sleep(delayMs)

         const res = await axios.get(url, {
            responseType: 'arraybuffer',
            headers: {
               'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
         })

         const contentType = res.headers['content-type'] || ''
         if (res.status === 200 && !contentType.includes('xml')) {
            return Buffer.from(res.data)
         }
      } catch (err) {
         // متابعة المحاولة في حال لم تجهز الصورة بعد
      }
   }
   throw new Error('استغرق السيرفر وقتاً طويلاً في تجهيز الصورة، يرجى المحاولة مرة أخرى.')
}

// --- دالة الرفع السحابي إلى Uguu ---
const uploadToUguu = async (buffer, ext) => {
   const form = new FormData()
   form.append('files[]', buffer, `SONIC_FILE.${ext}`)

   const response = await fetch('https://uguu.se/upload.php', {
      method: 'POST',
      body: form
   })

   const result = await response.json()

   if (!result.files || result.files.length === 0) {
      throw new Error('فشل الرفع المباشر إلى سيرفر Uguu.se')
   }

   return result.files[0].url
}