let handler = async (m, { conn, command }) => {
  let groupMetadata = await conn.groupMetadata(m.chat)
  let participants = groupMetadata.participants

  // فحص البوت آدمن بطريقة صحيحة 100%
  let botJid = conn.user.jid
  let bot = participants.find(p =>
    p.id === botJid ||
    p.jid === botJid ||
    p.id === botJid.split(':')[0] + '@s.whatsapp.net' ||
    p.jid === botJid.split(':')[0] + '@s.whatsapp.net'
  )
  let isBotAdmin = bot?.admin === 'admin' || bot?.admin === 'superadmin'

  // فحص المرسل آدمن
  let sender = participants.find(p => p.id === m.sender || p.jid === m.sender)
  let isAdmin = sender?.admin === 'admin' || sender?.admin === 'superadmin'

  if (!isAdmin) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> ❌ خاصك تكون آدمن باش تستعمل هاد الأمر\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m)

  if (!isBotAdmin) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> ❌ البوت ليس مشرف\n> تأكد أنك رافع البوت آدمن\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m)

  let isClose = ['قفل','اقفل','close'].includes(command)
  let img = 'https://files.catbox.moe/gqp5td.jpeg'

  try {
    await conn.groupSettingUpdate(m.chat, isClose? 'announcement' : 'not_announcement')
  } catch (e) {
    return conn.reply(m.chat, `❌ فشل: ${e.message}\nجرب ترفع البوت آدمن مرة أخرى`, m)
  }

  let caption = isClose?
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 تـم قـفـل الـمـجـمـوعـة┊ 🔒 ↶〕*
> 🥷🏻┊الحالة: المشرفين فقط
> 🥷🏻┊بواسطة: @${m.sender.split('@')[0]}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
:
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 تـم فـتـح الـمـجـمـوعـة┊ 🔓 ↶〕*
> 🥷🏻┊الحالة: مفتوحة للجميع
> 🥷🏻┊بواسطة: @${m.sender.split('@')[0]}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`

  await conn.sendMessage(m.chat, { image: { url: img }, caption, mentions: [m.sender] }, { quoted: m })
}

handler.help = ['قفل','فتح']
handler.tags = ['group']
handler.command = ['قفل','اقفل','close','فتح','افتح','open']
handler.group = true
export default handler