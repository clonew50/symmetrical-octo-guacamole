// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الـحـسـاب┊ ˼‏ 🔤˹ ↶〕* *𝐆𝐎𝐉𝐎* ──¤﹝نـظـام حـسـاب الأحـرف ↶﹞*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

let handler = async (m, { conn, text }) => {
  try {
    let obito;

    if (m.quoted?.text) {
      obito = m.quoted.text;
    } else if (text && text.trim() !== "") {
      obito = text;
    } else {
      return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❗ 〕الـرجـاء إرسـال الـنـص أو الـرد عـلـى رسـالـة*

*📝┊طـريـقـة الاسـتـخـدام:*
*حساب-الحروف النص*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);
    }

    const total = obito.length;
    const withoutSpace = obito.replace(/\s/g, '').length;
    const words = obito.trim().split(/\s+/).length;

    await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـنـتـيـجـة┊ ˼‏ 🔤˹ ↶〕* *𝐆𝐎𝐉𝐎*

*🔤┊عـدد الأحـرف مـع الـفـراغ:* *${total}*
*✏️┊بـدون فـراغ:* *${withoutSpace}*
*📝┊عـدد الـكـلـمـات:* *${words}*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`);

  } catch (e) {
    console.log(e);
    await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕حـدث خـطـأ أثـنـاء الـحـسـاب*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);
  }
};

handler.help = ["حساب-الحروف"];
handler.tags = ["ادوات"];
handler.command = /^(حساب-الحروف|حروف)$/i;

export default handler;