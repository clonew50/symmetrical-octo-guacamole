/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: كومنت يوتيوب وهمي
 * 📢 القناة: https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

import axios from 'axios'

let handler = async (m, { conn, text }) => {
if (!text) return m.reply(
`* ━ ╼╃ ⌬〔⚠️〕⌬ ╄╾ ━ *
> *فـيـن الـنـص يـا حـب 🥲*
> *اسـتـخـدام:* \`.كومنت انا ملك التوكيتا\`
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
)

try {
await m.react('✍️')

let avatar = await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/24fa902ead26340f3df2c.png')
let name = await conn.getName(m.sender) || 'GOJO User'

// API جديد شغال - popcat
let url = `https://api.popcat.xyz/v2/youtube-comment?image=${encodeURIComponent(avatar)}&name=${encodeURIComponent(name)}&comment=${encodeURIComponent(text)}`

let res = await axios.get(url, { responseType: 'arraybuffer' })
let buffer = Buffer.from(res.data, 'binary')

await conn.sendMessage(m.chat, {
  image: buffer,
  caption: 
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 💬 〕 تـم إنـشـاء الـكـومـنـت ♛*
> *💭 الـنـص:* ${text}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
}, { quoted: m })

await m.react('✅')

} catch (e) {
console.error(e)
// fallback API ثاني الى فشل الأول
try {
let avatar2 = await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/24fa902ead26340f3df2c.png')
let fallback = `https://some-random-api.com/canvas/misc/youtube-comment?avatar=${encodeURIComponent(avatar2)}&username=${encodeURIComponent(conn.getName(m.sender))}&comment=${encodeURIComponent(text)}`
await conn.sendFile(m.chat, fallback, 'yt.png',
`* ━ ╼╃ ⌬〔💬〕⌬ ╄╾ ━ *\n> *كـومـنـت: ${text}*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m)
} catch {
m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *الـ API طـايـح حـاول بـعـد قـلـيـل*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
}
}
}

handler.help = ['كومنت']
handler.tags = ['ترفيه','ميكر']
handler.command = /^(ytcomment|كومنت|تعليق)$/i

export default handler