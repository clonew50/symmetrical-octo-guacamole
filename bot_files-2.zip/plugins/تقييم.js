/* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO DEV
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | 6 STARS EDITION 👑
 * 📦 الوظيفة: نظام التقييم الملكي - 6 نجوم
 * 🖼️ الصورة: https://files.catbox.moe/ya46m3.jpeg
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 PRO MAX 〕⌬ ╄╾ ━
 */

import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

let handler = async (m, { conn, usedPrefix, command, text }) => {
    const imageUrl = 'https://files.catbox.moe/ya46m3.jpeg';
    const developerContact = '212674375708@s.whatsapp.net';

    // --- 1 - معالجة التقييم (1 الى 6) ---
    if (text &&!isNaN(text.trim())) {
        let stars = parseInt(text.trim());
        if (stars >= 1 && stars <= 6) {
            const feedbackMap = {
                1: { emoji: '💔', msg: 'نجمة واحدة.. بدايتنا معك، سنعمل المستحيل لنرتقي لذوقك.' },
                2: { emoji: '♣️', msg: 'نجمتان.. شكراً لصدقك، ملاحظتك ستدفعنا للأفضل.' },
                3: { emoji: '⚜️', msg: 'ثلاث نجوم.. تقييم متوازن، نحن في منتصف الطريق نحو القمة.' },
                4: { emoji: '⭐', msg: 'أربع نجوم.. تقدير رائع يمنحنا دافعاً لنقدم الأفضل دائماً.' },
                5: { emoji: '👑', msg: 'خمس نجوم! شرف لنا، هذا هو معيار التميز الملكي.' },
                6: { emoji: '💎👑', msg: 'سـت نجوم أسطورية! تجاوزت التوقعات، أنت أسطورة 𝐆𝐎𝐉𝐎 الحقيقي!' }
            }
            let { emoji, msg } = feedbackMap[stars];
            let starsDisplay = '⭐'.repeat(stars);

            // إرسال للمطور فوراً
            await conn.sendMessage(developerContact, {
                text: `* ━ ╼╃ ⌬〔 تقرير تقييم ملكي جديد 💎 〕⌬ ╄╾ ━ *\n\n> *📅┊التاريخ:* ${new Date().toLocaleString('ar-MA')}\n> *👤┊المستخدم:* @${m.sender.split('@')[0]}\n> *💎┊التقييم:* ${starsDisplay} (${stars}/6)\n> *💬┊التعليق:* ${msg}\n\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 6 STARS 〕⌬ ╄╾ ━ *`,
                mentions: [m.sender]
            }).catch(() => {});

            return await conn.reply(m.chat, `* ━ ╼╃ ⌬〔 تم استلام تقييمك ${emoji} 〕⌬ ╄╾ ━ *\n\n> *💎┊تقييمك:* ${starsDisplay}\n> *💬┊* ${msg}\n\n${stars === 6? '> *🎉┊مبروك! حصلت على لقب [ أسطورة 𝐆𝐎𝐉𝐎 ]* 👑\n\n' : ''}> *شكراً لك من القلب، رأيك يصنع مجدنا* 💎\n\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`, m);
        }
    }

    // --- 2 - عرض لوحة التقييم 6 نجوم ---
    try {
        await conn.sendMessage(m.chat, { react: { text: '💎', key: m.key } });

        const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer });

        let bodyText = `
* ━ ╼╃ ⌬〔 💎 〕⌬ ╄╾ ━ *
*〔 ♛ 𝐆𝐎𝐉𝐎 〕 ↜ الـتـقـيـيـم الأسـطـوري ↝* 👑

*------------------------------------------------*
*\`↯˹💎˼↯\` ↜ النسخة الجديدة 6 نجوم ↝*
> *“الأساطير لا تكتفي بخمس نجوم.. النجمة السادسة للعظماء فقط.”*

> *👥┊إلى أسطورة 𝐆𝐎𝐉𝐎:*
> كل نجمة منك هي وسام ملكي
> قيم تجربتك بصدق، فالنجمة السادسة
> لا يمنحها إلا الملوك الحقيقيون 💎

> *💎┊النجمة السادسة = لقب أسطورة البوت*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 6 STARS 〕⌬ ╄╾ ━*`.trim();

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: {
                        body: { text: bodyText },
                        footer: { text: '『 💎 ♛ 6 STARS LEGENDARY EDITION | 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 👑 』' },
                        header: { hasMediaAttachment: true,...media },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: 'single_select',
                                    buttonParamsJson: JSON.stringify({
                                        title: '💎 اختر تقييمك الأسطوري',
                                        sections: [{
                                            title: '👑 ميزان الملوك - 6 مستويات',
                                            highlight_label: 'LEGENDARY 💎',
                                            rows: [
                                                { header: '💔 المستوى 1', title: 'نجمة واحدة', description: 'يحتاج تحسين جذري', id: `${usedPrefix}${command} 1` },
                                                { header: '♣️ المستوى 2', title: 'نجمتان', description: 'أداء مقبول نوعاً ما', id: `${usedPrefix}${command} 2` },
                                                { header: '⚜️ المستوى 3', title: 'ثلاث نجوم', description: 'جيد جداً ومستقر', id: `${usedPrefix}${command} 3` },
                                                { header: '⭐ المستوى 4', title: 'أربع نجوم', description: 'ممتاز ورائع', id: `${usedPrefix}${command} 4` },
                                                { header: '👑 المستوى 5', title: 'خمس نجوم', description: 'ملكي - قمة التميز', id: `${usedPrefix}${command} 5` },
                                                { header: '💎👑 المستوى 6 LEGENDARY', title: 'ست نجوم أسطورية', description: 'للعظماء فقط - لقب أسطورة', id: `${usedPrefix}${command} 6` }
                                            ]
                                        }]
                                    }),
                                },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👨🏻‍💻 التواصل مع YONO", id: ".المطور" }) },
                                { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "📢 قناة 𝐆𝐎𝐉𝐎", url: "https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r", merchant_url: "https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r" }) }
                            ]
                        }
                    }
                }
            }
        }, { userJid: m.chat, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (e) {
        console.error('GOJO 6 Stars Error:', e);
        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: `*💎 نظام التقييم الأسطوري 6 نجوم* 👑\n\n> اكتب:\n> \`.قيم 1\` الى \`.قيم 6\`\n> النجمة السادسة للأساطير فقط 💎\n\nمثال: \`.قيم 6\``,
        }, { quoted: m });
    }
};

handler.help = ['قيم'];
handler.tags = ['main'];
handler.command = /^(قيم|تقييم|rate)$/i;

export default handler;