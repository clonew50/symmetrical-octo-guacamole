import https from 'https';
import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbBzSYd0AgW4AHD9j63c';
const lastSentSong = new Map();

function downloadFile(url, outputPath) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const request = client.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (response) => {
      if (response.statusCode === 301 || response.statusCode === 302) {
        return downloadFile(response.headers.location, outputPath).then(resolve).catch(reject);
      }
      if (response.statusCode !== 200) {
        reject(new Error(`Download Failed: ${response.statusCode}`));
        return;
      }
      const fileStream = fs.createWriteStream(outputPath);
      response.pipe(fileStream);
      fileStream.on('finish', () => { fileStream.close(); resolve(); });
      fileStream.on('error', (err) => { fs.unlink(outputPath, () => {}); reject(err); });
    });
    request.on('error', (err) => { reject(err); });
    request.setTimeout(60000, () => { request.destroy(); reject(new Error('انتهت مهلة التحميل')); });
  });
}

const handler = async (m, { conn, text }) => {
  const jid = m.chat;
  const songName = (text || '').trim();

  if (!songName) {
    return m.reply(
      `╭━━━〔 ❌ 𝑬𝑹𝑹𝑶𝑹 〕━━━⬣\n` +
      `┃ ✦ اكتب اسم الأغنية\n` +
      `┃ ✦ مثال ↬ .شغل mockingbird\n` +
      `╰━━━━━━━━━━━━━━⬣\n\n` +
      `> 👑 ⚡_KAISER_ 𝑩𝑶𝑻 👑`
    );
  }

  await conn.sendMessage(jid, { react: { text: '🎧', key: m.key } });

  await m.reply(
    `╭━━━〔 🔍 𝑺𝑬𝑨𝑹𝑪𝑯 〕━━━⬣\n` +
    `┃ ✦ 𝑺𝒐𝒏𝒈 ↬ ${songName}\n` +
    `┃ ✦ 𝑺𝒕𝒂𝒕𝒖𝒔 ↬ Searching...\n` +
    `╰━━━━━━━━━━━━━━⬣`
  );

  const cacheKey = `${jid}_${songName.toLowerCase()}`;
  const lastAudioUrl = lastSentSong.get(cacheKey);
  let audioUrl = null;

  try {
    const response = await fetch('https://www.tikwm.com/api/feed/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0' },
      body: JSON.stringify({ keywords: `${songName} full song`, count: 20, cursor: 0, HD: 1 })
    });

    const data = await response.json();

    if (data?.data?.videos?.length > 0) {
      for (const video of data.data.videos) {
        const currentAudioUrl = video.music || video.play;
        if (currentAudioUrl && currentAudioUrl !== lastAudioUrl) {
          audioUrl = currentAudioUrl;
          lastSentSong.set(cacheKey, currentAudioUrl);
          break;
        }
      }
      if (!audioUrl) {
        const video = data.data.videos[0];
        audioUrl = video.music || video.play;
        lastSentSong.set(cacheKey, audioUrl);
      }
    }
  } catch (e) {
    console.error('[شغل] API Error:', e.message);
  }

  if (!audioUrl) {
    return m.reply(
      `╭━━━〔 ❌ 𝑵𝑶 𝑹𝑬𝑺𝑼𝑳𝑻𝑺 〕━━━⬣\n` +
      `┃ ✦ لا توجد نتائج\n` +
      `┃ ✦ جرّب اسم آخر\n` +
      `╰━━━━━━━━━━━━━━⬣\n\n` +
      `> 👑 ⚡_KAISER_ 𝑩𝑶𝑻 👑`
    );
  }

  const tempDir = path.join(__dirname, '../tmp');
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

  const audioPath = path.join(tempDir, `song_${Date.now()}.mp3`);

  await conn.sendMessage(jid, { react: { text: '⬇️', key: m.key } });

  try {
    await downloadFile(audioUrl, audioPath);
  } catch (e) {
    return m.reply(`❌ فشل التحميل: ${e.message}`);
  }

  await conn.sendMessage(jid, { react: { text: '✅', key: m.key } });

  await conn.sendMessage(jid, {
    audio: fs.readFileSync(audioPath),
    mimetype: 'audio/mpeg',
    ptt: false,
    fileName: `${songName}.mp3`,
    caption:
      `╭━━━〔 🎵 𝑭𝑼𝑳𝑳 𝑺𝑶𝑵𝑮 〕━━━⬣\n` +
      `┃ ✦ 𝑺𝒐𝒏𝒈 ↬ ${songName}\n` +
      `┃ ✦ 𝑺𝒐𝒖𝒓𝒄𝒆 ↬ TikTok\n` +
      `┃ ✦ 𝑸𝒖𝒂𝒍𝒊𝒕𝒚 ↬ HQ\n` +
      `╰━━━━━━━━━━━━━━⬣\n\n` +
      `📢 القناة:\n${CHANNEL_LINK}\n\n` +
      `> 👑 ⚡_KAISER_ 𝑩𝑶𝑻 👑`
  }, { quoted: m });

  if (fs.existsSync(audioPath)) fs.unlinkSync(audioPath);
};

handler.help = ['شغل <اسم الأغنية>'];
handler.tags = ['downloader'];
handler.command = /^(شغل)$/i;

export default handler;