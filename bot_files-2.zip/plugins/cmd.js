// plugins/cmd.js
// Owner-only shell command executor (safe defaults)
import { exec } from 'child_process'
import fs from 'fs'
import path from 'path'
import os from 'os'

const TMP = process.env.TEMP_DIR || path.join(os.tmpdir(), 'gojo_cmd')
if (!fs.existsSync(TMP)) fs.mkdirSync(TMP, { recursive: true })

// قواعد منع أوامر خطرة (يمكن تعديله بحذر)
const FORBIDDEN_RE = /(rm\s+-rf|\bshutdown\b|\breboot\b|\bsudo\b|\bpasswd\b|\bmkfs\b|\bdd\s+if=|\bssh\b|\bnc\b|\bnetcat\b|>>|>\||\|\||\||;|\&\&)/i

const MAX_OUT_CHARS = Number(process.env.CMD_MAX_CHARS || 2000)
const EXEC_TIMEOUT_MS = Number(process.env.CMD_TIMEOUT_MS || 60_000) // 60s
const MAX_BUFFER = Number(process.env.CMD_MAX_BUFFER || 5 * 1024 * 1024) // 5MB

/***********************************************
  OWNER CONFIGURATION (priority):
  1) process.env.OWNER_JIDS  (comma-separated; can be full JIDs or numbers)
  2) global.owner            (array or single value)
  3) fallback default number: 01002804195
************************************************/

const FALLBACK_OWNER_NUMBER = '01002804195' // requested owner number

// collect owners from env + global + fallback
const ownersFromEnv = (process.env.OWNER_JIDS || '')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean)

let ownersFromGlobal = []
try {
  if (typeof global !== 'undefined' && global.owner) {
    if (Array.isArray(global.owner)) ownersFromGlobal = global.owner.map(String)
    else ownersFromGlobal = [String(global.owner)]
  }
} catch (e) { ownersFromGlobal = [] }

const rawOwners = Array.from(new Set([ ...ownersFromEnv, ...ownersFromGlobal, FALLBACK_OWNER_NUMBER ]))

// normalize owners into convenient lookup sets:
// - ownerDigitsSet: digits-only (e.g., 201029208043) for fast comparison
// - ownerJidSet: explicit JIDs (e.g., 201029208043@s.whatsapp.net, ...@c.us)
const ownerDigitsSet = new Set()
const ownerJidSet = new Set()

for (const o of rawOwners) {
  if (!o) continue
  const s = String(o).trim()
  // if already looks like JID, add as-is
  if (s.includes('@')) ownerJidSet.add(s)
  // digits-only canonical form
  const digits = s.replace(/\D/g, '')
  if (digits) {
    ownerDigitsSet.add(digits)
    // add common JID forms
    ownerJidSet.add(`${digits}@s.whatsapp.net`)
    ownerJidSet.add(`${digits}@c.us`)
  }
}

// helper to check if a sender is owner
function isOwnerJid(sender) {
  if (!sender) return false
  const s = String(sender)
  // sometimes sender contains device suffix after ':' -> remove
  const bare = s.split(':')[0]
  // if full jid matches
  if (ownerJidSet.has(bare)) return true
  // compare digits only
  const digits = bare.replace(/\D/g, '')
  if (digits && ownerDigitsSet.has(digits)) return true
  return false
}

let handler = async (m, { conn, args, usedPrefix = '.' }) => {
  try {
    const sender = (m && m.sender) ? m.sender : ''

    // owner check: use isOwnerJid which includes fallback owner
    if (!isOwnerJid(sender)) {
      // give informative message including visible owner digits (safe)
      const sampleOwners = Array.from(ownerDigitsSet).slice(0,5).map(d => `${d}`)
      return m.reply(`❌ هذا الأمر خاص بصاصوت البوت فقط.\nالمصرّح لهم: ${sampleOwners.join(', ')}`)
    }

    const cmd = (args || []).join(' ').trim()
    if (!cmd) return m.reply(`❌ استخدام: ${usedPrefix}cmd <shell command>\nمثال: ${usedPrefix}cmd uptime`)

    if (FORBIDDEN_RE.test(cmd)) {
      return m.reply('❌ الأمر يحتوي عناصر محظورة لأمان السيرفر. تواصل معي لو تريد إضافة استثناء آمن.')
    }

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(()=>{})

    exec(cmd, { timeout: EXEC_TIMEOUT_MS, maxBuffer: MAX_BUFFER }, async (err, stdout, stderr) => {
      try {
        if (err && err.killed) {
          await m.reply('❌ انتهت المهلة (timeout) أو تم قتل العملية.')
          return
        }
        const out = (stdout || '').toString().trim()
        const errout = (stderr || '').toString().trim()
        let full = ''
        if (out) full += `--- stdout ---\n${out}\n`
        if (errout) full += `--- stderr ---\n${errout}\n`
        if (!full) full = '⛔️ لا مخرجات.'

        // لو الناتج كبير نرجّع ملف بدل رسالة طويلة
        if (full.length > MAX_OUT_CHARS) {
          const fname = `cmd_output_${Date.now()}.txt`
          const fpath = path.join(TMP, fname)
          fs.writeFileSync(fpath, full, 'utf8')
          await conn.sendMessage(m.chat, { document: fs.readFileSync(fpath), fileName: fname, mimetype: 'text/plain' }, { quoted: m })
          try { fs.unlinkSync(fpath) } catch {}
          return
        }

        // غير ذلك نرجّع نص قصير (مقتطع لو طويل)
        const preview = full.length > 1500 ? (full.slice(0,1500) + '\n\n... (trimmed)') : full
        await conn.sendMessage(m.chat, { text: `✅ الأمر: \`${cmd}\`\n\n${preview}` }, { quoted: m })
      } catch (e) {
        console.error('cmd handler send error', e)
      }
    })

  } catch (e) {
    console.error('cmd handler error', e)
    try { await m.reply('❌ حدث خطأ داخلي أثناء تنفيذ الأمر.') } catch {}
  }
}

handler.command = /^\.?(cmd|sh|shell)$/i
handler.tags = ['owner','dev']
handler.help = ['cmd <command>']
handler.limit = true

export default handler