// =================================================================
// • الحقوق : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 - مطور 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓
// • القناة : https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
// • الوصف : بحث وصفات بالعربية + ترجمة تلقائية عربية
// • الإصدار : v2.0 ARABIC SUPPORT
// =================================================================
import axios from 'axios';
import cheerio from 'cheerio';
import translate from 'translate-google-api';

const DECO_TOP = `* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *`
const DECO_BOTTOM = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`

async function toArabic(text) {
    if (!text) return text
    try {
        let res = await translate(text, { from: 'id', to: 'ar' })
        return res[0] || text
    } catch {
        try {
            let res2 = await translate(text, { from: 'en', to: 'ar' })
            return res2[0] || text
        } catch { return text }
    }
}

class CookpadScraper {
  constructor(searchTerm) { this.searchTerm = searchTerm; this.baseUrl = 'https://cookpad.com/id/cari/'; }
  async fetchSearchResults(page = 1) {
    const url = `${this.baseUrl}${encodeURIComponent(this.searchTerm)}?page=${page}`;
    const response = await axios.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    return cheerio.load(response.data);
  }
  async extractRecipeLinks($) {
    const links = [];
    $('a.block-link__main').each((i, el) => {
      const href = $(el).attr('href');
      if (href) links.push(`https://cookpad.com${href}`);
    });
    if (links.length === 0) throw new Error('❌ لم أجد وصفات، جرب كلمة أخرى مثل: بيتزا، كيك، دجاج');
    return links;
  }
  async fetchRecipePage(url) {
    const response = await axios.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    return cheerio.load(response.data);
  }
  async extractRecipeDetails($) {
    const title = $('h1').text().trim();
    const mainImage = $('img[alt^="Foto resep"]').attr('src');
    const cookingTime = $('.flex.flex-wrap.mise-icon-text').first().text().trim() || 'غير محدد';
    const serving = $('.flex.flex-wrap.mise-icon-text').last().text().trim() || 'غير محدد';
    const ingredients = [];
    $('#ingredients.ingredient-list ol li').each((i, el) => {
      if ($(el).hasClass('font-semibold')) ingredients.push(`*${$(el).find('span').text().trim()}*`);
      else ingredients.push(`- ${$(el).find('bdi').text().trim()} ${$(el).find('span').text().trim()}`);
    });
    const steps = [];
    $('ol.list-none li.step').each((i, el) => {
      const num = $(el).find('.flex-shrink-0.text-cookpad-14').text().trim() || i+1;
      const desc = $(el).find('div[dir="auto"] p').text().trim();
      if(desc) steps.push(`${num}. ${desc}`);
    });
    return { title, mainImage, cookingTime, serving, ingredients: ingredients.join('\n'), steps: steps.join('\n') };
  }
  async scrapeRecipes() {
    const $ = await this.fetchSearchResults();
    const links = await this.extractRecipeLinks($);
    const recipePage = await this.fetchRecipePage(links[0]);
    return await this.extractRecipeDetails(recipePage);
  }
}

let handler = async (m, { text, conn }) => {
  if (!text) {
    return m.reply(`${DECO_TOP}

> *〔 الطبخ العربي┊ 🍳˹ ↶〕* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*

> *✅┊الآن يدعم العربية 100%*

> *📌┊أمثلة:*
> >.وصفة بيتزا
> >.وصفه كيكة شوكولاتة
> >.طبخ دجاج مشوي
> >.طبخ معكرونة

${DECO_BOTTOM}`);
  }

  await conn.sendMessage(m.chat, { react: { text: '🍳', key: m.key } })

  try {
    // 1- ترجمة البحث العربي -> إنجليزي للبحث في Cookpad
    let searchEn = text
    try {
        let t = await translate(text, { from: 'ar', to: 'en' })
        searchEn = t[0] || text
    } catch {}

    let scraper = new CookpadScraper(searchEn);
    let recipe = await scraper.scrapeRecipes();

    await conn.sendMessage(m.chat, { react: { text: '🌐', key: m.key } })

    // 2- ترجمة النتيجة للعربية
    let [titleAr, ingAr, stepsAr, timeAr, servAr] = await Promise.all([
        toArabic(recipe.title),
        toArabic(recipe.ingredients),
        toArabic(recipe.steps),
        toArabic(recipe.cookingTime),
        toArabic(recipe.serving)
    ])

    let caption = `${DECO_TOP}

> *〔 🍽️ ${titleAr} 〕*

> *⏳┊وقت الطهي:* ${timeAr}
> *🍽️┊عدد الحصص:* ${servAr}

> *📝┊المكونات:*
${ingAr}

> *👨‍🍳┊طريقة التحضير:*
${stepsAr}

${DECO_BOTTOM}
> *🔎┊بحثت عن:* ${text}
> *قناتنا:* https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r`;

    if (recipe.mainImage) {
      await conn.sendMessage(m.chat, { image: { url: recipe.mainImage }, caption }, { quoted: m });
    } else {
      await m.reply(caption);
    }
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    return m.reply(`${DECO_TOP}\n\n> *❌┊خطأ:* ${e.message}\n> جرب كلمة أخرى: بيتزا، برجر، كيك\n\n${DECO_BOTTOM}`)
  }
};

handler.command = ['وصفة', 'وصفه', 'طبخ']
handler.tags = ['cooking']
handler.help = ['وصفة <اسم عربي>']
handler.footer = '𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕'
export default handler;