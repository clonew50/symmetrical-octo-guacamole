// ════════════════════════════════════════════════════════
// 🔱 GOJO BOT v5 — handler.js (ULTRA SPEED EDITION)
//    ✅ Zero Lag | Zero Delay | Groups Only | No Hang
// ════════════════════════════════════════════════════════
import { smsg }          from './lib/simple.js'
import { fileURLToPath } from 'url'
import path, { join }    from 'path'
import fs, { readdirSync, existsSync, watch } from 'fs'
import { pathToFileURL } from 'url'
import chalk             from 'chalk'
import ws                from 'ws'

// ━━━ Baileys proto (lazy, cached) ━━━
let _proto = null
const getProto = async () => {
  if (_proto) return _proto
  const b = await import('@whiskeysockets/baileys')
  _proto = b?.proto || b?.default?.proto || {}
  return _proto
}

const isNumber = x => typeof x === 'number' && !isNaN(x)

// ════════════════════════════════════════════════════════
// ⚡ GroupMetadata Cache — LRU بسيط وسريع
// ════════════════════════════════════════════════════════
const GROUP_META_TTL = 20_000   // 20 ثانية
const _groupCache    = new Map()

// دالة تخزين مؤقت بدون await غير ضرورية
function setCacheMeta(jid, data) {
  _groupCache.set(jid, { data, ts: Date.now() })
}

async function getCachedGroupMeta(conn, jid) {
  const cached = _groupCache.get(jid)
  if (cached && Date.now() - cached.ts < GROUP_META_TTL) return cached.data

  // لا نستخدم await متسلسل — نحاول الـ API مرة واحدة فقط
  const meta = await conn.groupMetadata(jid).catch(() => null)
           || conn.chats?.[jid]?.metadata
           || null

  if (meta) setCacheMeta(jid, meta)
  return meta
}

// تنظيف Cache قديم — كل 3 دقائق بدلاً من 2
setInterval(() => {
  const exp = Date.now() - GROUP_META_TTL * 5
  for (const [k, v] of _groupCache) if (v.ts < exp) _groupCache.delete(k)
}, 3 * 60_000).unref() // .unref() يمنع الـ interval من إبقاء العملية حية

// ════════════════════════════════════════════════════════
// 🛡️ Anti-MassKick — Fire & Forget (لا يوقف المعالجة)
// ════════════════════════════════════════════════════════
const _massKick = {
  map: new Map(),

  track(gid, kicker, victims) {
    const key  = `${gid}:${kicker}`
    const now  = Date.now()
    const arr  = this.map.get(key) || []
    for (const v of victims) arr.push({ v, t: now })
    // نحتفظ بآخر 10 ثوانٍ فقط
    const recent = arr.filter(e => now - e.t < 10_000)
    this.map.set(key, recent)
    return recent
  },

  isMass(gid, kicker) {
    return (this.map.get(`${gid}:${kicker}`) || []).length >= 3
  },

  getVictims(gid, kicker) {
    return [...new Set((this.map.get(`${gid}:${kicker}`) || []).map(e => e.v))]
  },

  clear(gid, kicker) {
    this.map.delete(`${gid}:${kicker}`)
  }
}
global.antiMassKick = _massKick

setInterval(() => {
  const now = Date.now()
  for (const [k, arr] of _massKick.map)
    if (!arr.some(e => now - e.t < 10_000)) _massKick.map.delete(k)
}, 60_000).unref()

// دالة تنفيذ حماية الطرد — fire & forget، لا تبطئ الـ handler
function runAntiMassKick(conn, groupId, kickerJid, victims) {
  setImmediate(async () => {
    try {
      const recent = _massKick.track(groupId, kickerJid, victims)
      if (recent.length < 3) return

      const metadata = await getCachedGroupMeta(conn, groupId)
      if (!metadata) return

      const parts     = metadata.participants || []
      const botJid    = conn.user?.jid
      const checkAdm  = v => v && (v === 'admin' || v === 'superadmin')

      const botP    = parts.find(p => numOf(p?.id || p?.jid || '') === numOf(botJid))
      const kickerP = parts.find(p => numOf(p?.id || p?.jid || '') === numOf(kickerJid))

      if (!checkAdm(botP?.admin))    return
      if (!checkAdm(kickerP?.admin)) { _massKick.clear(groupId, kickerJid); return }

      const kickerNum = numOf(kickerJid)
      const isOwner   = (global.owners || []).some(o => String(o).replace(/\D/g,'') === kickerNum)
      if (isOwner) { _massKick.clear(groupId, kickerJid); return }

      // demote ثم remove بدون delay غير ضروري
      await Promise.allSettled([
        conn.groupParticipantsUpdate(groupId, [kickerJid], 'demote'),
      ])
      await conn.groupParticipantsUpdate(groupId, [kickerJid], 'remove').catch(() => {})

      const allVictims = _massKick.getVictims(groupId, kickerJid)
      const currentJids = new Set(parts.map(p => p.id || p.jid))
      const toReAdd = allVictims.filter(v => !currentJids.has(v) && v !== kickerJid)

      // إعادة الضحايا بشكل متوازٍ بدلاً من تسلسلي (أسرع بكثير)
      const results = await Promise.allSettled(
        toReAdd.map(v => conn.groupParticipantsUpdate(groupId, [v], 'add'))
      )
      const restored = results.filter(r => r.status === 'fulfilled').length

      await conn.sendMessage(groupId, {
        text: `*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n\n`
            + `*┇╎⚠️ تم إيقاف طرد جماعي*\n`
            + `*┇╎👤 المعتدي:* @${kickerNum}\n`
            + `*┇╎📊 الضحايا:* ${allVictims.length}\n`
            + `*┇╎✅ تمت إعادة:* ${restored}\n`
            + `*┇╎✓ تم إزالة إشرافه وطرده*\n\n`
            + `*╯━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━*`,
        mentions: [kickerJid, ...toReAdd]
      }).catch(() => {})

      _massKick.clear(groupId, kickerJid)
      _groupMetaInvalidate(groupId)

    } catch (e) { console.error('[AntiMassKick]', e.message) }
  })
}

// ════════════════════════════════════════════════════════
// 📦 PLUGIN LOADER — سريع مع دعم hot-reload
// ════════════════════════════════════════════════════════
global.plugins = global.plugins || {}

export async function loadPlugins(pluginDir) {
  if (!existsSync(pluginDir)) return
  const files = readdirSync(pluginDir).filter(f => f.endsWith('.js'))

  // تحميل كل البلاجنات بشكل متوازٍ — أسرع بكثير من تسلسلي
  const results = await Promise.allSettled(
    files.map(async file => {
      const url = pathToFileURL(join(pluginDir, file)).href + `?t=${Date.now()}`
      const mod = await import(url)
      return { file, mod }
    })
  )

  const newPlugins = {}
  let ok = 0, fail = 0

  for (const r of results) {
    if (r.status === 'rejected') { fail++; console.error(chalk.red(`[Plugin] ❌ ${r.reason?.message}`)); continue }
    const { file, mod } = r.value

    try {
      // ━━━ الصيغة الجديدة: export default { name, execute } ━━━
      if (mod.default?.execute) {
        const plug = mod.default
        const fn   = async function(m, extra) {
          return plug.execute.call(this, extra?.conn || this, m, extra)
        }
        fn.command  = plug.name ? [plug.name, ...(Array.isArray(plug.aliases) ? plug.aliases : [])]
                                : (Array.isArray(plug.aliases) ? plug.aliases : [])
        fn.tags     = plug.tags     || []
        fn.help     = plug.help     || fn.command
        fn.owner    = plug.ownerOnly  ?? plug.owner    ?? false
        fn.rowner   = plug.ownerOnly  ?? plug.rowner   ?? false
        fn.group    = plug.groupOnly  ?? plug.group    ?? false
        fn.private  = plug.privateOnly ?? plug.private ?? false
        fn.admin    = plug.adminOnly  ?? plug.admin    ?? false
        fn.botAdmin = plug.botAdminRequired ?? plug.botAdmin ?? false
        fn.premium  = plug.premium ?? false
        fn.limit    = plug.limit   ?? false
        fn.exp      = plug.exp     ?? 10
        fn.fail     = plug.fail    ?? null
        newPlugins[file] = fn
        ok++
        continue
      }

      // ━━━ الصيغة القديمة: export default function ━━━
      if (typeof mod.default === 'function') {
        const plug = mod.default
        if (!plug.before && typeof mod.before === 'function') plug.before = mod.before
        if (!plug.all    && typeof mod.all    === 'function') plug.all    = mod.all
        if (!plug.after  && typeof mod.after  === 'function') plug.after  = mod.after
        newPlugins[file] = plug
        ok++
        continue
      }

      // ━━━ named exports فقط (before / all) ━━━
      if (!mod.default && (mod.before || mod.all)) {
        const stub     = async function() {}
        stub.command   = []
        stub.before    = mod.before || null
        stub.all       = mod.all    || null
        stub.after     = mod.after  || null
        stub.disabled  = false
        newPlugins[file] = stub
        ok++
      }
    } catch (e) { fail++; console.error(chalk.red(`[Plugin] ❌ ${file}: ${e.message}`)) }
  }

  global.plugins = newPlugins
  console.log(chalk.hex('#9400FF')(
    `[Plugin] ✅ ${ok} loaded${fail ? `, ❌ ${fail} failed` : ''} | total: ${ok}`
  ))
}

export function watchPlugins(pluginDir) {
  if (!existsSync(pluginDir)) return
  watch(pluginDir, async (ev, file) => {
    if (!file?.endsWith('.js')) return
    console.log(chalk.yellow(`[Plugin] 🔄 Reloading: ${file}`))
    await loadPlugins(pluginDir).catch(console.error)
  })
}

// ════════════════════════════════════════════════════════
// 🔔 رسائل فشل الصلاحيات — مُخزّنة مسبقاً (لا تُبنى كل مرة)
// ════════════════════════════════════════════════════════
const FAIL_MSGS = {
  rowner:   `*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< 🌋  هذا الأمر لمالكي البوت فقط *\n*━ ╼╃ ⌬〔𝐆𝐎𝐉𝐎  〕⌬ ╄╾ ━*`,
  owner:    `*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< 🕸️ هذا الأمر للمطورين فقط *\n*━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎  〕⌬ ╄╾ ━*`,
  premium:  `*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< 👺 هذا الأمر للمستخدمين المميزين فقط *\n*━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎  〕⌬ ╄╾ ━*`,
  group:    `*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< 💀 هذا الأمر للمجموعات فقط *\n*━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎  〕⌬ ╄╾ ━*`,
  private:  `*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< 🦅 هذا الأمر للمحادثات الخاصة فقط *\n*━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎〕⌬ ╄╾ ━*`,
  admin:    `*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< ⚜️ هذا الأمر للأدمن فقط *\n*━ ╼╃ ⌬〔𝐆𝐎𝐉𝐎  〕⌬ ╄╾ ━*`,
  botAdmin: `*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< 🫧 لتنفيذ هذا الأمر يجب أن أكون أدمن *\n*━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎  〕⌬ ╄╾ ━*`,
  restrict: `*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< 🪖 هذه الخاصية معطلة حالياً *\n*━ ╼╃ ⌬〔𝐆𝐎𝐉𝐎  〕⌬ ╄╾ ━*`,
  limit:    `*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< 🕷️ انتهى حد استخدامك اليومي *\n*━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━*`
}

global.dfail = (type, m, conn) => {
  const msg = FAIL_MSGS[type]
  if (msg) conn?.reply?.(m.chat, msg, m).then(() => m.react?.('📛')).catch(() => {})
}

// ════════════════════════════════════════════════════════
// 🔧 مساعدات — مُعرّفة خارج الـ handler لتجنب إعادة البناء
// ════════════════════════════════════════════════════════
const numOf  = jid => String(jid || '').replace(/@\S+/,'').replace(/[^0-9]/g,'')
const escRgx = s   => s.replace(/[|\\{}()[\]^$+*?.]/g, '\\$&')

// فحص admin — بسيط وسريع
const isAdminVal = v => v === 'admin' || v === 'superadmin'

// إبطال cache الجروب
function _groupMetaInvalidate(jid) { _groupCache.delete(jid) }

// بناء prefix regex — مُخزّن (memoized)
const _pfxCache = new Map()
function buildPfxMatch(plugPfx, text) {
  const key = String(plugPfx) + '||' + text.slice(0, 40)
  if (_pfxCache.has(key)) return _pfxCache.get(key)

  let res
  if (plugPfx instanceof RegExp) {
    const m = plugPfx.exec(text)
    res = m ? [m, plugPfx] : null
  } else if (Array.isArray(plugPfx)) {
    for (const p of plugPfx) {
      const r = p instanceof RegExp ? p : new RegExp('^' + escRgx(p))
      const m = r.exec(text)
      if (m) { res = [m, r]; break }
    }
    res = res || null
  } else if (typeof plugPfx === 'string' && plugPfx.length) {
    const r = new RegExp('^' + escRgx(plugPfx))
    const m = r.exec(text)
    res = m ? [m, r] : null
  } else {
    res = null
  }

  // cache صغير (max 200 مدخلة)
  if (_pfxCache.size > 200) _pfxCache.clear()
  _pfxCache.set(key, res)
  return res
}

// ════════════════════════════════════════════════════════
// 🚀 MAIN HANDLER — مُحسَّن للسرعة القصوى
// ════════════════════════════════════════════════════════
export async function handler(conn, rawMsg) {

  // ══════════════════════════════════════════
  // 🛡️ رصد الطرد الجماعي — fire & forget
  //    لا يوقف بقية المعالجة أبداً
  // ══════════════════════════════════════════
  {
    const stub = rawMsg?.messageStubType
    if ((stub === 27 || stub === 28) && rawMsg?.key?.remoteJid?.endsWith('@g.us')) {
      const gid     = rawMsg.key.remoteJid
      const kicker  = rawMsg.participant || rawMsg.key?.participant
      const victims = rawMsg.messageStubParameters || []
      if (gid && kicker && victims.length)
        runAntiMassKick(conn, gid, kicker, victims)  // ← غير متزامن تماماً
    }
  }

  // ══════════════════════════════════════════
  // ✅ الفلتر الأول — أسرع فلتر ممكن
  //    يوقف المعالجة فوراً للرسائل غير المطلوبة
  // ══════════════════════════════════════════
  if (!rawMsg?.message) return

  // تجاهل broadcast
  const remoteJid = rawMsg.key?.remoteJid || ''
  if (remoteJid === 'status@broadcast') {
    if (global.autoRead) conn.readMessages([rawMsg.key]).catch(() => {})
    return
  }

  // ✅ فلتر الخاص — صارم وفوري
  // البوت يعمل في الجروبات فقط، أي رسالة خاصة تُتجاهل نهائياً
  if (!remoteJid.endsWith('@g.us')) return

  // تجاهل IDs معروفة بالإزعاج
  const msgId = rawMsg.key?.id || ''
  if (
    msgId.startsWith('NJX-')  ||
    msgId.startsWith('3EB0')  ||
    msgId.startsWith('3E83')  ||
    (msgId.startsWith('BAE5') && msgId.length === 16) ||
    (msgId.startsWith('B24E') && msgId.length === 20)
  ) return

  // pushMessage بشكل غير متزامن — لا نُوقف المعالجة بسببه
  conn.pushMessage([rawMsg]).catch(() => {})

  // ══════════════════════════════════════════
  // 📝 smsg — بناء كائن الرسالة
  // ══════════════════════════════════════════
  let m
  try { m = smsg(conn, rawMsg) } catch { return }
  if (!m) return

  m.exp = 0

  // ══════════════════════════════════════════
  // 🗃️ DB — تهيئة سريعة بدون await زائد
  // ══════════════════════════════════════════
  const db = global.db
  if (db?.data == null) {
    if (typeof global.loadDatabase === 'function')
      await global.loadDatabase().catch(() => {})
    if (db?.data == null) return  // لا نكمل بدون DB
  }

  const { users, chats, settings: dbSettings } = db.data

  // ━━━ users ━━━
  if (!users) db.data.users = {}
  const uKey = m.sender
  if (!users[uKey] || typeof users[uKey] !== 'object') users[uKey] = {}
  const user = users[uKey]

  // تهيئة batch — أسرع من if-checks منفصلة
  user.name        ??= m.name || ''
  user.exp         = isNumber(user.exp)      ? user.exp      : 0
  user.coin        = isNumber(user.coin)     ? user.coin     : 0
  user.bank        = isNumber(user.bank)     ? user.bank     : 0
  user.level       = isNumber(user.level)    ? user.level    : 0
  user.limit       = isNumber(user.limit)    ? user.limit    : 10
  user.health      = isNumber(user.health)   ? user.health   : 100
  user.premium     ??= false
  user.premiumTime ??= 0
  user.banned      ??= false
  user.bannedReason??= ''
  user.commands    = isNumber(user.commands) ? user.commands : 0
  user.afk         = isNumber(user.afk)      ? user.afk      : -1
  user.afkReason   ??= ''
  user.warn        = isNumber(user.warn)     ? user.warn     : 0

  // ━━━ chats ━━━
  if (!chats) db.data.chats = {}
  const cKey = m.chat
  if (!chats[cKey] || typeof chats[cKey] !== 'object') chats[cKey] = {}
  const chat = chats[cKey]

  chat.isBanned   ??= false
  chat.isMute     ??= false
  chat.welcome    ??= false
  chat.sWelcome   ??= ''
  chat.sBye       ??= ''
  chat.detect     ??= true
  chat.primaryBot ??= null
  chat.modoadmin  ??= false
  chat.antiLink   ??= true
  chat.nsfw       ??= false
  chat.economy    ??= true

  // ━━━ settings ━━━
  if (!dbSettings) db.data.settings = {}
  const sKey = conn.user?.jid || 'default'
  if (!dbSettings[sKey] || typeof dbSettings[sKey] !== 'object') dbSettings[sKey] = {}
  const settings = dbSettings[sKey]

  settings.self      ??= false
  settings.jadibotmd ??= true

  // ━━━ تحديث الاسم ━━━
  const newName = m.pushName || ''
  if (newName && newName !== user.name) user.name = newName

  // ════════════════════════════════════════════════════════
  // 🔒 صلاحيات المالك
  // ════════════════════════════════════════════════════════
  const owners    = Array.isArray(global.owners) ? global.owners : (global.owner || [])
  const prems     = Array.isArray(global.prems)  ? global.prems  : []

  // استخدام Set للبحث O(1) بدلاً من O(n)
  const ownerSet  = new Set(owners.map(n => String(n).replace(/\D/g,'') + '@s.whatsapp.net'))
  const premSet   = new Set(prems.map(n  => String(n).replace(/\D/g,'') + '@s.whatsapp.net'))

  const isROwner = ownerSet.has(m.sender)
  const isOwner  = isROwner
  const isPrems  = isROwner || premSet.has(m.sender) || user.premium === true

  // ━━━ autoRead ━━━
  if (global.autoRead) conn.readMessages([rawMsg.key]).catch(() => {})

  // ━━━ logger — fire & forget ━━━
  import('./lib/print.js')
    .then(p => p?.default?.(m, conn)?.catch?.(e => console.error('[print]', e.message)))
    .catch(e => console.error('[print import]', e.message))

  // ━━━ auto react ━━━
  if (global.autoReact && isROwner && !m.fromMe && m.text) m.react('🔱').catch(() => {})

  m.exp += (Math.random() * 10 | 0) + 1  // أسرع من Math.ceil(Math.random()*10)

  // ════════════════════════════════════════════════════════
  // 👥 بيانات الجروب — مرة واحدة، محمية بـ cache
  // ════════════════════════════════════════════════════════
  const groupMetadata = await getCachedGroupMeta(conn, m.chat) || {}

  // تخزين في conn.chats فقط عند الحاجة
  if (groupMetadata.id) {
    if (!conn.chats) conn.chats = {}
    conn.chats[m.chat] = { id: m.chat, metadata: groupMetadata }
  }

  const rawParts = Array.isArray(groupMetadata.participants)
    ? groupMetadata.participants
    : Object.values(groupMetadata.participants || {})

  // ══════════════════════════════════════════
  // ✅ LID resolver — واتساب الجديد
  // ══════════════════════════════════════════
  const lidMap = conn?.isLid || {}

  const resolveJid = jid => {
    if (!jid) return ''
    const clean = String(jid).replace(/:[0-9]+@/, '@')
    return clean.endsWith('@lid') ? (lidMap[clean] || clean) : clean
  }

  // بناء participants مرة واحدة فقط
  const participants = rawParts.map(p => {
    const rawId     = typeof p === 'string' ? p : (p?.id || p?.jid || '')
    const rawLid    = p?.lid || (rawId.includes('@lid') ? rawId : null)
    const directJid = (p?.jid && !String(p.jid).includes('@lid'))
      ? String(p.jid).replace(/:[0-9]+@/, '@') : null
    return {
      id:    directJid || resolveJid(rawId),
      jid:   directJid || resolveJid(rawId),
      rawId,
      lid:   rawLid,
      phone: p?.phoneNumber || null,
      admin: p?.admin ?? p?.isAdmin ?? null
    }
  })

  // بحث سريع بـ Map
  const partByNum = new Map()
  for (const p of participants) {
    for (const field of [p.jid, p.rawId, p.lid, p.phone])
      if (field) { const n = numOf(field); if (n) partByNum.set(n, p) }
  }

  const findPart  = jid => jid ? (partByNum.get(numOf(resolveJid(jid))) || {}) : {}

  let userGroup = findPart(m.sender)
  let botGroup  = findPart(conn.user?.jid || conn.user?.id || '')

  const isRAdmin   = userGroup?.admin === 'superadmin'
  const isAdmin    = isRAdmin || userGroup?.admin === 'admin'
  const isBotAdmin = isAdminVal(botGroup?.admin)

  // ════════════════════════════════════════════════════════
  // 🔄 تشغيل البلاجنات — الحلقة الرئيسية
  // ════════════════════════════════════════════════════════
  const opts      = global.opts || {}
  const pluginDir = path.join(path.dirname(fileURLToPath(import.meta.url)), 'plugins')
  const plugNames = Object.keys(global.plugins)

  for (let i = 0; i < plugNames.length; i++) {
    const name   = plugNames[i]
    const plugin = global.plugins[name]
    if (!plugin || plugin.disabled) continue

    const __filename = join(pluginDir, name)
    const extraBase  = {
      conn, participants, groupMetadata, userGroup, botGroup,
      isROwner, isOwner, isRAdmin, isAdmin, isBotAdmin, isPrems,
      chatUpdate: { messages: [rawMsg] },
      __dirname: pluginDir, __filename,
      user, chat, settings
    }

    // ━━━ hook: all — fire & forget ━━━
    if (typeof plugin.all === 'function') {
      plugin.all.call(conn, m, { ...extraBase, usedPrefix: global.prefix })
        .catch(e => console.error(`[all:${name}]`, e.message))
    }

    if (!opts.restrict && plugin.tags?.includes('admin')) continue

    // ━━━ prefix matching ━━━
    const plugPfx  = plugin.customPrefix ?? conn.prefix ?? global.prefix ?? '.'
    const pfxMatch = buildPfxMatch(plugPfx, m.text || '')
    if (!pfxMatch) {
      // ━━━ hook: before (بدون prefix) ━━━
      if (typeof plugin.before === 'function') {
        try {
          const skip = await plugin.before.call(conn, m, { ...extraBase, pfxMatch: null })
          if (skip) continue
        } catch (e) { console.error(`[before:${name}]`, e.message) }
      }
      continue
    }

    // ━━━ hook: before (مع prefix) ━━━
    if (typeof plugin.before === 'function') {
      try {
        const skip = await plugin.before.call(conn, m, { ...extraBase, pfxMatch })
        if (skip) continue
      } catch (e) { console.error(`[before:${name}]`, e.message) }
    }

    if (typeof plugin !== 'function') continue

    const usedPrefix = (pfxMatch[0] || '')[0] || ''
    if (!usedPrefix) continue

    const noPrefix = (m.text || '').replace(usedPrefix, '').trimStart()
    const parts2   = noPrefix.trim().split(/\s+/)
    const command  = (parts2[0] || '').toLowerCase()
    const args     = parts2.slice(1)
    const text     = args.join(' ')
    const _args    = parts2.slice(1)

 if (!command && !(plugin.command instanceof RegExp && plugin.command.test(''))) continue

    const isAccept = plugin.command instanceof RegExp
      ? plugin.command.test(command)
      : Array.isArray(plugin.command)
        ? plugin.command.some(c => c instanceof RegExp ? c.test(command) : c === command)
        : typeof plugin.command === 'string'
          ? plugin.command === command
          : false

    if (!isAccept) continue

    // ━━━ وضع الخاص ━━━
    if (!isROwner && settings.self) return

    // ━━━ primaryBot check ━━━
    if (chat.primaryBot && chat.primaryBot !== conn.user?.jid) {
      const primary  = global.conns?.find(c =>
        c.user?.jid === chat.primaryBot &&
        c.ws?.socket?.readyState !== ws.CLOSED
      )
      if (!primary) { chat.primaryBot = null }
      else {
        // هل البوت الأساسي في الجروب؟
        const inGroup = rawParts.some(p => numOf(p?.id || p?.jid || '') === numOf(chat.primaryBot))
        if (inGroup) continue
        else chat.primaryBot = null
      }
    }

    m.plugin    = name
    user.commands++

    // ━━━ جروب محظور ━━━
    if (chat.isBanned && !isROwner) {
      m.reply?.(`*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< 🪖 البوت معطل في هذه المجموعة *`).catch(() => {})
      return
    }

    // ━━━ مستخدم محظور ━━━
    if (m.text && user.banned && !isROwner) {
      m.reply?.(`*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< ♣️ تم حظرك من استخدام البوت *`).catch(() => {})
      return
    }

    // ━━━ modoadmin ━━━
    if (chat.modoadmin && !isROwner && !isAdmin) continue

    // ━━━ فحص الصلاحيات ━━━
    const fail = plugin.fail || global.dfail
    if (plugin.rowner   && !isROwner)   { fail('rowner',   m, conn); continue }
    if (plugin.owner    && !isROwner)   { fail('owner',    m, conn); continue }
    if (plugin.premium  && !isPrems)    { fail('premium',  m, conn); continue }
    if (plugin.group    && !m.isGroup)  { fail('group',    m, conn); continue }
    if (plugin.botAdmin && !isBotAdmin) { fail('botAdmin', m, conn); continue }
    if (plugin.admin    && !isAdmin)    { fail('admin',    m, conn); continue }
    if (plugin.private  && m.isGroup)   { fail('private',  m, conn); continue }
    if (plugin.limit    && !isROwner && user.limit <= 0) { fail('limit', m, conn); continue }

    // ━━━ publicMode ━━━
    if (!global.publicMode && !isROwner) {
      m.reply?.(`*━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━*\n*< 🙂‍↔️ البوت في وضع المطور فقط *`).catch(() => {})
      return
    }

    m.isCommand  = true
    m.exp       += plugin.exp ? (parseInt(plugin.exp) | 0) : 10

    const extra = {
      ...extraBase,
      pfxMatch, usedPrefix, noPrefix, _args, args, command, text
    }

    // ━━━ تنفيذ البلاجن ━━━
    try {
      await plugin.call(conn, m, extra)
      if (plugin.limit && !isROwner && isNumber(user.limit))
        user.limit = Math.max(0, user.limit - 1)
    } catch (err) {
      m.error = err
      console.error(chalk.red(`[Cmd:${command}]`), err.message)
      m.reply?.(
        `❌ *خطأ في تنفيذ الأمر*\n\`\`\`${String(err.message).slice(0, 300)}\`\`\``
      ).catch(() => {})
    } finally {
      if (typeof plugin.after === 'function')
        plugin.after.call(conn, m, extra).catch(e => console.error(`[after:${name}]`, e.message))
    }
  }

  // ━━━ تحديث exp ━━━
  if (m.sender && users[m.sender])
    users[m.sender].exp = (users[m.sender].exp || 0) + (m.exp || 0)
}

// ════════════════════════════════════════════════════════
// 👥 أحداث الجروبات
// ════════════════════════════════════════════════════════
export async function participantsUpdate(conn, update) {
  if (update?.id) _groupMetaInvalidate(update.id)

  const seen = new Set()
  for (const name in global.plugins) {
    const plugin = global.plugins[name]
    if (!plugin || seen.has(plugin)) continue
    seen.add(plugin)
    if (typeof plugin.participantsUpdate === 'function')
      plugin.participantsUpdate.call(conn, update).catch(() => {})
  }
}

export async function groupsUpdate(conn, updates) {
  const list = Array.isArray(updates) ? updates : [updates]
  for (const update of list) {
    if (update?.id) _groupMetaInvalidate(update.id)
    const seen = new Set()
    for (const name in global.plugins) {
      const plugin = global.plugins[name]
      if (!plugin || seen.has(plugin)) continue
      seen.add(plugin)
      if (typeof plugin.groupsUpdate === 'function')
        plugin.groupsUpdate.call(conn, update).catch(() => {})
    }
  }
}

// ════════════════════════════════════════════════════════
// 📞 رفض المكالمات
// ════════════════════════════════════════════════════════
export async function callUpdate(conn, call) {
  if (!global.antiCall || call.status !== 'ringing') return
  conn.rejectCall(call.id, call.from).catch(() => {})
  conn.sendMessage(call.from, {
    text: `🚫 *المكالمات مرفوضة تلقائياً*\nاستخدم البوت عبر الرسائل فقط.`
  }).catch(() => {})
}
