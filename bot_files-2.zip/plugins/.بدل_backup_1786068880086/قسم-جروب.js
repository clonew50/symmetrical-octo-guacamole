import fs from 'fs'

import path from 'path';

function getRandomMediaUrl() {
  try {
    const filePath = path.join(process.cwd(), 'media-links.txt');
    const data = fs.readFileSync(filePath, 'utf-8');
    const links = data.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (links.length === 0) return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
    return links[Math.floor(Math.random() * links.length)];
  } catch (e) {
    console.error('تعذر قراءة media-links.txt:', e.message);
    return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
  }
}


const handler = async (m, { conn }) => {
const imageUrl = getRandomMediaUrl();

const messageText = `

『 مـرحبـاً بـك يـا ⌊ ${m.pushName} ⌉ فـي قـسـم الـجـروبـات داخـل بـوت ⚡_KAISER_ 』

⌝ أوامــر الـجـروبـات ┋👥⌞ ⇊
⎔ ⋅ ───━ •﹝🪐﹞• ━─── ⋅ ⎔
┊⇇『 بروفايل 🪪 』
┊⇇『 طــرد 🚫 』
┊⇇『 لــفـل 🎯 』
┊⇇『 مـنـشـن 💥 』
┊⇇『 جــروب 🔒 』
┊⇇『 جـروب2 🔓 』
┊⇇『 تـرقـيـة ⚡ 』
┊⇇『 دعــوة 🎟️ 』
┊⇇『 مـخـفـي 👻 』
┊⇇『 مـعـلـومـات-الـجـروب ℹ️ 』
⎔ ⋅ ───━ •﹝🪐﹞• ━─── ⋅ ⎔

> جروبك مع ⚡_KAISER_ دائماً بأمان ونظام. 🔐
`.trim();

await conn.sendMessage(m.chat, { text: "*_جاري تحميل قسم الجروب... ⏳👥_*" }, { quoted: m });  

await conn.sendMessage(m.chat, {  
    image: { url: imageUrl },  
    caption: messageText  
}, { quoted: m });  

await conn.sendMessage(m.chat, { react: { text: '👥', key: m.key } });

};

handler.command = /^قسم-جروب$/i;
handler.tags = ["group"];
handler.help = ["قسم-جروب"];

export default handler;