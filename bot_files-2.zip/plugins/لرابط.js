import axios from 'axios'
import FormData from 'form-data'

let handler = async (m, { conn }) => {
    let q = m.quoted? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || ''

    if (!mime) return conn.sendMessage(m.chat, { text: '*❌ رد على صورة او فيديو او اوديو باش نرفعو لك* 🍧' }, { quoted: m })

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    try {
        // تحميل - هادي الطريقة لي خدامة فكل البوتات
        let buffer = await q.download()
        if (!buffer) buffer = await conn.downloadMediaMessage(q)
        if (!buffer) throw 'ماقدرتش نحمل الملف'

        let ext = mime.split('/')[1] || 'jpg'
        if (ext.includes('webp')) ext = 'webp'
        if (mime.includes('audio')) ext = 'mp3'
        if (mime.includes('video')) ext = 'mp4'

        let form = new FormData()
        form.append('reqtype', 'fileupload')
        form.append('userhash', '944145b0558412de8090cb6cb')
        form.append('fileToUpload', buffer, { filename: `nikolas.${ext}` })

        let { data: link } = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: form.getHeaders(),
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        })

        if (!link.includes('http')) throw link

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

        let caption = `📮 *تـم الـرفـع لـحـسـابـك الـخـاص :*\n\`\`\`• ${link}\`\`\`\n\n📊 *الـحـجـم :* ${(buffer.length / 1024).toFixed(2)} KB\n📛 *الـمـده :* لا يـنـتـهـي 🔥\n\n> حـقـوق **𝐆𝐎𝐉𝐎-𝐁𝐎𝐓** ⚜️`

        await conn.sendMessage(m.chat, { text: caption }, { quoted: m })

    } catch (e) {
        console.log(e)
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        return conn.sendMessage(m.chat, { text: `❌ *فشل الرفع:*\n${e.message || e}` }, { quoted: m })
    }
}

handler.command = ['لرابط','catbox','رفع']
handler.help = ['لرابط']
handler.tags = ['tools']

export default handler