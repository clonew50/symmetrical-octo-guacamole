import fs from 'fs';
import pkg from '@whiskeysockets/baileys';
const { generateWAMessageFromContent, prepareWAMessageMedia } = pkg;

function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

const handler = async (m, { conn }) => {
    try {
        // --- بيانات الوقت والتاريخ ---
        let d = new Date();
        let locale = 'ar';
        let dayName = d.toLocaleDateString(locale, { weekday: 'long' });
        let dateString = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
        let uptime = clockString(process.uptime() * 1000);

        // --- بيانات المستخدم ---
        let user = global.db.data.users[m.sender] || {};
        let name = conn.getName(m.sender) || m.sender.split('@')[0];
        let { role = 'مواطن' } = user;

        // --- رياكت ---
        await conn.sendMessage(m.chat, { react: { text: '📂', key: m.key } });

        // --- تحميل الصورة من مجلد media المحلي ---
        // تأكد من مسار وصيغة الصورة داخل مجلد media (مثلاً geom.jpg أو geom.png)
        const imagePath = './media/geom.jpg'; 
        const media = await prepareWAMessageMedia(
            { image: fs.readFileSync(imagePath) },
            { upload: conn.waUploadToServer }
        );

        // --- النص الجديد مع المتغيرات ---
        const bodyText = `⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞
≪  ❪ ♾️ ⚡_KAISER_ 𝑩𝑶𝑻 ✅ ♾️ ❫ ≫
      ⛩️ ⚡_KAISER_ ・ 𝑩𝑶𝑻 ⛩️
≪ ━ ❪ 🩸 𝐓𝐇𝐄 𝐎𝐍𝐄 𝐀𝐁𝐎𝐕𝐄 𝐀𝐋𝐋 🩸 ❫ ━ ≫
⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞
╟「 👤 」↬ الاسم: *${m.sender.split`@`[0]}*
╟「 📦 」↬ الرتبة: *${role}*
╟「 🩸 」↬ اسم البوت: *⚡_KAISER_ 𝑩𝑶𝑻*
╟「 💡 」↬ المطور: *.⤹𝑴𝑨𝑬𝑺𝑻𝑹𝑶 𝑻𝑯𝑬 ⚡_KAISER_✨⤾.*
╟「 🌥️ 」↬ الـيـوم: *${dayName}*
╟「 📆 」↬ الـتـاريـخ: *${dateString}*
╟「 ⏱️ 」↬ مدة التشغيل: *${uptime}*
⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞
╰─── ≪ ❪ 🩸 ♾️ 🩸 ❫ ≫ ───╯
◜⏤͟͟͞͞ ⚡_KAISER_ ⚡ 𝑩𝑶𝑻 ˖࣪⃟🩸 ◞`;

        // --- إنشاء الرسالة التفاعلية ---
        const message = generateWAMessageFromContent(m.chat, {
            interactiveMessage: {
                header: { title: "🌹*صــبــآح آلــورد*✨", hasMediaAttachment: true, ...media },
                body: { text: bodyText, subtitle: "⚡_KAISER_" },
                contextInfo: { mentionedJid: [m.sender], isForwarded: false },
                nativeFlowMessage: {
                    buttons: [
                        {
                            name: 'single_select',
                            buttonParamsJson: JSON.stringify({
                                title: '⏤͟͟͞͞💠⏤͟͟͞͞⌈🩸┊اوامر┊🩸⌋⏤͟͟͞͞💠⏤͟͟͞͞',
                                sections: [
                                    {
                                        title: '≪ ❪ 🩸 جـــمــيـع اقـــســـام بوت ⚡_KAISER_ 🩸 ❫ ≫',
                                        highlight_label: '⛩️ ⚡_KAISER_ 𝑩𝑶𝑻 ⛩️',
                                        rows: [
                                            { header: '🚀┊القـ🚀ـسـم الأول', title: '📡┊「قـسـم_الـبـحـث_والـتـنـزيـل」📥', id: '.قسم-البحث' },
                                            { header: '🎮┊القـ🎮ـسـم الثاني', title: '🎯┊「قـسـم_الألـعـاب_والفـعـالـيـات」🍭', id: '.قسم-الفعاليات' },
                                            { header: '🎭┊القـ🎭ـسـم الثالث', title: '🎲┊「قـسـم_الـتـرفـيـه_والـتـسـلـيـه」🎉', id: '.قسم-الترفيه' },
                                            { header: '💻┊القـ💻ـسـم الرابع', title: '👨‍💻┊「قـسـم_الـبـرمـجـه」🧠', id: '.قسم-برمجه' },
                                            { header: '⭐┊الق⭐ـسـم', title: '🌍┊「قـسـم_الـدول_والـاطـارات」🔍', id: '.قسم-دول' },
                                            { header: '💬┊القـ💬ـسـم السادس', title: '🗨️┊「قـسـم_الـمـجـمـوعـات」📢', id: '.قسم-جروب' },
                                            { header: '📲┊القـ📲ـسـم السابع', title: '🛜┊「قـسـم_الـتـحـمـيـل」📥', id: '.قسم-التحميلات' },
                                            { header: '🔊┊القـ🔊ـسـم الثامن', title: '🎙️┊「قـسـم_الـصـوتـيـات」🔉', id: '.قسم-صوتيات' },
                                            { header: '🛠️┊القـ🛠️ـسـم التاسع', title: '🧰┊「قـسـم_الأدوات」🧱', id: '.قسم-الادوات' },
                                            { header: '📿┊القـ📿ـسـم العاشر', title: '🤲🏻┊「قـسـم_الـديـنـي」🕌', id: '.قسم-الدين' },
                                            { header: '📰┊القـ📰ـسـم الحادي عشر', title: '🔍┊「قـسـم_الأخـبـار_والتواصل」📡', id: '.قسم-بحث' },
                                            { header: '🩸┊القـ🩸ـسـم الثاني عشر', title: '🧠┊「قـسـم_الذكاء_الاصطناعي」🩸', id: '.قسم-الذكاء' },
                                            { header: '👑┊القـ👑ـسـم الثالث عشر', title: '🍫┊「قـسـم_الألـعـاب」🍥', id: '.ق1' },
                                            { header: '🩸‍🔥┊القـ🩸‍🔥ـسـم الرابع عشر', title: '🍨┊「قـسـم_الـمـشـرفـيـن」🍨', id: '.ق3' },
                                            { header: '👑┊القـ👑ـسـم الخامس عشر', title: '🍨┊「قـسـم_الادوات」🍬', id: '.ق4' },
                                            { header: '🛡┊القـ🛡ـسـم السادس عشر', title: '🍬┊「قـسـم_الـتـحـمـيـل」🍨', id: '.ق5' },
                                            { header: '🕹┊القـ🕹ـسـم السابع عشر', title: '🍬┊「قـسـم_الـبـنـك」🍨', id: '.ق6' },
                                            { header: '🌀┊القـ🌀ـسـم الثامن عشر', title: '🍬┊「قـسـم_الــAI」🍨', id: '.ق7' },
                                            { header: '🩸┊القـ🩸ـسـم التاسع عشر', title: '🍬┊「قـسـم_الـتـسـلـيـه」🍨', id: '.ق9' },
                                            { header: '🕋┊القـ📿ـسـم العشرون', title: '🍬┊「قــســم_الـديـن」🍨', id: '.ق10' },
                                            { header: '🖌️┊القـ🖌️ـسـم الحادي والعشرون', title: '🍬┊「قــســم_الـزخــارف」🍨', id: '.ق11' },
                                            { header: '⚔️┊القـ⚜️ـسـم الثاني والعشرون', title: '🍬┊「قــســم_الـنـقـابـات」🍨', id: '.ق12' },
                                            { header: '🗾┊القـ🌅ـسـم الثالث والعشرون', title: '🍬┊「قــســم_الـصــور」🍨', id: '.ق13' },
                                            { header: '👨🏻‍💻┊القـ👨🏻‍💻ـسـم الرابع والعشرون', title: '🍬┊「 القوانين 」🍨', id: '.القواعد' }
                                        ]
                                    }
                                ]
                            })
                        },
                        {
                            name: "quick_reply",
                            buttonParamsJson: '{"display_text":"⏤͟͟͞͞💠⏤͟͟͞͞⌈🌟╎التقييم╎🌟⌋⏤͟͟͞͞💠⏤͟͟͞͞","id":".تقيم"}'
                        },
                        {
                            name: "cta_url",
                            buttonParamsJson: '{"display_text":"⏤͟͟͞͞💠⏤͟͟͞͞⌈📲╎قـنـاة الـمـطـور╎📲⌋⏤͟͟͞͞💠⏤͟͟͞͞","url":"https://chat.whatsapp.com/HrySq5pzp0O9bn4ZBAplRE?s=cl&p=a&ilr=1"}'
                        },
                        {
                            name: "quick_reply",
                            buttonParamsJson: '{"display_text":"⏤͟͟͞͞💠⏤͟͟͞͞⌈🚀╎المطور╎🚀⌋⏤͟͟͞͞💠⏤͟͟͞͞","id":".المطور"}'
                        }
                    ]
                }
            }
        }, { quoted: m });

        // --- إرسال الرسالة ---
        await conn.relayMessage(m.chat, message.message, { messageId: message.key.id });

    } catch (err) {
        console.error('خطأ في أمر الأوامر:', err);
        await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m });
    }
};

handler.help = ['info'];
handler.tags = ['main'];
handler.command = ['menu', 'أوامر', 'اوامر', 'الاوامر', 'قائمة', 'القائمة', 'مينيو'];

export default handler;