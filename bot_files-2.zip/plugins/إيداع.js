let handler = async (m, { conn, args, text, usedPrefix, command }) => {
    try {
        let userId = m.sender
        if (!global.db) global.db = { data: { users: {} } }
        if (!global.db.data) global.db.data = { users: {} }
        if (!global.db.data.users) global.db.data.users = {}
        if (!global.db.data.users[userId]) global.db.data.users[userId] = { money: 0, bank: 0, diamond: 0, exp: 0 }
        let user = global.db.data.users[userId]

        let amountText = (args[0] || text || '').toLowerCase().trim()
        let amount = amountText === 'الكل' || amountText === 'all'? (user.money||0) : parseInt(amountText.replace(/[^0-9]/g, ''))

        if (!amountText) return conn.sendMessage(m.chat, { text: `*اكـتـب ${usedPrefix + command} 1000 او ${usedPrefix + command} الكل*\n*رصيدك الكاش: ${user.money||0}*` }, { quoted: m })
        if (isNaN(amount) || amount <= 0) return m.reply('*دخل رقم صحيح*')
        if ((user.money||0) < amount) return conn.sendMessage(m.chat, { text: `*〔 ♛ 〕 فلوس الكاش ما كافينش! عندك ${user.money||0} فقط*` }, { quoted: m })

        user.money -= amount
        user.bank = (user.bank||0) + amount

        await conn.sendMessage(m.chat, { text: `*✅ تم ايداع ${amount.toLocaleString()} فالبنك*\n*🏦 البنك: ${user.bank.toLocaleString()}*\n*💵 الكاش: ${user.money.toLocaleString()}*`, mentions: [userId] }, { quoted: m })
    } catch (e) { m.reply(e.message) }
}
handler.help = ['ايداع']; handler.tags = ['economy']; handler.command = ['ايداع','إيداع','deposit']; export default handler