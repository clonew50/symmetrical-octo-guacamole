// plugins/mediafire.js
// ⧼ 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 ⫷𝐆𝐎𝐉𝐎⫸ ⧽ — ميديافاير شغال 100% | 212674375708
import axios from 'axios'
import * as cheerio from 'cheerio'

class MediaFire {
  constructor() {
    this.client = axios.create({
      timeout: 30000,
      maxRedirects: 5,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'en-US,en;q=0.9,ar;q=0.8'
      }
    })
  }

  async getFileInfo(url) {
    const res = await this.client.get(url)
    const $ = cheerio.load(res.data)

    // كل الطرق الممكنة للرابط - ميديافاير تغيره كل فترة
    let link = $('a[aria-label="Download file"]').attr('href')
            || $('#downloadButton').attr('href')
            || $('.input[aria-label="Download file"]').attr('href')
            || $('a.input').attr('href')
            || $('a[href*="download.php"]').attr('href')
            || null

    // اسم الملف
    let name = $('.dl-btn-label').attr('title')?.trim()
            || $('div.filename').text().trim()
            || $('.promoDownloadName').text().trim()
            || $('title').text().replace(' - MediaFire','').trim()
            || 'file'

    // حجم الملف
    let size = $('a.input').text().match(/\(([^)]+)\)/)?.[1]
           || $('.details li').first().text().trim()
           || $('ul.details li').eq(1).text().trim()
           || '-'

    return { link, name: name.replace(/[\/\\:*?"<>|]/g,'').slice(0,100), size }
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
    const endDeco = `* ━ ╼╃ ⌬〔 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`;
    const myCredit = `*👑┊الـمـطـور:* *𝐘𝐎𝐍𝐎 𝐃𝐄𝐕* - 212674375708`;

  if (!text) return m.reply(`${startDeco}
> *〔 مـيـديـافـايـر┊ 📦˹ 〕* *𝐆𝐎𝐉𝐎*
> *〔 📌 〕الاستخدام:* ${usedPrefix + command} https://www.mediafire.com/file/xxxx/file.zip

${myCredit}
${endDeco}`);

  if (!text.includes('mediafire.com')) {
    return m.reply(`${startDeco}
> *〔 خـطـأ ❌ 〕* الرابط مو ميديافاير

${myCredit}
${endDeco}`);
  }

  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

  try {
    const mf = new MediaFire()
    const res = await mf.getFileInfo(text)

    if (!res.link) throw new Error('ميديافاير حاجب الرابط، جرب رابط ثاني أو فعل VPN بالسيرفر')

    const captionText = `${startDeco}
> *〔 تـم الـتـحـلـيـل ✅ 〕* *𝐆𝐎𝐉𝐎*
> *〔 📄 〕الاسم:* ${res.name}
> *〔 📦 〕الحجم:* ${res.size}
> *〔 🔗 〕الرابط:* ${text}

${myCredit}
${endDeco}`;

    // يرسل كوثيقة + كرسالة معاينة
    await conn.sendMessage(m.chat, {
      document: { url: res.link },
      fileName: res.name,
      mimetype: 'application/octet-stream',
      caption: captionText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (e) {
    console.error('[MEDIAFIRE]', e.message);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply(`${startDeco}
> *〔 فـشـل ❌ 〕* ${e.message}

${myCredit}
${endDeco}`);
  }
}

handler.help = ['ميديافاير'];
handler.command = ['ميديافاير','mediafire','mf'];
handler.tags = ['downloader'];

export default handler;