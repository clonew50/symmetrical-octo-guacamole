const handler = async function(m, { conn }) {
  try {
    const groupId = m.chat;
    const users = global.db?.data?.users || {};
    const user = users[m.sender];

    // التحقق من تسجيل العضو في المجموعة الحالية
    if (!user ||!user.groups ||!user.groups[groupId] ||!user.groups[groupId].name) {
      throw `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 خـطـأ ┊ ˼‏ ❌˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *🥷🏻 أنت غير مسجل في هذه المجموعة*
> *👑 احجز لقبك اولاً بـ:.حجز_لقب <الاسم>*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`
    }

    // استرجاع اللقب من بيانات المجموعة المحددة
    const nickname = user.groups[groupId].name;
    const regTime = user.groups[groupId].regTime;

    await conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 لـقـبـك ┊ ˼‏ 👑˹ ↶〕*

*🪖 ──¤﹝الـمـعـلـومـات ↶ 🕸️﹞*
> *🏷️ اللقب:* ${nickname}
> *👤 العضو:* @${m.sender.split('@')[0]}
> *📅 تاريخ الحجز:* ${formatDate(regTime)}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`, m, { mentions: [m.sender] });

  } catch (err) {
    await conn.reply(m.chat, err, m);
  }
};

function formatDate(timestamp) {
  if (!timestamp) return 'غير معروف'
  const date = new Date(timestamp);
  return `${date.toLocaleDateString('ar-EG')} - ${date.toLocaleTimeString('ar-EG')}`;
}

handler.group = true;
handler.command = /^(لقبي|mynickname)$/i;
handler.tags = ['مجموعة'];
handler.help = ['لقبي'];

export default handler;