import fs from 'fs';
import path from 'path';
import archiver from 'archiver'; // المكتبة اللي ثبتناها الحين

const h = async (m, { conn }) => {
    const chat = m.chat;
    const zipFileName = `Nagomu_Script_${Date.now()}.zip`;
    const zipFilePath = path.join(process.cwd(), zipFileName);

    await m.reply('🚀 جاري ضغط ملفات السكريبت... انتظر قليلاً يا 𝑻𝑶𝑱𝑰');

    try {
        const output = fs.createWriteStream(zipFilePath);
        const archive = archiver('zip', { zlib: { level: 9 } });

        output.on('close', async () => {
            await conn.sendMessage(chat, {
                document: fs.readFileSync(zipFilePath),
                mimetype: 'application/zip',
                fileName: zipFileName,
                caption: `✅ تم استخراج السكريبت بنجاح يا 𝑻𝑶𝑱𝑰\n📦 الحجم: ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB`
            }, { quoted: m });

            if (fs.existsSync(zipFilePath)) fs.unlinkSync(zipFilePath);
        });

        archive.on('error', (err) => { throw err; });
        archive.pipe(output);

        archive.glob('**/*', {
            cwd: process.cwd(),
            ignore: [
                'node_modules/**',
                '.npm/**',
                '*sessions/**',
                '.git/**',
                zipFileName,
                '*.zip'
            ]
        });

        await archive.finalize();

    } catch (err) {
        await m.reply(`❌ حدث خطأ: ${err.message}`);
        if (fs.existsSync(zipFilePath)) fs.unlinkSync(zipFilePath);
    }
};

h.usage = ["سكربتي"];
h.category = "owner";
h.command = ['سكربتي', 'script'];
h.owner = true;

export default h;