import { join } from 'path'
import { unlinkSync, writeFileSync, readFileSync, mkdirSync } from 'fs'
import { randomBytes } from 'crypto'
import { exec } from 'child_process'
import { promisify } from 'util'
import sharp from 'sharp'

const execAsync = promisify(exec)

// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
const zkhrafa_top = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`
const zkhrafa_bottom = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`

var handler = async (m, { conn }) => {
  const quoted = m.quoted
  if (!quoted) {
    await conn.sendMessage(m.chat, {
      text: `${zkhrafa_top}
> *〔 طـريـقـة الاسـتـعـمـال┊ ˼‏ 🎬˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *🥷🏻┊.لفيديو رد على الملصق*
> *🥷🏻┊.tomp4 رد على الملصق المتحرك*

${zkhrafa_bottom}`
    }, { quoted: m })
    return
  }

  const mime = quoted.mimetype || ''
  if (!mime.includes('sticker') && !mime.includes('webp')) {
    await conn.sendMessage(m.chat, {
      text: `${zkhrafa_top}
❌ *خطأ* : يجب الرد على ملصق فقط
${zkhrafa_bottom}`
    }, { quoted: m })
    return
  }

  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
  await conn.sendMessage(m.chat, {
    text: `${zkhrafa_top}
> *〔 جـاري الـتـحـويـل┊ ˼‏ ⚡˹ ↶〕*

*🪖 ──¤﹝GOJO يعمل ↶ 🕸️﹞*
> *🥷🏻┊.المرجو الانتظار قليلا...*
> *🥷🏻┊.تحويل ملصق الى فيديو*

${zkhrafa_bottom}`
  }, { quoted: m })

  const buf = await quoted.download()
  const id = randomBytes(6).toString('hex')
  const tmpDir = join('/home/container', id)
  const inputPath = join('/home/container', id + '.webp')
  const outputPath = join('/home/container', id + '.mp4')

  writeFileSync(inputPath, buf)
  mkdirSync(tmpDir, { recursive: true })

  try {
    const img = sharp(inputPath, { animated: true })
    const meta = await img.metadata()
    const frames = meta.pages || 1

    if (frames > 1) {
      for (let i = 0; i < frames; i++) {
        const frameBuf = await sharp(inputPath, { page: i })
          .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 1 } })
          .png()
          .toBuffer()
        const frameNum = String(i).padStart(4, '0')
        writeFileSync(join(tmpDir, 'frame' + frameNum + '.png'), frameBuf)
      }

      await execAsync(
        'ffmpeg -r 15 -i "' + tmpDir + '/frame%04d.png" ' +
        '-vf "format=yuv420p" ' +
        '-c:v libx264 -preset ultrafast -crf 28 "' + outputPath + '"'
      )
    } else {
      const pngBuf = await sharp(inputPath)
        .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 1 } })
        .png()
        .toBuffer()
      const pngPath = join('/home/container', id + '.png')
      writeFileSync(pngPath, pngBuf)

      await execAsync(
        'ffmpeg -loop 1 -i "' + pngPath + '" ' +
        '-vf "format=yuv420p" ' +
        '-c:v libx264 -preset ultrafast -crf 28 -t 3 "' + outputPath + '"'
      )

      try { unlinkSync(pngPath) } catch {}
    }

    const video = readFileSync(outputPath)

    await conn.sendMessage(m.chat, {
      video: video,
      mimetype: 'video/mp4',
      caption: `${zkhrafa_top}
> *〔 تـم الـتـحـويـل┊ ˼‏ ✅˹ ↶〕*

*🪖 ──¤﹝GOJO BOT ↶ 🕸️﹞*
> *🥷🏻┊.اتفضل يا قلبي ❤️‍🩹*
> *🥷🏻┊.Powered by YONO DEV*

${zkhrafa_bottom}`
    }, { quoted: m })

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

  } catch (e) {
    await conn.sendMessage(m.chat, {
      text: `${zkhrafa_top}
❌ *فـشـل الـتـحـويـل*
> *🥷🏻┊.السبب: ${e.message}*

${zkhrafa_bottom}`
    }, { quoted: m })
  } finally {
    try { unlinkSync(inputPath) } catch {}
    try { unlinkSync(outputPath) } catch {}
    try {
      const { readdirSync } = await import('fs')
      for (const f of readdirSync(tmpDir)) {
        try { unlinkSync(join(tmpDir, f)) } catch {}
      }
      const { rmdirSync } = await import('fs')
      rmdirSync(tmpDir)
    } catch {}
  }
}

handler.help = ['لفيديو']
handler.tags = ['sticker']
handler.command = ['لفيد', 'tomp4', 'لفيديو']
handler.group = false
handler.register = false

export default handler