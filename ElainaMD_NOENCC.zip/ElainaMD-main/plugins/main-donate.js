let handler = async (m) => {
    let caption = `⠀⠀⠀⠀⠀⠀⠀⠀⢀⢠⠞⠙⣆⠀
    ⠀⠀⠀⠀⣴⠒⠒⠮⢿⡏⠀⢀⡿⠀
    ⠀⠀⠀⠀⠘⢦⣀⣀⣠⢷⡒⠋⢹⡄
    ⠀⠀⣀⡀⠀⠀⢸⡁⣀⠖⠉⠛⠋⠀
    ⠀⢸⠁⠘⢦⣄⡀⠉⠁⠀⠀⠀⠀⠀
    ⠀⣸⣄⡀⢘⡿⠛⠋⠉⣷⠀⠀⠀⠀
    ⠰⣇⣀⣩⡟⠠⢤⣤⠴⠁⠀⠀⠀⠀
    ⠀⠀⠀⠀⠹⣄⣠⠃⠀⠀⠀
ׅ 𓏼‌⟳ 𝗉𝗋𝖾𝗍𝗍𝗒 — 𝗏𝗂𝗍𝖺𝖺 🐬
                 ׅ  ⵑ‌︶︶֟⏝ ۫ׄ𝅄
 ₍‌ဗ 𝗉𝖺𝗒𝗆𝖾𝗇𝗍 𝖺!!
╭╮ 
│ ׄ 𖹭⃘𔖸 𝖽𝖺𝗇𝖺 : 6289658675858

│ ׄ 𖹭⃘𔖸 𝗃𝖺𝗇𝗀𝖺𝗇 𝗅𝗎𝗉𝖺 𝖽𝗈𝗇𝖺𝗍𝖾 𝗒𝖺 𝗀𝗎𝗒𝗌𝖾 𝗇𝖺𝗇𝗍𝗂 𝖺𝗄𝗎 𝗌𝖼 𝗍𝗂𝖺𝗉 𝗎𝗉𝖽𝖺𝗍𝖾 𝗍𝖾𝗋𝗆𝗌!! 🐾
ׅ     ׂ ִ  ۫۫ ⏝︶ ۪ ⎯⎯♡♡ ֺ ִ
`;

    await m.reply(caption);
};

handler.help = ['donate'];
handler.tags = ['main'];
handler.command = /^(donate|donasi|traktir)$/i;

export default handler;