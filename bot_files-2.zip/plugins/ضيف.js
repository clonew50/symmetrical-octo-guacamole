let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    let groupMetadata = await conn.groupMetadata(m.chat)
    let participants = groupMetadata.participants

    let botJid = conn.user.jid.split(':')[0] + '@s.whatsapp.net'
    let bot = participants.find(p => p.id === botJid || p.id === conn.user.jid || p.jid === conn.user.jid)
    let isBotAdmin = bot && (bot.admin === 'admin' || bot.admin === 'superadmin')

    let sender = participants.find(p => p.id === m.sender || p.jid === m.sender)
    let isAdmin = sender && (sender.admin === 'admin' || sender.admin === 'superadmin')

    if (!isBotAdmin) return conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *❌ البوت ليس مشرف*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })
    if (!isAdmin) return conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *❌ خاصك تكون آدمن*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })

    if (!text) {
      return conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 طـريـقـة الاضـافـة┊ ˼‏ ➕˹ ↶〕*\n\n*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*\n> *🥷🏻┊${usedPrefix + command} 2126xxxxxxx*\n> *🥷🏻┊${usedPrefix + command} 2126xxxx,2127xxxx*\n\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })
    }

    let numbers = text.split(',').map(v => v.replace(/[^0-9]/g,'')).filter(v => v.length > 5 && v.length < 16)
    if (!numbers.length) return conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *❌ رقم غالط*\n> *🥷🏻┊مثال:* ${usedPrefix+command} 2127xxxxxx\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })

    let users = numbers.map(n => n + '@s.whatsapp.net')
    let result = await conn.groupParticipantsUpdate(m.chat, users, 'add')

    await conn.sendMessage(m.chat, { react: { text: '➕', key: m.key } })

    for (let res of result) {
      let status = res.status
      let jid = res.jid || res.content?.jid || users[0]
      let num = jid.split('@')[0]

      if (status == 200 || status == '200') {
        await conn.sendMessage(m.chat, {
          text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 تـمـت الاضـافـة┊ ˼‏ ➕˹ ↶〕*

*🪖 ──¤﹝بـيـانـات الـعـمـلـيـة ↶ 🕸️﹞*
> *🥷🏻┊الـشـخـص:* @${num}
> *🥷🏻┊الـحـالـة:* 〘 تـمـت اضـافـتـه 〙
> *🥷🏻┊بـواسـطـة:* @${m.sender.split('@')[0]}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`,
          mentions: [jid, m.sender]
        }, { quoted: m })
      } else if (status == 409) {
        await conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *⚠️ @${num} موجود أصلا فالجروب*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, mentions:[jid] }, { quoted: m })
      } else if (status == 403) {
        // إذا واتساب بلوكا الإضافة يرسل له دعوة
        let invite = await conn.groupInviteCode(m.chat).catch(()=>null)
        if(invite){
          await conn.sendMessage(jid, { text: `تمت دعوتك لجروب: https://chat.whatsapp.com/${invite}` }).catch(()=>{})
          await conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *📨 @${num} ماقدرتش نضيفو، رسلت ليه دعوة فالخاص*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, mentions:[jid] }, { quoted: m })
        }
      } else {
        await conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *❌ فشل إضافة @${num}*\n> *🥷🏻┊السبب:* ${status}\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, mentions:[jid] }, { quoted: m })
      }
    }

  } catch (e) {
    console.error(e)
    conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *❌ فشل: ${e.message || e}*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m })
  }
}

handler.help = ['ضيف']
handler.tags = ['group']
handler.command = ['ضيف', 'اضافة', 'add', 'ادد']
handler.group = true
export default handler