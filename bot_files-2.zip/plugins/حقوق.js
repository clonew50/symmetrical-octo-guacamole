import { addExif } from '../lib/sticker.js'

let handler = async (m, { conn, text }) => {
    const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
    const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;
    const myCredit = `*⚜️┊اسـم الـبـوت:* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*`;

    try {
        // التحقق من وجود رد على استيكر
        if (!m.quoted) {
            return m.reply(`${startDeco}
> *〔 خـطـأ┊ ˼‏ ⚠️˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝إضـافـة الـحـقـوق ↶﹞*
> *〔 ❌ 〕 الـحـالـة:* خطأ في الاستخدام
> *〔 📝 〕 الـمـلاحـظـة:* لازم ترد على الاستيكر اللي عايز تضيف عليه اسم الباكدج
> *〔 💡 〕 الـمـثـال:* .حقوق اسم الباكدج | اسم المؤلف

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
${myCredit} *🕸️ ───━ •﹝📌﹞• ━───*
${endDeco}`);
        }

        // إرسال الرياكشن
        await conn.sendMessage(m.chat, {
            react: { text: '🕷', key: m.key }
        });

        let stiker = false
        try {
            let [packname, ...author] = text ? text.split('|') : ['']
            author = (author || []).join('|')
            let mime = m.quoted.mimetype || ''

            if (!/webp/.test(mime)) {
                return m.reply(`${startDeco}
> *〔 خـطـأ┊ ˼‏ ❌˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝إضـافـة الـحـقـوق ↶﹞*
> *〔 ❌ 〕 الـمـلاحـظـة:* لازم ترد على استيكر عشان نضيف الاسم

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
${myCredit} *🕸️ ───━ •﹝📌﹞• ━───*
${endDeco}`);
            }

            let img = await m.quoted.download()
            if (!img) {
                return m.reply(`${startDeco}
> *〔 خـطـأ┊ ˼‏ ❌˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝إضـافـة الـحـقـوق ↶﹞*
> *〔 ❌ 〕 الـمـلاحـظـة:* فيه حاجة مش مزبوطة.. حاول تنزل الاستيكر تاني

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
${myCredit} *🕸️ ───━ •﹝📌﹞• ━───*
${endDeco}`);
            }

            stiker = await addExif(img, packname || '', author || '')
        } catch (e) {
            console.error(e)
            if (Buffer.isBuffer(e)) stiker = e
        } finally {
            if (stiker) {
                await conn.sendMessage(m.chat, {
                    sticker: stiker,
                    mimetype: 'image/webp',
                    contextInfo: {
                        externalAdReply: {
                            title: "𝐆𝐎𝐉𝐎-𝐁𝐎𝐓",
                            body: "© Powered By GOJO 🇲🇦",
                            thumbnailUrl: "https://files.catbox.moe/1044iz.jpg",
                            mediaUrl: "https://whatsapp.com/channel/0029Vb7AkG84inotOc8BXE1K",
                            mediaType: 2,
                        }
                    }
                }, { quoted: m });
            } else {
                throw new Error('حصلت غلطة!')
            }
        }

    } catch (e) {
        console.error(e);
        await m.reply(`${startDeco}
> *〔 خـطـأ┊ ˼‏ ❌˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝إضـافـة الـحـقـوق ↶﹞*
> *〔 ❌ 〕 الـمـلاحـظـة:* حصلت غلطة! تأكد انك رديت على استيكر وضفت اسم الباكدج

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
${myCredit} *🕸️ ───━ •﹝📌﹞• ━───*
${endDeco}`);
    }
}

handler.help = ['حقوق <packname>|<author>']
handler.tags = ['🎭 الملصقات 🎭']
handler.command = /^(حقوق)$/i
handler.limit = true

export default handler;