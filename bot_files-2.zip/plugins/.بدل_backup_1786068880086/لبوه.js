let handler = async (m) => {
  const reply = ` ____________________________ 
*لبوي🗻*
::::::::::::::::::🩸::::::::::::::::::: `.trim();
  await m.conn.sendMessage(m.chat, {
    text: reply,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 999,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363411035938060@newsletter',
        newsletterName: '⚡_KAISER_ 𝐁𝐎𝐓🩸',
        serverMessageId: 100
      }
    }
  }, { quoted: m });
};

// كلمات مفتاحية للرد التلقائي
handler.customPrefix = /^(|لبو|يا لبوه|لبوه|لبوه|||)$/i;
handler.command = new RegExp;
handler.exp = 0;

export default handler;