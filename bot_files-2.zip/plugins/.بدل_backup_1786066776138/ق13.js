import fs from 'fs';
import path from 'path';

function getRandomMediaUrl() {
  try {
    const filePath = path.join(process.cwd(), 'media-links.txt');
    const data = fs.readFileSync(filePath, 'utf-8');
    const links = data.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (links.length === 0) return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
    return links[Math.floor(Math.random() * links.length)];
  } catch (e) {
    console.error('تعذر قراءة media-links.txt:', e.message);
    return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
  }
}

let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let name = conn.getName(m.sender) || 'مستخدم';
  let taguser = '@' + m.sender.split("@")[0];

  let currentTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

  let groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : null;
  let groupName = groupMetadata ? groupMetadata.subject : 'غير معروف';
  let groupMembers = groupMetadata ? groupMetadata.participants.length : 'غير معروف';

  let message = `
*┃ 🍥┊❝ مـــرحبــــاً بـــكـ/ﻲ يـا ❪${taguser}❫ في قسم التحميل┊🍥┃*  
   *┃ ☠️┊❝ بــــ⚡𝑮𝑬𝑶ـــوت ❞┊☠️┃*  
*┃ 🍡┊❝ قسم الصور ❞┊🍡┃*  
*┃ 🔥┊❝ القسـم يـقدم لك أوامر تخص الصور ❞┊🔥┃*
*╰───⊰ 🍡❀⊱───╮*  
*✦ ━━━━━ ❀🗻❀ ━━━━━ ✦*  
🍡 *القسم يقدم لك اوامر  صور بي جميع انوعها!* 🍡  
*✦ ━━━━━ ❀🗻❀ ━━━━━ ✦*  
*╭──⊰ 🍬 قائمة صور 🍬 ⊱──╮*  
🍡 ⩺ ⌟كـورومـي⌜ 
🍡 ⩺ ⌟كـيـوت⌜   
🍡 ⩺ ⌟مـيـكـاسـا⌜  
🍡 ⩺ ⌟كـابـلـز⌜  
🍡 ⩺ ⌟هـيـنـاتـا⌜  
🍡 ⩺ ⌟بـيـن⌜  
🍡 ⩺ ⌟صــوره⌜    
🍡 ⩺ ⌟خـلـفـيـات⌜ 
🍡 ⩺ ⌟كـانـيـكـي⌜    
🍡 ⩺ ⌟صـوره⌜    
🍡 ⩺ ⌟تـصـفـح⌜    
*╰──⊰ 🍬 ⊱──╯*
*╭━─━─━─━─━──━─❀🗻❀─━─━─━─━─━──━╮*  
*┃ 🍬┊ البوت:  ⚡𝑮𝑬𝑶 𝑩𝑶𝑻🪄🪄              ┊🍬┃*  
*┃ ☠️┊ توقيع: .⤹𝑴𝑨𝑬𝑺𝑻𝑹𝑶 𝑻𝑯𝑬 𝑮✨𝑶⤾┊☠️┃*  
*╰━─━─━─━─━─━─━─❀🗻❀─━─━─━─━─━─━╯*`;

  const emojiReaction = '⬇️';

  try {
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });4

    await conn.sendMessage(m.chat, { 
      image: { url: getRandomMediaUrl() },
      caption: message,
      mentions: [m.sender]
    });
  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق13)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;