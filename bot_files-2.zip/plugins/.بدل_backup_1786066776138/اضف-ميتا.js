// .⤹⚡𝑮𝑬𝑶⤾.:... 
// كود لآضـآفة 𝒎𝒆𝒕𝒂 𝒂𝒊 للمـجـمـوعآت
// https://whatsapp.com/channel/0029Vb8OLjc9MF8vdLAHev2C

const tt = "\n> 𝑩𝒚 𝒗𝒆𝒙 𝑻𝒆𝒂𝒎"
let handler = async (m, { conn, text }) => {
  try {
    const groupJid = m.chat;

    if (!groupJid.endsWith("@g.us")) {
      return m.reply("هذآ آلآمـر للمـجـمـوعآت فقطـ 🍷.\n> 𝑩𝒚 𝑽𝒆𝒙 𝑻𝒆𝒂𝒎");
    }

    const res = await conn.groupParticipantsUpdate(
      groupJid,
      ["867051314767696@bot"],
      "add",
    );

    m.reply(
      "تمـت إضــــافة أغــــبى ذڪــــاء اصــــطناعي فــــي المجــــموعة بنــــجاح. ✅\n> 𝑩𝒚 .⤹⚡𝑮𝑬𝑶⤾."
    );
  } catch (e) {
    console.error(e);
    m.reply(String(e?.stack || e));
  }
};

handler.command = /^(اضف-ميتا)$/i;
export default handler;