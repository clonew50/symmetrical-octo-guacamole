let handler = async (m, { conn, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply('❌ هذا الامر للجروبات فقط')
    if (!isAdmin &&!isOwner) return m.reply('❌ لازم تكون ادمن')

    const botNumber = conn.user.id.split(':')[0] + '@s.whatsapp.net'
    const groupMetadata = await conn.groupMetadata(m.chat)
    const participants = groupMetadata.participants

    // نجيب الادمنز عشان ما نطردهمش
    const admins = participants.filter(p => p.admin).map(p => p.id)

    // قائمة الناس اللي هنطردهم
    const toKick = participants
       .map(p => p.id)
       .filter(id =>
            id!== botNumber && // مش البوت
            id!== m.sender && // مش انت
           !admins.includes(id) // مش ادمن
        )

    if (toKick.length === 0) return m.reply('✅ مفيش حد نطرده')

    await m.reply(`* ━ ╼╃ ⌬〔 GOJO 🥷🏻 〕⌬ ╄╾ ━ *\n> *جاري طرد ${toKick.length} شخص... 💀*\n* ━ ╼╃ ⌬〔 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`)

    let success = 0
    let failed = 0

    for (let user of toKick) {
        await new Promise(resolve => setTimeout(resolve, 3000)) // نطرد كل 3 ثواني عشان ما نتبندش
        try {
            await conn.groupParticipantsUpdate(m.chat, [user], 'remove')
            success++
        } catch {
            failed++
        }
    }

    await m.reply(`* ━ ╼╃ ⌬〔 GOJO 🥷🏻 〕⌬ ╄╾ ━ *
> *تم بنجاح: ${success} 💀*
> *فشل: ${failed} 😏*
* ━ ╼╃ ⌬〔 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`)
}

handler.help = ['طرد-الكل']
handler.tags = ['group']
handler.command = /^(طرد-الكل|kickall)$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler