//=====================================================
// 🔐 أمر قفل وفتح الخاص + فلترة الرسائل الخاصة
//=====================================================

import fs from 'fs';
import path from 'path';

// الأرقام المسموح ليها تتحكم وتراسل وقت القفل
const allowedNumbers = [
  '9647882860837', // رقمك
  '9647882860837'  // رقم إضافي لو حبيت
];

// الحالة الافتراضية (الخاص مفتوح)
let privateLocked = false;

// دالة لاستخراج الرقم من الـ JID
function extractNumber(jid) {
  if (!jid) return '';
  let num = jid.split('@')[0];
  if (num.includes(':')) num = num.split(':')[0];
  return num.replace(/\D/g, '');
}

let handler = {};

// القسم الخاص بالأوامر
handler.command = ['الخاص-قفل', 'قفل-الخاص', 'lockpm', 'الخاص-فتح', 'فتح-الخاص', 'unlockpm'];
handler.tags = ['developer'];
handler.help = ['قفل وفتح الخاص'];

handler.before = async function (m, { conn }) {
  if (!m.chat.endsWith('@s.whatsapp.net')) return; // تجاهل الجروبات
  if (!privateLocked) return; // الخاص مفتوح

  const senderNumber = extractNumber(m.sender);
  if (!allowedNumbers.includes(senderNumber)) {
    try {
      await conn.sendMessage(m.chat, { text: ♡゙💙ٴَʿ 𔖱۪𔖱.اࠗلــخــاࠗصــ مــغــلــقــ ســيــتــمــ حــظــٍرڪــ تــلــقــاࠗيــاࠗ ٍراࠗســلــ اࠗلــمــطــوٍر اࠗذاࠗ اࠗســتــحــقــقــتــ اࠗلــفــكــ🚫
「+9647882860837」' });
      await conn.updateBlockStatus(m.chat, 'block');
    } catch (e) {
      console.log('❌ فشل في حظر المستخدم:', e);
    }
    return !0;
  }
};

handler.run = async function (m, { conn, command }) {
  const senderNumber = extractNumber(m.sender);
  if (!allowedNumbers.includes(senderNumber)) {
    return await conn.sendMessage(m.chat, {
      text: '🚫 ياعبد هذا الامر ليس لك'
    }, { quoted: m });
  }

  if (['الخاص-قفل', 'قفل-الخاص', 'lockpm'].includes(command)) {
    if (privateLocked) return await conn.sendMessage(m.chat, { text: '⚠️ الخاص مقفول بالفعل.' }, { quoted: m });
    privateLocked = true;
    await conn.sendMessage(m.chat, {
      text: '🔒 تم قفل الخاص.\nأي شخص غير مصرح له هيحظر تلقائيًا لو حاول يكلمني.'
    }, { quoted: m });
  }

  if (['الخاص-فتح', 'فتح-الخاص', 'unlockpm'].includes(command)) {
    if (!privateLocked) return await conn.sendMessage(m.chat, { text: '⚠️ الخاص مفتوح بالفعل.' }, { quoted: m });
    privateLocked = false;
    await conn.sendMessage(m.chat, {
      text: '🔓 تم فتح الخاص بنجاح.\nيمكن للجميع المراسلة الآن.'
    }, { quoted: m });
  }
};

export default handler;