import fs from 'fs'

// 👻 قائمة الأرقام المسموح لها فقط
const allowedNumbers = [
  '212674375708@s.whatsapp.net', // الرقم الأول
  '212674375708@s.whatsapp.net'  // الرقم الثاني
]

let handler = async (m, { conn, command, usedPrefix }) => {

  // 👻 التحقق من الرقم المسموح
  if (!allowedNumbers.includes(m.sender)) {
    return m.reply('🚫 👻 هذا الرقم غير مسموح له باستخدام هذا الأمر.\n👻 اتصل بالمالك إذا كنت تريد الوصول.\n\n𝐆𝐎𝐉o ぽ ​​​⚴ 𝐁𝐎𝐓 👻')
  }

  // 👻 التحقق من وجود نص إضافي (لشرح الاستخدام)
  if (!command) {
    let example = `${usedPrefix}getdb`
    let explain = `👻 لتنزيل نسخة من قاعدة بيانات البوت، استخدم الأمر هكذا:\nمثال: ${example}\n👻 فقط للأرقام المسموح لها.\n\n𝐆𝐎𝐉o ぽ ​​​⚴ 𝐁𝐎𝐓 👻`
    return m.reply(explain)
  }

  // 👻 إخطار المستخدم بالانتظار
  m.reply('👻 انتظر قليلاً، جارٍ تحميل ملف قاعدة البيانات...\n𝐆𝐎𝐉o ぽ ​​​⚴ 𝐁𝐎𝐓 👻')

  try {
    let sesi = fs.readFileSync('./database.json')
    await conn.sendMessage(
      m.chat, 
      { document: sesi, mimetype: 'application/json', fileName: 'database.json' }, 
      { quoted: m }
    )
  } catch (e) {
    m.reply(`❌ 👻 حدث خطأ أثناء تحميل الملف: ${e.message}\n𝐆𝐎𝐉o ぽ ​​​⚴ 𝐁𝐎𝐓 👻`)
  }
}

handler.help = ['getdb', 'تحميل-داتا']
handler.tags = ['owner']
handler.command = /^(getdb|تحميل-داتا)$/i
handler.mods = true

export default handler