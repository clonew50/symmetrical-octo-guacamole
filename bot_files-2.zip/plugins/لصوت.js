// commands/لصوت.js
// ⧼ 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 ⫷𝐆𝐎𝐉𝐎⫸ ⧽ - تحويل الفيديو إلى صوت 🎵

import { promises as fs } from 'fs';
import { join } from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

// دالة تحويل الفيديو إلى صوت باستخدام FFmpeg
async function convertToAudio(buffer, inputExt = 'mp4') {
    const tmpDir = join(process.cwd(), 'tmp');
    await fs.mkdir(tmpDir, { recursive: true });

    const timestamp = Date.now();
    const inputFile = join(tmpDir, `${timestamp}.${inputExt}`);
    const outputFile = join(tmpDir, `${timestamp}.mp3`);

    await fs.writeFile(inputFile, buffer);

    // تم تصحيح الخطأ هنا: -acodec
    const cmd = `ffmpeg -i "${inputFile}" -vn -acodec libmp3lame -ab 128k -ar 44100 "${outputFile}" -y`;

    try {
        await execAsync(cmd, { timeout: 60000 });
        const resultBuffer = await fs.readFile(outputFile);
        return resultBuffer;
    } finally {
        await fs.unlink(inputFile).catch(() => {});
        await fs.unlink(outputFile).catch(() => {});
    }
}

let handler = async (m, { conn, usedPrefix, command }) => {
    try {
        await m.react("⏳");

        if (!m.quoted) {
            return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـتـحـويـل┊ ˼‏ 🎵˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *𝐆𝐎𝐉𝐎* ──¤﹝تـنـبـيـه ↶ ⚠️﹞*
> *🥷🏻┊قـم بـالـرد عـلـى فـيـديـو لـتـحـويـلـه الـى صـوت*
> *📌┊مـثـال:* ${usedPrefix + command} *رد عـلـى فـيـديـو*

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
> *⚜️┊اسـم الـبـوت:* *𝐘𝐎𝐍𝐎 𝐃𝐄𝐕* *🕸️ ───━ •﹝📌﹞• ━───*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);
        }

        let quoted = m.quoted;

        let mime = quoted.mimetype || quoted.msg?.mimetype || quoted.message?.videoMessage?.mimetype || quoted.message?.audioMessage?.mimetype || '';

        if (!/video|audio/.test(mime)) {
            return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـتـحـويـل┊ ˼‏ 🎵˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *𝐆𝐎𝐉𝐎* ──¤﹝نـوع مـلـف خـاطـئ ↶ ⚠️﹞*
> *🥷🏻┊قـم بـالـرد عـلـى فـيـديـو او صـوت*
> *📁┊الـنـوع الـمـدعـوم:* video / audio

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
> *⚜️┊اسـم الـبـوت:* *𝐘𝐎𝐍𝐎 𝐃𝐄𝐕* *🕸️ ───━ •﹝📌﹞• ━───*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);
        }

        let media = await quoted.download().catch(() => null);

        if (!media || media.length < 100) {
            throw new Error('فشل تحميل الوسائط');
        }

        await conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـتـحـويـل┊ ˼‏ 🎵˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *𝐆𝐎𝐉𝐎* ──¤﹝جـاري الـتـحـويـل ↶ ⏳﹞*
> *🥷🏻┊الـحـالـة:* جـاري تـحـويـل الـفـيـديـو الـى صـوت...

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
> *⚜️┊اسـم الـبـوت:* *𝐘𝐎𝐍𝐎 𝐃𝐄𝐕* *🕸️ ───━ •﹝📌﹞• ━───*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m });

        let ext = mime.split('/')[1]?.split(';')[0] || 'mp4';
        let audioBuffer = await convertToAudio(media, ext);

        if (!audioBuffer || audioBuffer.length < 1000) {
            throw new Error('حدث خطأ أثناء التحويل');
        }

        await m.react("✅");

        await conn.sendMessage(m.chat, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            ptt: false,
            fileName: 'YONO-DEV.mp3'
        }, { quoted: m });

        await conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـتـحـويـل┊ ˼‏ 🎵˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *𝐆𝐎𝐉𝐎* ──¤﹝تـم الـتـحـويـل بـنـجـاح ↶ ✅﹞*
> *🥷🏻┊الـحـالـة:* تـم تـحـويـل الـفـيـديـو الـى صـوت
> *📁┊الـحـجـم:* ${(audioBuffer.length / 1024).toFixed(2)} KB

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
> *⚜️┊اسـم الـبـوت:* *𝐘𝐎𝐍𝐎 𝐃𝐄𝐕* *🕸️ ───━ •﹝📌﹞• ━───*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *` }, { quoted: m });

    } catch (err) {
        await m.react("❌");
        console.error("Error in tomp3:", err);

        let errorMsg = err.message || 'حدث خطأ غير متوقع';

        m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـتـحـويـل┊ ˼‏ 🎵˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *𝐆𝐎𝐉𝐎* ──¤﹝فـشـل الـتـنـفـيـذ ↶ ❌﹞*
> *🥷🏻┊الـخـطـأ:* ${errorMsg}
> *💡┊تـأكـد مـن الـرد عـلـى فـيـديـو صـالـح*

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
> *⚜️┊اسـم الـبـوت:* *𝐘𝐎𝐍𝐎 𝐃𝐄𝐕* *🕸️ ───━ •﹝📌﹞• ━───*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);
    }
};

handler.help = ['لصوت', 'tomp3'];
handler.tags = ['تحويل'];
handler.command = /^(لصوت|لفويس|تـحـويـل|tomp3|toaudio)$/i;

export default handler;