/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * ♛ GOJO - FIX GPS LIGHT ♛
 * ━ ╼╃ ⌬〔 GOJO 〕⌬ ╄╾ ━ */

let handler = async (m, { conn }) => {
    try {
        await m.react('🔧')

        // الطريقة الخفيفة اللي ما كتبلوكيش البوت
        let chats = conn.chats || {}
        let groups = Object.keys(chats).filter(j => j.endsWith('@g.us'))

        // الى الكاش خاوي نجربو الطريقة التقيلة مرة وحدة
        if (groups.length === 0) {
            try {
                let all = await conn.groupFetchAllParticipating()
                groups = Object.keys(all)
                // نحفظوهم فالكاش باش المرة الجاية ما نعاودوش
                for (let id in all) conn.chats[id] = all[id]
            } catch (e) {
                console.log('fetch error:', e.message)
            }
        }

        if (groups.length === 0) {
            return m.reply(
`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *
> *ما لقيت والو فالكاش*
> *صيفط شي ميساج فشي جروب وعاود كتب.اصلاح*
* ━ ╼╃ ⌬〔 GOJO 〕⌬ ╄╾ ━ *`
            )
        }

        let txt = `* ━ ╼╃ ⌬〔✅〕⌬ ╄╾ ━ *\n> *لقيت ${groups.length} جروب*\n* ━ ╼╃ ⌬〔 GOJO 〕⌬ ╄╾ ━ *\n\n`

        let c = 1
        for (let jid of groups.slice(0, 20)) {
            let name = 'جروب'
            try {
                let meta = chats[jid] || await conn.groupMetadata(jid).catch(()=>null)
                if (meta) name = meta.subject || meta.name || name
            } catch {}
            txt += `*〔 ${c++} 〕* ${name}\n> ${jid.split('@')[0]}\n\n`
        }

        if (groups.length > 20) txt += `> *... و ${groups.length - 20} آخرين*\n\n`
        txt += `* ━ ╼╃ ⌬〔⚡〕⌬ ╄╾ ━ *\n> *تم التحديث بنجاح*\n> *GOJO-BOT ♛*\n* ━ ╼╃ ⌬〔 GOJO 〕⌬ ╄╾ ━ *`

        await m.reply(txt)
        await m.react('✅')

    } catch (e) {
        console.log(e)
        await m.reply(`*❌ خطأ:* ${e.message}\n*قول ليا شنو طلع فالكونسول*`)
        await m.react('❌')
    }
}

handler.help = ['اصلاح']
handler.tags = ['group']
handler.command = /^(إصلاح-الجروبات|اصلاح|fix)$/i
// حيدت rowner باش يخدم عند الكل، الى بغيتيه غير ليك رجعها
// handler.rowner = true

export default handler