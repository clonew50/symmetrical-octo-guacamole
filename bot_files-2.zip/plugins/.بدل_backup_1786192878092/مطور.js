// plugins/dev.owner.gojo.js
import fetch from 'node-fetch';

const MENU_IMAGE = 'https://i.ibb.co/JW7Fcdz1/gojo-1784416116801.jpg';
const CONTACT_NUMBER = '9647882860837';
const WA_LINK = `https://wa.me/${CONTACT_NUMBER}`;
const FANCY_NAME = '𝑴𝑨𝑬𝑺𝑻𝑹𝑶 𝑻𝑯𝑬 𝑮✨𝑶'; // الاسم الفخم المطلوب

let handler = async (m, { conn }) => {
  try {
    // 1) رد فعل سريع
    await conn.sendMessage(m.chat, { react: { text: '💠', key: m.key } });

    // 2) جلب الصورة وتحويلها لـ Buffer
    const res = await fetch(MENU_IMAGE);
    const imageBuffer = Buffer.from(await res.arrayBuffer());

    // 3) الـ Quoted المزيف (التوثيق الرسمي بصورة جوجو)
    const fakeOfficial = {
      key: {
        fromMe: false,
        participant: '0@s.whatsapp.net', // المصدر الرسمي للعلامة الزرقاء
        remoteJid: 'status@broadcast'
      },
      message: {
        imageMessage: {
          jpegThumbnail: imageBuffer,
          caption: FANCY_NAME // النص يظهر بجانب علامة التوثيق
        }
      }
    };

    // 4) إنشاء الـ vCard
    const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${FANCY_NAME}
ORG:Infinite Void;
TEL;type=CELL;type=VOICE;waid=${CONTACT_NUMBER}:+${CONTACT_NUMBER}
END:VCARD`;

    // 5) إرسال جهة الاتصال ملتصقة بالصورة العريضة بدون إعادة توجيه
    await conn.sendMessage(m.chat, {
      contacts: {
        displayName: FANCY_NAME,
        contacts: [{ vcard }]
      },
      contextInfo: {
        externalAdReply: {
          title: FANCY_NAME, 
          body: '𝑻𝑯𝑬 𝑨𝑩𝑺𝑶𝑳𝑼𝑻𝑬 | ⚡',
          thumbnail: imageBuffer,
          mediaType: 1,
          renderLargerThumbnail: true,
          showAdAttribution: true,
          sourceUrl: WA_LINK
        }
      }
    }, { quoted: fakeOfficial });

  } catch (err) {
    console.error('Error in Gojo Dev Plugin:', err);
  }
};

handler.help = ['owner'];
handler.tags = ['main'];
handler.command = /^(owner|المطور|مطور)$/i;

export default handler;