import fs from 'fs';
import path from 'path';

function getRandomMediaUrl() {
  try {
    const filePath = path.join(process.cwd(), 'media-links.txt');
    const data = fs.readFileSync(filePath, 'utf-8');
    const links = data.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (links.length === 0) return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
    return links[Math.floor(Math.random() * links.length)];
  } catch (e) {
    console.error('تعذر قراءة media-links.txt:', e.message);
    return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
  }
}

const handler = async (m, { conn }) => {
    const imageUrl = getRandomMediaUrl();

    const messageText = `
╔═══❖•ೋ° °ೋ•❖═══╗  
 ✦『 مــرحــبــاً بــك يــا ⌊ ${m.pushName} ⌉ فــي ⚡_KAISER_ـــوت 』✦  
╚═══❖•ೋ° °ೋ•❖═══╝  

✦━━━━━━━━━━━━━━✦  
      🩸⌝ قــســم الــصــوتــيــات ⌞🩸  
✦━━━━━━━━━━━━━━✦  

🗿 ⊰ عَـمـيــــق ⊱  
⛓‍💥 ⊰ مــنـفــــوخ ⊱  
🎐 ⊰ تــخــيــــن ⊱  
⚽ ⊰ صــاخــــب ⊱  
📿 ⊰ ســريــــع ⊱  
📍 ⊰ تـخـيــنـن ⊱  
🗃️ ⊰ رفــيــــع ⊱  
📬 ⊰ تـقـطـيــــع ⊱  
📕 ⊰ روبــــــوت ⊱  
📆 ⊰ بــــطــيء ⊱  
🗞️ ⊰ نــاعـــــم ⊱  
🐿️ ⊰ سـنـجــــاب ⊱  
🎙️ ⊰ 𝑻𝑻𝑺② ⊱  
🗣️ ⊰ أنــــطــق ⊱  
🔊 ⊰ أنــــطــق② ⊱  
🎤 ⊰ أنــــطــق③ ⊱  
🎚️ ⊰ تـأثــــيــر ⊱  
📑 ⊰ تـفــاصـيــــل-الأغـنـيــة ⊱  
🏆 ⊰ تـــــوبــتــيــف ⊱  
🔁 ⊰ صــوتـكــوبــــو ⊱  
🔇 ⊰ لــــصـــــوت ⊱  

✦━━━━━━━━━━━━━━✦  
     💗💛  ⚡_KAISER_ 💛💗  
✦━━━━━━━━━━━━━━✦  
    `.trim();

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: messageText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
};

handler.command = /^قسم-صوتيات$/i;
handler.tags = ["جــيـ❣ـہ"];
handler.help = ["جــيـ❣ـہ"];

export default handler;