/* حقوق حرب مطور بوت انيا المظه و بوت حرب 

https://whatsapp.com/channel/0029Vb8ZbJSFSAsyDyL8Wr0F
لاتحذف السطرين دول بالحب 🩸♥️
*/
import axios from 'axios'
import { Sticker, StickerTypes } from 'wa-sticker-formatter'

let handler = async (m, { conn, text }) => {
  if (!text)
    return conn.sendMessage(
      m.chat,
      { text: '🧩 اكتب نص علشان أعمل منه ستيكر يا زعيم 😎' },
      { quoted: m }
    )

  try {
    await m.react('🕓')

    // عمو حرب 9647882860837
    let api = `https://kepolu-brat.hf.space/brat?q=${encodeURIComponent(text)}`
    let response = await axios.get(api, { responseType: 'arraybuffer' })
    let buffer = Buffer.from(response.data, 'binary')

    // عمو حرب 9647882860837
    let sticker = new Sticker(buffer, {
      pack: global.packname,
      author: global.author,
      type: StickerTypes.FULL,
      quality: 80
    })

    let stickerBuffer = await sticker.build()
    await conn.sendFile(m.chat, stickerBuffer, 'sticker.webp', '', m, false, { asSticker: true })
    await m.react('✅')

  } catch (e) {
    console.error(e)
    await m.react('✖️')
    await conn.sendMessage(
      m.chat,
      { text: '⚠️ حصل خطأ أثناء إنشاء الستيكر، جرّب تاني بعد شوية 😔' },
      { quoted: m }
    )
  }
}

handler.help = ['استيك <نص>']
handler.tags = ['sticker']
handler.command = ['استيك']

export default handler