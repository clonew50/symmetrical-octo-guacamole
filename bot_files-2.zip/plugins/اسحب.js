let handler = async (m, { conn, args, text, usedPrefix, command }) => {
    try {
        let userId = m.sender

        // تهيئة قاعدة البيانات
        if (!global.db) global.db = { data: { users: {} } }
        if (!global.db.data) global.db.data = { users: {} }
        if (!global.db.data.users) global.db.data.users = {}
        if (!global.db.data.users[userId]) {
            global.db.data.users[userId] = { money: 0, diamond: 0, bank: 0, exp: 0, lastDaily: 0, lastWeekly: 0 }
        }
        let user = global.db.data.users[userId]

        // قراءة المبلغ - كيدعم.سحب 1000 و.سحب الكل
        let amountText = (args[0] || text || '').toLowerCase().trim()
        let amount

        if (amountText === 'الكل' || amountText === 'all' || amountText === 'الكل') {
            amount = user.bank || 0
        } else {
            amount = parseInt(amountText.replace(/[^0-9]/g, ''))
        }

        if (!amountText) {
            return conn.sendMessage(m.chat, {
                text: `* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 اسـتـخـدام خـاطـئ!*\n\n*الـصـحـيـح:*\n*› ${usedPrefix + command} 1000*\n*› ${usedPrefix + command} الكل*\n\n*رصـيـدك فـالـبـنـك: ${user.bank || 0}*\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`
            }, { quoted: m })
        }

        if (isNaN(amount) || amount <= 0) {
            return conn.sendMessage(m.chat, { text: `*〔 ♛ 〕 دخـل رقـم صـحـيـح!*\n*مـثـال: ${usedPrefix + command} 500*` }, { quoted: m })
        }

        if ((user.bank || 0) < amount) {
            return conn.sendMessage(m.chat, {
                text: `* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 فـلـوس الـبـنـك مـا كـافـيـنـش!*\n\n*〔 🏦 〕 عـنـدك فـالـبـنـك :* ${user.bank || 0}\n*〔 💸 〕 بـغـيـتـي تـسـحـب :* ${amount}\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`
            }, { quoted: m })
        }

        // العملية
        user.bank -= amount
        user.money = (user.money || 0) + amount

        let txt = `
* ━ ╼╃ ⌬〔✅〕⌬ ╄╾ ━ *
*〔 ♛ 〕 عـمـلـيـة سـحـب نـاجـحـة*
* ━ ╼╃ ⌬〔 💸 〕⌬ ╄╾ ━ *

*〔 💰 〕 سـحـبـت :* ${amount.toLocaleString()} 💵
*〔 🏦 〕 الـبـاقـي فـالـبـنـك :* ${user.bank.toLocaleString()}
*〔 💵 〕 الـكـاش الان :* ${user.money.toLocaleString()}

* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`.trim()

        await conn.sendMessage(m.chat, { text: txt, mentions: [userId] }, { quoted: m })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, { text: `*خطأ:* ${e.message}` }, { quoted: m })
    }
}

handler.help = ['سحب']
handler.tags = ['economy']
handler.command = ['سحب', 'withdraw', 'اسحب']
handler.group = false

export default handler