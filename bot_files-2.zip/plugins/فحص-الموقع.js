// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الـفـحـص┊ ˼‏ 🌐˹ ↶〕* *𝐆𝐎𝐉𝐎* ──¤﹝نـظـام فـحـص حـالـة الـمـواقـع ↶﹞*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

import fetch from 'node-fetch'

const nodeToRegion = {
    ae1:'🇦🇪 الإمارات', bg1:'🇧🇬 بلغاريا', br1:'🇧🇷 البرازيل', ch1:'🇨🇭 سويسرا', cz1:'🇨🇿 التشيك',
    de1:'🇩🇪 ألمانيا', de4:'🇩🇪 ألمانيا', es1:'🇪🇸 إسبانيا', fi1:'🇫🇮 فنلندا', fr2:'🇫🇷 فرنسا',
    hk1:'🇭🇰 هونغ كونغ', hr1:'🇭🇷 كرواتيا', id1:'🇮🇩 إندونيسيا', il1:'🇮🇱 إسرائيل', il2:'🇮🇱 إسرائيل',
    in1:'🇮🇳 الهند', ir1:'🇮🇷 إيران', ir3:'🇮🇷 إيران', ir5:'🇮🇷 إيران', it2:'🇮🇹 إيطاليا',
    jp1:'🇯🇵 اليابان', kz1:'🇰🇿 كازاخستان', lt1:'🇱🇹 ليتوانيا', md1:'🇲🇩 مولدوفا', nl1:'🇳🇱 هولندا',
    nl2:'🇳🇱 هولندا', pl1:'🇵🇱 بولندا', pl2:'🇵🇱 بولندا', pt1:'🇵🇹 البرتغال', rs1:'🇷🇸 صربيا',
    ru1:'🇷🇺 روسيا', ru2:'🇷🇺 روسيا', ru3:'🇷🇺 روسيا', se1:'🇸🇪 السويد', tr1:'🇹🇷 تركيا',
    tr2:'🇹🇷 تركيا', ua1:'🇺🇦 أوكرانيا', ua2:'🇺🇦 أوكرانيا', ua3:'🇺🇦 أوكرانيا', uk1:'🇬🇧 بريطانيا',
    us1:'🇺🇸 أمريكا', us2:'🇺🇸 أمريكا', us3:'🇺🇸 أمريكا',
    eg1:'🇪🇬 مصر', ma1:'🇲🇦 المغرب', ye1:'🇾🇪 اليمن', sa1:'🇸🇦 السعودية', kw1:'🇰🇼 الكويت',
    dz1:'🇩🇿 الجزائر', jo1:'🇯🇴 الأردن', lb1:'🇱🇧 لبنان', qa1:'🇶🇦 قطر', sy1:'🇸🇾 سوريا',
    tn1:'🇹🇳 تونس', om1:'🇴🇲 عمان', bh1:'🇧🇭 البحرين', ps1:'🇵🇸 فلسطين'
};

let handler = async (m, { text }) => {
    if (!text) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❗ 〕أدخـل رابـط الـمـوقـع*

*🌐┊مـثـال:*
*.فحص-الموقع google.com*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);

    try {
        await m.react('🕒')
        let host = text.replace(/^https?:\/\//, '').split('/')[0]

        let res = await fetch(`https://check-host.net/check-http?host=${encodeURIComponent(host)}&max_nodes=43`, { headers: { 'Accept':'application/json' } })
        let data = await res.json()
        const { request_id: requestId, permanent_link: reportLink } = data

        await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ⏳ 〕جـاري الـفـحـص...*

*🆔┊ID:* *${requestId}*
*🌐┊الـمـوقـع:* *${host}*
*🔗┊الـتـقـريـر:* ${reportLink}

*انـتـظـر 5 ثـوانـي...*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)

        await new Promise(r => setTimeout(r, 5000))

        let res1 = await fetch(`https://check-host.net/check-result/${requestId}`, { headers: { 'Accept':'application/json' } })
        let resultData = await res1.json()

        let results = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 الـنـتـائـج┊ 🌍 〕* *${host}*\n* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n\n`
        let count = 0

        for (const [node, arr] of Object.entries(resultData)) {
            if (Array.isArray(arr) && arr.length > 0) {
                arr.forEach(result => {
                    if(!result) return
                    const region = nodeToRegion[node.split('.')[0]] || '🌍 غير معروف'
                    results += `*${region}*\n*📶┊الـحـالـة:* ${result[3]||''} ${result[2]||''}\n*⏳┊الاسـتـجـابـة:* ${(result[1]*1000).toFixed(0)}ms\n*🖥️┊IP:* ${result[4]||'—'}\n*────────────────*\n`
                    count++
                })
            }
        }

        if (!count) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 📭 〕لـم يـتـم الـعـثـور عـلـى نـتـائـج*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)

        await m.react('✅')
        await m.reply(results + `\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`)

    } catch (e) {
        console.log(e); await m.react('❌')
        return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕فـشـل فـي الـفـحـص، حـاول لاحـقـا*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    }
}

handler.help = ['فحص-الموقع']
handler.tags = ['ادوات']
handler.command = /^(فحص-الموقع|check-host)$/i

export default handler