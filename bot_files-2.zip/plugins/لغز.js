/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO (معدل عن GEO)
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: لعبة الألغاز الذكية
 * 📢 القناة: https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

const RIDDLES = [
  { riddle: 'أنا بلا أرجل لكن أجري دائماً، وبلا فم لكن أغني أحياناً. من أنا؟', answers: ['نهر', 'ماء', 'مياه'] },
  { riddle: 'أكبر كلما أخذت منها. ما هي؟', answers: ['حفرة'] },
  { riddle: 'لها أسنان ولا تعض، وتمشط ولا تحلق. ما هي؟', answers: ['مشط'] },
  { riddle: 'أنا أمشي وأنا جالس، وأسافر وأنا في مكاني. من أنا؟', answers: ['ساعة', 'الساعة'] },
  { riddle: 'كلما أكلت ازداد حجمي، وإذا شربت الماء مت. ما أنا؟', answers: ['نار'] },
  { riddle: 'لي عينان ولا أرى، ولي قدمان ولا أمشي. ما أنا؟', answers: ['حذاء', 'جزمة'] },
  { riddle: 'أطول من النخلة وأخف من الريشة. ما هو؟', answers: ['ظل', 'الظل'] },
  { riddle: 'ينزل ولا يصعد. ما هو؟', answers: ['مطر'] },
  { riddle: 'أنا دائماً أمامك لكن لا يمكن رؤيتي. ما أنا؟', answers: ['مستقبل', 'المستقبل'] },
  { riddle: 'ما الشيء الذي تراه مرتين في الدقيقة ومرة في الساعة ومرة في الدهر؟', answers: ['حرف م'] },
  { riddle: 'شيء عندك لكن الآخرون يستخدمونه أكثر منك. ما هو؟', answers: ['اسمك', 'اسم'] },
  { riddle: 'لي قلب لكن لا أحس، ولي أوراق لكن لا أشجر. ما أنا؟', answers: ['كتاب'] },
  { riddle: 'كلما أعطيت منه كثر، وكلما أخذت منه قل. ما هو؟', answers: ['علم', 'معرفة'] },
  { riddle: 'ما الشيء الذي له رقبة ولا رأس له؟', answers: ['قنينة', 'زجاجة'] },
  { riddle: 'أنا بلا جسد لكن تسمع صوتي. ما أنا؟', answers: ['صدى'] },
  { riddle: 'لا يؤكل ولا يشرب لكن الكل يحتاجه. ما هو؟', answers: ['هواء'] },
  { riddle: 'ما الشيء الذي يملك مفتاحاً لكن لا قفل له؟', answers: ['بيانو'] },
  { riddle: 'صندوق ليس فيه مفتاح ولا قفل لكن فيه ذهب. ما هو؟', answers: ['بيضة'] },
  { riddle: 'يمشي على أربعة في الصغر وعلى اثنين في الكبر وعلى ثلاثة في الشيخوخة. من هو؟', answers: ['إنسان', 'انسان', 'بشر'] },
  { riddle: 'ما الشيء الذي يزداد كلما شاركته؟', answers: ['فرح', 'سعادة', 'علم', 'حب'] },
  { riddle: 'ما الحيوان الذي ينام وعيناه مفتوحتان؟', answers: ['سمكة'] },
  { riddle: 'كم بيضة يمكن لرجل جائع أن يأكل على معدة فارغة؟', answers: ['واحدة', 'بيضة واحدة'] },
  { riddle: 'أول كلمة نزل بها جبريل على النبي. ما هي؟', answers: ['اقرأ'] },
  { riddle: 'كم عدد أركان الإسلام؟', answers: ['خمسة', '5'] },
  { riddle: 'ما الشيء الذي يملأ الغرفة لكن لا يأخذ حجماً؟', answers: ['نور', 'ضوء'] },
  { riddle: 'ما الرقم الذي إذا ضربته في أي رقم يظل كما هو؟', answers: ['صفر', '0'] },
];

if (!global._tokitaRiddle) global._tokitaRiddle = {};

const normalize = s => s.trim().replace(/[إأآا]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').replace(/\s+/g,' ').toLowerCase()
const checkAnswer = (u, arr) => arr.some(a => normalize(u) === normalize(a) || normalize(u).includes(normalize(a)))

let handler = async (m, { conn, usedPrefix }) => {
  const gameKey = `${m.chat}_${m.sender}`
  if (global._tokitaRiddle[gameKey]) {
    return m.reply(
`* ━ ╼╃ ⌬〔⚠️〕⌬ ╄╾ ━ *
> *عـنـدك لـغـز شـغـال!*
> *🧩 ${global._tokitaRiddle[gameKey].riddle}*
> *جـاوب عـلـيـه قـبـل مـا تـطـلـب جـديـد*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
    )
  }

  const item = RIDDLES[Math.floor(Math.random()*RIDDLES.length)]

  await conn.sendMessage(m.chat, {
    text:
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🧩 〕 لـعـبـة الألـغـاز - 𝐆𝐎𝐉𝐎 ♛*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *

> *❪🤔❫ الـلـغـز:*
> *${item.riddle}*

> *⏱️ الـوقـت:* 60 ثـانـيـة
> *💰 الـجـائـزة:* 4000 XP
> *💡 اكـتـب الإجـابـة مـبـاشـرة*

* ━ ╼╃ ⌬〔 🧠 〕⌬ ╄╾ ━ *`
  }, { quoted: m })

  global._tokitaRiddle[gameKey] = {
    riddle: item.riddle,
    answers: item.answers,
    starter: m.sender,
    chatId: m.chat,
    timeout: setTimeout(() => {
      if (global._tokitaRiddle[gameKey]) {
        conn.sendMessage(m.chat, {
          text:
`* ━ ╼╃ ⌬〔⏰〕⌬ ╄╾ ━ *
> *انـتـهـى الـوقـت @${m.sender.split('@')[0]}!*
> *🧩 الـلـغـز:* ${item.riddle}
> *✅ الإجـابـة:* *${item.answers[0]}*
> *🎯 اكـتـب ${usedPrefix}لغز لـلـعـب مـرة أخـرى*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`,
          mentions: [m.sender]
        })
        delete global._tokitaRiddle[gameKey]
      }
    }, 60000)
  }
}

handler.before = async function (m, { conn }) {
  if (!m.text || /^[.\/!#]/.test(m.text.trim())) return false
  // ما يردش على النصوص الطويلة بزاف باش ما يزعجش
  if (m.text.trim().length > 25) return false

  let activeKey=null, game=null
  for(let k in global._tokitaRiddle){
    let g = global._tokitaRiddle[k]
    if(g.starter===m.sender && g.chatId===m.chat){ activeKey=k; game=g; break }
  }
  if (!game) return false

  const isCorrect = checkAnswer(m.text.trim(), game.answers)
  if (!isCorrect) return false // ما يردش على الغلط باش ما يسباميش، يرد غير الى صح

  clearTimeout(game.timeout)
  if(!global.db?.data?.users?.[m.sender]) global.db.data.users[m.sender]={exp:0}
  global.db.data.users[m.sender].exp += 4000

  await conn.sendMessage(m.chat, {
    text:
`* ━ ╼╃ ⌬〔✅〕⌬ ╄╾ ━ *
> *إجـابـة صـحـيـحـة يـا @${m.sender.split('@')[0]} 🎉*

> *🧩 الـلـغـز:* ${game.riddle}
> *✅ الإجـابـة:* *${game.answers[0]}*
> *💰 ربـحـت:* *4000 XP*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`,
    mentions: [m.sender]
  })
  delete global._tokitaRiddle[activeKey]
  return true
}

handler.help = ['لغز']
handler.tags = ['العاب']
handler.command = /^(لغز|riddle|الغاز)$/i
export default handler