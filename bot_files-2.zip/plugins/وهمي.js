/* حقوق التطوير
 * المطور: 🪖 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 🔮
 * البوت: ☃️ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🪖🔮
 */

let handler = async (m, { conn, args, usedPrefix, command }) => {

  if (!m.mentionedJid[0]) {
    return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 امـر الــوهمي┊ ˼‏ 🥷˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *🥷🏻┊ ${usedPrefix + command} @منشن النص_الوهمي | رد_البوت*
> *🥷🏻┊ مـثـال:* ${usedPrefix + command} @2126xxxx وا مشيتي لقنت | اه مشيت

* 🪖 ──¤﹝الـمـلاحـظـة ↶ 🕸️﹞*
> *🥷🏻┊ دير | بين الرسالة الوهمية ورد البوت*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
  }

  let target = m.mentionedJid[0]
  let fullText = args.join(' ').split('|')

  let fakeText = fullText[0]?.replace(/@\d+/g, '').trim() // النص الوهمي
  let replyText = fullText[1]?.trim() // رد البوت

  if (!fakeText ||!replyText) {
    return m.reply(`❌ خـاصـك دـيـر | \nمـثـال:.وهمي @شخص النص | الرد`)
  }

  let name = await conn.getName(target)
  let pp = await conn.profilePictureUrl(target, 'image').catch(() => 'https://telegra.ph/file/320b066dc81928b782c7b.png')

  // 1. نصيفط الرسالة الوهمية من الشخص
  let fakeMsg = await conn.sendMessage(m.chat, {
    text: fakeText,
    contextInfo: {
      mentionedJid: [target],
      externalAdReply: {
        title: name,
        body: 'عضو',
        thumbnailUrl: pp,
        mediaType: 1
      }
    }
  })

  // 2. البوت يرد على الرسالة الوهمية
  await new Promise(r => setTimeout(r, 500))
  await conn.sendMessage(m.chat, {
    text: replyText
  }, { quoted: fakeMsg })

  await m.react('✅')
}

handler.help = ['وهمي']
handler.tags = ['🪖 اوامر 🕸️']
handler.command = /^(وهمي|fake)$/i
handler.group = true

export default handler