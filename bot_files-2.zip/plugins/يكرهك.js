let handler = async (m, { conn }) => {
    let isGroup = m.chat?.endsWith('@g.us') || m.isGroup || false
    if (!isGroup) {
        try { await conn.groupMetadata(m.chat); isGroup = true } catch { isGroup = false }
    }
    if (!isGroup) return conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 هـاد الأمـر خـاص بـالـمـجـمـوعـات فـقـط!*\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })

    try {
        let groupMetadata = await conn.groupMetadata(m.chat)
        let participants = groupMetadata.participants.map(v => v.id || v.jid || v)
        let users = participants.filter(v => v!== conn.user.jid && v!== conn.user.id && v!== m.sender)
        if (users.length === 0) users = participants.filter(v => v!== conn.user.jid)

        let hater = users[Math.floor(Math.random() * users.length)]

        let hateReasons = [
            "كـيـكـرهـك حـيـت كـتـصـيـفـط ريـكـوردات طـوال 😒",
            "كـيـكـرهـك حـيـت ديـمـا كـتـسـبـقـو لـلأكـل 🍔",
            "كـيـكـرهـك حـيـت كـتـجـيـب لـيـه الـنـحـس فـالـلـعـبـة 🎮",
            "كـيـكـرهـك حـيـت كـتـكـتـب كـثـيـر ومـا كـتـقـول والـو 📝",
            "كـيـكـرهـك حـيـت كـتـسـرق لـيـه الـمـلـصـقـات 😼",
            "كـيـكـرهـك حـيـت ديـمـا كـتـبـان مـتـصـل ومـا كـتـجـاوبـش 📵",
            "كـيـكـرهـك حـيـت ضـحـكـتـك مـزعـجـة فـي الـكـول 😹",
            "كـيـكـرهـك حـيـت كـتـهـضـر عـلـى الـدراسـة بـزاف 📚",
            "كـيـكـرهـك حـيـت كـتـنـافـسـو عـلـى نـفـس الـكـراش 💔",
            "كـيـكـرهـك بـلا سـبـب هـكـا لـلـه فـي سـبـيـل الله 😭",
            "كـيـكـرهـك حـيـت كـتـبـقـى تـقـول انـك فـاهـم كـلـشـي 🤓",
            "كـيـكـرهـك حـيـت كـتـسـرق لـيـه الـويـفـي ديـالـو 📶"
        ]

        let reason = hateReasons[Math.floor(Math.random() * hateReasons.length)]
        let imageUrl = 'https://files.catbox.moe/1p87nf.jpg'

        let txt = `
* ━ ╼╃ ⌬〔💔〕⌬ ╄╾ ━ *
*〔 ♛ 〕 كـاشـف الـكـراهـيـة 𝐆𝐎𝐉𝐎*
* ━ ╼╃ ⌬〔 😾 〕⌬ ╄╾ ━ *

*〔 🙋‍♂️ 〕 الـطـالـب :* @${m.sender.split('@')[0]}
*〔 😡 〕 الـلـي كـيـكـرهـك :* @${hater.split('@')[0]}

*〔 📜 〕 الـسـبـب :*
*› ${reason}*

*〔 💣 〕 الـحـالـة :*
*› كـراهـيـة شـديـدة جـدا ولا يـمـكـن عـلاجـهـا*

* ━ ╼╃ ⌬〔 📌 〕⌬ ╄╾ ━ *
*⚠️ تـنـبـيـه : هـادا الـكـود عـشـوائـي 100% لـلـتـرفـيـه فـقـط*
*الـحـب والـكـراهـيـة بـيـد الله مـاشـي الـبـوت 😹*
* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`.trim()

        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: txt,
            mentions: [m.sender, hater]
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 خـطـأ:* ' + e.message + '\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })
    }
}

handler.help = ['يكرهني']
handler.tags = ['fun']
handler.command = ['يكرهني', 'يكرهك', 'كرهني', 'من_يكرهني']
handler.group = true

export default handler