import fs from "fs";
import path from "path";

// تعريف الفئات (Categories) لسهولة الاختيار
const CATEGORIES = [
    [1, 'التـحـمـيـل', 'downloads'], [2, 'الـمـجـمـوعـات', 'group'],
    [3, 'الـمـلـصـقـات', 'sticker'], [4, 'الـمـطـوريـن', 'owner'],
    [5, 'امـثـلـه', 'example'], [6, 'الـادوات', 'tools'],
    [7, 'الـبـحـث', 'search'], [8, 'الادمــن', 'admin'],
    [9, 'الالــعـاب', 'games'], [10, 'الچيف', 'gif'],
    [11, 'الـبــنـك', 'bank'], [12, 'الـذكـاء الاصـطـنـاعـي', 'ai'],
    [13, 'الـبـوتـات الـفـرعـي', 'sub'], [14, 'مـعـلومـات الـبـوت', 'info'],
    [15, 'أخــرى', 'other']
];

if (!global.plugin_sessions) global.plugin_sessions = {};

const h = async (m, { text, conn, bot, args }) => {
    const action = args[0]?.toLowerCase();
    const pluginsDir = path.join(process.cwd(), "plugins");

    if (action === 'اضف' || action === 'عدل') {
        const quoted = m.quoted ? m.quoted : m;
        const code = quoted.text;
        if (!code) return await m.reply("❌ رد على الكود المطلوب حفظه.");

        // --- ميكانيكية استخراج اسم الأمر (مثل بوتك القديم) ---
        // يبحث عن نمط: command: ['اسم'] أو command = ['اسم']
        let cmdName = '';
        const match = code.match(/command\s*[:=]\s*['"\[]+([^'"`\],\]]+)/i);
        
        if (match && match[1]) {
            cmdName = match[1].replace(/['"\[\]\s]/g, '').trim();
        } else {
            // محاولة ثانية لو الاسم مكتوب بطريقة تانية
            const altMatch = code.match(/handler\.command\s*=\s*\/^([^$|/]+)/i);
            cmdName = altMatch ? altMatch[1].trim() : `plugin_${Date.now()}`;
        }

        let txt = `🛠️ *إدارة البلوجن: [ ${cmdName} ]*\n\n📂 رد على هذه الرسالة برقم المجلد:\n`;
        CATEGORIES.forEach(c => txt += `${c[0]} - ${c[1]} (${c[2]})\n`);
        txt += `\n> *رد بالرقم فقط يا 𝑩𝑳𝑶𝑫*`;

        const msg = await m.reply(txt);
        global.plugin_sessions[msg.key.id] = { code, cmdName, time: Date.now() };
        return;
    }

    // واجهة المساعدة الأساسية
    const help = `*🔧 لوحة تحكم البلوقنات 𝑩𝑳𝑶𝑫:*\n\n` +
                 `- .بلوجن كل\n` +
                 `- .بلوجن اضف (رد ع كود)\n` +
                 `- .بلوجن عدل (رد ع كود)\n\n` +
                 `> 𒉭✦⃝𝑩𝑳𝑶𝑫🎲`;
    await m.reply(help);
};

h.before = async (m, { conn }) => {
    if (!m.quoted || !m.text || !global.plugin_sessions[m.quoted.id]) return false;

    const session = global.plugin_sessions[m.quoted.id];
    const categoryIndex = parseInt(m.text.trim());
    const selectedCat = CATEGORIES.find(c => c[0] === categoryIndex);

    if (!selectedCat) return false; // اترك المجال للمستخدم يصحح الرقم

    const pluginsDir = path.join(process.cwd(), "plugins");
    const targetFolder = path.join(pluginsDir, selectedCat[2]);

    if (!fs.existsSync(targetFolder)) fs.mkdirSync(targetFolder, { recursive: true });

    const savePath = path.join(targetFolder, `${session.cmdName}.js`);
    fs.writeFileSync(savePath, session.code, "utf-8");

    await m.reply(`✅ تم الحفظ بنجاح!\n\n📄 الاسم: ${session.cmdName}\n📂 المجلد: ${selectedCat[2]}`);
    
    delete global.plugin_sessions[m.quoted.id];
    return true;
};

h.usage = ["بلوجن"];
h.category = "owner";
h.command = ['بلوجن'];
h.owner = true;

export default h;
