// =================================================================
// • Plugin Name : Email Generator Temp
// • Bot Name : 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓
// • Developer : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 — 212674375708
// • API : engez.a7a.online
// • Commands : توليد-بريد | قراءة-بريد | تحديث-بريد
// =================================================================
import axios from 'axios'

const API_BASE = 'https://engez.a7a.online/api/v1'
const sessions = new Map()

// تنظيف الجلسات كل ساعة
setInterval(() => {
    let now = Date.now()
    for (let [k, v] of sessions) if (now - v.created > 3600000) sessions.delete(k)
}, 60000 * 30)

async function callAPI(params) {
    const { data } = await axios.get(`${API_BASE}/tools/email-generator?${params.toString()}`, { timeout: 30000 })
    if (!data?.success) throw new Error(data?.error || 'فشل الطلب')
    return data
}

let handler = async (m, { conn, text, command }) => {
    // توليد بريد
    if (command === 'توليد-بريد' || command === 'gen-email') {
        await m.react('⏳')
        try {
            const data = await callAPI(new URLSearchParams({ action: 'generate' }))
            const res = data.response
            
            sessions.set(m.sender, {
                email: res.email,
                sessionRaw: res.session, // نخليها raw
                session: encodeURIComponent(JSON.stringify(res.session)),
                created: Date.now()
            })

            let txt = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n\n`
            txt += `> *📧 تم توليد البريد بنجاح*\n\n`
            txt += `> *📫 البريد:*\n> \`${res.email}\`\n\n`
            txt += `> *📊 الرسائل:* ${res.messages?.length || 0}\n`
            if (res.messages?.length) {
                txt += `\n> *📨 الرسائل:*\n`
                res.messages.slice(0,5).forEach((msg,i)=>{
                    txt += `> ${i+1}. من: ${msg.from}\n> موضوع: ${msg.subject}\n> معرف: \`${msg.messageID}\`\n\n`
                })
                txt += `> للقراءة: \`.قراءة-بريد المعرف\`\n`
            } else txt += `> 📭 لا توجد رسائل حاليا - استعمل \`.تحديث-بريد\`\n`
            txt += `\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`

            await m.reply(txt)
            await m.react('✅')
        } catch (e) { await m.react('❌'); return m.reply(`❌ *خطأ:* ${e.message}`) }
        return
    }

    // قراءة بريد
    if (command === 'قراءة-بريد' || command === 'read-email') {
        if (!text) return m.reply(`📌 *الاستخدام:*\n\`.قراءة-بريد <المعرف>\`\nمثال: \`.قراءة-بريد A1B2C3\``)
        let s = sessions.get(m.sender)
        if (!s) return m.reply(`❌ ما عندكش جلسة\nدير \`.توليد-بريد\` أولا`)
        await m.react('⏳')
        try {
            let p = new URLSearchParams({ action: 'read', email: s.email, messageId: text.trim(), session: s.session })
            let data = await callAPI(p)
            await m.reply(`*📨 محتوى الرسالة*\n\n> *📫 البريد:* ${s.email}\n\n> *📝 المحتوى:*\n${data.message || JSON.stringify(data.response||data).slice(0,3000)}`)
            await m.react('✅')
        } catch (e) { await m.react('❌'); return m.reply(`❌ *خطأ:* ${e.message}`) }
        return
    }

    // تحديث
    if (command === 'تحديث-بريد' || command === 'refresh-email') {
        let s = sessions.get(m.sender)
        if (!s) return m.reply(`❌ ما عندكش جلسة`)
        await m.react('⏳')
        try {
            let p = new URLSearchParams({ action: 'refresh', email: s.email, session: s.session })
            let data = await callAPI(p)
            let msgs = data.messages || []
            s.messages = msgs; sessions.set(m.sender, s)
            let txt = `> *📨 تم التحديث*\n> *📫 ${s.email}*\n> *📊 ${msgs.length} رسالة*\n\n`
            if (msgs.length) msgs.slice(0,5).forEach((x,i)=>{ txt+=`${i+1}. *${x.subject||'بدون موضوع'}* من ${x.from}\n   ID: \`${x.messageID}\`\n\n` })
            else txt+=`📭 لا جديد`
            await m.reply(txt); await m.react('✅')
        } catch (e) { await m.react('❌'); return m.reply(`❌ ${e.message}`) }
        return
    }

    if (command === 'بريد-مساعدة' || command === 'email-help') {
        return m.reply(`*📧 أوامر البريد المؤقت*\n\n> \`.توليد-بريد\` - توليد بريد\n> \`.تحديث-بريد\` - تحديث الرسائل\n> \`.قراءة-بريد <id>\` - قراءة رسالة\n> \`.بريد-مساعدة\` - المساعدة`)
    }
}

handler.command = ['توليد-بريد','gen-email','قراءة-بريد','read-email','تحديث-بريد','refresh-email','بريد-مساعدة','email-help']
handler.help = ['توليد-بريد','قراءة-بريد','تحديث-بريد']
handler.tags = ['tools']
export default handler