// ⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽
// 📌 البلاجين: تصويت مزيف قابل للتعديل + منشن الكل
// Developed by: YONO DEV 🪖

let handler = async (m, { conn, participants, text }) => {
  if (!m.isGroup) return m.reply('⚠️ *هذا الامر خاص بالمجموعات فقط*')
  if (!text) return m.reply(`*⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽*\n\n*📝 طريقة الاستخدام:*\n`
    + `.منشن-تصويت السؤال | الخيار1 999 | الخيار2 777 | الخيار3 111\n`
    + `*مثال:*\n`
    + `.منشن-تصويت هل تريدون اكواد | نعم 999 | لا 77777 | ممكن 55555\n`
    + `*ملاحظة:* تقدر تزيد حتى 5 خيارات`)

  let users = participants.map(u => u.id)

  // فورمات: السؤال | خيار1 عدد | خيار2 عدد | خيار3 عدد
  let parts = text.split('|').map(v => v.trim())
  let question = parts[0] || "تصويت"

  let pollVotes = []
  for (let i = 1; i < parts.length; i++) {
    let [name, count] = parts[i].split(/(\d+)/).filter(Boolean)
    pollVotes.push({
      optionName: name.trim(),
      optionVoteCount: parseInt(count) || 1000
    })
  }

  if (pollVotes.length < 2) return m.reply('❌ *خاص على الاقل خيارين*')

  const content = {
    pollResultSnapshotMessage: {
      pollVotes: pollVotes,
      name: question,
      contextInfo: {
        mentionedJid: users,
        forwardingScore: 127,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363428598542954@newsletter", // <<< ها هو كود القناة ديالك
          serverMessageId: 0,
          newsletterName: "⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽"
        },
        forwardOrigin: 0
      },
      pollType: 0
    }
  }

  await conn.relayMessage(m.chat, content, { mentions: users })
  await conn.sendMessage(m.chat, { react: { text: '📊', key: m.key } })
}

handler.help = ['منشن-تصويت <السؤال | خيار عدد | خيار عدد>'];
handler.tags = ['المجموعة'];
handler.command = /^(منشن-تصويت|hidetagfakepoll)$/i;
handler.group = true;
handler.admin = true;

export default handler