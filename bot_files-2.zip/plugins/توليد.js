// ⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽
// 📌 البلاجين: توليد الصور بالذكاء الاصطناعي Flux
// Developed by: YONO DEV 🪖

import axios from 'axios'
import { join } from 'path'
import { tmpdir } from 'os'
import { createWriteStream, unlinkSync, statSync, mkdirSync, existsSync } from 'fs'
import { pipeline } from 'stream/promises'

const box = (title, body) => {
`* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
> *〔 ${title} ┊ ˼‏ 🪖˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
${body}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*GOJO BOT 🥷🏻*`
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const react = async (emoji) => {
    try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) } catch {}
  }

  if (!text) {
    await react('❌')
    return m.reply(box(
      `طـريـقـة الاسـتـخـدام`,
      `> *🥷🏻┊.${command} وصف الصورة*
> *🥷🏻┊.${command} فتاة انمي*
> *🥷🏻┊.${command} مدينة مستقبلية*

*🎨 امثلة سريعة:*
> قطة لطيفة في حديقة
> غروب الشمس على البحر
> محارب ساموراي`
    ))
  }

  await react('🎨')
  await m.reply(box(
    `جـاري تـولـيـد الـصـورة`,
    `> *⏳ انتظر 15-30 ثانية...*
> *📝 الوصف:* ${text}`
  ))

  try {
    // ترجمة للإنجليزية
    let englishText = text
    try {
      const trRes = await axios.get(
        `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(text)}`,
        { timeout: 8000 }
      )
      const translated = trRes.data?.[0]?.map(x => x?.[0]).filter(Boolean).join('') || text
      if (translated) englishText = translated
    } catch { englishText = text }

    // رابط Pollinations الجديد + بدون توكن
    const encoded  = encodeURIComponent(englishText + ', high quality, detailed, 8k, masterpiece')
    const seed     = Math.floor(Math.random() * 999)
    const imageUrl = `https://image.pollinations.ai/prompt/${encoded}?width=1024&height=1024&seed=${seed}&model=flux&enhance=true&nologo=true`

    // انشاء مجلد tmp لو غير موجود
    const tmpDir = './tmp'
    if (!existsSync(tmpDir)) mkdirSync(tmpDir)

    const filePath = join(tmpDir, `gojo_img_${Date.now()}.jpg`)
    
    const imgRes = await axios({
      method: 'GET',
      url: imageUrl,
      responseType: 'stream',
      timeout: 120000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    })

    await pipeline(imgRes.data, createWriteStream(filePath))

    const size = statSync(filePath).size
    if (size < 5000) {
      try { unlinkSync(filePath) } catch {}
      throw new Error('فشل توليد الصورة — السيرفر لم يرجع صورة')
    }

    await conn.sendMessage(m.chat, {
      image: { url: filePath },
      caption: box(
        `تـم تـولـيـد الـصـورة`,
        `> *✅ تم بنجاح*
> *📝 الوصف:* ${text}
> *🔤 المترجم:* ${englishText}
> *📁 الحجم:* ${(size / 1024).toFixed(2)} KB
> *🤖 الموديل:* Flux AI`
      )
    }, { quoted: m })

    await react('✅')
    setTimeout(() => { try { unlinkSync(filePath) } catch {} }, 3000)

  } catch (err) {
    await react('❌')
    console.error('draw error:', err.message)
    m.reply(box(
      `فـشـل الـتـولـيـد`,
      `> *❌ الخطأ:* ${err.message}
> *💡 نصيحة:* 
> 1. جرب وصف بالانجليزي
> 2. انتظر دقيقة وعاود
> *مثال:* .صورة cat warrior`
    ))
  }
}

handler.help    = ['صورة <الوصف>'];
handler.tags    = ['الذكاء الاصطناعي'];
handler.command = /^(صورة|صوره|توليد|imagine|img|imag)$/i;
handler.limit   = true;

export default handler