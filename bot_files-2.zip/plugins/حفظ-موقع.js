// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الـتـحـمـيـل┊ ˼‏ 💾˹ ↶〕* *𝐆𝐎𝐉𝐎* ──¤﹝نـظـام حـفـظ الـمـواقـع ZIP ↶﹞*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

import axios from 'axios';

let handler = async (m, { args, usedPrefix, command }) => {
    const isArabic = /^(حفظ-موقع|ويب|عيي)$/i.test(command)

    if (!args[0]) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❗ 〕أدخـل رابـط الـمـوقـع*

*💾┊طـريـقـة الاسـتـخـدام:*
*${usedPrefix + command} https://google.com*

*⚙️┊الـمـمـيـزات:*
*• تـغـيـيـر أسـمـاء الـمـلـفـات تـلـقـائـي*
*• حـفـظ كـامـل لـلـمـوقـع*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);

    let url = args[0].trim()
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url

    await m.reply(isArabic
       ? `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ⏳ 〕جـاري حـفـظ الـمـوقـع...*\n> *قـد تـسـتـغـرق بـعـض الـوقـت ⏰*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
        : `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ⏳ 〕Saving website...*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);

    await m.react('🕒')

    try {
        const result = await saveweb2zip(url, {
            renameAssets: true,
            saveStructure: false,
            alternativeAlgorithm: false,
            mobileVersion: false
        });

        if (result.error?.code) throw new Error(result.error.text || 'فشل الحفظ')

        await m.react('✅')
        await m.conn.sendMessage(m.chat, {
            document: { url: result.downloadUrl },
            fileName: `GOJO-${url.replace(/https?:\/\//,'').replace(/[^a-z0-9]/gi,'_')}.zip`,
            mimetype: 'application/zip',
            caption: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـحـفـظ┊ 💾 〕* *𝐆𝐎𝐉𝐎*

*🌐┊الـرابـط:* ${url}
*📁┊عـدد الـمـلـفـات:* *${result.copiedFilesAmount}*
*✅┊الـحـالـة:* *تـم الـحـفـظ بـنـجـاح*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`
        }, { quoted: m });

    } catch (e) {
        console.log(e); await m.react('❌')
        return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕فـشـل حـفـظ الـمـوقـع*\n> *${e.message}*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    }
};

async function saveweb2zip(url, options = {}) {
    const { data } = await axios.post('https://copier.saveweb2zip.com/api/copySite', {
        url,...options
    }, {
        headers: {
            'accept': '*/*',
            'content-type': 'application/json',
            'origin': 'https://saveweb2zip.com',
            'referer': 'https://saveweb2zip.com/',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 Chrome/137.0.0.0 Mobile Safari/537.36'
        }
    });

    while (true) {
        const { data: process } = await axios.get(`https://copier.saveweb2zip.com/api/getStatus/${data.md5}`, {
            headers: {
                'origin': 'https://saveweb2zip.com',
                'referer': 'https://saveweb2zip.com/',
                'user-agent': 'Mozilla/5.0'
            }
        });
        if (!process.isFinished) { await new Promise(r => setTimeout(r, 1200)); continue; }
        return {
            copiedFilesAmount: process.copiedFilesAmount,
            downloadUrl: `https://copier.saveweb2zip.com/api/downloadArchive/${process.md5}`,
            error: { text: process.errorText, code: process.errorCode }
        };
    }
}

handler.help = ['حفظ-موقع']
handler.tags = ['ادوات']
handler.command = /^(saveweb|web2zip|حفظ-موقع|ويب)$/i

export default handler