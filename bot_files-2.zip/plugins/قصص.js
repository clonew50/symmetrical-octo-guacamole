/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: قصص إسلامية عشوائية
 * 📢 القناة: https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

import pkg from '@whiskeysockets/baileys';
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

let stories = [
    "*قصة النبي نوح عليه السلام:* كان النبي نوح يدعو قومه لعبادة الله وحده، لكنهم كذبوه. فأمره الله أن يبني سفينة، وحين حل الطوفان، نجا المؤمنون وغرق الكافرون. تعلمنا الصبر والإصرار.",
    "*قصة النبي موسى وفرعون:* عاش موسى في زمن فرعون الظالم. دعاه لعبادة الله فجحد، فأرسل الله آيات عظيمة حتى غرق فرعون. تعلمنا أن الحق ينتصر مهما كانت قوة الباطل.",
    "*قصة النبي عيسى عليه السلام:* حاول أن يقنع قومه بالحق وظهرت معه معجزات، لكنهم كذبوه وحاولوا قتله فرفعه الله. تعلمنا أن القلب هو من يفتح أبواب الإيمان.",
    "*قصة سلمان الفارسي:* كان يبحث عن الحقيقة حتى وجدها في الإسلام، وقال عنه النبي ﷺ: 'سلمان منا أهل البيت'. تعلمنا أن البحث عن الحقيقة يوصل للنور.",
    "*قصة بلال بن رباح:* كان عبدا يعذب في مكة ويقول أحد أحد، فثبت على إيمانه وكان أول مؤذن في الإسلام. تعلمنا الثبات مهما كانت الظروف.",
    "*قصة أبي بكر الصديق:* أول من آمن ورافق النبي في الهجرة وأنفق ماله كله لله. تعلمنا الصدق والوفاء.",
    "*قصة عمر بن الخطاب:* كان عدواً للإسلام ثم أصبح فاروق الأمة وأعدل حكامها. تعلمنا أن التغيير ممكن بفضل الله.",
    "*قصة عثمان بن عفان:* اشترى بئر رومة وأوقفه للمسلمين وجهز جيش العسرة. تعلمنا أن المال قوة حين ينفق لله.",
    "*قصة علي بن أبي طالب:* أول صبي أسلم وفدى النبي بنفسه ليلة الهجرة. تعلمنا الشجاعة والحكمة.",
    "*قصة خالد بن الوليد:* سيف الله المسلول الذي لم يهزم في معركة قط. تعلمنا الإخلاص في الدفاع عن الحق.",
    "*قصة النبي يوسف عليه السلام:* حسده إخوته وألقوه في البئر، ثم مكنه الله حتى أصبح عزيز مصر. تعلمنا أن الله يرفع من يشاء.",
    "*قصة غزوة بدر:* أول معركة كبرى انتصر فيها 313 مسلما على ألف مشرك. تعلمنا الثقة بنصر الله.",
    "*قصة طارق بن زياد:* أحرق السفن وقال البحر من ورائكم والعدو أمامكم. تعلمنا الجرأة والتوكل."
];

var handler = async (m, { conn }) => {

let randomStory = stories[Math.floor(Math.random() * stories.length)];

try {
    var messa = await prepareWAMessageMedia({ image: { url: 'https://i.pinimg.com/736x/60/9c/3c/609c3c6d1e9e6a2e3f4a5b6c7d8e9f0a1.jpg' } }, { upload: conn.waUploadToServer });

    let msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
            "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 },
            interactiveMessage: proto.Message.InteractiveMessage.create({
              body: proto.Message.InteractiveMessage.Body.create({
                text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 📖 〕 قـصـة الـيـوم ♣️*\n\n${randomStory}\n\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: "♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | قصص وعبر 🌙"
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                title: "📚 قصة إسلامية",
                subtitle: "♛ 𝐆𝐎𝐉𝐎 ♛",
                hasMediaAttachment: true,
                imageMessage: messa.imageMessage,
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                   name: "quick_reply",
                   buttonParamsJson: JSON.stringify({
                     "display_text": "📖 التالي",
                     "id": ".قصة"
                    })
                   },
                  {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                      "display_text": "📢 قناة 𝐆𝐎𝐉𝐎 الرسمية",
                      "url": "https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r",
                      "merchant_url": "https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r"
                    })
                  }
                ],
              })
            })
        }
      }
    }, { quoted: m })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

} catch (e) {
    await conn.reply(m.chat,
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 📖 〕 قـصـة الـيـوم ♣️*

${randomStory}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m)
}
}

handler.help = ['قصة']
handler.tags = ['دين','تفاعل']
handler.command = /^(قصة|قصص|حكاية|qissa)$/i

export default handler;