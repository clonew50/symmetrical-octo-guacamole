import fetch from 'node-fetch';
import { format } from 'util';

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🌐 〕أدخـل الـرابـط ↶*
> *مـثـال:* *${usedPrefix + command} https://api.waifu.pics*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`, m);

  if (!/^https?:\/\//i.test(text)) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🩸 〕يـجـب أن يـبـدأ الـرابـط بـ http:// أو https://*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m);

  const url = text.trim();

  try {
    await conn.sendMessage(m.chat, { react: { text: '🌐', key: m.key } });

    const res = await fetch(url, { headers: { 'user-agent': 'Mozilla/5.0 (GOJO)' } });

    let clen = res.headers.get('content-length');
    if (clen && parseInt(clen) > 100 * 1024) {
      throw `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🩸 〕الـمـلـف كـبـيـر جـدا!*
> *الـحـجـم:* ${(parseInt(clen) / 1024 / 1024).toFixed(2)} MB
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;
    }

    let ctype = res.headers.get('content-type') || '';

    if (!/text|json|javascript|html|xml/i.test(ctype)) {
      return await conn.sendFile(m.chat, url, 'tokita_file', `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 📦 〕تـم الـجـلـب بـنـجـاح*
> *〔 🌐 〕الـرابـط:* ${url}
> *〔 🧩 〕الـنـوع:* ${ctype}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`, m);
    }

    let txt = await res.buffer();

    try {
      txt = format(JSON.parse(txt + ''));
    } catch {
      txt = txt + '';
    }

    if (!txt || txt.trim().length === 0) throw '*الـرابـط فـارغ مـا فـيـه والـو*';

    if (txt.length > 60000) {
      return await conn.sendFile(m.chat, Buffer.from(txt), '𝐆𝐎𝐉𝐎_fetch.txt', `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 📝 〕الـنـص طـويـل*
> *تـم إرسـالـه كـمـلـف*
> *${url}*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m);
    }

    await m.reply(txt.slice(0, 65536) + '');

  } catch (e) {
    console.error(e);
    await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ 〕فـشـل الـجـلـب*
> *${e.message || e}*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);
  }
};

handler.help = ['fetch', 'get', 'احضر'].map(v => v + ' <الرابط>')
handler.tags = ['internet']
handler.command = /^(fetch|get|احضر)$/i
handler.premium = true

export default handler;