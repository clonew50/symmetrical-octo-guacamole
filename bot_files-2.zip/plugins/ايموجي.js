// ⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽
// 📌 البلاجين: تحميل الايموجي بجودة HD من Noto
// Developed by: YONO DEV 🪖
// حقوق النشر محفوظة © 2026 GOJO BOT

import axios from 'axios'

/**
 * تحويل الايموجي الى Unicode hex
 */
function toUnicode(input) {
    let pairs = []
    for (let i = 0; i < input.length; i++) {
        if (input.charCodeAt(i) >= 0xd800 && input.charCodeAt(i) <= 0xdbff) {
            if (input.charCodeAt(i + 1) >= 0xdc00 && input.charCodeAt(i + 1) <= 0xdfff) {
                pairs.push((input.charCodeAt(i) - 0xd800) * 0x400 + (input.charCodeAt(i + 1) - 0xdc00) + 0x10000)
                i++
            }
        } else if (input.charCodeAt(i) < 0xd800 || input.charCodeAt(i) > 0xdfff) {
            pairs.push(input.charCodeAt(i))
        }
    }
    return pairs.map(val => val.toString(16)).join('_')
}

let handler = async (m, { conn, text }) => {
    try {
        if (!text) {
            return m.reply(`*⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽*\n\n❌ *المرجو إدخال ايموجي*\n\n*مثال:*\n.noto 😅\n.noto ❤️‍🔥`)
        }

        await conn.sendMessage(m.chat, { react: { text: '😀', key: m.key } })

        const unicode = toUnicode(text.trim())
        const url = `https://fonts.gstatic.com/s/e/notoemoji/latest/${unicode}/512.webp`

        // فحص اذا الايموجي موجود
        const check = await axios.head(url).catch(() => null)
        if (!check) throw new Error("الايموجي غير مدعوم او غير صالح.")

        await conn.sendFile(
            m.chat,
            url,
            `${unicode}.webp`,
            `*⧼ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🕷️ ⧽*\n`
            + `*⧼ 𝐍𝐎𝐓𝐎 𝐄𝐌𝐎𝐉𝐈 ⧽*\n\n`
            + `✅ *تم التحميل بنجاح*\n\n`
            + `😀 *الايموجي:* ${text}\n`
            + `🔢 *Unicode:* ${unicode}\n`
            + `📦 *المصدر:* Google Noto Emoji 512px\n`
            + `*© Developed by YONO DEV 🪖*`,
            m
        )

    } catch (err) {
        m.reply(`❌ *خطأ:* ${err.message}`)
    }
}

handler.help = ['noto <الايموجي>'];
handler.tags = ['أدوات'];
handler.command = /^(noto|ايموجي|emoji)$/i;
handler.limit = true;

export default handler