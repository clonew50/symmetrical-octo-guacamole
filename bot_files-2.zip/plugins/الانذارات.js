// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الانذارات┊ ˼‏ 🚨˹ ↶〕* *𝐆𝐎𝐉𝐎* ──¤﹝قـائـمـة الـتـحـذيـرات ↶﹞*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

async function isAdminCheck(conn, chatId, userJid) {
  const meta = await conn.groupMetadata(chatId)
  const userNum = userJid.split('@')[0].split(':')[0]
  for (let p of meta.participants) {
    let pId = (p.id || '').split('@')[0].split(':')[0]
    let pPhone = (p.phoneNumber || '').split('@')[0].split(':')[0]
    if ((pId === userNum || pPhone === userNum) && (p.admin === 'admin' || p.admin === 'superadmin')) return true
  }
  return false
}

const handler = async (m, { conn }) => {
  if (!m.chat.endsWith('@g.us')) return m.reply('*للجروبات فقط*')

  let isAdmin = await isAdminCheck(conn, m.chat, m.sender)
  let isOwner = global.owner?.some(v => m.sender.includes(v[0]))
  if (!isAdmin &&!isOwner) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 👑 〕خاصك تكون آدمن باش تشوف القائمة*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)

  const adv = Object.entries(global.db.data.users).filter(([jid, data]) => data.warn && data.warn > 0)

  let caption = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n`
  caption += `> *〔 الـقـائـمـة┊ ˼‏ 🚨˹ ↶〕* *قـائـمـة الإنـذارات*\n`
  caption += `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n\n`

  if (adv.length === 0) {
    caption += `> *〔 📭 〕لا يـوجـد مـسـتـخـدمـون لـديـهـم إنـذارات حـالـيـا*\n`
  } else {
    for (let [jid, data] of adv) {
      caption += `*👤┊الـمـسـتـخـدم:* @${jid.split('@')[0]}\n`
      caption += `*⚠️┊انـذاراتـه:* *${data.warn}/3*\n`
      caption += `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *\n`
    }
  }
  caption += `\n*👑┊الـعـدد الـكـلـي:* *${adv.length}*`

  await conn.sendMessage(m.chat, { react: { text: '🚨', key: m.key } })
  await conn.sendMessage(m.chat, {
    text: caption,
    mentions: adv.map(([jid]) => jid)
  }, { quoted: m })
};

handler.command = /^(listwarn|الانذارات|التحذيرات)$/i;
handler.group = true
// مهم جدا باش ما يبلوكيش
handler.admin = false
handler.botAdmin = false

export default handler;