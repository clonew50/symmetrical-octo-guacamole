/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * امر: احذف
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━
 * By : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 212674375708
 */

import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, text, usedPrefix, command }) => {
   // 1. التحقق من إدخال اسم الملف
   if (!text) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ خـطـأ فـي الاسـتـخـدام┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـطـريـقـة ↶ 🕸️﹞*
> *🥷🏻┊* ${usedPrefix + command} اسـم_الـمـلـف
> *🥷🏻┊* مـثـال: ${usedPrefix + command} test

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)

   // 2. تنظيف اسم الملف ومنع الحذف خارج plugins
   let fileName = text.trim().replace(/\s+/g, '_')
   if (!fileName.endsWith('.js') && !fileName.endsWith('.json')) {
      fileName += '.js'
   }
   
   // حماية: منع ../
   if (fileName.includes('..')) {
      return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ مـمـنـوع┊ ˼‏ 🔒˹ ↶〕*

*🪖 ──¤﹝الـحـمـايـة ↶ 🕸️﹞*
> *🥷🏻┊* لا يمكن حذف ملفات خارج مجلد plugins

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
   }

   const pluginsDir = path.join(process.cwd(), 'plugins')
   const filePath = path.join(pluginsDir, fileName)
   const normalizedPath = `/home/container/plugins/${fileName}`

   const botJid = conn.user?.id?.includes(':')? conn.user.id.split(':')[0] + '@s.whatsapp.net' : conn.user?.id
   const botMeta = {
      isForwarded: true,
      forwardingScore: 999,
      forwardedAiBotMessageInfo: { botJid: '867051314767696@bot' },
      forwardOrigin: 4
   }

   const generateMsg = conn.generateWAMessageFromContent ||
                       (await import('@whiskeysockets/baileys')).default?.generateWAMessageFromContent ||
                       (await import('@whiskeysockets/baileys')).generateWAMessageFromContent

   const sendRich = async (richMessage) => {
      if (typeof generateMsg!== 'function') return m.reply(richMessage.richResponseMessage.submessages[0].messageText)
      
      const msg = await generateMsg(m.chat, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
                  body: { text: richMessage.richResponseMessage.submessages[0].messageText },
                  footer: { text: '🔮 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓' },
                  contextInfo: botMeta,
                  nativeFlowMessage: {
                     buttons: [
                        {
                           name: 'quick_reply',
                           buttonParamsJson: JSON.stringify({ display_text: '📂 عرض الملفات', id: `${usedPrefix}باتش` })
                        }
                     ]
                  }
               }
            }
         }
      }, { userJid: botJid, quoted: m })

      return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
   }

   try {
      // 3. التحقق من وجود الملف
      if (!fs.existsSync(filePath)) {
         return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ لـم يـتـم الـعـثـور┊ ˼‏ 🔍˹ ↶〕*

*🪖 ──¤﹝الـمـلـف ↶ 🕸️﹞*
> *🥷🏻┊* الـمـلـف: ${fileName}
> *🥷🏻┊* الـحـالـة: غير موجود

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
      }

      // 4. عملية الحذف
      fs.unlinkSync(filePath)
      await m.react('🗑️')

      // رسالة النجاح
      return sendRich({
         richResponseMessage: {
            submessages: [
               { 
                  messageText: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🗑️ تـم الـحـذف بـنـجـاح┊ ˼‏ ✅˹ ↶〕*

*🪖 ──¤﹝تـفـاصـيـل الـمـلـف ↶ 🕸️﹞*
> *🥷🏻┊* الـمـلـف: ${fileName}
> *🥷🏻┊* الـمـسـار: ${normalizedPath}
> *🥷🏻┊* الـمـطـور: 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`
               }
            ]
         }
      })

   } catch (e) {
      console.error(e)
      await m.react('❌')
      return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ خـطـأ┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـسـبـب ↶ 🕸️﹞*
> *🥷🏻┊* ${e.message}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
   }
}

handler.help = ['احذف'];
handler.command = ['م', 'delete'];
handler.tags = ['👑 المالك'];
handler.owner = true;
handler.register = true;

export default handler;