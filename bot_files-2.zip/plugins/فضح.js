/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: فضح عرض لمرة واحدة
 * 📢 القناة: https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

import { downloadMediaMessage } from '@whiskeysockets/baileys'

let handler = async (m, { conn }) => {
  try {
    const contextInfo =
      m.message?.extendedTextMessage?.contextInfo ||
      m.message?.imageMessage?.contextInfo ||
      m.message?.videoMessage?.contextInfo ||
      m.quoted?.message?.extendedTextMessage?.contextInfo

    if (!m.quoted &&!contextInfo?.quotedMessage) {
      return m.reply(
`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *
> *رد على رسالة عرض لمرة واحدة*
> *مـثـال:* رد بـ \`.فضح\` على الصورة
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    }

    let quotedMessage = contextInfo?.quotedMessage || m.quoted?.message

    if (quotedMessage?.viewOnceMessageV2) quotedMessage = quotedMessage.viewOnceMessageV2.message
    else if (quotedMessage?.viewOnceMessage) quotedMessage = quotedMessage.viewOnceMessage.message
    else if (quotedMessage?.viewOnceMessageV2Extension) quotedMessage = quotedMessage.viewOnceMessageV2Extension.message
    else if (quotedMessage?.ephemeralMessage) quotedMessage = quotedMessage.ephemeralMessage.message

    const mediaType = Object.keys(quotedMessage || {})[0]
    const validMedia = ['imageMessage', 'videoMessage', 'audioMessage']

    if (!validMedia.includes(mediaType)) {
      return m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *ما فيهاش ميديا*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    }

    await conn.sendMessage(m.chat, { react: { text: '👁️', key: m.key } })

    const buffer = await downloadMediaMessage(
      { message: quotedMessage },
      'buffer',
      {},
      { logger: undefined, reuploadRequest: conn.updateMediaMessage }
    )

    let caption = quotedMessage[mediaType]?.caption || ''
    let finalCaption =
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🔥 〕 تـم فـضـحـه بـنـجـاح ♣️*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *

${caption? `> *📝┊الـوصـف:* ${caption}\n` : ''}> *🥷🏻┊الـنـوع:* ${mediaType === 'imageMessage'? 'صـورة' : mediaType === 'videoMessage'? 'فـيـديـو' : 'صـوت'}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`

    if (mediaType === 'imageMessage') {
      await conn.sendFile(m.chat, buffer, 'tokita.jpg', finalCaption, m)
    } else if (mediaType === 'videoMessage') {
      await conn.sendFile(m.chat, buffer, 'tokita.mp4', finalCaption, m)
    } else {
      await conn.sendMessage(m.chat, { audio: buffer, mimetype: 'audio/ogg; codecs=opus', ptt: false }, { quoted: m })
      await conn.reply(m.chat, finalCaption, m)
    }

  } catch (err) {
    console.error(err)
    m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *فشل - الرسالة قديمة*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
  }
}

handler.help = ['فضح']
handler.tags = ['ادوات']
handler.command = /^(فضح|افضح|kashf)$/i

export default handler