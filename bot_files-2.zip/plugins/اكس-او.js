// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الـلـعـبـة┊ ˼‏ 🎮˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *𝐆𝐎𝐉𝐎* ──¤﹝لـعـبـة 𝐗-𝐎 الاحـتـرافـيـة ↶﹞*
// > *〔 🎮 〕 الاسـتـخـدام:* xo منشن
// > *〔 💡 〕 الـمـثـال:* xo @الشخص
// *🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
// *🤖┊اسـم الـبـوت:* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*
// *👑┊الـمـطـور:* *𝐘𝐎𝐍𝐎 𝐃𝐄𝐕*
// *📞┊الـرقـم:* *212674375708* *🐣 ───━ •﹝📌﹞• ━───*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

class TicTacToeGame {
    constructor(player1Id, player2Id, player1Name, player2Name) {
        this.board = Array(9).fill(null)
        this.players = { 'X': player1Id, 'O': player2Id }
        this.names = { 'X': player1Name, 'O': player2Name }
        this.currentPlayer = 'X'
        this.gameActive = true
        this.winningConditions = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]
    }

    getBoardString() {
        let b = this.board.map((v,i) => v? (v === 'X'? '❌' : '⭕') : `${i+1}️⃣`)
        let display = `* ━ ╼╃ ⌬〔 🎮 𝐗-𝐎 〕⌬ ╄╾ ━ *\n\n`
        display += ` ${b[0]} ┃ ${b[1]} ┃ ${b[2]}\n`
        display += ` ━━━╋━━━╋━━━\n`
        display += ` ${b[3]} ┃ ${b[4]} ┃ ${b[5]}\n`
        display += ` ━━━╋━━━╋━━━\n`
        display += ` ${b[6]} ┃ ${b[7]} ┃ ${b[8]}\n\n`
        display += `*👑┊الـدور┊* @${this.players[this.currentPlayer].split('@')[0]} [ ${this.currentPlayer} ]\n`
        display += `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
        return display
    }

    checkWin() {
        for (const [a,b,c] of this.winningConditions) {
            if (this.board[a] && this.board[a] === this.board[b] && this.board[a] === this.board[c]) {
                this.gameActive = false
                return this.board[a]
            }
        }
        return null
    }
    checkDraw() {
        if (!this.board.includes(null)) { this.gameActive = false; return true }
        return false
    }

    makeMove(moveIndex, playerId) {
        if (!this.gameActive) return null
        let mark = Object.keys(this.players).find(k => this.players[k] === playerId)
        if (mark!== this.currentPlayer) return `> *〔 ⚠️ 〕انـتـظـر دورك يا @${playerId.split('@')[0]}*`
        let idx = moveIndex - 1
        if (idx < 0 || idx > 8 || this.board[idx]!== null) return `> *〔 ❌ 〕حـركـة خـاطـئـة، اخـتـر رقـم فـارغ 1-9*`
        this.board[idx] = this.currentPlayer

        let win = this.checkWin()
        if (win) {
            let winnerId = this.players[win]
            return `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 🎉 〕مـبـروك الـفـوز!*\n> *〔 👑 〕الـفـائـز:* @${winnerId.split('@')[0]} [ ${win} ]\n\n${this.getBoardString()}`
        }
        if (this.checkDraw()) return `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 🤝 〕تـعـادل! الـلـوحـة امـتـلأت*\n\n${this.getBoardString()}`

        this.currentPlayer = this.currentPlayer === 'X'? 'O' : 'X'
        return this.getBoardString()
    }
}

let activeGames = {}

let handler = async (m, { conn, command, args }) => {
    let chatId = m.chat
    let sender = m.sender

    if (command === 'xo' || command === 'اكس' || command === 'tic') {
        if (activeGames[chatId]) return conn.reply(chatId, `> *〔 ⚠️ 〕يـوجـد لـعـبـة قـائـمـة بـالـفـعـل*\n> اكـتـب *الـلـوحـة* لـعـرضـهـا أو *انـهـاء*`, m)

        let target = m.mentionedJid?.[0] || m.quoted?.sender
        if (!target) return conn.reply(chatId, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 الـلـعـبـة┊ ˼‏ 🎮˹ ↶〕* *𝐆𝐎𝐉𝐎*\n> *〔 📱 〕الاسـتـخـدام:*.xo @الشخص\n> *〔 💡 〕الـمـثـال:*.xo @YONO\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`, m)
        if (target === sender) return m.reply('> *〔 😹 〕ما تقدر تلعب مع نفسك*')

        let game = new TicTacToeGame(sender, target, sender, target)
        activeGames[chatId] = game

        let txt = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 🎮 〕بـدأت لـعـبـة 𝐗-𝐎 الـجـديـدة!*\n\n*❌┊* @${sender.split('@')[0]}\n*⭕┊* @${target.split('@')[0]}\n\n> لـلـعـب أرسـل رقـم الـخـلـيـة 1-9\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *\n\n${game.getBoardString()}`
        return conn.sendMessage(chatId, { text: txt, mentions: [sender, target] }, { quoted: m })
    }

    if (activeGames[chatId]) {
        let game = activeGames[chatId]
        let move = parseInt(m.text?.trim())

        if (m.text?.toLowerCase() === 'اللوحة' || m.text?.toLowerCase() === 'xo board') {
            return conn.sendMessage(chatId, { text: game.getBoardString(), mentions: Object.values(game.players) }, { quoted: m })
        }
        if (m.text?.toLowerCase() === 'انهاء' || m.text?.toLowerCase() === 'انهي') {
            delete activeGames[chatId]
            return m.reply('> *〔 🛑 〕تـم إنـهـاء الـلـعـبـة*')
        }

        if (move >= 1 && move <= 9) {
            if (!Object.values(game.players).includes(sender)) return
            let result = game.makeMove(move, sender)
            if (!game.gameActive) delete activeGames[chatId]
            return conn.sendMessage(chatId, { text: result, mentions: Object.values(game.players) }, { quoted: m })
        }
    }
}

handler.command = /^(xo|اكس|tic|اللوحة|انهاء|انهي)$/i
handler.group = true
export default handler