import fetch from 'node-fetch';

const handler = async (m, { conn, command, text, isAdmin }) => {
  if (!isAdmin) {
    return conn.reply(
      m.chat,
      `* ━ ╼╃ ⌬〔 ❌ 〕⌬ ╄╾ ━ *
> *🥷🏻┊* لـيـس لـديـك صـلاحـيـة
> *🥷🏻┊* فـقـط الـمـشـرفـون يـمـكـنـهـم اسـتـخـدام هـذا الأمـر
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`,
      m
    );
  }

  let user = m.mentionedJid?.[0] || m.quoted?.sender || text;
  if (!user) {
    return conn.reply(
      m.chat,
      command === 'كتم'
      ? `* ━ ╼╃ ⌬〔 🕯️ 〕⌬ ╄╾ ━ *
> *🥷🏻┊* مـنـشـن الـعـضـو
> *🥷🏻┊* قـم بـمـنـشـن الـعـضـو الـذي تـريـد كـتـمـه
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`
        : `* ━ ╼╃ ⌬〔 ✨ 〕⌬ ╄╾ ━ *
> *🥷🏻┊* مـنـشـن الـعـضـو
> *🥷🏻┊* قـم بـمـنـشـن الـعـضـو الـذي تـريـد فـك الـكـتـم عـنـه
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`,
      m
    );
  }

  if (!/@s\.whatsapp\.net$/.test(user)) {
    user = user.replace(/[^\d]/g, '');
    if (user.length > 5) user = `${user}@s.whatsapp.net`;
  }

  if (user === conn.user.jid) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔 🚩 〕⌬ ╄╾ ━ *\n> *🥷🏻┊* لا يـمـكـنـك كـتـم او فـك الـبـوت\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`, m);

  const ownerNumber = '212674375708@s.whatsapp.net';
  if (user === ownerNumber) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔 🚩 〕⌬ ╄╾ ━ *\n> *🥷🏻┊* لا يـمـكـنـك كـتـم الـمـطـور 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`, m);

  const groupMetadata = await conn.groupMetadata(m.chat);
  const groupOwner = groupMetadata.owner || m.chat.split`-`[0] + '@s.whatsapp.net';
  if (user === groupOwner) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔 🚩 〕⌬ ╄╾ ━ *\n> *🥷🏻┊* لا يـمـكـنـك كـتـم صـاحـب الـمـجـمـوعـة\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`, m);

  if (!global.db.data.users[user]) global.db.data.users[user] = {};
  const userData = global.db.data.users[user];

  const fkontak = {
    key: { participants: '0@s.whatsapp.net', fromMe: false, id: 'GOJO_KTM' },
    message: {
      locationMessage: {
        name: command === 'كتم'? '🔒 تـم كـتـم الـعـضـو' : '🔓 تـم فـك الـكـتـم',
        jpegThumbnail: await (await fetch(
          command === 'كتم'
          ? 'https://telegra.ph/file/f8324d9798fa2ed2317bc.png'
            : 'https://telegra.ph/file/aea704d0b242b8c41bf15.png'
        )).buffer(),
        vcard:
          'BEGIN:VCARD\nVERSION:3.0\nN:;GOJO BOT;;;\nFN:GOJO BOT 🥷🏻\nORG:GOJO SYSTEM\nTITLE:الـمـشـرف\nitem1.TEL;waid=212674375708:+212674375708\nitem1.X-ABLabel:GOJO\nX-WA-BIZ-DESCRIPTION:GOJO BOT By YONO\nX-WA-BIZ-NAME:GOJO. 𝐛𝐨𝐭\nEND:VCARD'
      }
    },
    participant: '0@s.whatsapp.net'
  };

  if (command === 'كتم') {
    if (userData.mute === true) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔 🚩 〕⌬ ╄╾ ━ *\n> *🥷🏻┊* هـذا الـعـضـو مـكـتـوم مـن قـبـل\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`, m);
    global.db.data.users[user].mute = true;

    let buttons = [
      {buttonId: '.فك_الكتم @' + user.split('@')[0], buttonText: {displayText: '🔓 فـك الـكـتـم'}, type: 1}
    ]

    return conn.sendMessage(m.chat, {
      text: `* ━ ╼╃ ⌬〔 🔒 〕⌬ ╄╾ ━ *
> *🥷🏻┊* تـم كـتـم الـعـضـو: @${user.split('@')[0]}
> *🥷🏻┊* بـأمـر مـن الـمـشـرف
> *🥷🏻┊* الـمـطـور: 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`,
      mentions: [user],
      footer: '𝐆𝐎𝐉𝐎 𝐁𝐎𝐓',
      buttons: buttons,
      headerType: 1
    }, { quoted: fkontak });
  }

  if (command === 'فك_الكتم') {
    if (userData.mute!== true) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔 🚩 〕⌬ ╄╾ ━ *\n> *🥷🏻┊* هـذا الـعـضـو غـيـر مـكـتـوم\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`, m);
    if (user === m.sender) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔 🚩 〕⌬ ╄╾ ━ *\n> *🥷🏻┊* لا يـمـكـنـك فـك الـكـتـم عـن نـفـسـك\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`, m);

    global.db.data.users[user].mute = false;

    let buttons = [
      {buttonId: '.كتم @' + user.split('@')[0], buttonText: {displayText: '🔒 كـتـم مـرة اخـرى'}, type: 1}
    ]

    return conn.sendMessage(m.chat, {
      text: `* ━ ╼╃ ⌬〔 🔓 〕⌬ ╄╾ ━ *
> *🥷🏻┊* تـم فـك الـكـتـم: @${user.split('@')[0]}
> *🥷🏻┊* بـأمـر مـن الـمـشـرف
> *🥷🏻┊* الـمـطـور: 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`,
      mentions: [user],
      footer: '𝐆𝐎𝐉𝐎 𝐁𝐎𝐓',
      buttons: buttons,
      headerType: 1
    }, { quoted: fkontak });
  }
};

handler.before = async function (m, { conn }) {
  if (!m.isGroup) return;
  const sender = m.sender;
  const userData = global.db.data.users[sender];

  if (userData && userData.mute === true) {
    try {
      await conn.sendMessage(m.chat, { delete: m.key });
      await conn.sendMessage(m.chat, {
        text: `* ━ ╼╃ ⌬〔 🚫 〕⌬ ╄╾ ━ *
> *🥷🏻┊* الـعـضـو مـكـتـوم
> *🥷🏻┊* @${sender.split('@')[0]} مـمـنـوع مـن الـكـلام
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 〕⌬ ╄╾ ━ *`,
        mentions: [sender]
      }).catch(() => {})
    } catch (e) {
      console.error("Error:", e);
    }
  }
};

handler.command = ['كتم', 'فك_الكتم'];
handler.group = true;
handler.admin = true;

export default handler;