// plugins/link.js - ANTI LID FIX BY YONO DEV 212674375708
let handler = async (m, { conn, command }) => {
    if (!m.isGroup) return;

    let isReset = /^(ريست|تجديد|تحديث|revoke|resetlink)$/i.test(command);

    try {
        let code;

        if (isReset) {
            await conn.sendMessage(m.chat, { react: { text: '♻️', key: m.key } });
            try {
                code = await conn.groupRevokeInvite(m.chat);
            } catch (e) {
                console.log('revoke fail try query', e.message);
                const result = await conn.query({
                    tag: 'iq',
                    attrs: { type: 'set', xmlns: 'w:g2', to: m.chat },
                    content: [{ tag: 'invite', attrs: {}, content: [] }]
                });
                code = result?.content?.[0]?.attrs?.code || result?.attrs?.code;
                if (!code) throw e;
            }
        } else {
            await conn.sendMessage(m.chat, { react: { text: '🔗', key: m.key } });
            code = await conn.groupInviteCode(m.chat);
        }

        if (!code) throw new Error('ما رجع كود');

        let link = `https://chat.whatsapp.com/${code}`;
        let meta = await conn.groupMetadata(m.chat).catch(()=>({ subject: 'الجروب' }));

        await conn.sendMessage(m.chat, {
            text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ${isReset ? 'تـم تـجـديـد الـرابـط ♻️' : 'رابـط الـجـروب 🔗'} 〕* *𝐆𝐎𝐉𝐎*\n\n> *📛┊الاسم:* ${meta.subject}\n> *${isReset ? '♻️┊الجديد:' : '🔗┊الرابط:'}*\n> ${link}\n\n${isReset ? '> *⚠️ الرابط القديم انلغى*\n' : ''}> *👑┊𝐘𝐎𝐍𝐎 𝐃𝐄𝐕* - 212674375708\n* ━ ╼╃ ⌬〔 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`
        }, { quoted: m });

    } catch (e) {
        console.error('[LINK]', e);
        if (e.message.includes('403') || e.message.includes('401') || e.message.includes('not-authorized')) {
            return m.reply(`*❌ واتساب يقول البوت مو أدمن*\n> احذف البوت ورجعه أدمن من جديد\n> مرات واتساب يعلق بعد الترقية لـ LID\n*𝐘𝐎𝐍𝐎 𝐃𝐄𝐕*`);
        }
        return m.reply(`*❌ خطأ:* ${e.message}\n*𝐘𝐎𝐍𝐎 𝐃𝐄𝐕*`);
    }
};

handler.command = /^(link|لينك|الرابط|رابط|ريست|تجديد|تحديث|revoke|resetlink)$/i;
handler.group = true;
handler.admin = true; //  <-- هنا التعديل: غا الآدمين يقدر يستخدمو
handler.botAdmin = false;
export default handler;