let handler = async (m) => {
  const reply = ` *هات بوسه 🫦* `.trim();
  await m.conn.sendMessage(m.chat, {
    text: reply,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 999,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363411035938060@newsletter',
        newsletterName: '⚡𝑮𝑬𝑶┊🩸┊𝐂𝐇𝐀𝐍𝐍𝐄𝐋◞',
        serverMessageId: 100
      }
    }
  }, { quoted: m });
};

// كلمات مفتاحية للرد التلقائي
handler.customPrefix = /(بحبك انا اكتر)/i
handler.command = new RegExp;
handler.exp = 0;

export default handler;