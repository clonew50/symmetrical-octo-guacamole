import fs from 'fs'
import path from 'path'

let handler = async (m, { conn }) => {
    if (!m.sender.includes('212674375708')) {
        await conn.sendMessage(m.chat, { text: '❌ خاص بالمطور' }, { quoted: m })
        return
    }

    await conn.sendMessage(m.chat, { text: '*🧹╎ جاري فحص ملفات الجلسة...*' }, { quoted: m })

    let count = 0
    let foundPaths = []
    let deletedFiles = []

    // كل المسارات المحتملة عندك
    const checkDirs = [
        './session',
        './sessions',
        './auth',
        './auth_info',
        './baileys_auth',
        './NikolasSession',
        './database',
        '.'
    ]

    // كل الأنماط لي خاصها تتمسح
    const patterns = ['pre-key-', 'sender-key-', 'session-', 'app-state', 'device-list-']

    try {
        for (let dir of checkDirs) {
            if (!fs.existsSync(dir)) continue
            let stat = fs.statSync(dir)
            if (!stat.isDirectory()) continue

            let files = fs.readdirSync(dir)
            foundPaths.push(`${dir} (${files.length} ملف)`)

            for (let file of files) {
                let shouldDelete = patterns.some(p => file.startsWith(p))

                if (shouldDelete) {
                    let full = path.join(dir, file)
                    try {
                        let s = fs.statSync(full)
                        fs.rmSync(full, { recursive: true, force: true })
                        count++
                        deletedFiles.push(file)
                    } catch {}
                }
            }
        }

        // الى لقى والو، قلب فالمجلدات الفرعية
        if (count === 0) {
            for (let dir of checkDirs) {
                if (!fs.existsSync(dir)) continue
                try {
                    let subFiles = fs.readdirSync(dir, { recursive: true })
                    for (let f of subFiles) {
                        let base = path.basename(f)
                        if (patterns.some(p => base.startsWith(p))) {
                            let full = path.join(dir, f)
                            try { fs.rmSync(full, { recursive: true, force: true }); count++ } catch {}
                        }
                    }
                } catch {}
            }
        }

        if (global.gc) global.gc()

        let msg = count > 0 
        ? `*🗑️╎ تم تنظيف [ ${count} ] ملف*\n\n*📋 الملفات:*\n${deletedFiles.slice(0,15).join('\n')}${deletedFiles.length > 15 ? '\n...' : ''}`
        : `*⚠️ لم يتم العثور على ملفات للحذف*\n\n*📁 فحصت:*\n${foundPaths.join('\n') || 'لا يوجد مجلد جلسة'}\n\n*💡 الحل:* صيفط ليا نتيجة الأمر:\n\`ls -la | head -20\``

        await conn.sendMessage(m.chat, { text: msg }, { quoted: m })

    } catch (e) {
        await conn.sendMessage(m.chat, { text: `❌ خطأ: ${e.message}\n\nفحصت: ${foundPaths.join(', ')}` }, { quoted: m })
    }
}

handler.command = /^(تنظيف|تنضيف|نظف)$/i
handler.rowner = true
export default handler