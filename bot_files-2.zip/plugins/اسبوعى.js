let handler = async (m, { conn }) => {
    try {
        let userId = m.sender
        if (!global.db) global.db = { data: { users: {} } }
        if (!global.db.data) global.db.data = { users: {} }
        if (!global.db.data.users) global.db.data.users = {}
        if (!global.db.data.users[userId]) {
            global.db.data.users[userId] = { money: 0, diamond: 0, lastWeekly: 0, exp: 0, level: 0 }
        }
        let user = global.db.data.users[userId]

        let cooldown = 7 * 24 * 60 * 60 * 1000 // 7 أيام
        let now = Date.now()
        let timeLeft = (user.lastWeekly || 0) + cooldown - now

        if (timeLeft > 0) {
            let days = Math.floor(timeLeft / (1000 * 60 * 60 * 24))
            let hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
            let minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60))

            return conn.sendMessage(m.chat, {
                text: `* ━ ╼╃ ⌬〔⏳〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 الـجـائـزة الاسـبـوعـيـة مـازال وقـتـهـا!*\n\n*〔 ⏰ 〕 الـوقـت الـمـتـبـقـي :*\n*› ${days} يـوم و ${hours} سـاعـة و ${minutes} دقـيـقـة*\n\n*ارجـع بـعـد مـا يـكـمـل الاسـبـوع*\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`
            }, { quoted: m })
        }

        // جوائز اسبوعية كبيرة
        let moneyReward = Math.floor(Math.random() * 10000) + 5000 // 5000 الى 15000
        let diamondReward = Math.floor(Math.random() * 50) + 30 // 30 الى 80
        let expReward = Math.floor(Math.random() * 500) + 300

        user.money = (user.money || 0) + moneyReward
        user.diamond = (user.diamond || 0) + diamondReward
        user.exp = (user.exp || 0) + expReward
        user.lastWeekly = now

        let txt = `
* ━ ╼╃ ⌬〔👑〕⌬ ╄╾ ━ *
*〔 ♛ 〕 الـجـائـزة الاسـبـوعـيـة الـكـبـرى*
* ━ ╼╃ ⌬〔 💎 〕⌬ ╄╾ ━ *

*〔 👋 〕 مـبـروك @${m.sender.split('@')[0]}*
*〔 🎉 〕 كـمـلـت اسـبـوع كـامـل مـعـنـا!*

*〔 💰 〕 الـفـلـوس :* +${moneyReward} 💵
*〔 💎 〕 الالـمـاس :* +${diamondReward} 💠
*〔 🏯 〕 الـخـبـرة :* +${expReward}

*〔 📊 〕 رصـيـدك الان :*
*› 💵 ${user.money} فـلـوس*
*› 💎 ${user.diamond} الـمـاس*

*هـادي جـائـزة الـوفـاء اسـتـاهـلـتـهـا!*
*ارجـع الـسـيـمـانـة الـجـايـة لـجـائـزة اكـبـر*
* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`.trim()

        await conn.sendMessage(m.chat, {
            text: txt,
            mentions: [m.sender]
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 خـطـأ:* ' + e.message + '\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })
    }
}

handler.help = ['اسبوعي']
handler.tags = ['economy']
handler.command = ['اسبوعي', 'اسبوعى', 'weekly']
handler.group = false

export default handler