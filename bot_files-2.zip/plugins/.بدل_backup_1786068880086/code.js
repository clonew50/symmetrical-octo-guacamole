let handler = async (m) => {
  const reply = ` ____________________________ 
*لا يوجد ".code" اكتب ".تنصيب"*
::::::::::::::::::🩸::::::::::::::::::: `.trim();
  await m.conn.sendMessage(m.chat, {
    text: reply,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 999,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363411035938060@newsletter',
        newsletterName: '⚡_KAISER_ 𝑩𝑶𝑻 🪄',
        serverMessageId: 100
      }
    }
  }, { quoted: m });
};

// كلمات مفتاحية للرد التلقائي
handler.customPrefix = /^(|code|.code|code|ا.code|||)$/i;
handler.command = new RegExp;
handler.exp = 0;

export default handler;