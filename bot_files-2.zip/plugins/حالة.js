/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * امر: ستوري / حالة
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━
 * By : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 212674375708
 */

import fs from 'fs'

const handler = async (m, { conn, text }) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''

    if (!mime) {
        return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ خـطـأ┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـتـنـبـيـه ↶ 🕸️﹞*
> *🥷🏻┊* المرجو الرد على 🌠صورة، 🎥فيديو، أو 🎙️مقطع صوتي لرفعه كسطوري

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
    }

    console.log('* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *');
    console.log('       ✨ تنفيذ أمر : ستوري ✨');
    console.log(`       نوع الوسائط: ${mime}`);
    console.log('* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *');

    let buffer = await q.download()
    let caption = text ? `*${text}*` : '*✨ سطوري 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ✨*'

    try {
        if (/image/.test(mime)) {
            await conn.sendMessage(m.chat, { groupStatusMessage: { image: buffer, caption: caption } });
            return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ✅ نـجـاح┊ ˼‏ 🌠˹ ↶〕*

*🪖 ──¤﹝الـسـطـوري ↶ 🕸️﹞*
> *🥷🏻┊* تم رفع الصورة بنجاح كسطوري للمجموعة!

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
        } else if (/video/.test(mime)) {
            await conn.sendMessage(m.chat, { groupStatusMessage: { video: buffer, caption: caption } });
            return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ✅ نـجـاح┊ ˼‏ 🎥˹ ↶〕*

*🪖 ──¤﹝الـسـطـوري ↶ 🕸️﹞*
> *🥷🏻┊* تم رفع الفيديو بنجاح كسطوري للمجموعة!

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
        } else if (/audio/.test(mime)) {
            await conn.sendMessage(m.chat, { groupStatusMessage: { audio: buffer, caption: caption } });
            return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ✅ نـجـاح┊ ˼‏ 🎙️˹ ↶〕*

*🪖 ──¤﹝الـسـطـوري ↶ 🕸️﹞*
> *🥷🏻┊* تم رفع المقطع الصوتي بنجاح كسطوري للمجموعة!

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
        } else {
            return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ مـدعـوم┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـوسـائـط ↶ 🕸️﹞*
> *🥷🏻┊* المدعوم حاليا: 🌠الصور، 🎥الفيديوهات، 🎙️المقاطع الصوتية فقط

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
        }
    } catch (e) {
        console.error(e);
        return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❌ خـطـأ┊ ˼‏ ⚠️˹ ↶〕*

*🪖 ──¤﹝الـخـطـأ ↶ 🕸️﹞*
> *🥷🏻┊* حدث خطأ أثناء رفع السطوري. حاول مرة أخرى

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🔮 〕⌬ ╄╾ ━ *`)
    }
};

handler.help = ['ستوري', 'حالة']
handler.tags = ['👑 المالك']
handler.command = /^(ستوري|حالة|story)$/i
handler.owner = true

export default handler;