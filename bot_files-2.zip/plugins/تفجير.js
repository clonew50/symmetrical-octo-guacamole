// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// ♛ GOJO BOT ♛ | انفجار كوني
// ✧ انميشن تفجير الجروب 🚀🌌
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *

const handler = async (m, { conn, command, text }) => {
  const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
  const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;
  const dev = '212674375708@s.whatsapp.net'; // المطور ما نطردوش

  if (!m.isGroup) return m.reply(`${startDeco}\n> *〔 خـطـأ┊ ˼‏ ❌˹ ↶〕*\n> *هـذا الأمـر للـجـروبـات فـقـط*\n${endDeco}`);

  const groupName = text || m.chat;

  // رسائل الحب الكوني
  const loveMessages = [
    "💥🌟 انفجار كوني من الحب! اذهب واعترف بمشاعرك الآن!",
    "🚀🌠 شرارة مجرية بينكم! تجرأ وحاول!",
    "🪐✨ قد يكون هناك شيء مميز هنا! اعطه فرصة في المجرة!",
    "🌌☕ همم، الحب في الهواء الكوني. ربما قهوة نجمية معا!",
    "🌟 النجوم تلمع بامكانية رومانسية! قم بحركتك المجرية!",
    "📜🚀 قصة حب ملحمية قد تنتظر ان تكتب في النجوم!",
    "⏳🌌 لا تستهين بقوة الوقت والصبر في الحب الكوني. اشياء عظيمة قادمة!",
    "🌍💫 تذكر ان الحب رحلة نجمية، وكل خطوة قيمة مهما كانت المسافة!",
    "🌠💞 الروابط الكونية القوية يمكن ان تصبح علاقات مجرية جميلة!",
    "💫🔮 الحب الحقيقي يحتاج وقت وجهد نجمي. لا تستسلم ابدا!",
  ];

  const notSoHighLoveMessages = [
    "🌌🚀 احيانا الصداقة هي بداية شيء نجمي، لكنها لا تتحول دائما لحب كوني.",
    "🌟👫 الحب ليس كل شيء، الصداقة النجمية رائعة ايضا! حافظوا على رابطكم.",
    "✨💬 تذكر ان افضل العلاقات تبدأ بصداقة كونية. لا تستهينوا برابطكم!",
    "⏳🛸 احيانا الحب ينمو مع الوقت النجمي. استمروا في تقوية رابطكم!",
    "🌠🌟 الحياة مفاجأة مجرية. من يدري ماذا يخبئ المستقبل! لا تفقدوا الامل.",
    "💫 حتى لو لم يزهر الحب كما توقعتم، رابطكم الكوني لا يزال قيما.",
    "🪐🔭 القلوب قد تتأخر في التزامن، لكن هذا لا يقلل من خصوصيتكم في المجرة.",
    "🌌🎉 رغم تحديات الحب الكوني، صداقتكم النجمية هدية تستحق الاحتفال.",
    "✨🌠 الوقت قد يكشف اشياء مدهشة. لنستمر في الاستكشاف معا في الكون!",
    "🪐🌌 الحياة مليئة بالمنعطفات غير المتوقعة. ابقوا منفتحين للاحتمالات!",
  ];

  const getRandomMessage = (messages) => messages[Math.floor(Math.random() * messages.length)];
  const lovePercentage = Math.floor(Math.random() * 100);
  const isHighLove = lovePercentage >= 50;
  const loveMessage = isHighLove? getRandomMessage(loveMessages) : getRandomMessage(notSoHighLoveMessages);

  const getRandomAge = () => Math.floor(Math.random() * 100) + 1;
  const getRandomWeight = () => (Math.random() * 100).toFixed(2);

  const response =
`${startDeco}
> *〔 انـفـجـار كـونـي┊ ˼‏ 🚀🌌˹ ↶〕* *⚔️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝مـعـلـومـات الـجـروب الـمـسـتـهـدف ↶﹞*
> *〔 📛 〕 الاسـم:* ${groupName}
> *〔 📍 〕 الـمـوقـع:* واتساب الكون
> *〔 👴 〕 الـعـمـر:* ${getRandomAge()} مليار سنة ضوئية
> *〔 ⚖️ 〕 الـوزن:* ${getRandomWeight()} كتلة كونية
> *〔 🔐 〕 الـرمـز الـسـري:* اعضاء الاجرام السماوية
> *〔 🌐 〕 IPV6:* 7e4:8fe3:1265:ff9f:42b:سعادة:مضحك:وقت%42
> *〔 📡 〕 UPNP:* متاح في جميع الابعاد الكونية
> *〔 🛡️ 〕 DMZ:* 42.42.42.42
> *〔 📟 〕 MAC:* 42:42:42:42:42:42
> *〔 🏢 〕 مـزود الـخـدمـة:* شركة المجرات GOJO
> *〔 🌍 〕 DNS:* 42.42.42.42
> *〔 🌍 〕 DNS الـبـديـل:* 42.42.42.1
> *〔 🚀 〕 WAN:* 42.42.42.42
> *〔 ⚡ 〕 نـوع WAN:* محرك الانطلاق الكوني
> *〔 🚪 〕 الـبـوابـة:* 42.0.0.1
> *〔 🎭 〕 رسـالـة الـحـب:* ${loveMessage}

*🧣 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
*👁️┊اسـم الـبـوت:* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*
*🐣 ───━ •﹝📌﹞• ━───*
${endDeco}`;

  async function loading() {
    var hawemod = [
      "🌼 تم تفعيل المحرك الكوني...",
      "🌚 جاري اختراق جدار الحماية الكوني...",
      "🫡 تم استثناء المطور 212674375708 من الاستهداف",
      "🫵🏻 جاري تغيير اسم الجروب الى: GOJO EXPLOSION",
      "🗣 تم تغيير وصف الجروب بنجاح",
      "🌌 جاري بدء عملية المسح العشوائي...",
      "👁️ تم رصد هدف: @ حان دورك",
      "💥 تمت عملية الطرد الوهمي بنجاح",
      "🚀 جاري الاستمرار في المسح الكوني...",
      "✨ اكتملت عملية الانفجار الكوني!"
    ];

    // الخطوة 1: تغيير اسم الجروب
    try { await conn.groupUpdateSubject(m.chat, '♛ GOJO EXPLOSION ♛'); } catch {}

    // الخطوة 2: تغيير وصف الجروب
    try { await conn.groupUpdateDescription(m.chat, `* ━ ╼╃ ⌬〔 تم التفجير بواسطة GOJO BOT 〕⌬ ╄╾ ━ *`); } catch {}

    let { key } = await conn.sendMessage(m.chat, { text: `_*🚀🌌 بدء التفجير الكوني للجروب 🌠*_`, mentions: conn.parseMention(response) }, { quoted: m });

    for (let i = 0; i < hawemod.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 1200));
      await conn.sendMessage(m.chat, { text: hawemod[i], edit: key, mentions: conn.parseMention(response) }, { quoted: m });
    }

    await conn.sendMessage(m.chat, { text: response, edit: key, mentions: conn.parseMention(response) }, { quoted: m });

    await new Promise(resolve => setTimeout(resolve, 2000));

    const additionalMessage = `${startDeco}
> *〔 انـتـهـى الـتـفـجـيـر┊ ˼‏ ✅˹ ↶〕* *⚔️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝تـم الاسـتـهـداف بـنـجـاح ↶﹞*
> *〔 📊 〕 الـنـتـيـجـة:* تم استهداف 42 عضو وهمي
> *〔 👁️ 〕 الـمـطـور:* محمي من الطرد

*🧣 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
*👁️┊اسـم الـبـوت:* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*
*🐣 ───━ •﹝📌﹞• ━───*
${endDeco}`;
    await conn.sendMessage(m.chat, { text: additionalMessage }, { quoted: m });
  }

  await loading();
};

handler.help = ['انفجار-كوني <اسم>'];
handler.tags = ['♛ gojo ♛'];
handler.command = /^(اخترق|اختراق-كوني|تفجير|مرح-كوني)$/i;
handler.group = true;
handler.admin = true;

export default handler;