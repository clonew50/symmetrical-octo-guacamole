// ╮••─๋︩︪──๋︩︪─═⊐‹⧫›⊏═─๋︩︪──๋︩︪─┈☇
// ☃️ Plugin : صــيــد الــســمــك الاحــتــرافــي
// ⚡ Bot : 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🪖🔮
// ╮••─๋︩︪──๋︩︪─═⊐‹⧫›⊏═─๋︩︪──๋︩︪─┈☇

let handler = async (m, { conn, command, usedPrefix, args }) => {
    const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
    const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;

    // فحص الاقتصاد
    if (!global.db.data.chats[m.chat].economy && m.isGroup) {
        return m.reply(`${startDeco}\n> *〔 ⚠️┊ ˼‏ 〕 اوامر *الاقـتـصـاد* مـعـطـلـة فـي هـذه الـمـجـمـوعـة*\n\n*للتفعيل:* ${usedPrefix}اقتصاد تشغيل\n${endDeco}`, m)
    }

    // تهيئة بيانات اليوزر
    let user = global.db.data.users[m.sender]
    if (!user) global.db.data.users[m.sender] = user = {
        coin: 0, exp: 0, level: 1, lastFish: 0,
        rod: 'عادية', fishCaught: 0, treasures: 0,
        totalCoins: 0, bestCatch: 'لا شيء'
    }

    const rods = {
        'عادية': { price: 0, cooldown: 12 * 60 * 1000, win: [8000, 15000], exp: [30, 60], chance: 0.6, emoji: '🎣' },
        'متطورة': { price: 100000, cooldown: 8 * 60 * 1000, win: [20000, 40000], exp: [60, 100], chance: 0.75, emoji: '🎣✨' },
        'اسطورية': { price: 500000, cooldown: 4 * 60 * 1000, win: [50000, 100000], exp: [100, 200], chance: 0.9, emoji: '🎣👑' },
        'التنين': { price: 2000000, cooldown: 2 * 60 * 1000, win: [100000, 300000], exp: [200, 400], chance: 0.98, emoji: '🐉🎣' }
    }

    const currentRod = rods[user.rod] || rods['عادية']

    // اوامر فرعية
    if (args[0] === 'معلومات' || args[0] === 'info') {
        const nextLevelFish = 10 - (user.fishCaught % 10)
        const nextLevelExp = user.level * 10
        return conn.reply(m.chat, `${startDeco}
*〔 👤┊ مــلــف الــصــيــاد 〕*

*الاسم:* @${m.sender.split('@')[0]}
*المستوى:* ${user.level} ⭐
*الخبرة:* ${user.exp}/${nextLevelExp}

*الصنارة:* ${currentRod.emoji} ${user.rod}
*عدد الاصطيادات:* ${user.fishCaught} 🐟
*افضل صيدة:* ${user.bestCatch}
*الكنوز:* ${user.treasures} 📦

*الكوين:* ${user.coin.toLocaleString()} 💰
*اجمالي الربح:* ${user.totalCoins.toLocaleString()} 💎

*التقدم للمستوى القادم:* ${10 - nextLevelFish}/10
${endDeco}`, m, { mentions: [m.sender] })
    }

    if (args[0] === 'متجر' || args[0] === 'shop') {
        let shopText = `${startDeco}\n*〔 🛒┊ مــتــجــر الــصــنــارات 〕*\n\n`
        for(let rod in rods) {
            shopText += `*${rods[rod].emoji} ${rod}*\n`
            shopText += `*السعر:* ${rods[rod].price.toLocaleString()} كوين\n`
            shopText += `*السرعة:* ${rods[rod].cooldown/60000} دقيقة\n`
            shopText += `*فرصة الربح:* ${rods[rod].chance*100}%\n\n`
        }
        shopText += `*للشراء:* ${usedPrefix}صيد_السمك شراء <الاسم>\n${endDeco}`
        return conn.reply(m.chat, shopText, m)
    }

    if (args[0] === 'شراء') {
        const rodName = args[1]
        if (!rods[rodName]) return m.reply(`${startDeco}\n> *〔 ❌┊ ˼‏ 〕 الصنارة غير موجودة*\n${endDeco}`, m)
        if (user.rod === rodName) return m.reply(`${startDeco}\n> *〔 ❌┊ ˼‏ 〕 انت تملك هذه الصنارة بالفعل*\n${endDeco}`, m)
        if (user.coin < rods[rodName].price) return m.reply(`${startDeco}\n> *〔 ❌┊ ˼‏ 〕 ليس لديك كوين كافي. تحتاج ${rods[rodName].price.toLocaleString()}*\n${endDeco}`, m)

        user.coin -= rods[rodName].price
        user.rod = rodName
        return conn.reply(m.chat, `${startDeco}\n> *〔 ✅┊ ˼‏ 〕 تم شراء صنارة ${rodName} بنجاح!*\n${endDeco}`, m)
    }

    const now = Date.now()
    if (now < user.lastFish) {
        const remaining = user.lastFish - now
        const wait = formatTimeMs(remaining)
        return conn.reply(m.chat, `${startDeco}\n> *〔 ⏳┊ ˼‏ 〕 يـجـب ان تـنـتـظـر *${wait}* قـبـل الـصـيـد مـرة اخـرى*\n\n*الصنارة:* ${currentRod.emoji} ${user.rod}\n${endDeco}`, m)
    }

    await m.react('🎣')
    user.lastFish = now + currentRod.cooldown
    user.fishCaught += 1

    // رفع المستوى
    if (user.exp >= user.level * 10) {
        user.level += 1
        user.exp = 0
        const bonus = user.level * 10000
        user.coin += bonus
        conn.reply(m.chat, `${startDeco}\n> *〔 ⭐┊ ˼‏ 〕 تـرقـيـت لـلـمـسـتـوى ${user.level}!*\n> *مـكـافـأة:* +${bonus.toLocaleString()} كوين\n${endDeco}`, m)
    }

    // اختيار الحدث
    const isWin = Math.random() < currentRod.chance
    const eventList = isWin? events.win : events.lose
    const event = pickRandom(eventList)

    let coins, exp

    if (isWin) {
        coins = Math.floor(Math.random() * (currentRod.win[1] - currentRod.win[0])) + currentRod.win[0]
        exp = Math.floor(Math.random() * (currentRod.exp[1] - currentRod.exp[0])) + currentRod.exp[0]

        // فرصة صندوق كنز 8%
        if (Math.random() < 0.08) {
            const treasure = Math.floor(Math.random() * 200000) + 100000
            coins += treasure
            user.treasures += 1
            event.message = `📦 *كـنـز اسـطـوري!* ${event.message}\n*+${treasure.toLocaleString()}* كوين`
        }

        // افضل صيدة
        if (coins > parseInt(user.bestCatch.replace(/,/g, '')) || user.bestCatch === 'لا شيء') {
            user.bestCatch = coins.toLocaleString()
        }

        user.coin += coins
        user.exp += exp
        user.totalCoins += coins
    } else {
        coins = Math.floor(Math.random() * 4000) + 3000
        exp = Math.floor(Math.random() * 15) + 5
        user.coin -= coins
        user.exp -= exp
        if (user.exp < 0) user.exp = 0
        if (user.coin < 0) user.coin = 0
    }

    const levelProgress = (user.fishCaught % 10) * 10

    const result = `${startDeco}
*〔 🎣┊ صــيــد الــســمــك 〕*

┌──⊷ *الــنــتــيــجــة* ⊶──
│ ${event.message}
└───────────────

💰 *الــعــمــلات:* ${isWin? `+${coins.toLocaleString()}` : `-${coins.toLocaleString()}`}
⭐ *الــخــبــرة:* ${isWin? `+${exp}` : `-${exp}`}

┌──⊷ *احــصــائــيــاتــك* ⊶──
│ 👤 *الـمـسـتـوى:* ${user.level}
│ ${currentRod.emoji} *الـصـنـارة:* ${user.rod}
│ 🐟 *اصـطـدت:* ${user.fishCaught}
│ 📦 *الـكـنـوز:* ${user.treasures}
│ 👑 *افـضـل صـيـدة:* ${user.bestCatch}
│ 📈 *الـتـقـدم:* ${levelProgress}%
└───────────────

*اوامر:* ${usedPrefix}صيد معلومات | متجر | شراء
${endDeco}`

    await conn.reply(m.chat, result, m)
    await global.db.write()
    await m.react(isWin? '✅' : '❌')
}

handler.tags = ['𝐆𝐎𝐉𝐎 𝐄𝐂𝐎𝐍𝐎𝐌𝐘']
handler.help = ['صيد_السمك', 'صيد معلومات', 'صيد متجر', 'صيد شراء'];
handler.command = ['صيد_السمك', 'pescar', 'fish', 'صيد'];
handler.group = true;
handler.register = true;

export default handler

function formatTimeMs(ms) {
    const totalSec = Math.ceil(ms / 1000)
    const min = Math.floor(totalSec / 60)
    const sec = totalSec % 60
    return min? `${min} دقيقة ${sec} ثانية` : `${sec} ثانية`
}

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

const events = {
    win: [
        { message: '🐟 لــقــد صــدت ســلــمــوناً! طــعــمــه شــهــي جــداً.' },
        { message: '🐠 لــقــد صــدت تــروتــة! نــضــارتهــا مــذهــلــة.' },
        { message: '🦈 لــقــد امســكــت بــقــرش! كــان قــتــالاً شــديــداً.' },
        { message: '🐋 رائــع! لــقــد صــدت حــوتــاً. كــانــت تــجــربــة فــريــدة.' },
        { message: '🐉 لــقــد حــصــلــت عــلــى ســمــكــة تــنــيــن! مــخــلــوق اســطــوري.' },
        { message: '👑 لــقــد صــدت ســمــكــة الــمــلــك! تــاجـهـا يـلـمـع.' },
        { message: '💎 لــقــد صــدت ســمــكــة مــاســيــة! نــادرة جــداً.' }
    ],
    lose: [
        { message: '🗑️ اخرجــت قــمــامــة: كــيــس بــلاستــيــك.' },
        { message: '🥫 اخرجــت قــمــامــة: عــلــبــة قــديــمــة.' },
        { message: '🌊 لــم تــصــد شــيــئاً هــذه الــمــرة. كــانــت الــمــيــاه هــادئــة.' },
        { message: '🎣 تــمــزقــت بــكــرة الــصــنــار عــنــد الإمــســاك بــشــيء ضــخــم.' },
        { message: '⛈️ عـاصـفـة! اضـطـرت للـعـودة بـدون صـيـد.' }
    ]
}