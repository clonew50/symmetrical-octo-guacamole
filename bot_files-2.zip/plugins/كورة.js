/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: لعبة تخمين اللاعب
 * 📢 القناة: https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

import pkg from '@whiskeysockets/baileys';
const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = pkg;

const PLAYERS = [
  { name: 'اوزيل', img: 'https://files.catbox.moe/gb8lop.jpg', hair: 'black', skin: 'white' },
  { name: 'فينيسيوس جونير', img: 'https://files.catbox.moe/i66qsk.jpg', hair: 'black', skin: 'black' },
  { name: 'بيكيه', img: 'https://files.catbox.moe/l15sni.jpg', hair: 'black', skin: 'white' },
  { name: 'تشافي سيمونز', img: 'https://files.catbox.moe/c7dw1j.jpg', hair: 'black', skin: 'white' },
  { name: 'ماريو غوتزة', img: 'https://files.catbox.moe/s2vepi.jpg', hair: 'brown', skin: 'white' },
  { name: 'لامبارد', img: 'https://files.catbox.moe/qofy0n.jpg', hair: 'blonde', skin: 'white' },
  { name: 'فان بيرسي', img: 'https://files.catbox.moe/kfpibc.jpg', hair: 'black', skin: 'white' },
  { name: 'جواو فيليكس', img: 'https://files.catbox.moe/y3xmao.jpg', hair: 'brown', skin: 'white' },
  { name: 'كيفين دي بروين', img: 'https://files.catbox.moe/mdwuqq.jpg', hair: 'blonde', skin: 'white' },
  { name: 'روديريغو', img: 'https://files.catbox.moe/oz22fg.jpg', hair: 'black', skin: 'black' },
  { name: 'تشافي', img: 'https://files.catbox.moe/shv659.jpg', hair: 'black', skin: 'white' },
  { name: 'باو كوبارسي', img: 'https://files.catbox.moe/jh9ira.jpg', hair: 'brown', skin: 'white' },
  { name: 'خوان غارسيا', img: 'https://files.catbox.moe/f2d1v6.jpg', hair: 'black', skin: 'white' },
  { name: 'اندري شيفشينكو', img: 'https://files.catbox.moe/nox9vm.jpg', hair: 'blonde', skin: 'white' },
  { name: 'مانويل نوير', img: 'https://files.catbox.moe/2bdmub.jpg', hair: 'blonde', skin: 'white' },
  { name: 'دوكو', img: 'https://files.catbox.moe/3dbl5g.jpg', hair: 'black', skin: 'black' },
  { name: 'تشواميني', img: 'https://files.catbox.moe/xv8awj.jpg', hair: 'black', skin: 'black' },
  { name: 'جمال موسيالا', img: 'https://files.catbox.moe/3eyslg.jpg', hair: 'black', skin: 'black' },
  { name: 'ابراهيم دياز', img: 'https://files.catbox.moe/re519z.jpg', hair: 'black', skin: 'black' },
  { name: 'ايكر كاسياس', img: 'https://files.catbox.moe/sqcad0.jpg', hair: 'black', skin: 'white' },
  { name: 'ماركو رويس', img: 'https://files.catbox.moe/39iyyk.jpg', hair: 'black', skin: 'white' },
  { name: 'دي روسي', img: 'https://files.catbox.moe/tfjp0h.jpg', hair: 'black', skin: 'white' },
  { name: 'توتي', img: 'https://files.catbox.moe/bp1yx8.jpg', hair: 'black', skin: 'white' },
  { name: 'فالفيردي', img: 'https://files.catbox.moe/vs3aiu.jpg', hair: 'brown', skin: 'white' },
  { name: 'مارك كوكوريا', img: 'https://files.catbox.moe/2ovzxj.jpg', hair: 'black', skin: 'white' },
  { name: 'تيري هنري', img: 'https://files.catbox.moe/l45moz.jpg', hair: 'black', skin: 'black' },
  { name: 'جابريل باتيستوتا', img: 'https://files.catbox.moe/5c51ak.jpg', hair: 'brown', skin: 'white' },
  { name: 'مايكل اوليسي', img: 'https://files.catbox.moe/o5mhd9.jpg', hair: 'black', skin: 'black' },
  { name: 'اوين', img: 'https://files.catbox.moe/fk9ym6.jpg', hair: 'brown', skin: 'white' },
  { name: 'بيكهام', img: 'https://files.catbox.moe/i9zt1b.jpg', hair: 'brown', skin: 'white' },
  { name: 'سواريز', img: 'https://files.catbox.moe/lavcya.jpg', hair: 'brown', skin: 'white' },
  { name: 'ساديو ماني', img: 'https://files.catbox.moe/qstavl.jpg', hair: 'black', skin: 'black' },
  { name: 'إيفان راكيتيتش', img: 'https://files.catbox.moe/6gt9cf.jpg', hair: 'black', skin: 'white' },
  { name: 'تيفيز', img: 'https://files.catbox.moe/uclgnb.jpg', hair: 'black', skin: 'white' },
  { name: 'بوسكيتس', img: 'https://files.catbox.moe/qa4bjg.jpg', hair: 'brown', skin: 'white' },
  { name: 'مارادونا', img: 'https://files.catbox.moe/hauprc.jpg', hair: 'black', skin: 'white' },
  { name: 'كارفخال', img: 'https://files.catbox.moe/c3nlez.jpg', hair: 'black', skin: 'white' },
  { name: 'روبينهو', img: 'https://files.catbox.moe/1ndziq.jpg', hair: 'black', skin: 'black' },
  { name: 'بالوتيلي', img: 'https://files.catbox.moe/gyfjr4.jpg', hair: 'black', skin: 'black' },
  { name: 'ماك اليستر', img: 'https://files.catbox.moe/g8og2s.jpg', hair: 'brown', skin: 'white' }
];

const shuffle = a => { let b=[...a]; for(let i=b.length-1;i>0;i--){ let j=Math.floor(Math.random()*(i+1)); [b[i],b[j]]=[b[j],b[i]] } return b }
const getChoices = (correct, all) => {
  let similar = all.filter(p=>p.name!==correct.name && p.hair===correct.hair && p.skin===correct.skin)
  let wrong = similar.length>=3? shuffle(similar).slice(0,3) : [...similar,...shuffle(all.filter(p=>p.name!==correct.name &&!similar.find(s=>s.name===p.name)))].slice(0,3-similar.length)
  return shuffle([correct,...wrong.slice(0,3)])
}

if (!global._tokitaGames) global._tokitaGames = {};

let handler = async (m, { conn, usedPrefix }) => {
  const gameKey = `${m.chat}_${m.sender}`
  if (global._tokitaGames[gameKey]) return m.reply(`* ━ ╼╃ ⌬〔⚠️〕⌬ ╄╾ ━ *\n> *عـنـدك لـعـبـة شـغـالـة جـاوب عـلـيـهـا أولا*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)

  const correct = PLAYERS[Math.floor(Math.random()*PLAYERS.length)]
  const choices = getChoices(correct, PLAYERS)

  try {
    await m.react('⚽')
    const res = await fetch(correct.img)
    if(!res.ok) throw new Error('img fail')
    const buf = Buffer.from(await res.arrayBuffer())
    const media = await prepareWAMessageMedia({ image: buf }, { upload: conn.waUploadToServer })

    const buttons = choices.map((p,i)=>({
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text: `${['1️⃣','2️⃣','3️⃣','4️⃣'][i]} ${p.name}`, id: `tokita_ans_${i}_${p.name}` })
    }))

    const txt =
`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ⚽ 〕 لـعـبـة تـخـمـيـن الـلاعـب ♛*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *

> *👤 الـلاعـب:* *@${m.sender.split('@')[0]}*
> *⏱️ الـوقـت:* 60 ثـانـيـة
> *💰 الـجـائـزة:* 5000 XP
> *🎯 اخـتـر الإجـابـة مـن الأسـفـل*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`

    let msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata:{}, deviceListMetadataVersion:2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({ text: txt }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: "♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | خمن اللاعب" }),
            header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment:true,...media }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })
          })
        }
      }
    }, { userJid: conn.user.id })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

    global._tokitaGames[gameKey] = {
      answer: correct.name,
      choices: choices.map(c=>c.name),
      starter: m.sender,
      chatId: m.chat,
      timeout: setTimeout(async()=>{
        if(global._tokitaGames[gameKey]){
          await conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔⏰〕⌬ ╄╾ ━ *\n> *انـتـهـى الـوقـت @${m.sender.split('@')[0]}*\n> *✅ الإجـابـة:* *${correct.name}*\n> *🎯 اكـتـب ${usedPrefix}كورة لـلـعـب مـرة أخـرى*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, mentions:[m.sender] })
          delete global._tokitaGames[gameKey]
        }
      }, 60000)
    }

  } catch(e){
    console.error(e)
    m.reply(`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *فـشـل تـحـمـيـل صـورة ${correct.name}*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
  }
}

handler.before = async function(m, { conn }){
  if(!m.message) return
  // يقرا id الزر من 3 أماكن مختلفة باش يضمن يشتغل
  let id = m.message?.buttonsResponseMessage?.selectedButtonId
        || m.message?.templateButtonReplyMessage?.selectedId
        || m.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson && JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id
        || m.text || ""

  if(!id.startsWith('tokita_ans_')) {
    // دعم الرد برقم 1-4
    if(!/^[1-4]$/.test(m.text?.trim())) return false
  }

  let activeKey = null, game = null
  for(let k in global._tokitaGames){
    let g = global._tokitaGames[k]
    if(g.starter===m.sender && g.chatId===m.chat){ activeKey=k; game=g; break }
  }
  if(!game) return false

  let userAnswer = ""
  if(id.startsWith('tokita_ans_')){
    let parts = id.split('_'); parts.splice(0,3); userAnswer = parts.join('_').toLowerCase().trim()
  } else if(/^[1-4]$/.test(m.text?.trim())){
    let n = parseInt(m.text.trim())-1
    userAnswer = (game.choices[n]||"").toLowerCase()
  }
  if(!userAnswer) return false

  const isCorrect = userAnswer === game.answer.toLowerCase()
  clearTimeout(game.timeout)

  if(!isCorrect){
    await conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n> *إجـابـة غـلـط يـا @${m.sender.split('@')[0]} 😢*\n> *✅ الـصـح:* *${game.answer}*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, mentions:[m.sender] })
    delete global._tokitaGames[activeKey]; return true
  }

  if(!global.db?.data?.users?.[m.sender]) global.db.data.users[m.sender]={exp:0}
  global.db.data.users[m.sender].exp += 5000

  await conn.sendMessage(m.chat, { text: `* ━ ╼╃ ⌬〔✅〕⌬ ╄╾ ━ *\n> *إجـابـة صـحـيـحـة @${m.sender.split('@')[0]} 🎉*\n> *🏆 الـلاعـب:* *${game.answer}*\n> *💰 ربـحـت:* *5000 XP*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, mentions:[m.sender] })
  delete global._tokitaGames[activeKey]; return true
}

handler.help = ['كورة']
handler.tags = ['العاب']
handler.command = /^(كورة|تخمين|لاعب|football)$/i
export default handler