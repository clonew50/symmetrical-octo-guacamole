import fs from 'fs';
import path from 'path';

const h = async (m, { text, conn, bot }) => {
    const chat = m.chat;

    try {
        if (!text || !text.includes('|')) {
            return await m.reply(`❌ الصيغة: \`.بدلو القديم|الجديد\``);
        }

        const [oldText, newText] = text.split('|').map(s => s.trim());
        const pluginsDir = path.resolve(process.cwd(), 'plugins');
        
        if (!fs.existsSync(pluginsDir)) {
            return await m.reply(`❌ المجلد غير موجود في: ${pluginsDir}`);
        }

        let changedFiles = [];

        const getAllFiles = (dirPath, arrayOfFiles) => {
            const files = fs.readdirSync(dirPath);
            arrayOfFiles = arrayOfFiles || [];
            files.forEach((file) => {
                if (fs.statSync(dirPath + "/" + file).isDirectory()) {
                    arrayOfFiles = getAllFiles(dirPath + "/" + file, arrayOfFiles);
                } else if (file.endsWith('.js')) {
                    arrayOfFiles.push(path.join(dirPath, "/", file));
                }
            });
            return arrayOfFiles;
        };

        const allFiles = getAllFiles(pluginsDir);

        for (let filePath of allFiles) {
            let content = fs.readFileSync(filePath, 'utf8');
            if (content.includes(oldText)) {
                let updatedContent = content.split(oldText).join(newText);
                fs.writeFileSync(filePath, updatedContent, 'utf8');
                changedFiles.push(path.basename(filePath));
            }
        }

        if (changedFiles.length === 0) {
            await m.reply(`ℹ️ لم يجد الكلمة في ${allFiles.length} ملف.\nالكلمة: ${oldText}`);
        } else {
            const successText = `✅ *تم التبديل بنجاح يا 𝑩𝑳𝑶𝑫!*\n\n• تم تبديل: ${oldText}\n• إلى: ${newText}\n• في عدد ملفات: ${changedFiles.length}`;
            await conn.sendMessage(chat, { text: successText }, { quoted: m });
        }

    } catch (err) {
        await m.reply('❌ حدث خطأ فني: ' + err.message);
    }
}

h.usage = ["بدلو"]
h.category = "owner";
h.command = ['بدلو']
h.owner = true; // جعلته للمطور فقط للأمان

export default h;
