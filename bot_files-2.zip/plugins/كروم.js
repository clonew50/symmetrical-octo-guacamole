/* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
 * 👤 المطور: YONO
 * 🤖 البوت: ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ♛
 * 📦 الوظيفة: جلب ملف من رابط
 * 📢 القناة: https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
 * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━
 */

import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) return m.reply(
`* ━ ╼╃ ⌬〔⚠️〕⌬ ╄╾ ━ *
> *اسـتـخـدام: ${usedPrefix + command} + الـرابـط*
> *مـثـال: ${usedPrefix + command} https://example.com/file.json*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
)

const url = text.trim()
if (!/^https?:\/\//i.test(url)) return m.reply(`> *❌ الـرابـط غـيـر صـالـح*`)

try {
await m.react('⏳')
const response = await fetch(url)
if (!response.ok) throw new Error(`HTTP ${response.status}`)

const contentType = response.headers.get('content-type') || ''
const fileName = decodeURIComponent(url.split('/').pop().split('?')[0]) || 'file'

if (contentType.includes('application/json')) {
  const json = await response.json()
  let txt = JSON.stringify(json, null, 2)
  if (txt.length > 4000) txt = txt.slice(0, 4000) + '\n... [تم اقتطاع الباقي]'
  return m.reply(
`* ━ ╼╃ ⌬〔📄〕⌬ ╄╾ ━ *
> *نـوع الـمـلـف: JSON*
> *الـرابـط: ${url}*

\`\`\`json
${txt}
\`\`\`
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
)

} else if (contentType.includes('text/') || contentType.includes('javascript') || contentType.includes('application/xml')) {
  let content = await response.text()
  if (content.length > 4000) content = content.slice(0, 4000) + '\n... [تم اقتطاع الباقي]'
  return m.reply(
`* ━ ╼╃ ⌬〔📃〕⌬ ╄╾ ━ *
> *نـوع الـمـلـف: TEXT*

${content}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
)

} else {
  const buffer = Buffer.from(await response.arrayBuffer())
  await conn.sendMessage(m.chat, {
    document: buffer,
    fileName: fileName,
    mimetype: contentType || 'application/octet-stream',
    caption: 
`* ━ ╼╃ ⌬〔📦〕⌬ ╄╾ ━ *
> *تـم الـتـنـزيـل بـنـجـاح ♛*
> *📁 الاسـم:* ${fileName}
> *📏 الـحـجـم:* ${(buffer.length / 1024).toFixed(2)} KB
> *🔗 الـنـوع:* ${contentType}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
  }, { quoted: m })
  await m.react('✅')
}

} catch (error) {
  console.error(error)
  m.reply(
`* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *
> *خـطـأ فـي الـجـلـب*
> *الـسـبـب:* ${error.message}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`
  )
  await m.react('❌')
}
}

handler.help = ['جلب']
handler.tags = ['أدوات']
handler.command = /^(كروم|جلب|fetch|get)$/i

export default handler