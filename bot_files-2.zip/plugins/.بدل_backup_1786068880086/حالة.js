import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'

const COLORS = [
    0xFFF44336, 0xFFE91E63, 0xFF9C27B0, 0xFF673AB7, 0xFF3F51B5,
    0xFF2196F3, 0xFF03A9F4, 0xFF00BCD4, 0xFF009688, 0xFF4CAF50,
    0xFF8BC34A, 0xFFCDDC39, 0xFFFFEB3B, 0xFFFFC107, 0xFFFF9800, 0xFFFF5722
]

let handler = async (m, { conn, text }) => {

    let q = m.quoted
    let mime = q ? ((q.msg || q).mimetype || '') : ''
    let isImage = mime.includes('image')
    let isVideo = mime.includes('video')
    let isAudio = mime.includes('audio')
    let isVoice = mime.includes('audio/ogg') || q?.msg?.audioMessage?.ptt

    let audienceType = 1
    let listEmoji = '⚡'
    let listName = '◜⏤͟͟͞͞ ◜⏤͟͟͞͞ ⚡_KAISER_ ⚡ 𝑩𝑶𝑻 ˖࣪⃟🩸◞•'
    let postText = ''
    let colorIndex = -1
    let remainingText = text ? text.trim() : ''

    if (remainingText) {
        let parts = remainingText.split(' ')
        let firstWord = parts[0]?.toLowerCase()

        if (firstWord === 'عام') {
            audienceType = 0
            listEmoji = ''
            listName = ''
            remainingText = parts.slice(1).join(' ')
        } else if (firstWord === 'خاص' || firstWord === 'اقارب' || firstWord === 'اصدقاء') {
            audienceType = 2
            listEmoji = '⭐'
            listName = 'الأقارب'
            remainingText = parts.slice(1).join(' ')
        } else if (firstWord === 'قائمة' && parts.length >= 3) {
            audienceType = 1
            listEmoji = parts[1]
            listName = parts[2]
            remainingText = parts.slice(3).join(' ')
        }

        if (remainingText) {
            let colorParts = remainingText.split(' ')
            let potentialColor = parseInt(colorParts[0])
            if (!isNaN(potentialColor) && potentialColor >= 0 && potentialColor <= 15) {
                colorIndex = potentialColor
                remainingText = colorParts.slice(1).join(' ')
            }
        }

        postText = remainingText
    }

    const finalColor = (colorIndex >= 0 && colorIndex < COLORS.length)
        ? COLORS[colorIndex]
        : COLORS[Math.floor(Math.random() * COLORS.length)]

    if (!postText && !isImage && !isVideo && !isAudio && !isVoice) {
        return m.reply(`⚡ *نظام الحالة سعق*

👥 *أنواع الجمهور:*
• عام - للجميع
• خاص ⭐ - للأقارب
• قائمة <ايموجي> <اسم> - تخصيص

🎨 *الألوان (0-15):*
0-أحمر | 1-وردي | 2-بنفسجي | 3-نيلي
4-أزرق | 5-سماوي | 6-تركواز | 7-فيروزي
8-أخضر | 9-ليموني | 10-أصفر | 11-ذهبي
12-برتقالي | 13-مرجاني | 14-ناري | 15-ياقوتي

✏️ *أمثلة:*
• .حالة عام 5 مرحبا
• .حالة قائمة ⚡ جيو 12
• رد على صورة/فيديو + .حالة`)
    }

    try {
        if (isImage || isVideo || isAudio || isVoice) {
            let media = await q.download()
            let mediaType = isImage ? 'image' : isVideo ? 'video' : 'audio'
            let mediaOptions = { [mediaType]: media }
            if (isVoice) mediaOptions = { audio: media, mimetype: 'audio/ogg; codecs=opus', ptt: false }

            let prepared = await prepareWAMessageMedia(mediaOptions, { upload: conn.waUploadToServer })
            let messageKey = isImage ? 'imageMessage' : isVideo ? 'videoMessage' : 'audioMessage'

            const contentMsg = {
                [messageKey]: {
                    ...prepared[messageKey],
                    caption: postText || '',
                    contextInfo: {
                        isGroupStatus: true,
                        pairedMediaType: 'NOT_PAIRED_MEDIA',
                        statusAudienceMetadata: {
                            audienceType: audienceType,
                            ...(listEmoji && { listEmoji }),
                            ...(listName && { listName })
                        }
                    }
                }
            }

            const webMsg = proto.Message.fromObject(contentMsg)
            const waMsg = generateWAMessageFromContent(m.chat, webMsg, { userJid: conn.user.jid, quoted: m })
            await conn.relayMessage(m.chat, waMsg.message, { messageId: waMsg.key.id })
            await m.react('✅')
            return
        }

        const groupMetadata = await conn.groupMetadata(m.chat)
        const statusJidList = groupMetadata.participants.map(p => p.id)

        await conn.relayMessage(m.chat, {
            statusJidList,
            messageContextInfo: {
                messageSecret: Buffer.from(Array(32).fill(0).map(() => Math.floor(Math.random() * 256)))
            },
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: `${global.watermark}\n\n${postText}`,
                        thumbnailUrl: 'https://file.garden/aauvg01sjleV_ic1/c2a3bfd6e9fd1db2f5358f8feec9261f.jpg',
                        textArgb: 4294967040,
                        backgroundArgb: finalColor,
                        font: 5,
                        previewType: 0,
                        contextInfo: {
                            statusAttributions: [{ type: 10 }],
                            featureEligibilities: { canBeReshared: true, canReceiveMultiReact: true },
                            statusSourceType: 4,
                            statusAudienceMetadata: {
                                audienceType: audienceType,
                                ...(listEmoji && { listEmoji }),
                                ...(listName && { listName })
                            }
                        },
                        inviteLinkGroupTypeV2: 0
                    }
                }
            }
        }, {})

        await m.react('✅')
    } catch (e) {
        console.error('❌ خطأ:', e)
        await m.react('❌')
        m.reply('حصل خطأ: ' + e.message)
    }
}

handler.help = ['حالة']
handler.tags = ['group']
handler.command = /^(حالة)$/i
handler.group = true
handler.admin = false 

export default handler