// plugins/hidetag.js
// ⧼ 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 ⫷𝐆𝐎𝐉𝐎⫸ ⧽ — مخفي موثق | 212674375708
import { generateWAMessageFromContent } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';

const handler = async (m, { conn, text, participants }) => {
    if (!m.isGroup) return;

    // ── فحص أدمن حقيقي من الميتاداتا ──
    let meta = await conn.groupMetadata(m.chat).catch(()=>null);
    if (!meta) return;

    let sender = meta.participants.find(p => p.id === m.sender || p.jid === m.sender || p.id.includes(m.sender.split('@')[0]));
    let isAdminReal = sender?.admin === 'admin' || sender?.admin === 'superadmin';
    let isDev = m.sender.includes('212674375708');

    if (!isAdminReal &&!isDev) {
        return conn.sendMessage(m.chat, {
            text: `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 مـخـفـي┊ 👁️‍🗨️˹ 〕* *𝐆𝐎𝐉𝐎* ──¤﹝صـلاحـيـات ❌﹞*\n> *🥷🏻┊فقط المشرفين والمطور* *𝐘𝐎𝐍𝐎 𝐃𝐄𝐕* *يقدرو يستخدموه*\n* ━ ╼╃ ⌬〔 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`
        }, { quoted: m });
    }

    let users = participants.map(u => conn.decodeJid(u.id));
    let q = m.quoted? await m.getQuotedObj().catch(()=>null) : null;
    let htext = text || q?.text || q?.caption || '*📢 تـنـبـيـه لـلـجـمـيـع*';

    // اخفاء المنشن
    const more = String.fromCharCode(8206);
    const mass = more.repeat(850);

    // ── التوثيق ──
    let thumb;
    try { thumb = await (await fetch('https://files.catbox.moe/80dv0b.jpg')).buffer(); } catch { thumb = null; }

    const fkontak = {
        key: { participants:"0@s.whatsapp.net", fromMe:false, id:"Hidetag_Verified" },
        message: {
            locationMessage: {
                name: `👁️‍🗨️ مخفي - 𝐆𝐎𝐉𝐎 BOT`,
                jpegThumbnail: thumb,
                vcard: `BEGIN:VCARD
VERSION:3.0
N:; YONO DEV 👑
FN: YONO DEV 👑
ORG: GOJO BOT - HIDETAG
item1.TEL;waid=212674375708:+212674375708
item1.X-ABLabel: المطور YONO DEV
X-WA-BIZ-NAME:𝐆𝐎𝐉𝐎 - 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 212674375708
END:VCARD`
            }
        },
        participant: "0@s.whatsapp.net"
    };

    try {
        // اذا معه صورة / فيديو مقتبس
        if (q) {
            let mime = (q.msg || q).mimetype || q.mtype || '';
            if (/image|video|sticker|audio/.test(mime)) {
                let media = await q.download?.();
                if (media) {
                    if (/image/.test(mime)) return await conn.sendMessage(m.chat, { image: media, caption: `${mass}\n${htext}`, mentions: users }, { quoted: fkontak });
                    if (/video/.test(mime)) return await conn.sendMessage(m.chat, { video: media, caption: `${mass}\n${htext}`, mimetype: 'video/mp4', mentions: users }, { quoted: fkontak });
                    if (/sticker/.test(mime)) return await conn.sendMessage(m.chat, { sticker: media, mentions: users }, { quoted: fkontak });
                    if (/audio/.test(mime)) return await conn.sendMessage(m.chat, { audio: media, mimetype: 'audio/mpeg', mentions: users }, { quoted: fkontak });
                }
            } else {
                // نص مقتبس
                let msg = conn.cMod(m.chat, generateWAMessageFromContent(m.chat, { [q.mtype]: q.message[q.mtype] }, { quoted: fkontak, userJid: conn.user.id }), htext, conn.user.jid, { mentions: users });
                return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
            }
        }

        // نص عادي مخفي بدون @
        await conn.sendMessage(m.chat, {
            text: `${mass}\n* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> ${htext}\n* ━ ╼╃ ⌬〔 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`,
            mentions: users
        }, { quoted: fkontak });

        await conn.sendMessage(m.chat, { react: { text: '👁️‍🗨️', key: m.key } });

    } catch (e) {
        console.log('[HIDETAG]', e);
        await conn.sendMessage(m.chat, { text: htext, mentions: users }, { quoted: m });
    }
};

handler.command = /^(hidetag|notificar|مخفي|منشن)$/i;
handler.group = true;
handler.admin = false; // مهم عشان لا يعتمد على isAdmin الخربان
handler.botAdmin = false;

export default handler;