// ╮••─๋︩︪──๋︩︪─═⊐‹⧫›⊏═─๋︩︪──๋︩︪─┈☇
// ☃️ Plugin : مـضـاد الـشـتـم - نـظـام الـحـمـايـة الـتـلـقـائـي
// ⚡ Bot : 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🪖🔮
// 🍷 Developer : 𝐆𝐎𝐉𝐎
// 🍁 Version : SATORU v1.0
// 🛡️ حقوق النشر محفوظة © 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓
// ╮••─๋︩︪──๋︩︪─═⊐‹⧫›⊏═─๋︩︪──๋︩︪─┈☇

// قـائـمـة الـكـلـمـات الـمـمـنـوعـة
const badWords = [
    "قحبه", "شرموطه", "عرص", "كس", "زب", "منيوك", "متناك", "طيز", "خول", "قواد",
    "ابن الحرام", "يا بن القحبة", "كس اختك", "امك", "سكس", "نيك", "تناك", "شرمطه",
    "تيز", "مص", "يلعن", "كلب", "حمار", "تفو"
];

let handler = async (m, { conn, text, isMainAdmin, isAdmin, command, usedPrefix }) => {
    const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
    const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;

    if (!m.isGroup) return m.reply(`${startDeco}\n> *〔 ❌┊ ˼‏ 〕 هـذا الامـر للـجـروبـات فـقـط*\n${endDeco}`)
    if (!isAdmin && !isMainAdmin) return m.reply(`${startDeco}\n> *〔 ❌┊ ˼‏ 〕 خـاص بـالـمـشـرفـيـن فـقـط*\n${endDeco}`)

    global.db = global.db || {}
    global.db.chats = global.db.chats || {}
    global.db.chats[m.chat] = global.db.chats[m.chat] || { antiBadwords: false }

    if (command === 'مضاد_شتم' || command === 'مضاد_شتائم') {
        if (!text) return m.reply(`${startDeco}
> *〔 مـضـاد الـشـتـم┊ ˼‏ 🛡️˹ ↶〕*
> *🥷🏻┊الـحـالـة:* ${global.db.chats[m.chat].antiBadwords ? 'مـفـعـل ✅' : 'مـوقـف ❌'}
> *🥷🏻┊${usedPrefix + command} تشغيل*
> *🥷🏻┊${usedPrefix + command} ايقاف*
> *🥷🏻┊الـمـطـور:* 𝐆𝐎𝐉𝐎
${endDeco}`)
        
        if (text === 'تشغيل' || text === 'on') {
            global.db.chats[m.chat].antiBadwords = true
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
            return m.reply(`${startDeco}
> *〔 تـم الـتـفـعـيـل┊ ˼‏ ✅˹ ↶〕*
> *🥷🏻┊تـم تـشـغـيـل نـظـام مـضـاد الـشـتـم*
> *🥷🏻┊اي رسـالـة فـيـهـا لـفـظ غـادي تـتـمـسـح تـلـقـائـيـا*
${endDeco}`)
        } else if (text === 'ايقاف' || text === 'off' || text === 'إيقاف') {
            global.db.chats[m.chat].antiBadwords = false
            await conn.sendMessage(m.chat, { react: { text: '🔒', key: m.key } })
            return m.reply(`${startDeco}
> *〔 تـم الايـقـاف┊ ˼‏ 🔒˹ ↶〕*
> *🥷🏻┊تـم ايـقـاف نـظـام مـضـاد الـشـتـم*
${endDeco}`)
        }
    }
}

// فـحـص تـلـقـائـي
handler.before = async function (m, { conn, isAdmin, isBotAdmin }) {
    if (!m.isGroup) return false

    global.db = global.db || {}
    global.db.chats = global.db.chats || {}
    const chatSettings = global.db.chats[m.chat] || { antiBadwords: false }

    if (!chatSettings.antiBadwords) return false
    if (!m.text) return false

    const messageText = m.text.toLowerCase().trim()
    const isBad = badWords.some(word => messageText.includes(word))

    if (isBad) {
        if (isAdmin) return false // المشرفين معفيين

        if (!isBotAdmin) {
            await m.reply(`⚠️ *ارفعني مشرف لاحذف الشتائم تلقائيا*`)
            return true
        }

        try {
            await conn.sendMessage(m.chat, {
                text: `* ━ ╼╃ ⌬〔⚠️〕⌬ ╄╾ ━ *
> *〔 نـظـام الـحـمـايـة┊ ˼‏ 🛡️˹ ↶〕*
> *🥷🏻┊مـمـنـوع الـشـتـم هـنـا*
> *🥷🏻┊الـعـضـو:* @${m.sender.split('@')[0]}
> *🥷🏻┊تـم حـذف الـرسـالـة تـلـقـائـيـا*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`,
                mentions: [m.sender]
            }, { quoted: m })

            await conn.sendMessage(m.chat, {
                delete: { remoteJid: m.chat, fromMe: false, id: m.id, participant: m.sender }
            })

        } catch (error) {
            console.error('خطأ أثناء حذف الشتيمة:', error)
        }
        return true
    }
    return false
}

handler.help = ['مضاد_شتم <تشغيل/ايقاف>']
handler.tags = ['𝐆𝐎𝐉𝐎 𝐆𝐑𝐎𝐔𝐏']
handler.command = /^(مضاد_شتم|مضاد_شتائم|antibad|antibadwords)$/i
handler.group = true

export default handler