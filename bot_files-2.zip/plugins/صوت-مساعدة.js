// ╮••─๋︩︪──๋︩︪─═⊐‹⧫›⊏═─๋︩︪──๋︩︪─┈☇
// ☃️ Plugin : اصوات مشاهير وانمي TTS
// ⚡ Bot : 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓
// 🍷 Developer : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕
// 
// ╮••─๋︩︪──๋︩︪─═⊐‹⧫›⊏═─๋︩︪──๋︩︪─┈☇

import axios from 'axios'
import { generateWAMessageFromContent } from '@whiskeysockets/baileys'

const API_BASE = 'https://engez.a7a.online/api/v1'

// قائمة الأصوات (الأسماء فقط)
const VOICES = [
    'ميسي', 'نيمار', 'مبابي', 'غوكو', 'زونغلي', 'ناهيدا', 'نامي', 'يوكي',
    'ايمينيم', 'رابر', 'سنوب', 'دريك', 'كانيه', 'مورغان', 'صموئيل',
    'ذاروك', 'جوروغان', 'اندروتيت'
]

async function generateVoice(text, voice) {
    try {
        const params = new URLSearchParams()
        params.append('text', text)
        params.append('voice', voice)
        const response = await axios.get(`${API_BASE}/tools/anime-tts?${params.toString()}`, { timeout: 60000 })
        if (!response.data?.success) { throw new Error(response.data?.error || 'فشل توليد الصوت') }
        return response.data.response
    } catch (error) { throw new Error(error.message || 'فشل الاتصال') }
}

async function sendVoiceList(conn, chat, quoted, usedPrefix) {
    const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
    const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;

    const sections = [{
        title: '🎙️ اصـوات مـشـاهـيـر وانـمـي',
        rows: VOICES.map(name => ({
            title: name,
            description: `🎤 صـوت ${name}`,
            id: `${usedPrefix}صوت-أنمي ${name}`
        }))
    }]

    const msg = generateWAMessageFromContent(chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: `${startDeco}\n> *〔 اخـتـر الـصـوت┊ ˼‏ 🗣️˹ ↶〕*\n\n> *🥷🏻┊اخـتـر صـوتـاً لـتـولـيـد الـنـص الـصـوتـي:*\n${endDeco}` },
                    footer: { text: '🎙️ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓' },
                    nativeFlowMessage: {
                        buttons: [{
                            name: 'single_select',
                            buttonParamsJson: JSON.stringify({
                                title: '🎙️ اخـتـر صـوت',
                                sections
                            })
                        }]
                    }
                }
            }
        }
    }, { userJid: conn.user.jid, quoted })

    await conn.relayMessage(chat, msg.message, { messageId: msg.key.id })
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
    const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;

    // أمر عرض القائمة
    if (command === 'صوت-أنمي' && !text) {
        await sendVoiceList(conn, m.chat, m, usedPrefix)
        return
    }

    // أمر مساعد
    if (command === 'صوت-مساعدة') {
        return m.reply(`${startDeco}
> *〔 طـريـقـة الاسـتـخـدام┊ ˼‏ 🎙️˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *🥷🏻┊${usedPrefix}صوت-أنمي - عـرض الـقـائـمـة*
> *🥷🏻┊${usedPrefix}صوت-أنمي ميسي مرحبا*
> *🥷🏻┊الـمـتـاح:* ${VOICES.length} صـوت

> *〔 الامـثـلـة ↶〕*
> *🥷🏻┊${usedPrefix}صوت-أنمي غوكو السلام عليكم*

${endDeco}`)
    }

    // التحقق من وجود نص
    if (!text) {
        return m.reply(`${startDeco}
> *〔 خـطـأ┊ ˼‏ ❌˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *🥷🏻┊يـرجـى ادخـال الـنـص*
> *🥷🏻┊${usedPrefix}صوت-أنمي <الاسم> <النص>*
> *🥷🏻┊${usedPrefix}صوت-أنمي غوكو مرحبا*

${endDeco}`)
    }

    await m.react('⏳')

    try {
        let voiceName = null
        let textToSpeak = text

        // محاولة استخراج اسم الصوت من بداية النص
        const match = text.match(/^(\S+)\s+(.+)/)
        if (match) {
            const possibleVoice = match[1]
            if (VOICES.includes(possibleVoice)) {
                voiceName = possibleVoice
                textToSpeak = match[2]
            }
        }

        // إذا لم يتم العثور على صوت، استخدام الصوت الافتراضي
        if (!voiceName) {
            voiceName = 'ميسي'
            textToSpeak = text
        }

        const result = await generateVoice(textToSpeak, voiceName)

        if (result?.url) {
            await conn.sendMessage(m.chat, {
                audio: { url: result.url },
                mimetype: 'audio/mpeg',
                fileName: `GOJO_TTS_${voiceName}_${Date.now()}.mp3`,
                caption: `${startDeco}
> *〔 تـم الـتـولـيـد┊ ˼‏ ✅˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *🥷🏻┊الـصـوت:* ${voiceName}
> *🥷🏻┊الـنـص:* ${textToSpeak}

${endDeco}`
            }, { quoted: m })

            await m.react('✅')
        } else {
            throw new Error('لم يتم العثور على رابط الصوت')
        }

    } catch (error) {
        await m.react('❌')
        return m.reply(`${startDeco}\n> *〔 ❌ 〕 خـطـأ:* ${error.message}\n${endDeco}`)
    }
}

handler.command = ['صوت-أنمي', 'anime-tts', 'صوت-مساعدة']
handler.help = ['صوت-أنمي <اسم> <نص>', 'صوت-مساعدة']
handler.tags = ['🇲🇦الـ TTS🇲🇦']

export default handler