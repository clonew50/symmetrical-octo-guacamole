// حہּٰقَــــوٰقَ 𝑊𝐴𝐿𝐼𝐷 𝑀𝑂𝐶𝐻𝐴𝐾𝐼𝑆𝐸 💻🔥
// ملف قران-مبسط.js 

import axios from 'axios';
import fs from 'fs';
import path from 'path';

const startDeco = `┏━━━━━━━━━━━━━━━━━━━┓\n┃ ✦ ﷽ ✦ بسم الله الرحمن الرحيم ✦ ┃\n┗━━━━━━━━━━━━━━━━━━━┛`;
const endDeco = `┏━━━━━━━━━━━━━━━━━━━┓\n┃ ✦ صَدَقَ اللَّهُ الْعَظِيمُ ✦ ┃\n┗━━━━━━━━━━━━━━━━━━━┛`;
const signature = `╭─────────────╮\n│⫍ ⃢⚡_KAISER_ 𝘽𝙊𝙏シ︎⁩ 𖤍⫎ │\n╰─────────────╯`;

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        let list = `${startDeco}\n\n📖 *القرآن الكريم*\n✦ اكتب رقم السورة من 1 إلى 114\n\n*أمثلة:*\n✦ ${usedPrefix}قران 1 → الفاتحة\n✦ ${usedPrefix}قران 36 → يس\n✦ ${usedPrefix}قران 112 → الإخلاص\n\n${signature}\n\n${endDeco}`;
        return m.reply(list);
    }

    let surahNumber = parseInt(text);
    if (isNaN(surahNumber) || surahNumber < 1 || surahNumber > 114) {
        return m.reply(`${startDeco}\n\n❌ رقم السورة غلط! من 1 لـ 114\n\n${endDeco}`);
    }

    await m.react('⏳');
    
    try {
        // رابط مباشر من mp3quran
        let url = `https://server11.mp3quran.net/shatri/${String(surahNumber).padStart(3, '0')}.mp3`;
        
        let surahNames = ['الفاتحة', 'البقرة', 'آل عمران', 'النساء', 'المائدة', 'الأنعام', 'الأعراف', 'الأنفال', 'التوبة', 'يونس', 'هود', 'يوسف', 'الرعد', 'إبراهيم', 'الحجر', 'النحل', 'الإسراء', 'الكهف', 'مريم', 'طه', 'الأنبياء', 'الحج', 'المؤمنون', 'النور', 'الفرقان', 'الشعراء', 'النمل', 'القصص', 'العنكبوت', 'الروم', 'لقمان', 'السجدة', 'الأحزاب', 'سبأ', 'فاطر', 'يس', 'الصافات', 'ص', 'الزمر', 'غافر', 'فصلت', 'الشورى', 'الزخرف', 'الدخان', 'الجاثية', 'الأحقاف', 'محمد', 'الفتح', 'الحجرات', 'ق', 'الذاريات', 'الطور', 'النجم', 'القمر', 'الرحمن', 'الواقعة', 'الحديد', 'المجادلة', 'الحشر', 'الممتحنة', 'الصف', 'الجمعة', 'المنافقون', 'التغابن', 'الطلاق', 'التحريم', 'الملك', 'القلم', 'الحاقة', 'المعارج', 'نوح', 'الجن', 'المزمل', 'المدثر', 'القيامة', 'الإنسان', 'المرسلات', 'النبأ', 'النازعات', 'عبس', 'التكوير', 'الانفطار', 'المطففين', 'الانشقاق', 'البروج', 'الطارق', 'الأعلى', 'الغاشية', 'الفجر', 'البلد', 'الشمس', 'الليل', 'الضحى', 'الشرح', 'التين', 'العلق', 'القدر', 'البينة', 'الزلزلة', 'العاديات', 'القارعة', 'التكاثر', 'العصر', 'الهمزة', 'الفيل', 'قريش', 'الماعون', 'الكوثر', 'الكافرون', 'النصر', 'المسد', 'الإخلاص', 'الفلق', 'الناس'];
        
        let surahName = surahNames[surahNumber - 1];
        
        let caption = `${startDeco}\n\n📖 *سورة ${surahName}*\n🎙️ *القارئ:* أبو بكر الشاطري\n✨ *استمع وتدبر*\n\n${signature}\n\n${endDeco}`;
        
        await conn.sendMessage(m.chat, {
            audio: { url: url },
            mimetype: 'audio/mpeg',
            fileName: `سورة_${surahName}.mp3`,
            ptt: false,
            caption: caption
        }, { quoted: m });
        
        await m.react('✅');
        
    } catch (e) {
        console.error(e);
        await m.react('❌');
        m.reply(`${startDeco}\n\n❌ فشل التحميل\n\n${endDeco}`);
    }
}

handler.help = ['قران رقم_السورة']
handler.tags = ['quran']
handler.command = /^(قران|قرآن|quran)$/i

export default handler;