import fetch from 'node-fetch';

const gameDuration = 60000;
const basePoints = 500;
const maxQuestions = 15;
const maxHelps = 2;
const maxHints = 1;
const maxResponses = 1;
const maxReducedOptions = 1;

export async function handler(m, { command, text, conn }) {
    const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
    const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;
    const myCredit = `*⚜️┊اسـم الـبـوت:* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*`;

    let id = m.chat;
    conn.millionGame = conn.millionGame || {};
    let currentGame = conn.millionGame[id];

    let src = await (await fetch('https://gist.githubusercontent.com/Dx-Tea/19102ea14b19d7ef685128e6186a277d/raw/867b4da16f68253f67ca184f77ce5295d1da4029/By-shanks')).json();

    if (!src || src.length === 0) {
        return conn.reply(m.chat, `${startDeco}\n> *〔 خـطـأ┊ ˼‏ ⚠️˹ ↶〕*\n> *لا توجد أسئلة متاحة حالياً*\n${endDeco}`, m);
    }

    let shanks = 'https://qu.ax/Cnbf.jpg';

    if (currentGame) {
        if (!text) {
            return conn.reply(m.chat, `${startDeco}
> *〔 لـعـبـة قـائـمـة┊ ˼‏ 🎮˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝لـعـبـة الـمـلـيـون ↶﹞*
> *〔 📈 〕 الـمـسـتـوى:* ${currentGame[4]}
> *〔 🆘 〕 الـمـسـاعـدات:* ${currentGame[5]}
${endDeco}`, m);
        } else if (text === currentGame[1].response) {
            m.react('✅');
            let currentLevel = currentGame[4];
            let points = basePoints * currentLevel;

            let timeTaken = gameDuration - (Date.now() - currentGame[2].startTime);
            let speedBonus = Math.max(0, Math.floor((timeTaken / 1000) * 50));
            let totalPoints = points + speedBonus;

            global.db.data.users[m.sender].exp += totalPoints;

            // رسالة الفوز + زرين
            await conn.sendButton(m.chat, `${startDeco}
> *〔 إجـابـة صـحـيـحـة┊ ˼‏ ✅˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝لـعـبـة الـمـلـيـون ↶﹞*
> *〔 ✅ 〕 الاجـابـة:* ${currentGame[1].response}
> *〔 💰 〕 الـجـائـزة:* ${totalPoints} XP
> *〔 🕷️ 〕 بـونـص الـسـرعـة:* ${speedBonus}
> *〔 📈 〕 الـمـسـتـوى الـتـالـي:* ${currentLevel + 1}

*🪖 ──¤﹝مـعـلـومـات الـنـظـام↶﹞*
${myCredit} *🕸️ ───━ •﹝📌﹞• ━───*
${endDeco}`, '© Powered By GOJO 🇲🇦', shanks, [
                [`↬ السؤال التالي`, `.المليون`],
                [`🎮 لعبة جديدة`, `.المليون`]
            ], null, null);

            if (currentLevel === 5 || currentLevel === 10) {
                conn.reply(m.chat, `${startDeco}\n> *〔 مـكـافـأة┊ ˼‏ 🎉˹ ↶〕*\n> *مبروك! وصلت للمستوى ${currentLevel} وحصلت على 1000 XP إضافية!*\n${endDeco}`, m);
                global.db.data.users[m.sender].exp += 1000;
            }

            clearTimeout(currentGame[3]);
            currentLevel++;

            if (currentLevel > maxQuestions) {
                await conn.sendButton(m.chat, `${startDeco}
> *〔 فـزت بـالـمـلـيـون┊ ˼‏ 🎊˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝لـعـبـة الـمـلـيـون ↶﹞*
> *〔 🎊 〕 الـمـبـروك:* لقد ربحت المليون!
${endDeco}`, '© Powered By GOJO 🇲🇦', null, [[`🎮 لعبة جديدة`, `.المليون`]], null, null);
                delete conn.millionGame[id];
            } else {
                // نأجل السؤال الجديد 3 ثواني باش يضغط على الزر
                setTimeout(() => {
                    startNewQuestion(conn, m, id, currentLevel, src, startDeco, endDeco, myCredit);
                }, 3000);
            }

        } else if (text === 'قائمة المساعدات' && currentGame[5] > 0) {
            m.react('💡');
            let message = `${startDeco}
> *〔 قـائـمـة الـمـسـاعـدات┊ ˼‏ 🆘˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝لـعـبـة الـمـلـيـون ↶﹞*
> *〔 ❶ 〕 الـمـسـاعـدات:* ${currentGame[5]}
> *〔 ❷ 〕 الـتـلـمـيـحـات:* ${currentGame[6]}
> *〔 ❸ 〕 مـسـاعـدة الـجـمـهـور:* ${currentGame[7]}
> *〔 ❹ 〕 حـذف خـيـارين:* ${currentGame[8]}
${endDeco}`;

            await conn.sendButton(m.chat, message, '© Powered By GOJO 🇲🇦', shanks, [
                [`مساعدة 💡`, `.المليون مساعدة`],
                [`تلميح 💡`, `.المليون تلميح`],
                [`مساعدة الجمهور 🎥`, `.المليون جواب`],
                [`انسحاب 🏃‍♂️`, `.المليون انسحب`],
                [`حذف خيارين ✂️`, `.المليون إزالة اختيارين`]
            ], null, null);
        } else if (text === 'مساعدة' && currentGame[5] > 0) {
            let help = getHalfAnswer(currentGame[1].response);
            conn.reply(m.chat, `${startDeco}\n> *〔 تـلـمـيـح┊ ˼‏ 💡˹ ↶〕*\n> *نصف الاجابة:* [ ${help} ]\n${endDeco}`, m);
            currentGame[5]--;
        } else if (text === 'إزالة اختيارين' && currentGame[8] > 0) {
            let reducedOptions = removeTwoIncorrectOptions(currentGame[1].response, currentGame[1].options);
            await conn.sendButton(m.chat, `${startDeco}\n> *〔 حـذف خـيـارين┊ ˼‏ ✂️˹ ↶〕*\n> *الخيارات المتبقية:* ${reducedOptions.join(' أو ')}\n${endDeco}`, '© Powered By GOJO 🇲🇦', shanks, [
                [`${reducedOptions[0]}`, `.المليون ${reducedOptions[0]}`],
                [`${reducedOptions[1]}`, `.المليون ${reducedOptions[1]}`]
            ], null, null);
            currentGame[8]--;
        } else if (text === 'تلميح' && currentGame[6] > 0) {
            let hint = getHint(currentGame[1].hint);
            conn.reply(m.chat, `${startDeco}\n> *〔 تـلـمـيـح┊ ˼‏ 💡˹ ↶〕*\n> *${hint}*\n${endDeco}`, m);
            currentGame[6]--;
        } else if (text === 'جواب' && currentGame[7] > 0) {
            let response = getAudienceHelp(currentGame[1].response);
            conn.reply(m.chat, `${startDeco}\n> *〔 مـسـاعـدة الـجـمـهـور┊ ˼‏ 🎥˹ ↶〕*\n> *الجمهور يقول:* [ ${response} ]\n${endDeco}`, m);
            currentGame[7]--;
        } else if (text === 'انسحب') {
            clearTimeout(currentGame[3]);
            await conn.sendButton(m.chat, `${startDeco}\n> *〔 انـسـحـاب┊ ˼‏ 🏃‍♂️˹ ↶〕*\n> *تم الخروج بنجاح*\n> *الاجابة:* ${currentGame[1].response}\n${endDeco}`, '© Powered By GOJO 🇲🇦', null, [[`🎮 لعبة جديدة`, `.المليون`]], null, null);
            delete conn.millionGame[id];
        } else {
            clearTimeout(currentGame[3]);
            m.react('❌');
            await conn.sendButton(m.chat, `${startDeco}\n> *〔 إجـابـة خـاطـئـة┊ ˼‏ ❌˹ ↶〕*\n> *الاجابة الصحيحة:* ${currentGame[1].response}\n${endDeco}`, '© Powered By GOJO 🇲🇦', null, [[`🎮 لعبة جديدة`, `.المليون`]], null, null);
            delete conn.millionGame[id];
        }
    } else {
        let currentLevel = 1;
        startNewQuestion(conn, m, id, currentLevel, src, startDeco, endDeco, myCredit);
    }
}

async function startNewQuestion(conn, m, id, level, src, startDeco, endDeco, myCredit) {
    let question = src[Math.floor(Math.random() * src.length)];
    let options = [...question.options];
    while (options.length < 4) {
        let randomOption = src[Math.floor(Math.random() * src.length)].response;
        if (!options.includes(randomOption)) options.push(randomOption);
    }
    options = options.sort(() => Math.random() - 0.5);

    let remainingHelps = conn.millionGame[id]? conn.millionGame[id][5] : maxHelps;
    let remainingHints = conn.millionGame[id]? conn.millionGame[id][6] : maxHints;
    let remainingResponses = conn.millionGame[id]? conn.millionGame[id][7] : maxResponses;
    let remainingReducedOptions = conn.millionGame[id]? conn.millionGame[id][8] : maxReducedOptions;

    conn.millionGame[id] = [m, question, { startTime: Date.now() }, setTimeout(() => {
        delete conn.millionGame[id];
        conn.sendButton(m.chat, `${startDeco}\n> *〔 انـتـهـى الـوقـت┊ ˼‏ ⌛˹ ↶〕*\n> *الاجابة:* ${question.response}\n${endDeco}`, '© Powered By GOJO 🇲🇦', null, [[`🎮 لعبة جديدة`, `.المليون`]], null, null);
    }, gameDuration), level, remainingHelps, remainingHints, remainingResponses, remainingReducedOptions];

    let message = `${startDeco}
> *〔 لـعـبـة الـمـلـيـون┊ ˼‏ 🎮˹ ↶〕* *♣️ ───━ •﹝📌﹞• ━─── *GOJO* ──¤﹝الـسـؤال الـرقـم ${level} ↶﹞*
> *〔 ❓ 〕 الـسـؤال:* ${question.question}
>
> *〔 📈 〕 الـمـسـتـوى:* ${level}
> *〔 ⏳ 〕 الـوقـت:* 60 ثانية
> *〔 💰 〕 الـجـائـزة:* ${basePoints * level} XP
${endDeco}`;

    await conn.sendButton(m.chat, message, '© Powered By GOJO 🇲🇦', 'https://qu.ax/Cnbf.jpg', [
        [`① ↫ ${options[0]}`, `.المليون ${options[0]}`],
        [`② ↫ ${options[1]}`, `.المليون ${options[1]}`],
        [`③ ↫ ${options[2]}`, `.المليون ${options[2]}`],
        [`④ ↫ ${options[3]}`, `.المليون ${options[3]}`],
        [`قائمة المساعدات 🆘`, `.المليون قائمة المساعدات`]
    ], null, null);
}

function getHint(hint) { return hint? hint : 'لا يوجد تلميح متاح لهذا السؤال.'; }
function getAudienceHelp(response) { return response? response : 'لا توجد إجابة متاحة من الجمهور.'; }
function getHalfAnswer(answer) { return answer.substring(0, Math.ceil(answer.length / 2)) + "..."; }
function removeTwoIncorrectOptions(correctAnswer, options) {
    let incorrectOptions = options.filter(option => option!== correctAnswer).sort(() => Math.random() - 0.5).slice(0, 2);
    return options.filter(option =>!incorrectOptions.includes(option));
}

handler.help = ['المليون'];
handler.tags = ['🎮 الالعاب 🎮'];
handler.command = /^المليون$/i;
handler.limit = true;

export default handler;