import axios from "axios";
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys'

/* ========= إعدادات واستخراج بيانات Pinterest (الـ API من الكود الأول) ========= */
const base = "https://www.pinterest.com";
const search = "/resource/BaseSearchResource/get/";

const headers = {
  accept: "application/json, text/javascript, */*, q=0.01",
  referer: "https://www.pinterest.com/",
  "user-agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
  "x-app-version": "a9522f",
  "x-pinterest-appstate": "active",
  "x-pinterest-pws-handler": "www/[username]/[slug].js",
  "x-requested-with": "XMLHttpRequest",
};

async function getCookies() {
  try {
    const response = await axios.get(base);
    const setHeaders = response.headers["set-cookie"];
    if (setHeaders) {
      return setHeaders.map(v => v.split(";")[0]).join("; ");
    }
    return null;
  } catch {
    return null;
  }
}

async function searchPinterest(query) {
  try {
    const cookies = await getCookies();
    if (!cookies) return { status: false, message: "فشل جلب الكوكيز من بينترست." };

    const params = {
      source_url: `/search/pins/?q=${query}`,
      data: JSON.stringify({
        options: {
          isPrefetch: false,
          query,
          scope: "pins",
          bookmarks: [""],
          page_size: 10,
        },
        context: {},
      }),
      _: Date.now(),
    };

    const { data } = await axios.get(`${base}${search}`, {
      headers: {...headers, cookie: cookies },
      params,
    });

    const results = data.resource_response.data.results.filter(
      v => v.images?.orig
    );

    if (!results.length)
      return { status: false, message: "لم يتم العثور على نتائج." };

    return {
      status: true,
      pins: results.map(v => v.images.orig.url), // استخراج روابط الصور المباشرة فقط
    };
  } catch {
    return { status: false, message: "حدث خطأ أثناء الاتصال بموقع بينترست." };
  }
}

/* ========= الأمر الرئيسي ========= */
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text)
    return m.reply(`❐═━━━═╊⊰👑⊱╉═━━━═❐\n⚠️ يرجى كتابة كلمة البحث.\n📌 مثال:\n${usedPrefix + command} أنمي\n❐═━━━═╊⊰👑⊱╉═━━━═❐`)

  try {
    await m.react('⏳')

    // جلب البيانات باستخدام محرك الكود الأول
    let result = await searchPinterest(text);

    if (!result.status) {
      await m.react('❌')
      return m.reply(`❐═━━━═╊⊰👑⊱╉═━━━═❐\n❌ ${result.message} لـ *${text}*\n❐═━━━═╊⊰👑⊱╉═━━━═❐`)
    }

    let pins = result.pins.slice(0, 10) // نأخذ 10 صور فقط
    let cards = []

    for (let i = 0; i < pins.length; i++) {
      let imageUrl = pins[i]

      // تحضير الصورة لتظهر داخل البطاقة المتحركة
      let imageMsg = await prepareWAMessageMedia(
        { image: { url: imageUrl } },
        { upload: conn.waUploadToServer }
      )

      cards.push({
        header: {
          hasMediaAttachment: true,
          imageMessage: imageMsg.imageMessage,
        },
        body: {
          text: `❐═━━━═╊⊰👑⊱╉═━━━═❐\n🎯 *النتيجة رقم:* [ ${i + 1} / ${pins.length} ]\n❐═━━━═╊⊰👑⊱╉═━━━═❐`
        },
        footer: {
          text: `┇ 👑 𝗕𝘆 𝗬𝗢𝗡𝗢 | CHANLE 𝗕𝗢𝗧๔ぽ 👑 ┇`
        },
        nativeFlowMessage: {
          buttons: [
            {
              name: 'cta_url',
              buttonParamsJson: JSON.stringify({
                display_text: '👑 فتح الصورة الأصلية',
                url: imageUrl
              })
            }
          ]
        }
      })
    }

    // بناء الرسالة النهائية بنظام Carousel (التمرير يميناً ويساراً)
    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: `❐═━━━═╊⊰👑⊱╉═━━━═❐
    👺 𝐆𝐎𝐉o 𝘽𝙊𝙏๔ぽ ⚜️
❐═━━━═╊⊰👑⊱╉═━━━═❐

📸 *نتائج البحث في Pinterest لـ:* 『 ${text} 』

👑 مرر لليمين واليسار لمشاهدة الـ 10 صور 👑` },
            footer: { text: `┇ 👑 𝗕𝘆 𝗬𝗢𝗡𝗢 | CHANLE 𝗕𝗢𝗧๔ぽ 👑 ┇` },
            carouselMessage: {
              cards: cards
            }
          }
        }
      }
    }, { userJid: conn.user.jid, quoted: m })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
    await m.react('✅')

  } catch (err) {
    console.error(err)
    await m.react('❌')
    m.reply('❐═━━━═╊⊰👑⊱╉═━━━═❐\n⚠️ حدث خلل أثناء جلب الصور، قد يكون السيرفر مضغوطاً حالياً.\n❐═━━━═╊⊰👑⊱╉═━━━═❐')
  }
}

handler.help = ['pint <كلمة>']
handler.tags = ['tools']
handler.command = /^(pint|بينتر|بينترست|صور)$/i

export default handler