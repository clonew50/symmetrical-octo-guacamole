import fs from 'fs';
import path from 'path';
import { fileTypeFromBuffer } from 'file-type';

// ──────────────────────────────────────────────
// دالة التنسيق المزخرف — حقوق GEO BOT
// ──────────────────────────────────────────────
function adamStyle(title, lines = [], footer = '◜⏤͟͟͞͞ ⚡_KAISER_ ⚡ 𝑩𝑶𝑻 ˖࣪⃟🩸 ◞') {
  const top =
    `⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞\n` +
    `≪  ❪ ♾️ ${title} ♾️ ❫ ≫\n` +
    `      ⛩️ ⚡_KAISER_ ・ 𝑩𝑶𝑻 ⛩️\n` +
    `≪ ━ ❪ 🩸 𝐓𝐇𝐄 𝐎𝐍𝐄 𝐀𝐁𝐎𝐕𝐄 𝐀𝐋𝐋 🩸 ❫ ━ ≫\n` +
    `⏤͟͟͞͞💠⏤͟͟͞͞⏤͟͟͞͞⏤͟͟͞͞💠⏤͟͟͞͞`;
  const mid = lines.map(l => `╟「 ${l.icon} 」↬ ${l.text}`).join('\n');
  const bot = `╰─── ≪ ❪ 🩸 ♾️ 🩸 ❫ ≫ ───╯\n${footer}`;
  return `${top}\n${mid}\n\n${bot}`;
}

// ──────────────────────────────────────────────
// استخراج النص — يغطي كل أنواع Baileys
// ──────────────────────────────────────────────
function extractText(q) {
  if (!q) return null;

  // ─── الطريقة 1: Properties مباشرة (معظم frameworks) ───
  for (const key of ['text', 'body', 'msg', 'caption', 'content']) {
    if (q[key] && typeof q[key] === 'string' && q[key].trim()) {
      return q[key].trim();
    }
  }

  // ─── الطريقة 2: عبر q.message (raw Baileys object) ───
  const msg = q.message || q._message || q.fakeObj?.message || {};

  const candidates = [
    msg.conversation,
    msg.extendedTextMessage?.text,
    msg.imageMessage?.caption,
    msg.videoMessage?.caption,
    msg.documentMessage?.caption,
    msg.ephemeralMessage?.message?.conversation,
    msg.ephemeralMessage?.message?.extendedTextMessage?.text,
    msg.viewOnceMessage?.message?.imageMessage?.caption,
    msg.viewOnceMessage?.message?.videoMessage?.caption,
    msg.documentWithCaptionMessage?.message?.documentMessage?.caption,
    msg.buttonsResponseMessage?.selectedDisplayText,
    msg.templateButtonReplyMessage?.selectedDisplayText,
    msg.listResponseMessage?.title,
    msg.listResponseMessage?.description,
  ];

  for (const val of candidates) {
    if (val && typeof val === 'string' && val.trim()) {
      return val.trim();
    }
  }

  // ─── الطريقة 3: لو q نفسه هو message object ───
  if (q.conversation && typeof q.conversation === 'string') return q.conversation.trim();
  if (q.extendedTextMessage?.text) return q.extendedTextMessage.text.trim();

  return null;
}

// ──────────────────────────────────────────────
// استخراج الـ MIME الحقيقي (مش mtype)
// ──────────────────────────────────────────────
function getMime(q) {
  if (!q) return '';
  // ملاحظة: q.mtype هو نوع الرسالة (conversation/documentMessage) مش MIME حقيقي
  // نبحث عن mimetype الحقيقي فقط
  const direct = q.mimetype || q.mime || '';
  if (direct) return direct;

  const msg = q.message || q._message || {};
  return (
    msg.documentMessage?.mimetype ||
    msg.imageMessage?.mimetype ||
    msg.videoMessage?.mimetype ||
    msg.audioMessage?.mimetype ||
    msg.stickerMessage?.mimetype ||
    ''
  );
}

// ──────────────────────────────────────────────
// استخراج اسم الملف
// ──────────────────────────────────────────────
function getFileName(q) {
  if (!q) return '';
  const direct = q.filename || q.fileName || q.name || '';
  if (direct) return direct;
  const msg = q.message || {};
  return msg.documentMessage?.fileName || '';
}

// ──────────────────────────────────────────────
// هل الـ MIME مقبول كـ JS file؟
// ──────────────────────────────────────────────
function isJsMime(mime = '') {
  const allowed = [
    'application/javascript',
    'text/javascript',
    'application/x-javascript',
    'text/plain',
    'application/octet-stream',
  ];
  return allowed.some(t => mime.toLowerCase().includes(t));
}

// ──────────────────────────────────────────────
// إعادة تحميل البلجن بعد الحفظ
// ──────────────────────────────────────────────
async function reloadPlugin(filePath) {
  try {
    const absPath = path.resolve(filePath);
    if (global.plugins) {
      delete global.plugins[absPath];
      const mod = await import(`${absPath}?t=${Date.now()}`);
      global.plugins[absPath] = mod.default || mod;
      return true;
    }
    return false;
  } catch (e) {
    console.error('خطأ في reload البلجن:', e);
    return false;
  }
}

// ──────────────────────────────────────────────
// المعالج الرئيسي
// ──────────────────────────────────────────────
const handler = async (m, { text, usedPrefix, command }) => {

  // ─── التحقق من الاسم ───
  if (!text || !text.trim()) {
    return m.reply(adamStyle('MISSING FILE NAME', [
      { icon: '⚠️', text: 'يرجى إدخال اسم الملف بعد الأمر' },
      { icon: '📝', text: `مثال: ${usedPrefix}${command} اسم_الملف` }
    ], '◜⏤͟͟͞͞ ⚡_KAISER_ ⚡ 𝑩𝑶𝑻 ˖࣪⃟♾️ ◞'));
  }

  // ─── تنظيف الاسم ومنع path traversal ───
  const safeName = text.trim()
    .replace(/\.\./g, '')
    .replace(/[\/\\]/g, '')
    .replace(/\.js$/i, '')
    .trim();

  if (!safeName) {
    return m.reply(adamStyle('INVALID NAME', [
      { icon: '❌', text: 'اسم الملف غير صالح' }
    ]));
  }

  const filePath = `plugins/${safeName}.js`;

  // ─── ضمان وجود مجلد plugins ───
  if (!fs.existsSync('plugins')) {
    fs.mkdirSync('plugins', { recursive: true });
  }

  switch (command) {

    // ════════════════════════════════════════════
    // أمر الحفظ
    // ════════════════════════════════════════════
    case 'احفظ': {

      // ─── Step 1: يجب الرد على رسالة ───
      if (!m.quoted) {
        return m.reply(adamStyle('NO QUOTED MESSAGE', [
          { icon: '❌', text: 'يجب الرد على رسالة تحتوي على الكود' },
          { icon: '📝', text: `الطريقة: ارسل الكود ← ارد عليه بـ ${usedPrefix}احفظ اسم_الملف` }
        ], '◜⏤͟͟͞͞ الرجاء المحاولة مجدداً ◞'));
      }

      const q = m.quoted;

      // ─── Step 2: حاول تستخرج النص ───
      const extractedText = extractText(q);

      if (extractedText) {
        try {
          fs.writeFileSync(filePath, extractedText, 'utf8');
          const reloaded = await reloadPlugin(filePath);
          return m.reply(adamStyle('SAVED SUCCESSFULLY ✅', [
            { icon: '📁', text: `المسار: ${filePath}` },
            { icon: '📊', text: `الحجم: ${Buffer.byteLength(extractedText, 'utf8')} بايت` },
            { icon: '🔄', text: reloaded ? 'تم تحميل البلجن تلقائياً ✅' : 'أعد تشغيل البوت لتفعيل البلجن' }
          ]));
        } catch (err) {
          return m.reply(adamStyle('SAVE ERROR ❌', [
            { icon: '⚠️', text: err.message || String(err) }
          ]));
        }
      }

      // ─── Step 3: حاول تحمّل كملف ───
      const mime = getMime(q);
      const fileName = getFileName(q);
      const isJsFile = fileName.toLowerCase().endsWith('.js') || isJsMime(mime);

      // لو مفيش mime ولا اسم ملف .js → الرسالة مش نص ومش ملف معروف
      if (!mime && !isJsFile) {
        return m.reply(adamStyle('CANNOT READ CODE', [
          { icon: '❌', text: 'لا يمكن قراءة الكود من هذه الرسالة' },
          { icon: '💡', text: 'أرسل الكود كرسالة نصية عادية وارد عليها' },
          { icon: '💡', text: 'أو ارفق ملف .js وارد عليه' }
        ]));
      }

      // لو فيه mime بس مش JS
      if (mime && !isJsFile) {
        return m.reply(adamStyle('UNSUPPORTED FORMAT', [
          { icon: '🚫', text: `نوع الملف غير مدعوم: ${mime}` },
          { icon: '💡', text: 'يُسمح فقط بالنصوص أو ملفات .js' }
        ]));
      }

      // ─── تحميل الملف ───
      try {
        const buffer = await q.download();

        // تحقق أنه مش صورة أو فيديو
        const detected = await fileTypeFromBuffer(buffer).catch(() => null);
        if (detected) {
          const isSafe = ['text/', 'application/javascript', 'application/x-javascript', 'application/octet-stream']
            .some(t => detected.mime.startsWith(t));
          if (!isSafe) {
            return m.reply(adamStyle('INVALID FILE', [
              { icon: '🚫', text: `الملف من نوع: ${detected.mime}` },
              { icon: '💡', text: 'يُسمح فقط بملفات الجافاسكريبت' }
            ]));
          }
        }

        const fileContent = buffer.toString('utf8');
        if (!fileContent.trim()) {
          return m.reply(adamStyle('EMPTY FILE', [
            { icon: '❗', text: 'الملف فارغ أو لا يحتوي على كود' }
          ]));
        }

        fs.writeFileSync(filePath, fileContent, 'utf8');
        const reloaded = await reloadPlugin(filePath);

        return m.reply(adamStyle('SAVED SUCCESSFULLY ✅', [
          { icon: '📁', text: `المسار: ${filePath}` },
          { icon: '📊', text: `الحجم: ${buffer.byteLength} بايت` },
          { icon: '🔄', text: reloaded ? 'تم تحميل البلجن تلقائياً ✅' : 'أعد تشغيل البوت لتفعيل البلجن' }
        ]));

      } catch (err) {
        return m.reply(adamStyle('DOWNLOAD ERROR ❌', [
          { icon: '⚠️', text: err.message || String(err) },
          { icon: '💡', text: 'أرسل الكود كرسالة نصية عادية وارد عليها' }
        ]));
      }
    }

    // ════════════════════════════════════════════
    // أمر الحذف
    // ════════════════════════════════════════════
    case 'امسح': {
      if (!fs.existsSync(filePath)) {
        return m.reply(adamStyle('FILE NOT FOUND', [
          { icon: '🔍', text: `الملف "${filePath}" غير موجود` },
          { icon: '💡', text: 'تأكد من الاسم وأعد المحاولة' }
        ]));
      }

      try {
        fs.unlinkSync(filePath);

        try {
          const absPath = path.resolve(filePath);
          if (global.plugins?.[absPath]) delete global.plugins[absPath];
        } catch (_) {}

        return m.reply(adamStyle('DELETED SUCCESSFULLY 🗑️', [
          { icon: '✅', text: `تم حذف: ${filePath}` },
          { icon: '🔄', text: 'تم إزالة البلجن من الذاكرة' }
        ]));
      } catch (err) {
        return m.reply(adamStyle('DELETE ERROR ❌', [
          { icon: '⚠️', text: err.message || String(err) }
        ]));
      }
    }

    // ─── افتراضي ──────────────────────────────
    default:
      return m.reply(adamStyle('UNKNOWN COMMAND', [
        { icon: '❓', text: 'الأمر غير معروف' },
        { icon: '💡', text: `${usedPrefix}احفظ <اسم> ← رد على كود أو ملف .js` },
        { icon: '💡', text: `${usedPrefix}امسح <اسم> ← حذف بلجن` }
      ]));
  }
};

handler.help = ['احفظ', 'امسح'];
handler.tags = ['owner'];
handler.command = ['احفظ', 'امسح'];
handler.owner = true;

export default handler;