const {
  getContentType,
  downloadContentFromMessage,
  jidDecode,
  areJidsSameUser,
  proto,
  generateForwardMessageContent,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  generateWAMessageContent,
  getAggregateVotesInPollMessage,
} = require("@whiskeysockets/baileys")

const fs = require("fs-extra")
const path = require("path")
const axios = require("axios")
const chalk = require("chalk")
const FormData = require("form-data")

const config = require("./config")
const { userDB, groupDB, statsDB, rpgDB, economyDB } = require("./lib/database")
const { AI, ImageGen, Downloader, Tools, Info, AnimeImage, Fun, Sticker } = require("./lib/freeapi")
const { Scraper } = require("./lib/scraper")
const {
  getTime, getDate, getDateTime, getGreeting,
  formatJid, isGroup, formatSize, formatNumber,
  formatDuration, formatRupiah, randomItem, randomNumber,
  sleep, generateRandomString, isUrl, getBuffer,
  createHeader, createFooter, isSpam, getMentions,
  progressBar, calculateLevel, expToNextLevel,
} = require("./lib/helper")

function serializeMessage(sock, message, store) {
  const m = message
  if (!m.message) return m

  const mtype = getContentType(m.message)
  const msg = m.message[mtype] || m.message

  m.mtype = mtype
  m.from = m.key.remoteJid
  m.isGroup = m.from?.endsWith("@g.us")
  m.sender = m.isGroup
    ? m.key.participant || m.key.remoteJid
    : m.key.fromMe ? sock.user.id : m.key.remoteJid
  m.senderNumber = m.sender?.split("@")[0]
  m.fromMe = m.key.fromMe
  m.pushName = m.pushName || m.sender?.split("@")[0]
  m.timestamp = typeof m.messageTimestamp === "number"
    ? m.messageTimestamp
    : m.messageTimestamp?.toNumber?.()

  // Text content
  m.body = typeof msg === "string"
    ? msg
    : msg?.text || msg?.caption || msg?.conversation ||
      m.message?.conversation || m.message?.extendedTextMessage?.text || ""

  // Quoted message
  m.quoted = null
  const contextInfo = msg?.contextInfo
  if (contextInfo?.quotedMessage) {
    const qmtype = getContentType(contextInfo.quotedMessage)
    m.quoted = {
      key: {
        remoteJid: m.from,
        fromMe: contextInfo.participant === sock.user?.id,
        id: contextInfo.stanzaId,
        participant: contextInfo.participant,
      },
      message: contextInfo.quotedMessage,
      mtype: qmtype,
      text: contextInfo.quotedMessage?.conversation ||
        contextInfo.quotedMessage?.[qmtype]?.text ||
        contextInfo.quotedMessage?.[qmtype]?.caption || "",
      sender: contextInfo.participant,
      senderNumber: contextInfo.participant?.split("@")[0],
    }
  }

  // Mention
  m.mentionedJid = contextInfo?.mentionedJid || []

  // Media
  m.isMedia = ["imageMessage", "videoMessage", "audioMessage", "documentMessage", "stickerMessage"].includes(mtype)
  m.mimetype = msg?.mimetype || ""

  return m
}

async function reply(sock, jid, text, message) {
  return sock.sendMessage(jid, { text: String(text) }, { quoted: message })
}

async function react(sock, jid, emoji, message) {
  return sock.sendMessage(jid, {
    react: { text: emoji, key: message.key },
  })
}

async function sendImage(sock, jid, buffer, caption = "", quoted = null) {
  const opts = { image: Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer), caption }
  return sock.sendMessage(jid, opts, quoted ? { quoted } : {})
}

async function sendVideo(sock, jid, buffer, caption = "", quoted = null) {
  const opts = { video: Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer), caption, mimetype: "video/mp4" }
  return sock.sendMessage(jid, opts, quoted ? { quoted } : {})
}

async function sendAudio(sock, jid, buffer, ptt = false, quoted = null) {
  const opts = { audio: Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer), mimetype: "audio/mpeg", ptt }
  return sock.sendMessage(jid, opts, quoted ? { quoted } : {})
}

async function sendSticker(sock, jid, buffer, quoted = null) {
  return sock.sendMessage(jid, { sticker: buffer }, quoted ? { quoted } : {})
}

async function downloadMedia(message) {
  const mtype = getContentType(message.message)
  const msg = message.message[mtype]
  const stream = await downloadContentFromMessage(msg, mtype.replace("Message", ""))
  const chunks = []
  for await (const chunk of stream) chunks.push(chunk)
  return Buffer.concat(chunks)
}

function isOwner(jid) {
  const number = jid.split("@")[0].split(":")[0]
  return config.ownerNumber.includes(number)
}

async function isAdmin(sock, groupId, jid) {
  try {
    const metadata = await sock.groupMetadata(groupId)
    const admins = metadata.participants
      .filter(p => p.admin)
      .map(p => p.id)
    return admins.includes(jid)
  } catch {
    return false
  }
}

async function isBotAdmin(sock, groupId) {
  try {
    const metadata = await sock.groupMetadata(groupId)
    const botJid = sock.user?.id
    const botParticipant = metadata.participants.find(p =>
      areJidsSameUser(p.id, botJid)
    )
    return botParticipant?.admin ? true : false
  } catch {
    return false
  }
}

async function processMessage(sock, rawMessage, store) {
  try {
    const m = serializeMessage(sock, rawMessage, store)
    if (!m.from || !m.body) return

    const {
      from, body, sender, senderNumber, fromMe,
      isGroup: isGroupMsg, pushName, quoted, mtype,
    } = m

    // ─── Get prefix command ───
    const prefix = config.prefix
    const isCommand = body.startsWith(prefix)
    const args = body.trim().slice(prefix.length).split(/\s+/).filter(Boolean)
    const command = isCommand ? args.shift()?.toLowerCase() : ""
    const text = args.join(" ")
    const q = text

    // ─── User & Group data ───
    const userData = userDB.getUser(sender)
    const groupData = isGroupMsg ? groupDB.getGroup(from) : null

    // ─── Permissions ───
    const ownerOnly = isOwner(sender)
    const adminStatus = isGroupMsg ? await isAdmin(sock, from, sender) : false
    const botAdminStatus = isGroupMsg ? await isBotAdmin(sock, from) : false
    const isPremiumUser = userData.premium || ownerOnly

    // ─── Update user stats ───
    if (!userData.banned) {
      userDB.updateUser(sender, {
        name: pushName,
        lastSeen: Date.now(),
        totalCommand: (userData.totalCommand || 0) + (isCommand ? 1 : 0),
      })
    }

    // ─── Banned check ───
    if (userData.banned && !ownerOnly) return

    // ─── Anti spam ───
    if (config.antiSpam && isCommand && isSpam(sender)) return

    // ─── Group settings ───
    if (isGroupMsg && groupData) {
      // Anti link
      if (groupData.antilink && !adminStatus && !ownerOnly) {
        if (isUrl(body) || /chat\.whatsapp\.com/.test(body)) {
          await sock.sendMessage(from, {
            delete: m.key,
          })
          await reply(sock, from, `⚠️ @${senderNumber} dilarang mengirim link!`, m)
          return
        }
      }

      // Mute
      if (groupData.mute && !adminStatus && !ownerOnly && isCommand) {
        await reply(sock, from, "🔇 Grup sedang dalam mode mute!", m)
        return
      }
    }

    // ─── Log command ───
    if (isCommand) {
      console.log(
        chalk.cyan(`  [${getTime()}]`),
        chalk.yellow(`[CMD]`),
        chalk.white(`${pushName}`),
        chalk.gray(`(${senderNumber})`),
        chalk.green(`${prefix}${command}`),
        q ? chalk.gray(`"${q}"`) : ""
      )
      statsDB.increment(command)
    }

    // ─── Check limit ───
    if (isCommand && !ownerOnly && !isPremiumUser) {
      const limit = userDB.getLimit(sender)
      if (limit <= 0) {
        await reply(sock, from,
          `╭─「 *⚠️ LIMIT HABIS* 」\n│\n│ Limit harianmu sudah habis!\n│\n│ 💎 Upgrade ke premium untuk\n│ limit unlimited!\n│\n│ 📞 Hubungi owner:\n│ wa.me/${config.ownerNumber[0]}\n│\n╰─────────────────\n> ${config.footer}`,
          m
        )
        return
      }
      userDB.reduceLimit(sender, 1)
    }

    // ─────────────────────────────────────
    //         AFK HANDLER
    // ─────────────────────────────────────
    if (isGroupMsg && !isCommand) {
      // Check if sender has AFK
      if (userData.afk) {
        userDB.updateUser(sender, { afk: false, afkReason: "", afkTime: 0 })
        const afkDuration = Date.now() - userData.afkTime
        const mins = Math.floor(afkDuration / 60000)
        await reply(sock, from, `👋 @${senderNumber} sudah kembali dari AFK (${mins} menit)`, m)
      }

      // Check if mentioned someone who's AFK
      for (const mention of m.mentionedJid) {
        const mentionedUser = userDB.getUser(mention)
        if (mentionedUser.afk) {
          const mins = Math.floor((Date.now() - mentionedUser.afkTime) / 60000)
          await reply(sock, from,
            `💤 @${mention.split("@")[0]} sedang AFK\n📝 Alasan: ${mentionedUser.afkReason || "Tidak ada alasan"}\n⏰ Sudah: ${mins} menit`,
            m
          )
        }
      }
    }

    // ─────────────────────────────────────
    //         LEVEL UP CHECK
    // ─────────────────────────────────────
    if (!isCommand && isGroupMsg) {
      const { levelUp, newLevel } = userDB.addExp(sender, randomNumber(1, 5))
      if (levelUp && (groupData?.levelup !== false)) {
        await sock.sendMessage(from, {
          text: `🎉 Selamat @${senderNumber}!\nKamu naik ke Level *${newLevel}*! 🆙`,
          mentions: [sender],
        })
      }
    }

    if (!isCommand) return


    // React to processing
    await react(sock, from, config.reacts.wait, m)

    switch (command) {


      case "menu":
      case "help":
      case "start": {
        const menuText = `
╭─⊹「 *VITA BOT MENU* 」
│ ${getGreeting()}, *${pushName}*!
│ Selamat datang di VITA v${config.botVersion}
│ 📊 *STATUS MU*
│ 👤 Name: ${pushName}
│ 🏆 Level: ${userData.level || 1}
│ 💰 Coins: ${formatNumber(userData.coins || 0)}
│ 💎 Limit: ${userDB.getLimit(sender)}/${isPremiumUser ? "∞" : "20"}
│ ⭐ Status: ${isPremiumUser ? "Premium" : "Free"}
├─「 📋 *KATEGORI MENU* 」
│ ${prefix}menu1 - 📥 Downloader
│ ${prefix}menu2 - 🤖 AI & Chat
│ ${prefix}menu3 - 🎨 Image & Sticker
│ ${prefix}menu4 - 👥 Group Tools
│ ${prefix}menu5 - 🎮 Games & Fun
│ ${prefix}menu6 - 💰 Economy
│ ${prefix}menu7 - ⚔️ RPG System
│ ${prefix}menu8 - 🔧 Utility Tools
│ ${prefix}menu9 - 🕌 Islami
│ ${prefix}menu10 - 📱 Info & Search
│ ${prefix}menu11 - 🎵 Music
│ ${prefix}menu12 - 👑 Owner Only
├─「 📊 *BOT STATS* 」
│ 📨 Total CMD: ${statsDB.data.totalCommands || 0}
│ 👥 Users: ${Object.keys(userDB.all()).length}
│ 🕐 Uptime: ${formatDuration(process.uptime())}
╰─────────────⊹
`.trim()
        await react(sock, from, config.reacts.love, m)
        await reply(sock, from, menuText, m)
        break
      }

      case "menu1": {
        const text = `
╭─「 📥 *DOWNLOADER MENU* 」
│ ${prefix}tiktok [url]
│ ${prefix}tiktokmp3 [url]
│ ${prefix}tt [url]
│ ${prefix}ytmp4 [url]
│ ${prefix}ytmp3 [url]
│ ${prefix}yta [url] - audio only
│ ${prefix}ytv [url] - video
│ ${prefix}yt [query] - search
│ ${prefix}igdl [url] - instagram
│ ${prefix}fbdl [url] - facebook
│ ${prefix}twitter [url]
│ ${prefix}snack [url]
│ ${prefix}capcut [url]
│ ${prefix}pinterest [query]
│ ${prefix}gdrive [url]
│ ${prefix}mediafire [url]
│ ${prefix}spotifydl [query]
│ ${prefix}soundcloud [url]
│ ${prefix}apk [nama app]
│ ${prefix}playstore [query]
╰─────────────⊹
> 🌸 VITA BOT 2026 | Made with ❤️`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "menu2": {
        const text = `
╭─「 🤖 *AI* 」
│ ${prefix}ai [text] 
│ ${prefix}gpt [text] 
│ ${prefix}gemini [text] 
│ ${prefix}groq [text] 
│ ${prefix}imagine [prompt] 
│ ${prefix}dalle [prompt] 
│ ${prefix}txt2img [prompt] 
│ ${prefix}chatbot on/off
│ ${prefix}reset 
│ ${prefix}tts [text] 
│ ${prefix}tr [lang] [text] 
│ ${prefix}treid [text] 
│ ${prefix}treen [text] 
│ ${prefix}lang [text] 
╰─────────────⊹
`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "menu3": {
        const text = `
╭─「 🎨 *IMAGE & STICKER* 」
│ ${prefix}sticker / ${prefix}s 
│ ${prefix}toimg 
│ ${prefix}stickertext [text]
│ ${prefix}brat [text] 
│ ${prefix}wasted 
│ ${prefix}triggered
│ ${prefix}jail
│ ${prefix}blur 
│ ${prefix}enhance 
│ ${prefix}removebg 
│ ${prefix}cartoon 
│ ${prefix}hdr 
│ ${prefix}gray 
│ ${prefix}flip 
│ ${prefix}mirror 
│ ${prefix}rotate [deg] 
│ ${prefix}crop 
│ ${prefix}resize [w] [h]
│ ${prefix}watermark [text]
│ ${prefix}meme [top] | [bottom]
│ ${prefix}caption [text]
│ ${prefix}attp [text] 
│ ${prefix}qr [text] 
│ ${prefix}toqr [text]
╰─────────────⊹
`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "menu4": {
        const text = `
╭─「 👥 *GROUP TOOLS MENU* 」
│ 👑 Admin Only:
│ ${prefix}kick [@mention]
│ ${prefix}add [nomor]
│ ${prefix}promote [@mention]
│ ${prefix}demote [@mention]
│ ${prefix}everyone / ${prefix}tagall
│ ${prefix}hidetag [text]
│ ${prefix}mute on/off
│ ${prefix}open / ${prefix}close
│ ${prefix}link 
│ ${prefix}revoke 
│ ${prefix}setname [nama]
│ ${prefix}setdesc [deskripsi]
│ ${prefix}setppgc [img] 
│
│ ⚙️ Group Settings:
│ ${prefix}welcome on/off
│ ${prefix}goodbye on/off
│ ${prefix}antilink on/off
│ ${prefix}antispam on/off
│ ${prefix}antiflood on/off
│ ${prefix}antinsfw on/off
│ ${prefix}antihoax on/off
│ ${prefix}levelup on/off
│ ${prefix}nsfw on/off
│
│ 📊 Info Grup:
│ ${prefix}groupinfo / ${prefix}gi
│ ${prefix}admins
│ ${prefix}members / ${prefix}listmember
│ ${prefix}gclink
│ ${prefix}warn [@mention]
│ ${prefix}resetwarn [@mention]
│ ${prefix}getwarn [@mention]
│ ${prefix}banned - list banned user
╰─────────────⊹
`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "menu5": {
        const text = `
╭─「 🎮 *GAMES & FUN MENU* 」
│ 🎲 Games:
│ ${prefix}tebakgambar 
│ ${prefix}tebakkata 
│ ${prefix}tebaklirik 
│ ${prefix}tebakanime 
│ ${prefix}tebakbendera 
│ ${prefix}tebaklogo 
│ ${prefix}quiz 
│ ${prefix}truth
│ ${prefix}dare 
│ ${prefix}siapakah
│
│ 🎯 Mini Games:
│ ${prefix}ttt [X/O] 
│ ${prefix}chess 
│ ${prefix}hangman 
│ ${prefix}wordle 
│ ${prefix}akinator
│ ${prefix}sambungkata
│ ${prefix}duels [@mention] 
│
│ 🎰 Luck Games:
│ ${prefix}slot 
│ ${prefix}dadu 
│ ${prefix}koin 
│ ${prefix}spin 
│ ${prefix}lottery 
│ ${prefix}jackpot
│
│ 😂 Fun:
│ ${prefix}joke 
│ ${prefix}meme 
│ ${prefix}quote
│ ${prefix}advice 
│ ${prefix}roast [@mention] 
│ ${prefix}rizz [text] 
│ ${prefix}pick [opt1/opt2]
│ ${prefix}rate [sesuatu] 
│ ${prefix}ship [@1] [@2] 
│ ${prefix}zodiak [tgl/bln]
│ ${prefix}primbon [nama]
│ ${prefix}ramal [pertanyaan]
╰─────────────⊹
`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "menu6": {
        const text = `
╭─「 💰 *ECONOMY MENU* 」
│ 💳 Account:
│ ${prefix}dompet / ${prefix}wallet
│ ${prefix}daily 
│ ${prefix}weekly 
│ ${prefix}work / ${prefix}kerja
│ ${prefix}crime / ${prefix}nyolong
│ ${prefix}rob [@mention] 
│
│ 🏦 Banking:
│ ${prefix}deposit [amount]
│ ${prefix}withdraw [amount]
│ ${prefix}transfer [@mention] [amount]
│ ${prefix}saldo
│
│ 🏪 Shop:
│ ${prefix}shop / ${prefix}toko
│ ${prefix}buy [item]
│ ${prefix}inventory / ${prefix}inv
│ ${prefix}use [item]
│ ${prefix}sell [item] [amount]
│
│ 📊 Leaderboard:
│ ${prefix}topcoin / ${prefix}richest
│ ${prefix}toplevel
╰─────────────⊹
`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "menu7": {
        const text = `
╭─「 ⚔️ *RPG SYSTEM MENU* 」
│ 🎮 Character:
│ ${prefix}start 
│ ${prefix}profile 
│ ${prefix}class [nama] 
│ ${prefix}status 
│ ${prefix}inventory 
│
│ ⚔️ Battle:
│ ${prefix}battle [@mention] 
│ ${prefix}monster 
│ ${prefix}dungeon 
│ ${prefix}boss 
│ ${prefix}arena 
│
│ 🏪 Shop:
│ ${prefix}shop 
│ ${prefix}buy [item]
│ ${prefix}equip [item]
│ ${prefix}unequip [slot]
│ ${prefix}upgrade [item]
│
│ 💊 Recovery:
│ ${prefix}heal 
│ ${prefix}rest 
│
│ 🗺️ Explore:
│ ${prefix}hunt 
│ ${prefix}fish 
│ ${prefix}mine 
│ ${prefix}farm 
│
│ 📊 Ranking:
│ ${prefix}ranking 
│ ${prefix}topbattle
╰─────────────⊹
`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "menu8": {
        const text = `
╭─「 🔧 *UTILITY TOOLS* 」
│ 🌐 Web & Network:
│ ${prefix}ip [alamat] 
│ ${prefix}whois [domain]
│ ${prefix}ping [domain]
│ ${prefix}screenshot [url]
│ ${prefix}shortlink [url]
│ ${prefix}base64enc [text]
│ ${prefix}base64dec [text]
│ ${prefix}md5 [text]
│ ${prefix}sha256 [text]
│ ${prefix}binary [text]
│ ${prefix}morse [text]
│ ${prefix}hex [text]
│
│ 💱 Converter:
│ ${prefix}kurs [from] [to] [amount]
│ ${prefix}cuaca [kota] 
│ ${prefix}timezone [kota]
│ ${prefix}calorie [makanan]
│ ${prefix}bmi [tb] [bb]
│ ${prefix}convert [amount] [from] [to]
│
│ 📝 Text Tools:
│ ${prefix}reverse [text]
│ ${prefix}upper [text]
│ ${prefix}lower [text]
│ ${prefix}bold [text]
│ ${prefix}italic [text]
│ ${prefix}strike [text]
│ ${prefix}spoiler [text]
│ ${prefix}zalgo [text]
│ ${prefix}clapback [text]
│ ${prefix}aesthetic [text]
│ ${prefix}smallcaps [text]
│ ${prefix}count [text]
│ ${prefix}password [length]
╰─────────────⊹
`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "menu9": {
        const text = `
╭─「 🕌 *ISLAMI MENU* 」
│ 📖 Al-Quran:
│ ${prefix}quran [surah]:[ayat]
│ ${prefix}quranrandom 
│ ${prefix}surah [nomor] 
│ ${prefix}carisurah [nama] 
│ ${prefix}tafsir [surah]:[ayat]
│ ${prefix}lastread 
│
│ 🕌 Jadwal Sholat:
│ ${prefix}jadwalsholat [kota]
│ ${prefix}sholat [kota]
│ ${prefix}imsak [kota]
│ ${prefix}asmaul [nomor] 
│
│ 📿 Doa & Dzikir:
│ ${prefix}doa [kategori]
│ ${prefix}dzikir
│ ${prefix}hadits
│ ${prefix}kalimat 
│
│ 📅 Kalender Islam:
│ ${prefix}hijriah 
│ ${prefix}tarawih 
╰─────────────⊹
`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "menu10": {
        const text = `
╭─「 📱 *INFO & SEARCH MENU* 」
│ 🔍 Search:
│ ${prefix}google [query]
│ ${prefix}wiki [query]
│ ${prefix}kbbi [kata]
│ ${prefix}sinonim [kata]
│ ${prefix}antonim [kata]
│
│ 🎬 Entertainment:
│ ${prefix}anime [judul]
│ ${prefix}manga [judul]
│ ${prefix}movie [judul]
│ ${prefix}drakor [judul]
│ ${prefix}lirik [judul - artis]
│ ${prefix}spotify [lagu]
│
│ 📰 News:
│ ${prefix}news 
│ ${prefix}teknologi 
│ ${prefix}olahraga
│ ${prefix}hiburan
│
│ 💹 Finance:
│ ${prefix}saham [kode] 
│ ${prefix}crypto [nama]
│ ${prefix}bitcoin
│ ${prefix}kurs [mata uang]
│
│ 📦 Package:
│ ${prefix}npm [package]
│ ${prefix}github [user/repo]
│ ${prefix}pypi [package]
╰─────────────⊹
`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "menu11": {
        const text = `
╭─「 🎵 *MUSIC MENU* 」
│ ${prefix}play [judul lagu]
│ ${prefix}playlist [query]
│ ${prefix}lyrics [judul - artis]
│ ${prefix}music [query]
│ ${prefix}chord [judul lagu]
│ ${prefix}artist [nama]
│ ${prefix}album [nama album]
│ ${prefix}recommend 
│ ${prefix}top10 
│ ${prefix}nowplaying
╰─────────────⊹
`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "menu12": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        const text = `
╭─「 👑 *OWNER MENU* 」
│ 👥 User Management:
│ ${prefix}addprem [@/nomor] 
│ ${prefix}delprem [@/nomor] 
│ ${prefix}ban [@/nomor]
│ ${prefix}unban [@/nomor]
│ ${prefix}resetlimit [@/nomor]
│ ${prefix}addlimit [@/nomor] [amount]
│
│ 💰 Economy Control:
│ ${prefix}addcoin [@/nomor] [amount]
│ ${prefix}setcoin [@/nomor] [amount]
│ ${prefix}addexp [@/nomor] [amount]
│
│ 📢 Broadcast:
│ ${prefix}broadcast [text]
│ ${prefix}bc [text]
│ ${prefix}bcgc [text] 
│
│ ⚙️ Bot Settings:
│ ${prefix}setowner [nomor]
│ ${prefix}setprefix [prefix]
│ ${prefix}setbotname [nama]
│ ${prefix}maintenance on/off
│
│ 🔧 System:
│ ${prefix}eval [code]
│ ${prefix}exec [command]
│ ${prefix}restart
│ ${prefix}cleartemp 
│ ${prefix}stats 
│ ${prefix}listgroup 
│ ${prefix}listuser 
│ ${prefix}join [link grup]
│ ${prefix}leave [groupId]
╰─────────────⊹
`.trim()
        await reply(sock, from, text, m)
        break
      }

      case "tiktok":
      case "tt": {
        if (!q) return reply(sock, from, "❌ Masukkan URL TikTok!\nContoh: .tt https://vt.tiktok.com/xxx", m)
        try {
          await react(sock, from, "⏳", m)
          const data = await Downloader.tiktok(q)
          const caption = `
╭─「 *TikTok Downloader* 」
│ 📝 ${data.title || "No title"}
│ 👤 ${data.author || "Unknown"}
│ ⏱️ ${formatDuration(data.duration || 0)}
│ 👁️ ${formatNumber(data.views || 0)} views
│ ❤️ ${formatNumber(data.likes || 0)} likes
╰─────────────────`.trim()

          const videoBuffer = await getBuffer(data.videoHD || data.video)
          await sendVideo(sock, from, videoBuffer, caption, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Gagal download TikTok: ${e.message}`, m)
        }
        break
      }

      case "tiktokmp3": {
        if (!q) return reply(sock, from, "❌ Masukkan URL TikTok!", m)
        try {
          await react(sock, from, "⏳", m)
          const data = await Downloader.tiktok(q)
          const audioBuffer = await getBuffer(data.audio)
          await sendAudio(sock, from, audioBuffer, false, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "ytmp4":
      case "ytv": {
        if (!q) return reply(sock, from, "❌ Masukkan URL/judul YouTube!\nContoh: .ytmp4 https://youtube.com/watch?v=xxx", m)
        try {
          await react(sock, from, "⏳", m)
          await reply(sock, from, "⏳ Sedang memproses video YouTube...", m)
          const result = await Downloader.youtubeDl(q, "video")
          if (result.url || result.stream) {
            const videoBuffer = await getBuffer(result.url || result.stream)
            await sendVideo(sock, from, videoBuffer,
              `🎬 ${result.title || "YouTube Video"}\n> ${config.footer}`, m)
          } else {
            await reply(sock, from, `🔗 Link download:\n${result.url}`, m)
          }
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Gagal download: ${e.message}`, m)
        }
        break
      }

      case "ytmp3":
      case "yta": {
        if (!q) return reply(sock, from, "❌ Masukkan URL/judul YouTube!", m)
        try {
          await react(sock, from, "⏳", m)
          await reply(sock, from, "⏳ Sedang memproses audio YouTube...", m)
          const result = await Downloader.youtubeDl(q, "audio")
          if (result.url) {
            const audioBuffer = await getBuffer(result.url)
            await sendAudio(sock, from, audioBuffer, false, m)
          } else {
            await reply(sock, from, `🔗 Link audio:\n${result.url || "Tidak tersedia"}`, m)
          }
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "ytsearch":
      case "yt": {
        if (!q) return reply(sock, from, "❌ Masukkan kata kunci pencarian!", m)
        try {
          const results = await Downloader.youtubeSearch(q)
          let text = `╭─「 *🎬 YouTube Search* 」\n│\n│ 🔍 Query: ${q}\n│\n`
          results.slice(0, 5).forEach((v, i) => {
            text += `│ ${i + 1}. *${v.title}*\n│    ⏱️ ${v.duration} | 👁️ ${formatNumber(v.views || 0)}\n│    📺 ${v.author}\n│    🔗 ${v.url}\n│\n`
          })
          text += `╰─────────────────\n> ${config.footer}`
          await reply(sock, from, text, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "igdl":
      case "instagram": {
        if (!q) return reply(sock, from, "❌ Masukkan URL Instagram!", m)
        try {
          await react(sock, from, "⏳", m)
          const data = await Downloader.instagram(q)
          await reply(sock, from, `📷 *Instagram Downloader*\n🔗 Link: ${data.url || data.media?.[0]?.url || JSON.stringify(data)}`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "fbdl":
      case "facebook": {
        if (!q) return reply(sock, from, "❌ Masukkan URL Facebook!", m)
        try {
          await react(sock, from, "⏳", m)
          const data = await Downloader.facebook(q)
          await reply(sock, from, `📘 *Facebook Downloader*\n${JSON.stringify(data, null, 2)}`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "spotifydl":
      case "spotify": {
        if (!q) return reply(sock, from, "❌ Masukkan judul lagu!", m)
        try {
          await react(sock, from, "⏳", m)
          const results = await Downloader.spotifySearch(q)
          if (!results.length) return reply(sock, from, "❌ Lagu tidak ditemukan!", m)
          const song = results[0]
          let text = `╭─「 *🎵 Spotify Search* 」\n│\n│ 🎵 ${song.name}\n│ 👤 ${song.primaryArtists || "Unknown"}\n│ 💿 ${song.album?.name || "Unknown"}\n│ ⏱️ ${song.duration?.label || ""}\n│\n╰─────────────────\n> ${config.footer}`
          await reply(sock, from, text, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "ai":
      case "gpt":
      case "chatgpt": {
        if (!q) return reply(sock, from, "❌ Masukkan pertanyaan!\nContoh: .ai Apa itu AI?", m)
        try {
          await react(sock, from, "🤔", m)
          let response
          try {
            response = await AI.blackbox(q)
          } catch {
            response = await AI.freeGPT(q)
          }
          await reply(sock, from, `🤖 *VITA AI*\n\n${response}`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ AI Error: ${e.message}`, m)
        }
        break
      }

      case "groq": {
        if (!q) return reply(sock, from, "❌ Masukkan pertanyaan!", m)
        if (!config.groqApiKey || config.groqApiKey.includes("FREE_REGISTER")) {
          return reply(sock, from, "⚠️ Groq API belum dikonfigurasi.\nDaftar gratis di: https://console.groq.com", m)
        }
        try {
          await react(sock, from, "🤔", m)
          const response = await AI.groq(q, config.groqApiKey)
          await reply(sock, from, `🚀 *Groq AI (Llama3)*\n\n${response}`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "imagine":
      case "txt2img":
      case "dalle": {
        if (!q) return reply(sock, from, "❌ Masukkan deskripsi gambar!\nContoh: .imagine cute anime girl pink hair", m)
        try {
          await react(sock, from, "🎨", m)
          await reply(sock, from, `🎨 Sedang membuat gambar: "${q}"...`, m)
          const imageBuffer = await ImageGen.pollinations(q)
          await sendImage(sock, from, imageBuffer,
            `🎨 *AI Image Generator*\n📝 Prompt: ${q}\n> ${config.footer}`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Gagal generate: ${e.message}`, m)
        }
        break
      }

      case "tr":
      case "translate": {
        const parts = q.split(" ")
        const targetLang = parts[0]?.toLowerCase()
        const textToTranslate = parts.slice(1).join(" ")
        if (!textToTranslate) return reply(sock, from, "❌ Format: .tr [lang] [text]\nContoh: .tr en Halo dunia", m)
        try {
          const result = await Tools.translate(textToTranslate, "auto", targetLang)
          await reply(sock, from,
            `🌐 *Translator*\n│\n│ 🔤 Dari: ${result.from || "auto"}\n│ 📝 Ke: ${targetLang}\n│\n│ *Hasil:*\n${result.translated}`,
            m
          )
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "treid":
      case "idtranslate": {
        if (!q) return reply(sock, from, "❌ Masukkan teks!", m)
        try {
          const result = await Tools.translate(q, "auto", "id")
          await reply(sock, from, `🌐 *Terjemahan ke Indonesia:*\n\n${result.translated}`, m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "treen":
      case "entranslate": {
        if (!q) return reply(sock, from, "❌ Masukkan teks!", m)
        try {
          const result = await Tools.translate(q, "auto", "en")
          await reply(sock, from, `🌐 *Translation to English:*\n\n${result.translated}`, m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "sticker":
      case "s": {
        try {
          let mediaBuffer
          if (m.isMedia) {
            mediaBuffer = await downloadMedia(m)
          } else if (m.quoted?.mtype && ["imageMessage", "videoMessage", "stickerMessage"].includes(m.quoted.mtype)) {
            mediaBuffer = await downloadMedia({ ...m, message: m.quoted.message, key: m.quoted.key })
          } else {
            return reply(sock, from, "❌ Kirim/reply gambar, video, atau sticker dengan caption .s", m)
          }

          const sharp = require("sharp")
          let stickerBuffer

          if (m.mtype === "videoMessage" || m.quoted?.mtype === "videoMessage") {
            // Convert video to animated sticker
            const tempIn = `./temp/${generateRandomString()}.mp4`
            const tempOut = `./temp/${generateRandomString()}.webp`
            fs.writeFileSync(tempIn, mediaBuffer)

            const ffmpeg = require("fluent-ffmpeg")
            await new Promise((resolve, reject) => {
              ffmpeg(tempIn)
                .outputOptions([
                  "-vf", "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:white@0",
                  "-vcodec", "libwebp",
                  "-loop", "0",
                  "-ss", "00:00:00",
                  "-t", "00:00:08",
                  "-preset", "default",
                  "-an", "-vsync", "0",
                  "-s", "512:512",
                ])
                .toFormat("webp")
                .save(tempOut)
                .on("end", resolve)
                .on("error", reject)
            })

            stickerBuffer = fs.readFileSync(tempOut)
            fs.unlinkSync(tempIn)
            fs.unlinkSync(tempOut)
          } else {
            stickerBuffer = await sharp(mediaBuffer)
              .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
              .webp()
              .toBuffer()
          }

          await sendSticker(sock, from, stickerBuffer, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error buat sticker: ${e.message}`, m)
        }
        break
      }

      case "toimg": {
        try {
          let mediaBuffer
          if (m.mtype === "stickerMessage") {
            mediaBuffer = await downloadMedia(m)
          } else if (m.quoted?.mtype === "stickerMessage") {
            mediaBuffer = await downloadMedia({ ...m, message: m.quoted.message, key: m.quoted.key })
          } else {
            return reply(sock, from, "❌ Reply sticker dengan caption .toimg", m)
          }

          const sharp = require("sharp")
          const imgBuffer = await sharp(mediaBuffer).png().toBuffer()
          await sendImage(sock, from, imgBuffer, `> ${config.footer}`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "qr":
      case "toqr": {
        if (!q) return reply(sock, from, "❌ Masukkan teks yang mau dijadikan QR!", m)
        try {
          const qrBuffer = await Tools.generateQR(q)
          await sendImage(sock, from, qrBuffer,
            `📱 *QR Code*\n📝 Data: ${q.substring(0, 50)}\n> ${config.footer}`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "google": {
        if (!q) return reply(sock, from, "❌ Masukkan kata kunci!", m)
        try {
          const results = await Scraper.googleSearch(q)
          let text = `╭─「 *🔍 Google Search* 」\n│\n│ Query: ${q}\n│\n`
          results.forEach((r, i) => {
            text += `│ *${i + 1}. ${r.title}*\n│ ${r.snippet?.substring(0, 100) || ""}...\n│ 🔗 ${r.link}\n│\n`
          })
          text += `╰─────────────────\n> ${config.footer}`
          await reply(sock, from, text, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "wiki":
      case "wikipedia": {
        if (!q) return reply(sock, from, "❌ Masukkan kata kunci!", m)
        try {
          const data = await Scraper.wikipedia(q)
          let text = `╭─「 *📚 Wikipedia* 」\n│\n│ 📖 *${data.title}*\n│\n`
          const desc = data.description?.substring(0, 500) || "Tidak ada deskripsi"
          text += `│ ${desc}${desc.length >= 500 ? "..." : ""}\n│\n│ 🔗 ${data.url}\n╰─────────────────\n> ${config.footer}`
          if (data.thumbnail) {
            const imgBuffer = await getBuffer(data.thumbnail)
            await sendImage(sock, from, imgBuffer, text, m)
          } else {
            await reply(sock, from, text, m)
          }
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "kbbi": {
        if (!q) return reply(sock, from, "❌ Masukkan kata yang ingin dicari!", m)
        try {
          const data = await Scraper.kbbi(q)
          let text = `╭─「 *📚 KBBI* 」\n│\n│ 🔤 Kata: *${data.word}*\n│\n│ *Definisi:*\n`
          data.definitions.forEach((def, i) => {
            text += `│ ${i + 1}. ${def}\n`
          })
          text += `│\n╰─────────────────\n> ${config.footer}`
          await reply(sock, from, text, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Kata tidak ditemukan di KBBI`, m)
        }
        break
      }

      case "anime": {
        if (!q) return reply(sock, from, "❌ Masukkan judul anime!", m)
        try {
          const results = await Info.searchAnime(q)
          if (!results.length) return reply(sock, from, "❌ Anime tidak ditemukan!", m)
          const anime = results[0]
          const text = `
╭─「 *🎌 Anime Info* 」
│ 📺 *${anime.title?.romaji || anime.title}*
│ 🇯🇵 JP: ${anime.title?.native || "-"}
│ 📊 Score: ⭐ ${anime.score || "-"}/10
│ 📅 Tahun: ${anime.year || "-"}
│ 📋 Status: ${anime.status || "-"}
│ 🎬 Episode: ${anime.episodes || "-"}
│ 🎭 Genre: ${anime.genres?.join(", ") || "-"}
│
│ 📝 *Synopsis:*
│ ${anime.synopsis?.substring(0, 300) || "-"}...
│ 🔗 MAL ID: ${anime.mal_id}
╰─────────────────
> ${config.footer}`.trim()

          if (anime.images?.jpg?.large_image_url) {
            const imgBuffer = await getBuffer(anime.images.jpg.large_image_url)
            await sendImage(sock, from, imgBuffer, text, m)
          } else {
            await reply(sock, from, text, m)
          }
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "manga": {
        if (!q) return reply(sock, from, "❌ Masukkan judul manga!", m)
        try {
          const results = await Info.searchManga(q)
          if (!results.length) return reply(sock, from, "❌ Manga tidak ditemukan!", m)
          const manga = results[0]
          const text = `
╭─「 *📖 Manga Info* 」
│ 📕 *${manga.title}*
│ 📊 Score: ⭐ ${manga.score || "-"}/10
│ 📋 Status: ${manga.status || "-"}
│ 📚 Chapter: ${manga.chapters || "?"}
│ 📖 Volume: ${manga.volumes || "?"}
│ 🎭 Genre: ${manga.genres?.map(g => g.name).join(", ") || "-"}
│
│ 📝 *Synopsis:*
│ ${manga.synopsis?.substring(0, 300) || "-"}...
╰─────────────────
> ${config.footer}`.trim()
          await reply(sock, from, text, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "cuaca":
      case "weather": {
        if (!q) return reply(sock, from, "❌ Masukkan nama kota!\nContoh: .cuaca Jakarta", m)
        try {
          const data = await Tools.weather(q)
          const text = `
╭─「 *🌤️ Info Cuaca* 」
│ 📍 Lokasi: *${data.city}, ${data.country}*
│ 🌡️ Suhu: ${data.temp}°C
│ 🤔 Terasa: ${data.feelsLike}°C
│ 💧 Kelembaban: ${data.humidity}%
│ 💨 Angin: ${data.windSpeed} km/h
│ 👁️ Jarak Pandang: ${data.visibility} km
│ ☁️ Kondisi: ${data.description}
╰─────────────────
> ${config.footer}`.trim()
          await reply(sock, from, text, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "kurs":
      case "exchange": {
        const parts = q.split(" ")
        if (parts.length < 2) return reply(sock, from, "❌ Format: .kurs [FROM] [TO] [amount]\nContoh: .kurs USD IDR 100", m)
        try {
          const from_currency = parts[0].toUpperCase()
          const to_currency = parts[1].toUpperCase()
          const amount = parseFloat(parts[2]) || 1
          const data = await Tools.exchange(from_currency, to_currency, amount)
          await reply(sock, from,
            `💱 *Kurs Mata Uang*\n│\n│ ${amount} ${data.from} = *${data.result.toFixed(2)} ${data.to}*\n│ Rate: 1 ${data.from} = ${data.rate} ${data.to}\n╰─────────────────\n> ${config.footer}`,
            m
          )
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "ip":
      case "ipinfo": {
        if (!q) return reply(sock, from, "❌ Masukkan IP address!\nContoh: .ip 8.8.8.8", m)
        try {
          const data = await Tools.ipinfo(q)
          const text = `
╭─「 *🌐 IP Info* 」
│ 🔢 IP: ${data.ip}
│ 🏙️ Kota: ${data.city}
│ 🌏 Negara: ${data.country_name} ${data.country}
│ 📍 Region: ${data.region}
│ 🗺️ Koordinat: ${data.latitude}, ${data.longitude}
│ 🌐 ISP: ${data.org}
│ ⏰ Timezone: ${data.timezone}
╰─────────────────
> ${config.footer}`.trim()
          await reply(sock, from, text, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "github": {
        if (!q) return reply(sock, from, "❌ Masukkan username GitHub!", m)
        try {
          const data = await Info.githubUser(q)
          const text = `
╭─「 *📦 GitHub User* 」
│ 👤 Name: ${data.name || data.login}
│ 🆔 Username: @${data.login}
│ 📝 Bio: ${data.bio || "-"}
│ 🏢 Company: ${data.company || "-"}
│ 📍 Location: ${data.location || "-"}
│ 📧 Email: ${data.email || "-"}
│ 🔗 Blog: ${data.blog || "-"}
│ 📦 Repos: ${data.public_repos}
│ 👥 Followers: ${formatNumber(data.followers)}
│ 👤 Following: ${formatNumber(data.following)}
╰─────────────────
> ${config.footer}`.trim()
          const avatarBuffer = await getBuffer(data.avatar_url)
          await sendImage(sock, from, avatarBuffer, text, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ User tidak ditemukan!`, m)
        }
        break
      }

      case "npm": {
        if (!q) return reply(sock, from, "❌ Masukkan nama package!", m)
        try {
          const res = await axios.get(`https://registry.npmjs.org/${q}`)
          const data = res.data
          const latest = data["dist-tags"]?.latest
          const ver = data.versions?.[latest]
          const text = `
╭─「 *📦 NPM Package* 」
│ 📦 Name: ${data.name}
│ 🏷️ Version: ${latest}
│ 📝 Desc: ${data.description || "-"}
│ 👤 Author: ${ver?.author?.name || data.author?.name || "-"}
│ 📜 License: ${ver?.license || "-"}
│ 📥 Downloads: ${data.downloads || "-"}
│ 🔗 Homepage: ${ver?.homepage || "-"}
╰─────────────────
> ${config.footer}`.trim()
          await reply(sock, from, text, m)
          await react(sock, from, "✅", m)
        } catch {
          await reply(sock, from, `❌ Package tidak ditemukan!`, m)
        }
        break
      }

      case "lyrics": {
        if (!q) return reply(sock, from, "❌ Format: .lyrics [judul - artis]", m)
        try {
          const parts = q.split(" - ")
          const song = parts[0]?.trim()
          const artist = parts[1]?.trim() || ""
          const lyricsText = await Info.getLyrics(artist, song)
          await reply(sock, from,
            `🎵 *Lyrics: ${q}*\n\n${lyricsText?.substring(0, 2000) || "Lirik tidak ditemukan"}`,
            m
          )
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Lirik tidak ditemukan!`, m)
        }
        break
      }

      case "quran": {
        if (!q) return reply(sock, from, "❌ Format: .quran [surah]:[ayat]\nContoh: .quran 1:1", m)
        try {
          const [surahNum, ayatNum] = q.split(":").map(Number)
          const surah = await Info.getQuranSurah(surahNum)
          const ayat = surah.ayat?.find(a => a.nomorAyat === ayatNum)
          if (!ayat) return reply(sock, from, "❌ Ayat tidak ditemukan!", m)

          const text = `
╭─「 *📖 Al-Qur'an* 」
│ 📚 Surah: *${surah.namaLatin}* (${surah.nama})
│ 📖 Ayat: ${ayatNum} dari ${surah.jumlahAyat}
│ 🕌 Arti: ${surah.arti}
│
│ *Arab:*
│ ${ayat.teksArab}
│
│ *Latin:*
│ ${ayat.teksLatin}
│
│ *Terjemahan:*
│ ${ayat.teksIndonesia}
╰─────────────────
> ${config.footer}`.trim()
          await reply(sock, from, text, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "surah":
      case "carisurah": {
        if (!q) return reply(sock, from, "❌ Masukkan nama/nomor surah!", m)
        try {
          if (!isNaN(q)) {
            const surah = await Info.getQuranSurah(parseInt(q))
            const text = `
╭─「 *📖 Info Surah* 」
│ 📚 Nama: *${surah.namaLatin}* (${surah.nama})
│ 🔢 Nomor: ${surah.nomor}
│ 📖 Ayat: ${surah.jumlahAyat}
│ 📍 Tempat: ${surah.tempatTurun}
│ 🌙 Arti: ${surah.arti}
│
│ *Deskripsi:*
│ ${surah.deskripsi?.substring(0, 300)}...
╰─────────────────
> ${config.footer}`.trim()
            await reply(sock, from, text, m)
          } else {
            const results = await Info.searchQuran(q)
            let text = `╭─「 *📖 Cari Surah* 」\n│\n│ Query: ${q}\n│\n`
            results.slice(0, 10).forEach(s => {
              text += `│ ${s.nomor}. *${s.namaLatin}* - ${s.arti} (${s.jumlahAyat} ayat)\n`
            })
            text += `│\n╰─────────────────\n> ${config.footer}`
            await reply(sock, from, text, m)
          }
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "jadwalsholat":
      case "sholat": {
        const city = q || "Jakarta"
        try {
          const timings = await Info.prayerTime(city)
          const text = `
╭─「 *🕌 Jadwal Sholat* 」
│ 📍 Kota: *${city}*
│ 📅 ${getDate()}
│
│ 🌅 Subuh: ${timings.Fajr}
│ ☀️ Dzuhur: ${timings.Dhuhr}
│ 🌤️ Ashar: ${timings.Asr}
│ 🌅 Maghrib: ${timings.Maghrib}
│ 🌙 Isya: ${timings.Isha}
│ 🌙 Imsak: ${timings.Imsak}
│ 🌅 Sunrise: ${timings.Sunrise}
╰─────────────────
> ${config.footer}`.trim()
          await reply(sock, from, text, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "truth": {
        const question = await Fun.truthQuestion()
        await reply(sock, from,
          `🎲 *TRUTH*\n\n❓ ${question}\n\n> ${config.footer}`, m)
        await react(sock, from, "🎲", m)
        break
      }

      case "dare": {
        const challenge = await Fun.dareQuestion()
        await reply(sock, from,
          `🎲 *DARE*\n\n🎯 ${challenge}\n\n> ${config.footer}`, m)
        await react(sock, from, "🎯", m)
        break
      }

      case "slot": {
        const emojis = ["🍎", "🍊", "🍋", "🍇", "🍓", "⭐", "💎", "7️⃣", "🎰"]
        const s1 = randomItem(emojis)
        const s2 = randomItem(emojis)
        const s3 = randomItem(emojis)
        const won = s1 === s2 && s2 === s3
        const semi = s1 === s2 || s2 === s3 || s1 === s3

        let reward = 0
        let result = "Coba lagi!"

        if (won) {
          reward = 1000
          result = "JACKPOT! 🎉"
          userDB.addCoins(sender, reward)
        } else if (semi) {
          reward = 100
          result = "Hampir! 😅"
          userDB.addCoins(sender, reward)
        }

        await reply(sock, from,
          `🎰 *SLOT MACHINE*\n\n┌─────────────┐\n│  ${s1} │ ${s2} │ ${s3}  │\n└─────────────┘\n\n${won ? "🎉 JACKPOT!!!" : semi ? "😅 Hampir!" : "❌ Coba lagi!"}\n${reward > 0 ? `💰 +${reward} coins` : ""}\n\n> ${config.footer}`,
          m
        )
        await react(sock, from, won ? "🎉" : "🎰", m)
        break
      }

      case "dadu": {
        const dice = randomNumber(1, 6)
        const diceEmoji = ["", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣"]
        await reply(sock, from,
          `🎲 *LEMPAR DADU*\n\nHasilnya: ${diceEmoji[dice]} (${dice})\n\n> ${config.footer}`, m)
        await react(sock, from, "🎲", m)
        break
      }

      case "koin": {
        const result = randomItem(["Kepala", "Ekor"])
        const emoji = result === "Kepala" ? "🪙" : "🟡"
        await reply(sock, from,
          `🪙 *LEMPAR KOIN*\n\nHasilnya: ${emoji} *${result}*\n\n> ${config.footer}`, m)
        await react(sock, from, "🪙", m)
        break
      }

      case "joke": {
        const joke = await Fun.randomJoke()
        await reply(sock, from, `😂 *Joke Time!*\n\n${joke}\n\n> ${config.footer}`, m)
        await react(sock, from, "😂", m)
        break
      }

      case "meme": {
        try {
          const meme = await Fun.randomMeme()
          const imgBuffer = await getBuffer(meme.url)
          await sendImage(sock, from, imgBuffer,
            `😂 *${meme.title}*\n📍 r/${meme.subreddit}\n> ${config.footer}`, m)
          await react(sock, from, "😂", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "quote": {
        try {
          const quote = await Fun.randomQuote()
          await reply(sock, from,
            `✨ *Quote of the Day*\n\n"${quote.content}"\n\n— *${quote.author}*\n\n> ${config.footer}`, m)
          await react(sock, from, "✨", m)
        } catch (e) {
          const quotes = [
            "Jangan takut gagal, takutlah tidak pernah mencoba.",
            "Setiap hari adalah kesempatan baru untuk menjadi lebih baik.",
            "Mimpi besar, kerja keras, terus belajar.",
            "Tidak ada jalan pintas menuju kesuksesan.",
            "Hari ini lebih baik dari kemarin.",
          ]
          await reply(sock, from, `✨ *Quote*\n\n"${randomItem(quotes)}"\n\n> ${config.footer}`, m)
        }
        break
      }

      case "advice": {
        try {
          const advice = await Fun.randomAdvice()
          await reply(sock, from,
            `💡 *Nasihat Hari Ini*\n\n${advice}\n\n> ${config.footer}`, m)
          await react(sock, from, "💡", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "pick": {
        if (!q.includes("/")) return reply(sock, from, "❌ Format: .pick opsi1/opsi2/opsi3\nContoh: .pick makan/minum/tidur", m)
        const options = q.split("/").map(o => o.trim()).filter(Boolean)
        const chosen = randomItem(options)
        await reply(sock, from,
          `🎯 *VITA MEMILIH*\n\n${options.map((o, i) => `${i + 1}. ${o}`).join("\n")}\n\n✨ Pilihanku: *${chosen}*\n\n> ${config.footer}`, m)
        await react(sock, from, "🎯", m)
        break
      }

      case "rate": {
        if (!q) return reply(sock, from, "❌ Masukkan sesuatu yang mau dirate!", m)
        const rating = randomNumber(1, 100)
        let emoji = rating >= 80 ? "🔥" : rating >= 60 ? "✨" : rating >= 40 ? "😐" : rating >= 20 ? "😅" : "💀"
        await reply(sock, from,
          `${emoji} *VITA BOT RATES*\n\n📊 ${q}\n\n${progressBar(rating, 100)} ${rating}/100\n\n> ${config.footer}`, m)
        await react(sock, from, emoji, m)
        break
      }

      case "ship": {
        if (m.mentionedJid.length < 2) return reply(sock, from, "❌ Tag 2 orang!\nContoh: .ship @user1 @user2", m)
        const [user1, user2] = m.mentionedJid
        const u1 = user1.split("@")[0]
        const u2 = user2.split("@")[0]
        const shipScore = randomNumber(1, 100)
        let shipEmoji = shipScore >= 80 ? "💕 Jodoh banget!" : shipScore >= 60 ? "😍 Cocok nih!" : shipScore >= 40 ? "😊 Lumayan~" : "😅 Kurang cocok"

        await sock.sendMessage(from, {
          text: `💘 *SHIP METER*\n\n@${u1} + @${u2}\n\n${progressBar(shipScore, 100)} ${shipScore}%\n\n${shipEmoji}\n\n> ${config.footer}`,
          mentions: [user1, user2],
        }, { quoted: m })
        await react(sock, from, "💘", m)
        break
      }

      case "roast": {
        const roasts = [
          "Wajahmu kayak refresh F5 tapi halamannya error terus 😅",
          "Kamu tuh spesial... kayak password yang selalu salah",
          "IQ kamu kayak wifi tetangga, ada tapi ga bisa connect",
          "Kamu tuh kayak charger HP, penting tapi sering ketinggalan",
          "Otakmu kayak RAM 512MB, loading terus",
        ]
        const target = m.mentionedJid[0]
        const roast = randomItem(roasts)
        if (target) {
          await sock.sendMessage(from, {
            text: `🔥 *ROASTED!*\n\n@${target.split("@")[0]}\n\n${roast}\n\n> ${config.footer}`,
            mentions: [target],
          }, { quoted: m })
        } else {
          await reply(sock, from, `🔥 *ROASTED!*\n\n${roast}\n\n> ${config.footer}`, m)
        }
        await react(sock, from, "🔥", m)
        break
      }

      case "rizz": {
        const rizzLines = [
          "Kamu tahu ga? Tiap kamu tersenyum, bunga-bunga di taman cemburu 🌸",
          "Kalau kamu adalah wifi, aku mau connect seumur hidup 📶❤️",
          "Matamu itu kayak bintang, selalu bikin aku susah tidur ✨",
          "Kata dokter aku perlu vitamin U setiap hari 💊",
          "Kamu tuh kayak kopi pagi, bikin hari-hariku lebih bermakna ☕",
          "Boleh minta GPS-mu? Soalnya aku udah nyasar di matamu 👀",
        ]
        const target = m.mentionedJid[0]
        const line = q ? `${q} ❤️` : randomItem(rizzLines)
        if (target) {
          await sock.sendMessage(from, {
            text: `😏 *RIZZ LINE*\n\n@${target.split("@")[0]}\n\n"${line}"\n\n> ${config.footer}`,
            mentions: [target],
          }, { quoted: m })
        } else {
          await reply(sock, from, `😏 *RIZZ LINE*\n\n"${line}"\n\n> ${config.footer}`, m)
        }
        await react(sock, from, "😏", m)
        break
      }

      // ══════════════════════════════════════
      //  💰 ECONOMY COMMANDS
      // ══════════════════════════════════════

      case "dompet":
      case "wallet":
      case "balance": {
        const acc = economyDB.getAccount(sender)
        const user = userDB.getUser(sender)
        const text = `
╭─「 *💰 Dompet* 」
│ 👤 ${pushName}
│ 🏷️ Level: ${user.level || 1}
│ ⭐ Status: ${isPremiumUser ? "Premium 💎" : "Free"}
│
│ 💵 Saldo: ${formatRupiah(acc.balance)}
│ 🏦 Bank: ${formatRupiah(acc.bank)}
│ 💰 Koin: ${formatNumber(user.coins || 0)} 🪙
│ 💎 Diamond: ${user.diamonds || 0}
│
│ 📊 Limit hari ini: ${userDB.getLimit(sender)}
╰─────────────────
> ${config.footer}`.trim()
        await reply(sock, from, text, m)
        await react(sock, from, "💰", m)
        break
      }

      case "daily": {
        const acc = economyDB.getAccount(sender)
        const now = Date.now()
        const cooldown = 86400000 // 24 jam

        if (now - (acc.lastDaily || 0) < cooldown) {
          const remaining = cooldown - (now - (acc.lastDaily || 0))
          const hours = Math.floor(remaining / 3600000)
          const mins = Math.floor((remaining % 3600000) / 60000)
          return reply(sock, from,
            `⏰ Daily reward sudah diklaim!\n\nCoba lagi dalam *${hours} jam ${mins} menit*`, m)
        }

        const reward = isPremiumUser ? randomNumber(2000, 5000) : randomNumber(500, 2000)
        economyDB.updateAccount(sender, {
          balance: (acc.balance || 0) + reward,
          lastDaily: now,
        })
        userDB.addCoins(sender, isPremiumUser ? 100 : 50)

        await reply(sock, from,
          `✅ *Daily Reward Claimed!*\n\n💰 +${formatRupiah(reward)}\n🪙 +${isPremiumUser ? 100 : 50} coins\n\nKlaim lagi dalam 24 jam!\n\n> ${config.footer}`, m)
        await react(sock, from, "🎁", m)
        break
      }

      case "work":
      case "kerja": {
        const acc = economyDB.getAccount(sender)
        const now = Date.now()
        const cooldown = 3600000 // 1 jam

        if (now - (acc.lastWork || 0) < cooldown) {
          const remaining = cooldown - (now - (acc.lastWork || 0))
          const mins = Math.floor(remaining / 60000)
          return reply(sock, from, `⏰ Kamu baru kerja!\n\nIstirahat dulu, coba lagi dalam *${mins} menit*`, m)
        }

        const jobs = [
          { job: "Programmer", min: 300, max: 800 },
          { job: "Designer", min: 200, max: 600 },
          { job: "Youtuber", min: 100, max: 500 },
          { job: "Pedagang", min: 150, max: 400 },
          { job: "Dokter", min: 400, max: 900 },
          { job: "Driver Ojol", min: 100, max: 350 },
          { job: "Content Creator", min: 200, max: 700 },
        ]

        const job = randomItem(jobs)
        const earned = randomNumber(job.min, job.max)
        economyDB.updateAccount(sender, {
          balance: (acc.balance || 0) + earned,
          lastWork: now,
        })

        await reply(sock, from,
          `💼 *Bekerja sebagai ${job.job}*\n\n💰 Kamu mendapat ${formatRupiah(earned)}\n\nKerja lagi dalam 1 jam!\n\n> ${config.footer}`, m)
        await react(sock, from, "💼", m)
        break
      }

      case "transfer": {
        const target = m.mentionedJid[0]
        const amount = parseInt(args[args.length - 1])
        if (!target || !amount || amount <= 0) {
          return reply(sock, from, "❌ Format: .transfer @mention [jumlah]\nContoh: .transfer @user 1000", m)
        }
        const acc = economyDB.getAccount(sender)
        if (acc.balance < amount) {
          return reply(sock, from, `❌ Saldo tidak cukup!\nSaldo kamu: ${formatRupiah(acc.balance)}`, m)
        }
        economyDB.transfer(sender, target, amount)
        await sock.sendMessage(from, {
          text: `✅ *Transfer Berhasil!*\n\n💸 ${formatRupiah(amount)} telah dikirim ke @${target.split("@")[0]}\n\n> ${config.footer}`,
          mentions: [target],
        }, { quoted: m })
        await react(sock, from, "✅", m)
        break
      }

      case "topcoin":
      case "richest": {
        const top = userDB.getTopCoins(10)
        let text = `╭─「 *🏆 TOP COINS* 」\n│\n`
        top.forEach((u, i) => {
          const medals = ["🥇", "🥈", "🥉"]
          const medal = medals[i] || `${i + 1}.`
          text += `│ ${medal} ${u.name || u.id.split("@")[0]} - 🪙 ${formatNumber(u.coins || 0)}\n`
        })
        text += `│\n╰─────────────────\n> ${config.footer}`
        await reply(sock, from, text, m)
        await react(sock, from, "🏆", m)
        break
      }

      case "toplevel": {
        const top = userDB.getTopLevel(10)
        let text = `╭─「 *🏆 TOP LEVEL* 」\n│\n`
        top.forEach((u, i) => {
          const medals = ["🥇", "🥈", "🥉"]
          const medal = medals[i] || `${i + 1}.`
          text += `│ ${medal} ${u.name || u.id.split("@")[0]} - Lv.${u.level || 1}\n`
        })
        text += `│\n╰─────────────────\n> ${config.footer}`
        await reply(sock, from, text, m)
        await react(sock, from, "🏆", m)
        break
      }

      // ══════════════════════════════════════
      //  ⚔️ RPG COMMANDS
      // ══════════════════════════════════════

      case "rpgstart":
      case "mulairpg": {
        const player = rpgDB.getPlayer(sender)
        if (player.class !== "Novice") {
          return reply(sock, from, `⚔️ Kamu sudah memulai RPG sebagai *${player.class}*!`, m)
        }
        const text = `
╭─「 *⚔️ VITA RPG* 」
│ Selamat datang, *${pushName}*!
│ Petualanganmu dimulai sekarang!
│
│ 📊 *Stats Awal:*
│ ❤️ HP: ${player.hp}/${player.maxHp}
│ 💧 MP: ${player.mp}/${player.maxMp}
│ ⚔️ ATK: ${player.atk}
│ 🛡️ DEF: ${player.def}
│ ⚡ SPD: ${player.spd}
│ 💰 Gold: ${player.gold}
│
│ Pilih class dengan:
│ .class [warrior/mage/archer/rogue]
╰─────────────────
> ${config.footer}`.trim()
        await reply(sock, from, text, m)
        await react(sock, from, "⚔️", m)
        break
      }

      case "class": {
        const classes = {
          warrior: { name: "Warrior", atk: 20, def: 15, hp: 150, mp: 30, spd: 8, emoji: "⚔️" },
          mage: { name: "Mage", atk: 30, def: 5, hp: 80, mp: 100, spd: 10, emoji: "🧙" },
          archer: { name: "Archer", atk: 25, def: 10, hp: 100, mp: 50, spd: 15, emoji: "🏹" },
          rogue: { name: "Rogue", atk: 22, def: 8, hp: 90, mp: 40, spd: 20, emoji: "🗡️" },
          paladin: { name: "Paladin", atk: 18, def: 20, hp: 130, mp: 60, spd: 7, emoji: "🛡️" },
        }
        const selectedClass = classes[q?.toLowerCase()]
        if (!selectedClass) {
          return reply(sock, from,
            `❌ Class tidak valid!\nClass tersedia:\n${Object.entries(classes).map(([k, v]) => `${v.emoji} ${v.name}`).join("\n")}`, m)
        }
        rpgDB.updatePlayer(sender, {
          class: selectedClass.name,
          atk: selectedClass.atk,
          def: selectedClass.def,
          maxHp: selectedClass.hp,
          hp: selectedClass.hp,
          maxMp: selectedClass.mp,
          mp: selectedClass.mp,
          spd: selectedClass.spd,
        })
        await reply(sock, from,
          `${selectedClass.emoji} *Class ${selectedClass.name} Dipilih!*\n\n⚔️ ATK: ${selectedClass.atk}\n🛡️ DEF: ${selectedClass.def}\n❤️ HP: ${selectedClass.hp}\n💧 MP: ${selectedClass.mp}\n⚡ SPD: ${selectedClass.spd}\n\nSelamat bertarung, *${selectedClass.name}*!\n\n> ${config.footer}`,
          m
        )
        await react(sock, from, selectedClass.emoji, m)
        break
      }

      case "profile":
      case "rpgprofile": {
        const player = rpgDB.getPlayer(sender)
        const text = `
╭─「 *⚔️ RPG Profile* 」
│ 👤 *${pushName}*
│ ⚔️ Class: ${player.class}
│ 🏆 Level: ${player.level}
│ ✨ EXP: ${player.exp}
│
│ 📊 *Stats:*
│ ❤️ HP: ${player.hp}/${player.maxHp}
│ 💧 MP: ${player.mp}/${player.maxMp}
│ ⚔️ ATK: ${player.atk}
│ 🛡️ DEF: ${player.def}
│ ⚡ SPD: ${player.spd}
│
│ 💰 Gold: ${player.gold}
│ 🏆 Wins: ${player.wins}
│ 💀 Losses: ${player.losses}
│ ☠️ Kills: ${player.kills}
╰─────────────────
> ${config.footer}`.trim()
        await reply(sock, from, text, m)
        await react(sock, from, "⚔️", m)
        break
      }

      case "hunt":
      case "berburu": {
        const player = rpgDB.getPlayer(sender)
        const now = Date.now()
        if (now - (player.lastBattle || 0) < 60000) {
          const remaining = Math.ceil((60000 - (now - player.lastBattle)) / 1000)
          return reply(sock, from, `⏰ Kamu lelah! Tunggu *${remaining} detik* lagi.`, m)
        }

        const monsters = [
          { name: "Slime", hp: 20, atk: 5, exp: 15, gold: 10, emoji: "🟢" },
          { name: "Goblin", hp: 35, atk: 10, exp: 25, gold: 20, emoji: "👺" },
          { name: "Wolf", hp: 50, atk: 15, exp: 40, gold: 30, emoji: "🐺" },
          { name: "Skeleton", hp: 60, atk: 18, exp: 50, gold: 40, emoji: "💀" },
          { name: "Dragon", hp: 200, atk: 50, exp: 200, gold: 200, emoji: "🐲" },
        ]

        const monster = randomItem(monsters)
        const damage = Math.max(1, player.atk - randomNumber(0, 5))
        const monsterDamage = Math.max(1, monster.atk - player.def)
        const won = damage >= monster.hp || player.hp > monsterDamage

        rpgDB.updatePlayer(sender, { lastBattle: now })

        if (won) {
          const expGain = monster.exp + randomNumber(0, 10)
          const goldGain = monster.gold + randomNumber(0, 10)
          const newHp = Math.max(1, player.hp - monsterDamage)
          rpgDB.updatePlayer(sender, {
            hp: newHp,
            exp: player.exp + expGain,
            gold: player.gold + goldGain,
            wins: (player.wins || 0) + 1,
            kills: (player.kills || 0) + 1,
          })
          await reply(sock, from,
            `${monster.emoji} *BERBURU*\n\nKamu bertemu *${monster.name}*!\n\n⚔️ Damage: ${damage}\n💔 Kamu terkena: ${monsterDamage} damage\n\n✅ *MENANG!*\n✨ +${expGain} EXP\n💰 +${goldGain} Gold\n❤️ HP: ${newHp}/${player.maxHp}\n\n> ${config.footer}`,
            m
          )
          await react(sock, from, "✅", m)
        } else {
          const newHp = Math.max(1, player.hp - monsterDamage * 2)
          rpgDB.updatePlayer(sender, {
            hp: newHp,
            losses: (player.losses || 0) + 1,
          })
          await reply(sock, from,
            `${monster.emoji} *BERBURU*\n\nKamu bertemu *${monster.name}*!\n\n⚔️ Damage: ${damage}\n💔 Kamu terkena: ${monsterDamage * 2} damage\n\n❌ *KALAH!*\n❤️ HP: ${newHp}/${player.maxHp}\n\n💊 Gunakan .heal untuk memulihkan HP\n\n> ${config.footer}`,
            m
          )
          await react(sock, from, "❌", m)
        }
        break
      }

      case "heal": {
        const player = rpgDB.getPlayer(sender)
        if (player.hp >= player.maxHp) return reply(sock, from, "❤️ HP kamu sudah penuh!", m)
        if (player.gold < 50) return reply(sock, from, "❌ Gold tidak cukup! (Butuh 50 gold)", m)

        const healAmount = Math.floor(player.maxHp * 0.5)
        const newHp = Math.min(player.maxHp, player.hp + healAmount)
        rpgDB.updatePlayer(sender, { hp: newHp, gold: player.gold - 50 })
        await reply(sock, from,
          `💊 *Heal!*\n\n❤️ HP: ${player.hp} → ${newHp}/${player.maxHp}\n💰 -50 Gold\n\n> ${config.footer}`, m)
        await react(sock, from, "💊", m)
        break
      }


      case "reverse": {
        if (!q) return reply(sock, from, "❌ Masukkan teks!", m)
        await reply(sock, from, `🔄 *Reversed:*\n${q.split("").reverse().join("")}`, m)
        break
      }

      case "upper": {
        if (!q) return reply(sock, from, "❌ Masukkan teks!", m)
        await reply(sock, from, q.toUpperCase(), m)
        break
      }

      case "lower": {
        if (!q) return reply(sock, from, "❌ Masukkan teks!", m)
        await reply(sock, from, q.toLowerCase(), m)
        break
      }

      case "bold": {
        if (!q) return reply(sock, from, "❌ Masukkan teks!", m)
        await reply(sock, from, `*${q}*`, m)
        break
      }

      case "italic": {
        if (!q) return reply(sock, from, "❌ Masukkan teks!", m)
        await reply(sock, from, `_${q}_`, m)
        break
      }

      case "strike": {
        if (!q) return reply(sock, from, "❌ Masukkan teks!", m)
        await reply(sock, from, `~${q}~`, m)
        break
      }

      case "clapback": {
        if (!q) return reply(sock, from, "❌ Masukkan teks!", m)
        await reply(sock, from, q.split(" ").join(" 👏 "), m)
        break
      }

      case "aesthetic": {
        if (!q) return reply(sock, from, "❌ Masukkan teks!", m)
        const aesthetic = q.split("").map(c => {
          const base = c.charCodeAt(0)
          if (base >= 65 && base <= 90) return String.fromCharCode(base + 65248)
          if (base >= 97 && base <= 122) return String.fromCharCode(base + 65248)
          if (base >= 48 && base <= 57) return String.fromCharCode(base + 65248)
          return c
        }).join(" ")
        await reply(sock, from, aesthetic, m)
        break
      }

      case "base64enc": {
        if (!q) return reply(sock, from, "❌ Masukkan teks!", m)
        const encoded = Buffer.from(q).toString("base64")
        await reply(sock, from, `🔐 *Base64 Encoded:*\n${encoded}`, m)
        break
      }

      case "base64dec": {
        if (!q) return reply(sock, from, "❌ Masukkan teks base64!", m)
        try {
          const decoded = Buffer.from(q, "base64").toString("utf-8")
          await reply(sock, from, `🔓 *Base64 Decoded:*\n${decoded}`, m)
        } catch {
          await reply(sock, from, "❌ Teks bukan base64 yang valid!", m)
        }
        break
      }

      case "password": {
        const length = parseInt(q) || 12
        const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*"
        const password = Array.from({ length: Math.min(length, 50) }, () =>
          chars[Math.floor(Math.random() * chars.length)]
        ).join("")
        await reply(sock, from,
          `🔐 *Password Generator*\n\nPanjang: ${length} karakter\n\n\`${password}\`\n\n> ${config.footer}`, m)
        break
      }

      case "shortlink":
      case "shorten": {
        if (!q || !isUrl(q)) return reply(sock, from, "❌ Masukkan URL yang valid!", m)
        try {
          const short = await Tools.shortenUrl(q)
          await reply(sock, from, `🔗 *Short URL*\n\n📎 Original: ${q}\n✂️ Short: ${short}\n\n> ${config.footer}`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "bmi": {
        const parts = q.split(" ")
        if (parts.length < 2) return reply(sock, from, "❌ Format: .bmi [tinggi_cm] [berat_kg]\nContoh: .bmi 170 65", m)
        const height = parseFloat(parts[0]) / 100 // cm to m
        const weight = parseFloat(parts[1])
        if (!height || !weight) return reply(sock, from, "❌ Masukkan angka yang valid!", m)
        const bmi = (weight / (height * height)).toFixed(1)
        let category = ""
        let emoji = ""
        if (bmi < 18.5) { category = "Kurus"; emoji = "🦴" }
        else if (bmi < 25) { category = "Normal"; emoji = "✅" }
        else if (bmi < 30) { category = "Gemuk"; emoji = "⚠️" }
        else { category = "Obesitas"; emoji = "🚨" }

        await reply(sock, from,
          `💪 *BMI Calculator*\n\n📏 Tinggi: ${(height * 100).toFixed(0)} cm\n⚖️ Berat: ${weight} kg\n\n📊 BMI: *${bmi}*\n${emoji} Kategori: *${category}*\n\n> ${config.footer}`, m)
        break
      }

      case "screenshot":
      case "ss": {
        if (!q || !isUrl(q)) return reply(sock, from, "❌ Masukkan URL yang valid!", m)
        try {
          await react(sock, from, "📸", m)
          await reply(sock, from, "📸 Mengambil screenshot...", m)
          const imgBuffer = await getBuffer(
            `https://api.apiflash.com/v1/urltoimage?url=${encodeURIComponent(q)}&response_type=image&format=png&scroll_page=false&width=1280&height=720`
          )
          await sendImage(sock, from, imgBuffer, `🌐 *Screenshot*\n🔗 ${q}\n> ${config.footer}`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }


      case "kick": {
        if (!isGroupMsg) return reply(sock, from, "❌ Command ini hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin yang bisa kick!", m)
        if (!botAdminStatus) return reply(sock, from, "❌ Bot harus jadi admin!", m)

        const target = m.mentionedJid[0] || m.quoted?.sender
        if (!target) return reply(sock, from, "❌ Tag atau reply pesan member yang mau di-kick!", m)
        if (isOwner(target)) return reply(sock, from, "❌ Tidak bisa kick owner!", m)

        try {
          await sock.groupParticipantsUpdate(from, [target], "remove")
          await reply(sock, from,
            `✅ @${target.split("@")[0]} telah di-kick dari grup!`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await reply(sock, from, `❌ Gagal kick: ${e.message}`, m)
        }
        break
      }

      case "add": {
        if (!isGroupMsg) return reply(sock, from, "❌ Command ini hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)
        if (!botAdminStatus) return reply(sock, from, "❌ Bot harus jadi admin!", m)
        if (!q) return reply(sock, from, "❌ Masukkan nomor yang mau ditambahkan!", m)

        const number = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
        try {
          await sock.groupParticipantsUpdate(from, [number], "add")
          await reply(sock, from, `✅ ${q} berhasil ditambahkan!`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await reply(sock, from, `❌ Gagal: ${e.message}`, m)
        }
        break
      }

      case "promote": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)
        if (!botAdminStatus) return reply(sock, from, "❌ Bot harus jadi admin!", m)

        const target = m.mentionedJid[0] || m.quoted?.sender
        if (!target) return reply(sock, from, "❌ Tag member yang mau dipromote!", m)

        try {
          await sock.groupParticipantsUpdate(from, [target], "promote")
          await sock.sendMessage(from, {
            text: `⭐ @${target.split("@")[0]} sekarang menjadi Admin!\n\n> ${config.footer}`,
            mentions: [target],
          }, { quoted: m })
          await react(sock, from, "✅", m)
        } catch (e) {
          await reply(sock, from, `❌ Gagal: ${e.message}`, m)
        }
        break
      }

      case "demote": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)
        if (!botAdminStatus) return reply(sock, from, "❌ Bot harus jadi admin!", m)

        const target = m.mentionedJid[0] || m.quoted?.sender
        if (!target) return reply(sock, from, "❌ Tag admin yang mau di-demote!", m)

        try {
          await sock.groupParticipantsUpdate(from, [target], "demote")
          await sock.sendMessage(from, {
            text: `⬇️ @${target.split("@")[0]} sudah bukan Admin.\n\n> ${config.footer}`,
            mentions: [target],
          }, { quoted: m })
          await react(sock, from, "✅", m)
        } catch (e) {
          await reply(sock, from, `❌ Gagal: ${e.message}`, m)
        }
        break
      }

      case "everyone":
      case "tagall": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)

        try {
          const groupMeta = await sock.groupMetadata(from)
          const members = groupMeta.participants.map(p => p.id)
          const mentions = members
          const tagText = members.map(m => `@${m.split("@")[0]}`).join(" ")
          const message = q || `📢 *TAG ALL MEMBER*\n\n${tagText}`

          await sock.sendMessage(from, {
            text: message + `\n\n> ${config.footer}`,
            mentions,
          }, { quoted: m })
          await react(sock, from, "✅", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "hidetag": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)

        try {
          const groupMeta = await sock.groupMetadata(from)
          const members = groupMeta.participants.map(p => p.id)
          await sock.sendMessage(from, {
            text: q || "📢 Perhatian semua member!",
            mentions: members,
          }, { quoted: m })
          await react(sock, from, "✅", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "mute": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)

        const toggle = q === "on" ? true : false
        groupDB.updateGroup(from, { mute: toggle })
        await reply(sock, from,
          `${toggle ? "🔇" : "🔊"} Grup ${toggle ? "di-mute" : "di-unmute"} untuk non-admin!`, m)
        await react(sock, from, toggle ? "🔇" : "🔊", m)
        break
      }

      case "open":
      case "close": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)
        if (!botAdminStatus) return reply(sock, from, "❌ Bot harus jadi admin!", m)

        try {
          const isOpen = command === "open"
          await sock.groupSettingUpdate(from, isOpen ? "not_announcement" : "announcement")
          await reply(sock, from,
            `${isOpen ? "🔓 Grup dibuka!" : "🔒 Grup ditutup!"} Hanya admin yang bisa kirim pesan.`, m)
          await react(sock, from, isOpen ? "🔓" : "🔒", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "link":
      case "gclink": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)

        try {
          const link = await sock.groupInviteCode(from)
          await reply(sock, from,
            `🔗 *Invite Link Grup*\n\nhttps://chat.whatsapp.com/${link}\n\n> ${config.footer}`, m)
          await react(sock, from, "✅", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "revoke": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)
        if (!botAdminStatus) return reply(sock, from, "❌ Bot harus jadi admin!", m)

        try {
          await sock.groupRevokeInvite(from)
          await reply(sock, from, "✅ Link grup berhasil di-reset!", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "groupinfo":
      case "gi": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        try {
          const meta = await sock.groupMetadata(from)
          const admins = meta.participants.filter(p => p.admin).map(p => `@${p.id.split("@")[0]}`).join(", ")
          const text = `
╭─「 *👥 Info Grup* 」
│ 📛 Nama: *${meta.subject}*
│ 🆔 ID: ${from}
│ 📝 Deskripsi: ${(meta.desc || "Tidak ada").substring(0, 100)}
│ 👥 Member: ${meta.participants.length}
│ 👑 Admin: ${admins || "Tidak ada"}
│ 📅 Dibuat: ${new Date(meta.creation * 1000).toLocaleDateString("id-ID")}
│ 📱 Creator: @${meta.owner?.split("@")[0] || "Unknown"}
╰─────────────────
> ${config.footer}`.trim()
          await sock.sendMessage(from, {
            text,
            mentions: meta.participants.filter(p => p.admin).map(p => p.id),
          }, { quoted: m })
          await react(sock, from, "✅", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "admins": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        try {
          const meta = await sock.groupMetadata(from)
          const admins = meta.participants.filter(p => p.admin)
          let text = `╭─「 *👑 Admin Grup* 」\n│\n`
          admins.forEach((a, i) => {
            text += `│ ${i + 1}. @${a.id.split("@")[0]} ${a.admin === "superadmin" ? "👑" : "⭐"}\n`
          })
          text += `│\n│ Total: ${admins.length} admin\n╰─────────────────\n> ${config.footer}`
          await sock.sendMessage(from, {
            text,
            mentions: admins.map(a => a.id),
          }, { quoted: m })
          await react(sock, from, "✅", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "welcome": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)

        const toggle = q === "on"
        groupDB.updateGroup(from, { welcome: toggle })
        await reply(sock, from,
          `${toggle ? "✅" : "❌"} Welcome message ${toggle ? "diaktifkan" : "dinonaktifkan"}!`, m)
        break
      }

      case "antilink": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)

        const toggle = q === "on"
        groupDB.updateGroup(from, { antilink: toggle })
        await reply(sock, from,
          `${toggle ? "✅" : "❌"} Anti-link ${toggle ? "diaktifkan" : "dinonaktifkan"}!`, m)
        break
      }

      case "warn": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)

        const target = m.mentionedJid[0] || m.quoted?.sender
        if (!target) return reply(sock, from, "❌ Tag member yang mau di-warn!", m)

        const warnCount = groupDB.addWarn(from, target)
        const maxWarn = 3

        await sock.sendMessage(from, {
          text: `⚠️ *WARNING #${warnCount}*\n\n@${target.split("@")[0]} mendapat peringatan!\n(${warnCount}/${maxWarn})\n\n${warnCount >= maxWarn ? "❌ Batas warning tercapai!" : `Alasan: ${q || "Tidak ada alasan"}`}\n\n> ${config.footer}`,
          mentions: [target],
        }, { quoted: m })

        if (warnCount >= maxWarn && botAdminStatus) {
          await sleep(1000)
          await sock.groupParticipantsUpdate(from, [target], "remove")
          groupDB.resetWarn(from, target)
          await sock.sendMessage(from, {
            text: `🚫 @${target.split("@")[0]} telah di-kick karena mencapai ${maxWarn} warning!`,
            mentions: [target],
          })
        }
        await react(sock, from, "✅", m)
        break
      }

      case "resetwarn": {
        if (!isGroupMsg) return reply(sock, from, "❌ Hanya untuk grup!", m)
        if (!adminStatus && !ownerOnly) return reply(sock, from, "❌ Hanya admin!", m)

        const target = m.mentionedJid[0] || m.quoted?.sender
        if (!target) return reply(sock, from, "❌ Tag member!", m)

        groupDB.resetWarn(from, target)
        await sock.sendMessage(from, {
          text: `✅ Warning @${target.split("@")[0]} telah di-reset!`,
          mentions: [target],
        }, { quoted: m })
        break
      }

      case "waifu": {
        try {
          const imgUrl = await AnimeImage.getWaifu("waifu")
          const imgBuffer = await getBuffer(imgUrl)
          await sendImage(sock, from, imgBuffer, `🌸 Waifu~\n> ${config.footer}`, m)
          await react(sock, from, "🌸", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "neko": {
        try {
          const imgUrl = await AnimeImage.getWaifu("neko")
          const imgBuffer = await getBuffer(imgUrl)
          await sendImage(sock, from, imgBuffer, `🐱 Neko~\n> ${config.footer}`, m)
          await react(sock, from, "🐱", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "hug": {
        try {
          const imgUrl = await AnimeImage.getWaifu("hug")
          const imgBuffer = await getBuffer(imgUrl)
          const target = m.mentionedJid[0]
          const caption = target
            ? `🤗 @${senderNumber} memeluk @${target.split("@")[0]}!\n> ${config.footer}`
            : `🤗 Hug~\n> ${config.footer}`
          await sendImage(sock, from, imgBuffer, caption, m)
          await react(sock, from, "🤗", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "pat": {
        try {
          const imgUrl = await AnimeImage.getWaifu("pat")
          const imgBuffer = await getBuffer(imgUrl)
          const target = m.mentionedJid[0]
          const caption = target
            ? `👋 @${senderNumber} menepuk @${target.split("@")[0]}!\n> ${config.footer}`
            : `👋 Pat pat~\n> ${config.footer}`
          await sendImage(sock, from, imgBuffer, caption, m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "kiss": {
        try {
          const imgUrl = await AnimeImage.getWaifu("kiss")
          const imgBuffer = await getBuffer(imgUrl)
          const target = m.mentionedJid[0]
          const caption = target
            ? `💋 @${senderNumber} mencium @${target.split("@")[0]}!\n> ${config.footer}`
            : `💋 Kiss~\n> ${config.footer}`
          await sendImage(sock, from, imgBuffer, caption, m)
          await react(sock, from, "💋", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      // ══════════════════════════════════════
      //  📊 USER PROFILE COMMANDS
      // ══════════════════════════════════════

      case "profil":
      case "myprofile": {
        const user = userDB.getUser(sender)
        const exp = user.exp || 0
        const level = user.level || 1
        const nextLevelExp = expToNextLevel(level)
        const text = `
╭─「 *👤 Profil* 」
│ 👤 Nama: *${pushName}*
│ 📱 Nomor: +${senderNumber}
│ ⭐ Status: ${isPremiumUser ? "Premium 💎" : "Free"}
│
│ 📊 *Statistik:*
│ 🏆 Level: ${level}
│ ✨ EXP: ${exp}/${nextLevelExp}
│ 📈 Progress: ${progressBar(exp, nextLevelExp, 10)}
│
│ 💰 *Economy:*
│ 🪙 Coins: ${formatNumber(user.coins || 0)}
│ 💎 Diamond: ${user.diamonds || 0}
│
│ 📱 *Activity:*
│ 📨 Total CMD: ${user.totalCommand || 0}
│ 📅 Join: ${new Date(user.joinDate || Date.now()).toLocaleDateString("id-ID")}
│ 👁️ Last seen: ${new Date(user.lastSeen || Date.now()).toLocaleDateString("id-ID")}
╰─────────────────
> ${config.footer}`.trim()
        await reply(sock, from, text, m)
        await react(sock, from, "👤", m)
        break
      }

      case "afk": {
        const reason = q || "Tidak ada alasan"
        userDB.updateUser(sender, {
          afk: true,
          afkReason: reason,
          afkTime: Date.now(),
        })
        await reply(sock, from,
          `💤 @${senderNumber} sedang AFK\n📝 Alasan: ${reason}\n\n> ${config.footer}`, m)
        await react(sock, from, "💤", m)
        break
      }

      case "ping": {
        const start = Date.now()
        const msg = await reply(sock, from, "🏓 Pinging...", m)
        const end = Date.now()
        await sock.sendMessage(from, {
          text: `🏓 *PONG!*\n\n⚡ Response: ${end - start}ms\n🕐 Uptime: ${formatDuration(process.uptime())}\n\n> ${config.footer}`,
        }, { quoted: m })
        await react(sock, from, "🏓", m)
        break
      }

      case "uptime": {
        await reply(sock, from,
          `⏰ *Uptime Bot*\n\n🕐 ${formatDuration(process.uptime())}\n📅 Started: ${new Date(Date.now() - process.uptime() * 1000).toLocaleString("id-ID")}\n\n> ${config.footer}`, m)
        break
      }

      case "botinfo": {
        const text = `
╭─「 *🤖 Bot Info* 」
│ 🤖 Nama: ${config.botName}
│ 📱 Version: v${config.botVersion}
│ 👤 Owner: ${config.ownerName}
│ 📅 ${getDateTime()}
│
│ 📊 *Statistik:*
│ 👥 Users: ${Object.keys(userDB.all()).length}
│ 📨 Total CMD: ${statsDB.data.totalCommands || 0}
│ ⏰ Uptime: ${formatDuration(process.uptime())}
│
│ 💻 *System:*
│ 🖥️ Platform: ${process.platform}
│ 📦 Node: ${process.version}
│ 💾 Memory: ${formatSize(process.memoryUsage().heapUsed)}
╰─────────────────
> ${config.footer}`.trim()
        await reply(sock, from, text, m)
        await react(sock, from, "🤖", m)
        break
      }

      case "owner": {
        const text = `
╭─「 *👑 Owner Info* 」
│ 👤 Nama: *${config.ownerName}*
│ 📱 WA: wa.me/${config.ownerNumber[0]}
│
│ 📝 Creator of VITA BOT
╰─────────────────
> ${config.footer}`.trim()
        await reply(sock, from, text, m)
        break
      }

      // ══════════════════════════════════════
      //  🐱🐶 ANIMAL COMMANDS
      // ══════════════════════════════════════

      case "dog":
      case "anjing": {
        try {
          const dogUrl = await Fun.randomDog()
          const imgBuffer = await getBuffer(dogUrl)
          await sendImage(sock, from, imgBuffer, `🐶 Woof!\n> ${config.footer}`, m)
          await react(sock, from, "🐶", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "cat":
      case "kucing": {
        try {
          const catUrl = await Fun.randomCat()
          const imgBuffer = await getBuffer(catUrl)
          await sendImage(sock, from, imgBuffer, `😺 Meow!\n> ${config.footer}`, m)
          await react(sock, from, "🐱", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "fox":
      case "rubah": {
        try {
          const foxUrl = await Fun.randomFox()
          const imgBuffer = await getBuffer(foxUrl)
          await sendImage(sock, from, imgBuffer, `🦊 Fox!\n> ${config.footer}`, m)
          await react(sock, from, "🦊", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      // ══════════════════════════════════════
      //  👑 OWNER COMMANDS
      // ══════════════════════════════════════

      case "addprem": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        const target = m.mentionedJid[0] || (q ? `${q.replace(/[^0-9]/g, "")}@s.whatsapp.net` : null)
        if (!target) return reply(sock, from, "❌ Tag atau masukkan nomor!", m)

        userDB.updateUser(target, { premium: true })
        await sock.sendMessage(from, {
          text: `✅ @${target.split("@")[0]} sekarang *Premium*! 💎\n\n> ${config.footer}`,
          mentions: [target],
        }, { quoted: m })
        await react(sock, from, "💎", m)
        break
      }

      case "delprem": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        const target = m.mentionedJid[0] || (q ? `${q.replace(/[^0-9]/g, "")}@s.whatsapp.net` : null)
        if (!target) return reply(sock, from, "❌ Tag atau masukkan nomor!", m)

        userDB.updateUser(target, { premium: false })
        await sock.sendMessage(from, {
          text: `✅ Premium @${target.split("@")[0]} dicabut!`,
          mentions: [target],
        }, { quoted: m })
        await react(sock, from, "✅", m)
        break
      }

      case "ban": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        const target = m.mentionedJid[0] || m.quoted?.sender
        if (!target) return reply(sock, from, "❌ Tag user!", m)

        userDB.updateUser(target, { banned: true })
        await sock.sendMessage(from, {
          text: `🚫 @${target.split("@")[0]} telah di-ban!`,
          mentions: [target],
        }, { quoted: m })
        await react(sock, from, "🚫", m)
        break
      }

      case "unban": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        const target = m.mentionedJid[0] || m.quoted?.sender
        if (!target) return reply(sock, from, "❌ Tag user!", m)

        userDB.updateUser(target, { banned: false })
        await sock.sendMessage(from, {
          text: `✅ @${target.split("@")[0]} telah di-unban!`,
          mentions: [target],
        }, { quoted: m })
        await react(sock, from, "✅", m)
        break
      }

      case "addcoin": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        const target = m.mentionedJid[0]
        const amount = parseInt(args[args.length - 1])
        if (!target || !amount) return reply(sock, from, "❌ Format: .addcoin @user [amount]", m)

        userDB.addCoins(target, amount)
        await sock.sendMessage(from, {
          text: `✅ +${formatNumber(amount)} coins untuk @${target.split("@")[0]}!`,
          mentions: [target],
        }, { quoted: m })
        break
      }

      case "broadcast":
      case "bc": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        if (!q) return reply(sock, from, "❌ Masukkan pesan broadcast!", m)

        const users = Object.keys(userDB.all())
        let sent = 0
        let failed = 0

        await reply(sock, from, `📢 Memulai broadcast ke ${users.length} user...`, m)

        for (const userJid of users) {
          try {
            await sock.sendMessage(userJid, {
              text: `📢 *BROADCAST*\n\n${q}\n\n> ${config.footer}`,
            })
            sent++
            await sleep(500)
          } catch {
            failed++
          }
        }

        await reply(sock, from,
          `✅ Broadcast selesai!\n✅ Terkirim: ${sent}\n❌ Gagal: ${failed}`, m)
        break
      }

      case "stats": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)

        const topCmds = statsDB.getTopCommands(5)
        let text = `╭─「 *📊 Bot Statistics* 」\n│\n│ 👥 Users: ${Object.keys(userDB.all()).length}\n│ 💎 Premium: ${userDB.getAllPremium().length}\n│ 📨 Total CMD: ${statsDB.data.totalCommands || 0}\n│ ⏰ Uptime: ${formatDuration(process.uptime())}\n│\n│ *Top Commands:*\n`
        topCmds.forEach(([cmd, count], i) => {
          text += `│ ${i + 1}. .${cmd} (${count}x)\n`
        })
        text += `│\n╰─────────────────\n> ${config.footer}`
        await reply(sock, from, text, m)
        break
      }

      case "eval": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        if (!q) return reply(sock, from, "❌ Masukkan code!", m)
        try {
          let result = eval(q)
          if (result instanceof Promise) result = await result
          await reply(sock, from, `✅ *Eval Result:*\n\n${JSON.stringify(result, null, 2)}`, m)
        } catch (e) {
          await reply(sock, from, `❌ *Error:*\n${e.message}`, m)
        }
        break
      }

      case "exec": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        if (!q) return reply(sock, from, "❌ Masukkan command!", m)
        const { exec } = require("child_process")
        exec(q, async (error, stdout, stderr) => {
          const result = stdout || stderr || error?.message || "No output"
          await reply(sock, from, `💻 *Exec Result:*\n\n${result.substring(0, 3000)}`, m)
        })
        break
      }

      case "restart": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        await reply(sock, from, "♻️ Bot sedang restart...", m)
        await sleep(2000)
        process.exit(0)
      }

      case "cleartemp": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        const tempDir = "./temp"
        if (fs.existsSync(tempDir)) {
          const files = fs.readdirSync(tempDir)
          files.forEach(f => fs.unlinkSync(path.join(tempDir, f)))
          await reply(sock, from, `✅ ${files.length} file temp dihapus!`, m)
        } else {
          await reply(sock, from, "✅ Folder temp sudah kosong!", m)
        }
        break
      }

      case "listgroup": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        try {
          const groups = await sock.groupFetchAllParticipating()
          const groupList = Object.values(groups)
          let text = `╭─「 *👥 List Grup* 」\n│\n│ Total: ${groupList.length} grup\n│\n`
          groupList.slice(0, 20).forEach((g, i) => {
            text += `│ ${i + 1}. ${g.subject} (${g.participants.length} member)\n`
          })
          if (groupList.length > 20) text += `│ ... dan ${groupList.length - 20} grup lainnya\n`
          text += `│\n╰─────────────────\n> ${config.footer}`
          await reply(sock, from, text, m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "join": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        if (!q) return reply(sock, from, "❌ Masukkan link grup!", m)
        try {
          const code = q.split("chat.whatsapp.com/")[1] || q
          await sock.groupAcceptInvite(code.trim())
          await reply(sock, from, "✅ Berhasil join grup!", m)
        } catch (e) {
          await reply(sock, from, `❌ Gagal join: ${e.message}`, m)
        }
        break
      }

      case "leave": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        const targetGroup = q || (isGroupMsg ? from : null)
        if (!targetGroup) return reply(sock, from, "❌ Masukkan Group ID!", m)
        try {
          await sock.groupLeave(targetGroup)
          await reply(sock, from, "✅ Bot keluar dari grup!", m)
        } catch (e) {
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      case "resetlimit": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        const target = m.mentionedJid[0] || sender
        const maxLimit = userDB.getUser(target).premium ? 999 : 20
        userDB.updateUser(target, { limit: maxLimit, lastLimitReset: Date.now() })
        await reply(sock, from, `✅ Limit @${target.split("@")[0]} direset ke ${maxLimit}!`, m)
        break
      }

      case "addlimit": {
        if (!ownerOnly) return reply(sock, from, "❌ Owner only!", m)
        const target = m.mentionedJid[0]
        const amount = parseInt(args[args.length - 1]) || 10
        if (!target) return reply(sock, from, "❌ Tag user!", m)
        const user = userDB.getUser(target)
        userDB.updateUser(target, { limit: (user.limit || 0) + amount })
        await sock.sendMessage(from, {
          text: `✅ +${amount} limit untuk @${target.split("@")[0]}!`,
          mentions: [target],
        }, { quoted: m })
        break
      }

      // ══════════════════════════════════════
      //  🎵 MUSIC COMMANDS
      // ══════════════════════════════════════

      case "play": {
        if (!q) return reply(sock, from, "❌ Masukkan judul lagu!\nContoh: .play shape of you", m)
        try {
          await react(sock, from, "🎵", m)
          const results = await Downloader.youtubeSearch(q)
          if (!results.length) return reply(sock, from, "❌ Lagu tidak ditemukan!", m)

          const song = results[0]
          await reply(sock, from,
            `🎵 *${song.title}*\n⏱️ ${song.duration}\n📺 ${song.author}\n\n⏬ Sedang mengunduh...`, m)

          const result = await Downloader.youtubeDl(song.url, "audio")
          if (result.url) {
            const audioBuffer = await getBuffer(result.url)
            await sendAudio(sock, from, audioBuffer, false, m)
            await react(sock, from, "✅", m)
          } else {
            await reply(sock, from, `🔗 Link audio:\n${song.url}`, m)
          }
        } catch (e) {
          await react(sock, from, "❌", m)
          await reply(sock, from, `❌ Error: ${e.message}`, m)
        }
        break
      }

      // ══════════════════════════════════════
      //  🌸 MISC COMMANDS
      // ══════════════════════════════════════

      case "donation": {
        await reply(sock, from,
          `💝 *Support VITA BOT*\n\n🙏 Terima kasih sudah menggunakan VITA BOT!\n\nJika kamu suka dan mau mendukung:\n💳 DANA: +62${config.ownerNumber[0]}\n💳 GoPay: +62${config.ownerNumber[0]}\n💳 OVO: +62${config.ownerNumber[0]}\n\nAtau cukup kasih review bintang 5 🌟\n\n> ${config.footer}`, m)
        break
      }

      case "cr":
      case "credit": {
        await reply(sock, from,
          `✨ *Credits*\n\n🤖 Bot: ${config.botName}\n👤 Creator: ${config.ownerName} (vitaa)\n📦 Framework: Baileys MD\n🌐 Year: 2026\n\n💖 Made with love for VITA~\n\n> ${config.footer}`, m)
        break
      }

      case "report": {
        if (!q) return reply(sock, from, "❌ Masukkan laporan kamu!\nContoh: .report ada bug di command .sticker", m)
        try {
          for (const owner of config.ownerNumber) {
            await sock.sendMessage(`${owner}@s.whatsapp.net`, {
              text: `🚨 *LAPORAN USER*\n\n👤 Dari: ${pushName} (+${senderNumber})\n📅 ${getDateTime()}\n\n📝 Pesan:\n${q}\n\n> ${config.footer}`,
            })
          }
          await reply(sock, from, "✅ Laporan kamu sudah terkirim ke owner!", m)
        } catch {
          await reply(sock, from, "✅ Laporan diterima!", m)
        }
        break
      }

      case "request": {
        if (!q) return reply(sock, from, "❌ Masukkan requestmu!\nContoh: .request tambah fitur game", m)
        try {
          for (const owner of config.ownerNumber) {
            await sock.sendMessage(`${owner}@s.whatsapp.net`, {
              text: `💡 *REQUEST FITUR*\n\n👤 Dari: ${pushName} (+${senderNumber})\n📅 ${getDateTime()}\n\n💭 Request:\n${q}\n\n> ${config.footer}`,
            })
          }
          await reply(sock, from, "✅ Request kamu sudah dikirim ke owner! Terima kasih~ 🌸", m)
        } catch {
          await reply(sock, from, "✅ Request diterima!", m)
        }
        break
      }

      case "tes":
      case "test": {
        await reply(sock, from,
          `✅ *VITA BOT Active!*\n\n🤖 ${config.botName} v${config.botVersion}\n⚡ Ping: OK\n🕐 ${getTime()}\n\n> ${config.footer}`, m)
        await react(sock, from, "✅", m)
        break
      }

      // ══════════════════════════════════════
      //  DEFAULT - COMMAND NOT FOUND
      // ══════════════════════════════════════

      default: {
        if (!isCommand) return

        // Coba AI sebagai fallback
        if (config.features?.aiDefault) {
          try {
            const response = await AI.blackbox(`${command} ${q}`.trim())
            await reply(sock, from, `🤖 *VITA AI*\n\n${response}`, m)
            await react(sock, from, "🤖", m)
          } catch {
            await reply(sock, from,
              `❌ Command *${prefix}${command}* tidak ditemukan!\n\nKetik *${prefix}menu* untuk melihat daftar perintah.\n\n> ${config.footer}`, m)
          }
        } else {
          await reply(sock, from,
            `❌ Command *${prefix}${command}* tidak ditemukan!\n\nKetik *${prefix}menu* untuk melihat semua perintah.\n\n> ${config.footer}`, m)
          await react(sock, from, "❌", m)
        }
      }
    }

  } catch (err) {
    console.error(chalk.red(`[ERROR] ${err.message}`))
    try {
      await reply(sock, rawMessage.key.remoteJid, `❌ Terjadi kesalahan: ${err.message}`, rawMessage)
    } catch {}
  }
}

module.exports = { processMessage }