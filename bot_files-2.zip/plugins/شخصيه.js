// ╮••─๋︩︪──๋︩︪─═⊐‹⧫›⊏═─๋︩︪──๋︩︪─┈☇
// ☃️ Plugin : تــحــلــيــل الــشــخــصــيــة
// ⚡ Bot : 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🪖🔮
// ╮••─๋︩︪──๋︩︪─═⊐‹⧫›⊏═─๋︩︪──๋︩︪─┈☇

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
    const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;

    if (!text) {
        return m.reply(`${startDeco}
*〔 👤┊ تــحــلــيــل الــشــخــصــيــة 〕*

*طــريــقــة الاســتــخــدام:*
> ${usedPrefix + command} أحمد
> ${usedPrefix + command} سارة

اكــتــب اســم الــشــخــص الــذي تــريــد تــحــلــيــل شــخــصــيــتــه
${endDeco}`)
    }

    await m.react('👤')

    const name = text.trim()

    // حساب نسب عشوائية للشخصية
    const intelligence = Math.floor(Math.random() * 101)
    const kindness = Math.floor(Math.random() * 101)
    const courage = Math.floor(Math.random() * 101)
    const humor = Math.floor(Math.random() * 101)
    const beauty = Math.floor(Math.random() * 101)
    const wisdom = Math.floor(Math.random() * 101)
    const patience = Math.floor(Math.random() * 101)
    const honesty = Math.floor(Math.random() * 101)

    // تحديد الصفات
    const getTrait = (value) => {
        if (value >= 80) return 'ممتازة 🌟'
        if (value >= 60) return 'جيدة جداً 💫'
        if (value >= 40) return 'جيدة 👍'
        if (value >= 20) return 'متوسطة 😐'
        return 'تحتاج تطوير 📈'
    }

    // وصف الشخصية حسب أعلى نسبة
    const stats = { intelligence, kindness, courage, humor, beauty, wisdom, patience, honesty }
    const highestKey = Object.keys(stats).reduce((a, b) => stats[a] > stats[b]? a : b);

    const traits = {
        intelligence: 'ذكي جداً، عقله نيّر وحاد',
        kindness: 'قلب كبير، يحب الخير للجميع',
        courage: 'شجاع وجريء، لا يخاف من التحديات',
        humor: 'روح الدعابة عالية، يجلس المجالس',
        beauty: 'جذاب وحسن المظهر، يلفت الأنظار',
        wisdom: 'حكيم ورزين، يتخذ القرارات الصائبة',
        patience: 'صبور جداً، يتحمل المسؤولية',
        honesty: 'صادق وأمين، كلمته واحدة'
    }
    let mainTrait = traits[highestKey]

    // نصائح حسب أقل نسبة
    const lowestKey = Object.keys(stats).reduce((a, b) => stats[a] < stats[b]? a : b);
    const advices = {
        intelligence: 'ننصحك بقراءة المزيد وتطوير مهاراتك',
        kindness: 'حاول أن تكون أكثر لطفاً مع الآخرين',
        courage: 'واجه مخاوفك وكن أكثر جرأة',
        humor: 'حاول أن تكتسب روح الدعابة وتخفف عن نفسك',
        beauty: 'اهتم بنفسك وبمظهرك أكثر',
        wisdom: 'استشر الآخرين قبل اتخاذ القرارات المهمة',
        patience: 'تعلم الصبر والتأني في أمورك',
        honesty: 'حاول أن تكون أكثر صدقاً ووضوحاً'
    }
    let advice = advices[lowestKey]

    // نكتة عشوائية
    const jokes = [
        `😂 ${name} لو كان كتاب كان عنوانه "كيف تضحك بدون سبب"`,
        `🤣 ${name} دمه خفيف لدرجة إنه طاير من الفرحة`,
        `😎 ${name} شخصية قوية لدرجة إنه يقنعك إن النهارده الجمعة`,
        `🫢 ${name} لو كان حيوان كان زمانه قرد مذبوح`,
        `😏 ${name} لما يدخل القهوة بتضحكله القهوة`,
        `🤪 ${name} عقله في إجازة من سنين`
    ]
    const randomJoke = jokes[Math.floor(Math.random() * jokes.length)]

    const result = `${startDeco}
*〔 👤┊ تــحــلــيــل شــخــصــيــة: ${name} 〕*

╔═══『 📊 نــســب الــشــخــصــيــة 』═══╗
║ 🧠 *الــذكــاء:* ${intelligence}% ${getTrait(intelligence)}
║ 💖 *الــطــيــبــة:* ${kindness}% ${getTrait(kindness)}
║ 🦁 *الــشــجــاعــة:* ${courage}% ${getTrait(courage)}
║ 😂 *الــفــكــاهــة:* ${humor}% ${getTrait(humor)}
║ 💎 *الــجــمــال:* ${beauty}% ${getTrait(beauty)}
║ 🧘 *الــحــكــمــة:* ${wisdom}% ${getTrait(wisdom)}
║ 🐪 *الــصــبــر:* ${patience}% ${getTrait(patience)}
║ 🔐 *الــصــدق:* ${honesty}% ${getTrait(honesty)}
╚════════════════════════════════╝

⭐ *أهــم صــفــة:* ${mainTrait}

📝 *نــصــيــحــة:* ${advice}

😂 *طــرفــة:* ${randomJoke}
${endDeco}`

    await conn.sendMessage(m.chat, {
        text: result,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363424784024162@newsletter',
                newsletterName: '𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 🪖🔮',
                serverMessageId: 1
            }
        }
    }, { quoted: m })

    await m.react('✅')
}

handler.help = ['شخصيه <الاسم>'];
handler.tags = ['𝐆𝐎𝐉𝐎 𝐓𝐀𝐒𝐋𝐘𝐀'];
handler.command = ['شخصيه', 'personality', 'شخصية'];
handler.group = true;
handler.register = true;

export default handler