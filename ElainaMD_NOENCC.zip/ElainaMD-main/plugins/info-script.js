let handler = async (m) => {
    let caption = `kamu cari script? nih link ch ya https://whatsapp.com/channel/0029Vb7RdjHCBtxFJ1M6Tz32`;
    
    await m.reply(caption);
};

handler.help = ['script'];
handler.tags = ['info'];
handler.command = ['sc', 'script', 'esce'];

export default handler;