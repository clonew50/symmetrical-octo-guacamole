// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الـفـحـص┊ ˼‏ 🧩˹ ↶〕* *𝐆𝐎𝐉𝐎* ──¤﹝نـظـام كـشـف Headers الـمـواقـع ↶﹞*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

import axios from 'axios'

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🧩 〕أمـر كـشـف الـهـيـدر*

*🛠️┊كـيـفـيـة الاسـتـخـدام:*
*${usedPrefix + command} https://example.com*

*💡┊مـثـال:*
*هيدر https://google.com*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)

    let url = text.trim()
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url

    await m.react('🕒')
    try {
        let res = await axios.get(url, { timeout: 10000, headers: { 'User-Agent': 'Mozilla/5.0' } })
        let headers = Object.entries(res.headers).map(([k,v]) => `*🔹┊${k}:* ${v}`).join('\n')

        await m.react('✅')
        await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـهـيـدر┊ 🧩 〕* *${url}*

${headers}

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`)

    } catch (e) {
        await m.react('❌')
        return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕تـأكـد مـن الـرابـط، فـشـل جـلـب الـهـيـدر*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    }
}

handler.help = ['هيدر']
handler.tags = ['ادوات']
handler.command = /^(headers|هيدر)$/i

export default handler