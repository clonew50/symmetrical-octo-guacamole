// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الـروابـط┊ ˼‏ 🔗˹ ↶〕* *𝐆𝐎𝐉𝐎* ──¤﹝نـظـام اخـتـصـار الـروابـط ↶﹞*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

import axios from 'axios'

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❗ 〕الـرجـاء إدخـال الـرابـط*

*🔗┊طـريـقـة الاسـتـخـدام:*
*${usedPrefix + command} https://github.com/sadxzyq*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    
  await m.react('🕒')

  try {
    let isurl = /https?:\/\//.test(text)
    if (!isurl) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕الـرابـط غـيـر صـالـح، يـجـب أن يـبـدأ بـ https://*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)

    let res = await shortlink(text)

    await m.react('✅')
    await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـرابـط┊ ˼‏ 🔗˹ ↶〕* *𝐆𝐎𝐉𝐎*

*🌐┊الـرابـط الأصـلـي:*
${text}

*✨┊الـرابـط الـمـخـتـصـر:*
*${res.data}*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`)

  } catch (e) {
    console.log(e); await m.react('❌')
    return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕فـشـل اخـتـصـار الـرابـط*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
  }
}

handler.help = ['اختصر']
handler.tags = ['ادوات']
handler.command = /^(tinyurl|اختصر)$/i

export default handler

async function shortlink(url) {
  return axios.get('https://tinyurl.com/api-create.php?url=' + encodeURIComponent(url))
}