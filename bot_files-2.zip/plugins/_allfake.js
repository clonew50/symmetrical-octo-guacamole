import fetch from 'node-fetch'

// تعريف المتغيرات لتجنب الـ Crash
const idcanal = '120363428598542954@newsletter'
const namecanal = '⌜ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓🕷️ ⌟  || بوت غوجو 🥷🏻'

export async function before(m, { conn }) {
  global.rcanal = {
    contextInfo: {
      isForwarded: true,
      forwardingScore: 200,
      forwardedNewsletterMessageInfo: {
        newsletterJid: idcanal,
        serverMessageId: 100,
        newsletterName: namecanal,
      }
    }
  }
}
