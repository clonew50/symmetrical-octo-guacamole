let handler = async (m, { conn, text, usedPrefix, command }) => {
  let groupMetadata = await conn.groupMetadata(m.chat)
  let participants = groupMetadata.participants

  let sender = participants.find(p => p.id === m.sender || p.jid === m.sender)
  let isAdmin = sender && (sender.admin === 'admin' || sender.admin === 'superadmin')
  if (!isAdmin) return conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> ❌ خاصك تكون آدمن\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`, m)

  let users = participants.map(u => u.id || u.jid)
  let pesan = text ? text : ''

  let teks = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 مـنـشـن لـلـجـمـيـع┊ 📢 ↶〕*
${pesan ? `\n> 🥷🏻┊${pesan}\n` : ''}
`

  for (let id of users) {
    teks += `> @${id.split('@')[0]}\n`
  }

  teks += `\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`

  await conn.sendMessage(m.chat, { text: teks, mentions: users }, { quoted: m })
}

handler.help = ['منشن']
handler.tags = ['group']
handler.command = ['منشن','تاغ','tagall','منشن-الكل']
handler.group = true
export default handler