let handler = async (m, { conn }) => {
    let isGroup = m.chat?.endsWith('@g.us') || m.isGroup || false
    if (!isGroup) {
        try { await conn.groupMetadata(m.chat); isGroup = true } catch { isGroup = false }
    }
    if (!isGroup) return conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 هـاد الأمـر خـاص بـالـمـجـمـوعـات فـقـط!*\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })

    try {
        let groupMetadata = await conn.groupMetadata(m.chat)
        let participants = groupMetadata.participants.map(v => v.id || v.jid || v)
        let users = participants.filter(v => v!== conn.user.jid && v!== conn.user.id)
        if (users.length === 0) users = participants
        let randomUser = users[Math.floor(Math.random() * users.length)]

        let crimes = [
            "خـيـانـة عـظـمـى لـلـبـوت وافـشـاء اسـرار الـمـجـمـوعـة 🤫",
            "سـرقـة رصـيـد الادمـن وشـراء انـدومـي 🍜",
            "الـنـوم اثـنـاء وقـت الـعـمـل الـرسـمـي 😴",
            "ارسـال 1000 مـلـصـق فـي دقـيـقـة واحـدة 📦",
            "الـتـجـسـس لـصـالـح بـوتـات واتـسـاب اخـرى 🕵️",
            "مـحـاولـة الانـقـلاب عـلـى حـكـم الادمـن 👑",
            "شـرب الـشـاي بـدون سـكـر وهـذا جـرم لا يـغـتـفـر ☕",
            "الـضـحـك بـصـوت عـالـي بـعـد الـسـاعـة 12 لـيـلا 🤣",
            "الـخـروج مـن الـمـجـمـوعـة ثـم الـرجـوع كـان شـيـئـا لـم يـكـن 🚪",
            "اسـتـعـمـال كـلـمـة @الـجـمـيـع بـدون اذن 📢",
            "سـرقـة مـلـصـقـات الاعـضـاء ونـسـبـهـا لـنـفـسـه 😼",
            "تـهـديـد الـبـوت بـالـحـذف وهـو نـائـم 😾",
            "الـكـذب عـلـى الادمـن وقـال انـه صـائـم وهـو يـأكـل 🫓",
            "نـشـر اشـاعـة ان الـبـوت تـعـطـل وهـو خـدام 💻",
            "ازعـاج الاعـضـاء بـرسـائـل طـويـلـة بـلا فـائـدة 📝"
        ]

        let executions = [
            "اعـدام الـمـتـهـم شـنـقـا حـتـى الـمـوت بـسـلـك الـشـاحـن ⚔️",
            "اعـدام الـمـتـهـم رمـيـا بـالـرصـاص الـوردي 🌹",
            "اعـدام الـمـتـهـم غـرقـا فـي بـحـر الـشـاي الـسـاخـن 🍵",
            "اعـدام الـمـتـهـم بـتـفـجـيـره بـ 1000 مـلـصـق 💥",
            "اعـدام الـمـتـهـم نـفـيـا الـى كـوكـب الـمـريـخ بـلا انـتـرنـت 🪐",
            "اعـدام الـمـتـهـم بـاجـبـاره عـلـى سـمـاع ريـكـورد 20 دقـيـقـة 🎧",
            "اعـدام الـمـتـهـم بـوضـعـه فـي غـرفـة مـع نـامـوس 🦟",
            "اعـدام الـمـتـهـم بـقـطـع الـويـفـي عـنـه مـدى الـحـيـاة 📵",
            "اعـدام الـمـتـهـم بـمـصـادرة هـاتـفـه وتـسـلـيـمـه لـلادمـن 📱",
            "اعـدام الـمـتـهـم شـنـقـا امـام جـمـيـع الاعـضـاء لـيـكـون عـبـرة ⚖️"
        ]

        let crime = crimes[Math.floor(Math.random() * crimes.length)]
        let execution = executions[Math.floor(Math.random() * executions.length)]
        let imageUrl = 'https://files.catbox.moe/mmvt5p.jpg'

        let txt = `
* ━ ╼╃ ⌬〔⚖️〕⌬ ╄╾ ━ *
*〔 ♛ 〕 مـحـكـمـة 𝐆𝐎𝐉𝐎 الـعـلـيـا*
* ━ ╼╃ ⌬〔 ♣️ 〕⌬ ╄╾ ━ *

*〔 👤 〕 الـمـتـهـم :* @${randomUser.split('@')[0]}
*〔 💀 〕 الـحـكـم الـنـهـائـي :*
*› اعــدام*

*〔 📜 〕 مـاذا فـعـل :*
*› ${crime}*

*〔 🔨 〕 طـريـقـة الاعـدام :*
*› ${execution}*

*〔 ⏰ 〕 الـتـنـفـيـذ :* الآن فـورا ⚡

* ━ ╼╃ ⌬〔 📌 〕⌬ ╄╾ ━ *
*تـم الـنـطـق بـالـحـكـم ولا مـجـال لـلاسـتـئـنـاف*
*العـدالـة تـأخـذ مـجـراهـا*
* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`.trim()

        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: txt,
            mentions: [randomUser]
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 خـطـأ:* ' + e.message + '\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })
    }
}

handler.help = ['اعدام']
handler.tags = ['fun']
handler.command = ['اعدام', 'إعدام']
handler.group = true

export default handler