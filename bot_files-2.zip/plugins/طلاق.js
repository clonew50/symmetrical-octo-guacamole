let handler = async (m, { conn }) => {
    let isGroup = m.chat?.endsWith('@g.us') || m.isGroup || false
    if (!isGroup) {
        try { await conn.groupMetadata(m.chat); isGroup = true } catch { isGroup = false }
    }
    if (!isGroup) return conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 هـاد الأمـر خـاص بـالـمـجـمـوعـات فـقـط!*\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })

    try {
        let groupMetadata = await conn.groupMetadata(m.chat)
        let participants = groupMetadata.participants.map(v => v.id || v.jid || v)
        let users = participants.filter(v => v!== conn.user.jid && v!== conn.user.id)

        if (users.length < 2) return conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 خـاصـنـا عـلـى الاقـل 2 ديـال الاعـضـاء!*\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })

        let shuffled = users.sort(() => 0.5 - Math.random())
        let user1 = shuffled[0]
        let user2 = shuffled[1]

        let divorceReasons = [
            "الـطـلاق بـسـبـب الـخـيـانـة مـع الـويـفـي ديـال الـجـار 📶",
            "الـزوج نـسـى عـيـد الـزواج والـزوجـة مـا سـامـحـاتـوش 🎂",
            "تـطـلـقـو حـيـت مـا تـفـاهـمـوش شـكـون يـغـسـل الـمـواعـن 🍽️",
            "الـسـبـب : الـزوج كـيـشـخـر بـصـوت عـالـي بـالـلـيـل 😴",
            "الـزوجـة اكـتـشـفـات انـه كـيـتـابـع بـنـات فـي الانـسـتـا 😾",
            "تـطـلـقـو عـلـى ود شـاحـن الـهـاتـف مـن سـرقـو الاول 🔌",
            "الـحـب مـات حـيـت الـرصـيـد خـلاص 💸",
            "الـزوج قـال الـطـبـخ مـالـح والـمـحـكـمـة حـكـمـت فـورا 👨‍🍳",
            "الـسـبـب : خـنـاقـة عـلـى الـريـمـوت كـونـتـرول ديـال الـتـلـفـاز 📺",
            "تـطـلـقـو حـيـت بـجـوجـهـم بـغـاو يـكـونـو هـمـا الـصـح 👑",
            "الـزواج فـشـل بـسـبـب الـغـيـرة مـن بـوت 𝐆𝐎𝐉𝐎 🤖",
            "الـطـلاق بـسـبـب ان الـزوج كـيـقـول انـا نـاعـس وهـو اونـلايـن 🌙"
        ]

        let reason = divorceReasons[Math.floor(Math.random() * divorceReasons.length)]
        let imageUrl = 'https://files.catbox.moe/fiorvr.jpg'

        let txt = `
* ━ ╼╃ ⌬〔💔〕⌬ ╄╾ ━ *
*〔 ♛ 〕 مـحـكـمـة الـطـلاق 𝐆𝐎𝐉𝐎*
* ━ ╼╃ ⌬〔 ⚖️ 〕⌬ ╄╾ ━ *

*〔 👤 〕 الـطـرف الاول :* @${user1.split('@')[0]}
*〔 👤 〕 الـطـرف الـثـانـي :* @${user2.split('@')[0]}

*〔 📜 〕 تـم الـحـكـم بـالـطـلاق الـنـهـائـي!*
*〔 🔨 〕 الـحـالـة : مـطـلـقـيـن رسـمـيـا*

*〔 💣 〕 سـبـب الـطـلاق :*
*› ${reason}*

*〔 📄 〕 الـقـرار :*
*› لا رجـعـة فـيـه والـعـدة 3 ايـام بـلا ويـفـي*

* ━ ╼╃ ⌬〔 📌 〕⌬ ╄╾ ━ *
*⚠️ تـنـبـيـه : هـادا الـكـود عـشـوائـي 100% لـلـتـرفـيـه فـقـط*
*الـطـلاق مـاشـي لـعـبـة ولـكـن فـالـبـوت كـلـشـي مـمـكـن 😹*
* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`.trim()

        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: txt,
            mentions: [user1, user2]
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 خـطـأ:* ' + e.message + '\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })
    }
}

handler.help = ['طلاق']
handler.tags = ['fun']
handler.command = ['طلاق', 'تطليق', 'تفريق']
handler.group = true

export default handler