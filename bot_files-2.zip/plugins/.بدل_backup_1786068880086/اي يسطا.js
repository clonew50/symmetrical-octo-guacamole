let handler = async (m) => {
  const reply = ` *😙اي يزميلييي* `.trim();
  await m.conn.sendMessage(m.chat, {
    text: reply,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 999,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363411035938060@newsletter',
        newsletterName: '⚡_KAISER_┊🩸┊𝐂𝐇𝐀𝐍𝐍𝐄𝐋◞',
        serverMessageId: 100
      }
    }
  }, { quoted: m });
};

// كلمات مفتاحية للرد التلقائي
handler.customPrefix = /(اي يسطا)/i
handler.command = new RegExp;
handler.exp = 0;

export default handler;