// =================================================================
// • Plugin Name : انستا - تحميل انستغرام (Reels/Posts/Stories)
// • Bot Name : 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 | غوجو بوت
// • Developer : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 — 212775630435
// • Version : v3.0.0 GOJO Edition
// • Description : تحميل فيديوهات وصور انستغرام بجودة HD مع دعم الألبوم
// • Command : انستا / insta / ريلز
// • Copyright : © 2026 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 | All Rights Reserved
// • Credit : 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 Powered By 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 🇲🇦
// =================================================================

import axios from 'axios';
import fetch from 'node-fetch';

// ─── زخرفة 𝐆𝐎𝐉𝐎 ──────────────────────────────────────────
const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 | By 𝐘𝐎𝐍𝐎 〕⌬ ╄╾ ━ *`;
const line1 = `*🥷🏻┊𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*`;
const line2 = `*⚡┊By 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕*`;

// ─── إعدادات الـ API ──────────────────────────────────────────────
const DOWNREELS_API = "https://downreels.com/api/fetch.php"
const HEADERS = {
  "accept": "*/*",
  "accept-language": "en-US,en;q=0.9",
  "cache-control": "no-cache",
  "content-type": "application/json",
  "origin": "https://downreels.com",
  "referer": "https://downreels.com/en/download-video-instagram/",
  "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"
}

// ─── توثيق موحد VCard GOJO ─────────────────────────
async function getVerified(m) {
  const thumb = await (await fetch('https://files.catbox.moe/80dv0b.jpg')).buffer();
  return {
    key: { participants: "0@s.whatsapp.net", fromMe: false, id: "GOJO_VERIFIED_IG" },
    message: {
      locationMessage: {
        name: "🥷🏻⸽⃕❬ GOJO BOT❭ - Instagram DL 🕷️🌋⃨፝⃕✰",
        jpegThumbnail: thumb,
        vcard: `BEGIN:VCARD
VERSION:3.0
N:; GOJO BOT 🕸️
FN: GOJO BOT 🥷🏻
ORG: SYSTEM YONO - INSTAGRAM
TITLE: Verified Downloader
item1.TEL;waid=212775630435:+212775630435
item1.X-ABLabel: SUPPORT YONO
X-WA-BIZ-DESCRIPTION:Official GOJO Bot By YONO
X-WA-BIZ-NAME:YONO. 𝐛𝐨𝐭
END:VCARD`
      }
    },
    participant: "0@s.whatsapp.net"
  }
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const fkontak = await getVerified(m);

    if (!args[0]) {
        return conn.reply(m.chat,
            `${startDeco}\n\n*📌┊* ضـع رابـط انـسـتـغـرام\n*💡┊* مـثـال:\n${usedPrefix + command} https://www.instagram.com/reel/...\n\n${endDeco}`, fkontak);
    }

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    await conn.reply(m.chat, `${startDeco}\n\n*⏳┊* جـاري سـحـب الـمـيـديـا HD...\n\n${endDeco}`, fkontak);

    try {
        const response = await axios.post(DOWNREELS_API, { url: args[0] }, { headers: HEADERS, timeout: 30000 });
        const data = response.data;

        if (data.status!== "ok" ||!data.videos || data.videos.length === 0) {
            throw new Error('تـأكـد ان الـحـسـاب عـام Public');
        }

        const getBestVideo = (list) => {
            const hd = list.find(v => v.quality && v.quality.toLowerCase().includes("hd"));
            return hd? hd.url : list[0].url;
        };

        if (data.videos.length === 1) {
            let url = getBestVideo(data.videos);
            await conn.sendMessage(m.chat, {
                video: { url },
                caption: `${startDeco}\n\n*🎬┊* تـم الـتـحـمـيـل بـنـجـاح\n${line1}\n${line2}\n\n${endDeco}`
            }, { quoted: fkontak });
        } else {
            await conn.reply(m.chat, `${startDeco}\n\n*📦┊* الـبـوم *${data.videos.length}* مـلـف جـاري الارسـال...\n\n${endDeco}`, fkontak);
            for (const item of data.videos) {
                if (item.isVideo) await conn.sendMessage(m.chat, { video: { url: item.url } }, { quoted: fkontak });
                else await conn.sendMessage(m.chat, { image: { url: item.url } }, { quoted: fkontak });
            }
        }
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await conn.reply(m.chat, `${startDeco}\n\n*❌┊* خـطـأ: ${e.message || e}\n\n${endDeco}`, fkontak);
    }
}

handler.help = ['انستا', 'insta'];
handler.tags = ['📥 التحميل'];
handler.command = /^(انستا|انستغرام|insta|instagram|ig|ريلز|reel)$/i;
export default handler