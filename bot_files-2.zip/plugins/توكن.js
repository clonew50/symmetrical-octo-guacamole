// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الـفـحـص┊ ˼‏ 🤖˹ ↶〕* *𝐆𝐎𝐉𝐎* ──¤﹝نـظـام فـحـص تـوكـن تـلـيـجـرام ↶﹞*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {

  if (!text) {
    return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 🤖 〕فـحـص تـوكـن الـتـلـيـجـرام*

*📝┊طـريـقـة الاسـتـخـدام:*
*${usedPrefix + command} الـتـوكـن*

*💡┊مـثـال:*
*${usedPrefix + command} 123456:ABC-DEF...*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`);
  }

  const token = text.trim();
  const apiUrl = `https://api.telegram.org/bot${token}/getMe`;

  await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ⏳ 〕جـاري الـتـحـقـق مـن الـتـوكـن...*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);

  try {
    const response = await axios.get(apiUrl);
    const data = response.data;

    if (!data.ok) {
      return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕الـتـوكـن الـذي قـدمـتـه غـيـر صـالـح*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);
    }

    const botInfo = data.result;
    const infoMessage = `
* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـنـتـيـجـة┊ ˼‏ 🤖˹ ↶〕* *𝐆𝐎𝐉𝐎*

*🆔┊الايـدي:* *${botInfo.id}*
*🤖┊هـل هـو بـوت:* *${botInfo.is_bot ? 'نعم' : 'لا'}*
*📛┊اسـم الـبـوت:* *${botInfo.first_name}*
*🔗┊الـمـعـرف:* *@${botInfo.username}*
*👥┊يـنـضـم لـلـمـجـمـوعـات:* *${botInfo.can_join_groups ? 'نعم' : 'لا'}*
*📖┊يـقـرأ الـرسـائـل:* *${botInfo.can_read_all_group_messages ? 'نعم' : 'لا'}*
*✨┊يـدعـم الانـلايـن:* *${botInfo.supports_inline_queries ? 'نعم' : 'لا'}*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *
    `.trim();

    await m.reply(infoMessage);

  } catch (error) {
    console.error(error.message);
    return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕حـدثـت مـشـكـلـة أثـنـاء جـلـب الـمـعـلـومـات*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`);
  }
};

handler.command = ['توكن'];
handler.help = ['توكن']
handler.tags = ['tools']

export default handler;