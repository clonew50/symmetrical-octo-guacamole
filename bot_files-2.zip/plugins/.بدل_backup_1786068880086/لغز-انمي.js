// plugins/لغز-انمي.js

const FOOTER = '\n\n╭─────────────────⊹\n│ ✨ 𝑩𝒚 : ⚡_KAISER_ 𝑻𝑯𝑬 𝑨𝑩𝑺𝑶𝑳𝑼𝑻𝑬 ✨\n╰─────────────────⊹ 👑⚡';
const withCredit = (text) => `${text}${FOOTER}`;

const riddles = [
  { q: '🎌 من هو الشخص الذي يحمل دفتراً يقتل كل من يُكتب اسمه فيه؟', a: ['لايت', 'light yagami', 'لايت يوغامي'] },
  { q: '🎌 ما اسم الأنمي الذي بطله يموت ويرجع للحياة من نقطة معينة؟', a: ['ريزيرو', 're zero', 'ابدأ من الصفر', 'rezero'] },
  { q: '🎌 من هو حارس القرية الخفية للرمل وأصبح كاجي؟', a: ['غارا', 'gaara'] },
  { q: '🎌 من هو المحقق العبقري الذي يجلس بطريقة غريبة ويحب الحلوى؟', a: ['l', 'ال', 'إل'] },
  { q: '🎌 من هو أقوى ساحر في جوجوتسو كايسن؟', a: ['غوجو', 'gojo', 'ساتورو غوجو'] },
  { q: '🎌 من هو بطل أنمي "رجل اللكمة الواحدة"؟', a: ['سايتاما', 'saitama'] },
  { q: '🎌 من هو معلم ناروتو وساسكي وساكورا؟', a: ['كاكاشي', 'kakashi'] },
  { q: '🎌 من هو الشيطان الذي يسكن في إيتادوري يوجي؟', a: ['سوكونا', 'sukuna', 'ريومن سوكونا'] },
  { q: '🎌 ما اسم القوة الخاصة في هانتر × هانتر؟', a: ['نن', 'nen'] },
  { q: '🎌 من هو أخ إيرين في هجوم العمالقة؟', a: ['زيكه', 'zeke', 'زيك'] },
  { q: '🎌 من هو الشخص الذي يقاتل بثلاثة سيوف في ون بيس؟', a: ['زورو', 'zoro'] },
  { q: '🎌 من هو بطل أنمي "بليتش"؟', a: ['إيشيغو', 'ichigo', 'ايشيغو'] },
  { q: '🎌 ما اسم الفاكهة التي أكلها لوفي؟', a: ['غوم غوم', 'gum gum', 'هيتو هيتو'] },
  { q: '🎌 من هو قائد فيلق الاستطلاع الأقوى؟', a: ['ليفاي', 'levi', 'ليفي'] },
  { q: '🎌 ما اسم شيطان المنشار؟', a: ['بوشيتا', 'pochita'] },
  { q: '🎌 من هو بطل جوجوتسو كايسن؟', a: ['يوجي', 'إيتادوري', 'ايتادوري يوجي'] },
  { q: '🎌 ما اسم أقوى هجوم لناروتو؟', a: ['راسينغان', 'راسن شوريكن', 'كيج بونشين'] },
  { q: '🎌 من هو الشخص الذي علّم ناروتو تقنية راسينغان؟', a: ['جيرايا', 'كاكاشي', 'مينياتو'] },
  { q: '🎌 ما اسم المدرسة في بطلي الأكاديمية؟', a: ['يواي', 'ua', 'يو إيه'] },
  { q: '🎌 ما اسم الأنمي الذي تقاتل فيه شياطين بسيوف خاصة؟', a: ['قاتل الشياطين', 'demon slayer', 'كيميتسو نو يايبا'] },
];

const activeRiddles = new Map();

function normalize(str) {
  return str.trim().toLowerCase()
    .replace(/\s+/g, '')
    .replace(/[أإآا]/g, 'ا')
    .replace(/[ةه]/g, 'ه')
    .replace(/[يى]/g, 'ي');
}

const handler = async (m, { conn }) => {
  const groupId = m.chat;
  const text = m.text?.trim() || '';

  // ── الجواب ──
  if (/^[.!](ج|جواب)/i.test(text)) {
    if (!activeRiddles.has(groupId))
      return m.reply(withCredit('❌ مفيش لغز نشط! اكتب `.لغز-انمي` للبدء.'));

    const { riddle } = activeRiddles.get(groupId);
    const userAnswer = text.replace(/^[.!](ج|جواب)\s*/i, '').trim();

    if (!userAnswer) return m.reply('❌ اكتب إجابتك!\nمثال: `.ج ناروتو`');

    const isCorrect = riddle.a.some(ans => normalize(userAnswer) === normalize(ans));

    if (isCorrect) {
      clearTimeout(activeRiddles.get(groupId).timer);
      activeRiddles.delete(groupId);
      return m.reply(withCredit(
        `🎉 *إجابة صحيحة!*\n👤 *${m.pushName || 'مجهول'}* أجاب صح ✅\n\n🎌 اكتب \`.لغز-انمي\` للغز جديد!`
      ));
    } else {
      return m.reply(withCredit(`❌ إجابة خاطئة! حاول تاني.`));
    }
  }

  // ── لغز جديد ──
  if (activeRiddles.has(groupId))
    return m.reply(withCredit('⚠️ فيه لغز لسه مش اتجاوب!\n💬 اكتب: `.ج <إجابتك>`'));

  const riddle = riddles[Math.floor(Math.random() * riddles.length)];

  const timer = setTimeout(async () => {
    if (activeRiddles.has(groupId)) {
      activeRiddles.delete(groupId);
      await conn.sendMessage(groupId, {
        text: withCredit(`⏰ *انتهى الوقت!*\n✅ الإجابة كانت: *${riddle.a[0]}*\n\n🎌 اكتب \`.لغز-انمي\` للغز جديد!`)
      });
    }
  }, 60000);

  activeRiddles.set(groupId, { riddle, timer });

  return m.reply(withCredit(
    `${riddle.q}\n\n⏳ عندك *60 ثانية* للإجابة!\n💬 اكتب: \`.ج <إجابتك>\``
  ));
};

handler.help = ['لغز-انمي'];
handler.tags = ['games'];
handler.command = /^(لغز-انمي|لغز|anmequiz)$/i;

export default handler;