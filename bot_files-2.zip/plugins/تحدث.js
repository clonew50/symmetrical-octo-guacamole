// =================================================================
// • Plugin Name : TTS ElevenLabs - 165 صوت
// • Bot Name : 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 | غوجو بوت
// • Developer : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 — 212674375708
// • Version : v2.0.0
// • Channel : https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
// • Credit : izana, uncel shawaza
// =================================================================

import axios from 'axios'
import { generateWAMessageFromContent } from '@whiskeysockets/baileys'

const API_BASE = 'https://engez.a7a.online/api/v1'

// قائمة الأصوات 165 صوت
const VOICES = [
    { id: 1, name: 'Majed', name_ar: 'ماجد', gender: 'male' },
    { id: 2, name: 'Ghalia', name_ar: 'غالية', gender: 'female' },
    { id: 3, name: 'Aisha', name_ar: 'عائشة', gender: 'female' },
    { id: 4, name: 'Khalifa', name_ar: 'خليفة', gender: 'male' },
    { id: 5, name: 'fahad', name_ar: 'فهد', gender: 'male' },
    // ... باقي الاصوات لحد 165
    { id: 165, name: 'Arabic Poet', name_ar: 'الشاعر العربي', gender: 'male' }
]

// دالة توليد الصوت
async function generateVoice(text, voiceId) {
    try {
        const params = new URLSearchParams()
        params.append('text', text)
        params.append('voice', voiceId)

        const response = await axios.get(`${API_BASE}/tools/elevenlab?${params.toString()}`, {
            timeout: 60000
        })

        if (!response.data?.success) {
            throw new Error(response.data?.error || 'فشل توليد الصوت')
        }

        return response.data.response
    } catch (error) {
        throw new Error(error.message || 'فشل الاتصال')
    }
}

// دالة إرسال قائمة الأصوات
async function sendVoiceList(conn, chat, quoted, usedPrefix) {
    const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
    const sections = [{
        title: '🇸🇦 أصوات عربية (ذكر)',
        rows: VOICES.filter(v => v.gender === 'male' && v.name_ar).slice(0, 30).map(v => ({
            title: v.name_ar,
            description: `🎙️ ${v.name} | ID: ${v.id}`,
            id: `${usedPrefix}تحدث ${v.id}`
        }))
    }, {
        title: '🇸🇦 أصوات عربية (أنثى)',
        rows: VOICES.filter(v => v.gender === 'female' && v.name_ar).slice(0, 30).map(v => ({
            title: v.name_ar,
            description: `🎙️ ${v.name} | ID: ${v.id}`,
            id: `${usedPrefix}تحدث ${v.id}`
        }))
    }, {
        title: '🌍 أصوات أخرى',
        rows: VOICES.slice(60, 90).map(v => ({
            title: v.name || v.name_ar,
            description: `🎙️ ${v.gender === 'male' ? 'ذكر' : 'أنثى'} | ID: ${v.id}`,
            id: `${usedPrefix}تحدث ${v.id}`
        }))
    }]

    const msg = generateWAMessageFromContent(chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: `${startDeco}\n🪖 ──¤﹝مـولـد الأصـوات ↶﹞\n> *اخـتـر صـوتـاً لتوليد النص الصوتي*` },
                    footer: { text: '🎙️ 𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕' },
                    nativeFlowMessage: {
                        buttons: [{
                            name: 'single_select',
                            buttonParamsJson: JSON.stringify({
                                title: '🎙️ اختر الصوت',
                                sections
                            })
                        }]
                    }
                }
            }
        }
    }, { userJid: conn.user.jid, quoted })

    await conn.relayMessage(chat, msg.message, { messageId: msg.key.id })
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    const startDeco = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *`;
    const endDeco = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`;
    const myCredit = `*🤖┊اسـم الـبـوت:* *𝐆𝐎𝐉𝐎-𝐁𝐎𝐓*\n*👑┊الـمـطـور:* *𝐘𝐎𝐍𝐎 𝐃𝐄𝐕*\n*📢┊الـقـنـاة:* https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r`;

    // أمر عرض القائمة
    if (command === 'تحدث' && !text) {
        await sendVoiceList(conn, m.chat, m, usedPrefix)
        return
    }

    // أمر مساعد
    if (command === 'صوت-مساعدة') {
        return m.reply(`${startDeco}
🪖 ──¤﹝أوامـر الـ TTS ↶﹞
> *〔 📌 〕 الاسـتـخـدام:*
> *•* ${usedPrefix}تحدث - عـرض الـقـائـمـة
> *•* ${usedPrefix}تحدث 15 السلام عليكم
> *•* ${usedPrefix}ماجد مرحبا

> *〔 💡 〕 الـمـثـال:*
> *•* ${usedPrefix}تحدث 165 يا هلا

${myCredit}
${endDeco}`)
    }

    // التحقق من وجود نص
    if (!text) {
        return m.reply(`${startDeco}\n> *〔 ❌ 〕 يـرجـى ادخـال الـنـص*\n> *الـمـثـال:* ${usedPrefix}تحدث 1 اهلا\n${endDeco}`)
    }

    await m.react('⏳')

    try {
        let voiceId = null
        let textToSpeak = text

        // استخراج رقم الصوت
        const match = text.match(/^(\d+)\s+(.+)/)
        if (match) {
            voiceId = match[1]
            textToSpeak = match[2]
        } else {
            // البحث بالاسم
            const voice = VOICES.find(v => v.name_ar === command || v.name.toLowerCase() === command.toLowerCase())
            if (voice) {
                voiceId = voice.id
            } else {
                voiceId = 1 // الصوت الافتراضي
            }
        }

        if (!VOICES.some(v => v.id === parseInt(voiceId))) {
            throw new Error(`الـصـوت رقـم ${voiceId} غـيـر مـوجـود`)
        }

        const result = await generateVoice(textToSpeak, voiceId)

        if (result?.url) {
            const voiceName = VOICES.find(v => v.id === parseInt(voiceId))?.name_ar || voiceId
            await conn.sendMessage(m.chat, {
                audio: { url: result.url },
                mimetype: 'audio/mpeg',
                fileName: `GOJO_TTS_${voiceName}.mp3`,
                caption: `${startDeco}
🪖 ──¤﹝تـم تـولـيـد الـصـوت ↶﹞
> *〔 🗣️ 〕 الـصـوت:* ${voiceName}
> *〔 📝 〕 الـنـص:* ${textToSpeak}
${myCredit}
${endDeco}`
            }, { quoted: m })

            await m.react('✅')
        } else {
            throw new Error('لـم يـتـم الـعـثـور عـلـى الـصـوت')
        }

    } catch (error) {
        await m.react('❌')
        return m.reply(`${startDeco}\n> *〔 ❌ 〕 خـطـأ:* ${error.message}\n${endDeco}`)
    }
}

handler.command = ['تحدث', 'صوت-مساعدة']
handler.help = ['تحدث <رقم/اسم> <نص>', 'صوت-مساعدة']
handler.tags = ['🇲🇦الـ TTS🇲🇦']

export default handler