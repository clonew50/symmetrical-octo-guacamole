// ==============================
// ⚡ إدارة المجموعات - أوامر المطور (غابيمارو)
// المطور الوحيد: 212674375708
// الأوامر: .طيره  .ادبه  .تنفس  .اشراف  .ادبهم  .اباده  .رجعهم
// يعمل فقط داخل الجروبات والبوت لازم يكون أدمن
// ==============================

const DEVELOPER = '212674375708'; // بدون @ ولا +

/** helper: extract target jid from quoted / mentions / text */
function getTargetJid(m, text) {
  if (!m) return null;
  if (m.quoted && m.quoted.sender) return m.quoted.sender;
  if (m.mentionedJid && m.mentionedJid.length) return m.mentionedJid[0];
  if (text) {
    const digits = text.replace(/\D/g, '');
    if (digits) return `${digits}@s.whatsapp.net`;
  }
  return null;
}

/** helper to send bold reply فقط */
async function replyBold(conn, jid, quoted, message) {
  try {
    await conn.reply(jid, `*${message}*`, quoted);
  } catch (e) {
    await conn.sendMessage(jid, { text: `*${message}*` }, { quoted });
  }
}

let handler = async (m, { conn, command, text, participants }) => {
  try {
    if (!m.isGroup) return conn.reply(m.chat, '*هذه الأوامر تعمل داخل الجروبات فقط.*', m);

    const sender = (m.sender || '').split('@')[0];

    // التحقق من المطور فقط
    if (sender !== DEVELOPER) {
      return await replyBold(conn, m.chat, m, 'يا عبد اخلع ثوار العبوديه اولاً👁️');
    }

    // تأكد أن البوت مشرف
    const botJid = conn.user?.jid || null;
    const botNumber = botJid?.split('@')[0];
    const botParticipant = participants.find(p => p.id?.includes(botNumber));
    if (!botParticipant || !botParticipant.admin) {
      return await replyBold(conn, m.chat, m, 'يجب أن أكون مشرفًا في المجموعة ليتم تنفيذ الأوامر.');
    }

    const target = getTargetJid(m, text);

    switch (command) {
      case 'طيره': {
        if (!target) return await replyBold(conn, m.chat, m, 'رجاءً رد على رسالة الشخص أو منشنه لتنفيذ الطرد.');
        try {
          await conn.groupParticipantsUpdate(m.chat, [target], 'remove');
        } catch (e) {}
        await replyBold(conn, m.chat, m, 'مطوري اعطا امراً 🛡️');
        break;
      }

      case 'ادبه': {
        if (!target) return await replyBold(conn, m.chat, m, 'رجاءً رد على رسالة الشخص أو منشنه لسحب إشرافه.');
        try {
          await conn.groupParticipantsUpdate(m.chat, [target], 'demote');
        } catch (e) {}
        await replyBold(conn, m.chat, m, 'اتوسل لمطوري ممكن يرجعلك اشرافك');
        break;
      }

      case 'تنفس': {
        if (!target) return await replyBold(conn, m.chat, m, 'رجاءً رد على رسالة الشخص أو منشنه لمنحه إشراف.');
        try {
          await conn.groupParticipantsUpdate(m.chat, [target], 'promote');
        } catch (e) {}
        await replyBold(conn, m.chat, m, 'احنا لينا بركه الا هوا 🥞');
        break;
      }

      case 'اشراف': {
        try {
          await conn.groupParticipantsUpdate(m.chat, [m.sender], 'promote');
        } catch (e) {}
        await replyBold(conn, m.chat, m, 'تم سلب اشراف بأمر من مطوري');
        break;
      }

      case 'ادبهم': {
        await replyBold(conn, m.chat, m, 'جارٍ تأديب الجميع — سحب الإشرافات...');
        for (const p of participants) {
          try {
            if (!p.id) continue;
            const num = p.id.split('@')[0];
            if (num === DEVELOPER || num === botNumber) continue;
            if (p.admin) {
              await conn.groupParticipantsUpdate(m.chat, [p.id], 'demote');
              await new Promise(res => setTimeout(res, 700));
            }
          } catch {}
        }
        await replyBold(conn, m.chat, m, 'تم سلب اشراف بأمر من مطوري');
        break;
      }

      case 'اباده': {
        await replyBold(conn, m.chat, m, '𝐆𝐎𝐉o ぽ ​​​⚴ 𝐁𝐎𝐓 takes control...');
        const allIds = participants.map(p => p.id).filter(Boolean);
        const toRemove = allIds.filter(id => id !== `${DEVELOPER}@s.whatsapp.net` && id !== botJid);
        if (toRemove.length) {
          try {
            await conn.groupParticipantsUpdate(m.chat, toRemove, 'remove');
          } catch (e) {
            for (const id of toRemove) {
              try {
                await conn.groupParticipantsUpdate(m.chat, [id], 'remove');
                await new Promise(r => setTimeout(r, 700));
              } catch {}
            }
          }
        }
        await replyBold(conn, m.chat, m, 'تمت الإبادة الكاملة بنجاح');
        break;
      }

      case 'رجعهم': {
        await replyBold(conn, m.chat, m, 'جارٍ إعادة الإشراف للجميع...');
        for (const p of participants) {
          try {
            if (p.id === botJid) continue;
            await conn.groupParticipantsUpdate(m.chat, [p.id], 'promote');
            await new Promise(res => setTimeout(res, 700));
          } catch {}
        }
        await replyBold(conn, m.chat, m, 'تمت إعادة الإشراف للجميع بناءً على أمر المطور');
        break;
      }
    }
  } catch (err) {
    console.error('Owner admin commands error:', err);
    await replyBold(conn, m.chat, m, '⚠️ حدث خطأ أثناء تنفيذ الأمر.');
  }
};

handler.help = ['طيره', 'ادبه', 'تنفس', 'اشراف', 'ادبهم', 'اباده', 'رجعهم'];
handler.tags = ['owner'];
handler.command = /^(طيره|ادبه|تنفس|اشراف|ادبهم|اباده|رجعهم)$/i;
handler.group = true;

export default handler;