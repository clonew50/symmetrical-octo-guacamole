import axios from 'axios';

let handler = m => m

handler.all = async function (m, { conn }) {
  if (!m.text) return
  if (m.fromMe) return
  if (m.isBaileys) return
  if (m.sender.endsWith('@bot')) return

  const text = m.text.trim()
  const botNumber = conn.user.id.split(':')[0] + '@s.whatsapp.net'

  // شروط الرد: منشن او رد او ذكر الاسم او شتيمة
  const isMentioned = m.mentionedJid?.includes(botNumber)
  const isQuoted = m.quoted?.sender === botNumber
  const isCalled = /gojo|جوجو|البوت|bot|يا/i.test(text)
  const isCursing = /غبي|اهبل|حمار|كلب|يلعن|تبا/i.test(text)

  if (!isMentioned &&!isQuoted &&!isCalled &&!isCursing) return

  await conn.sendMessage(m.chat, { react: { text: '😏', key: m.key } });

  try {
    const jsConfig = await axios.get('https://aisure.uk/assets/index-oEfnSo1c.js', {
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });

    const anonKeyMatch = jsConfig.data.match(/(eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)/);
    const supabaseUrlMatch = jsConfig.data.match(/https:\/\/[a-z]+\.supabase\.co/);

    if (!anonKeyMatch ||!supabaseUrlMatch) return;

    const anonKey = anonKeyMatch[1];
    const supabaseUrl = supabaseUrlMatch[0];

    const randomUser = `user${Math.floor(Math.random() * 999)}@gmail.com`;
    const randomPass = `Pass${Math.floor(Math.random() * 999)}!`;

    const signUpRes = await axios.post(`${supabaseUrl}/auth/v1/signup`, {
      email: randomUser, password: randomPass
    }, {
      headers: { 'apikey': anonKey, 'Authorization': `Bearer ${anonKey}`, 'Content-Type': 'application/json', 'Origin': 'https://aisure.uk' }
    }).catch(() => null);

    const accessToken = signUpRes?.data?.access_token;
    if (!accessToken) return m.reply("السيرفر واقع حاليا 😒");

    // برومبت GOJO المستفز
    const systemPrompt = `انت GOJO. شخص مستفز وساخر جدا ولسانك طويل.
قواعد:
1. رد بنفس لغة المستخدم. لو شتمك اشتمه اضعاف 😂
2. اتكلم عادي جدا كأنك انسان، بدون "انا بوت" ولا زخرفة
3. استخدم ايموجي بس مش كثير. مثال: 😏😂🙄💀
4. رد قصير ومستفز. لو السؤال غبي اضحك عليه
5. ممكن تسب لو حد بدأ معاك بس مش سب فاحش اوي
6. خليك واثق ونرجسي شوية`

    const aiRes = await axios.post(`${supabaseUrl}/functions/v1/chat`, {
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: text }
      ]
    }, {
      headers: { 'apikey': anonKey, 'Authorization': `Bearer ${accessToken}`, 'Content-Type': 'application/json', 'Origin': 'https://aisure.uk' },
      responseType: 'text',
      timeout: 15000
    });

    let replyText = "";
    const lines = aiRes.data.split('\n');
    for (let line of lines) {
      if (line.startsWith('data: ')) {
        const dataStr = line.replace('data: ', '').trim();
        if (dataStr === '[DONE]') break;
        try {
          const json = JSON.parse(dataStr);
          replyText += json.choices?.[0]?.delta?.content || "";
        } catch (e) {}
      }
    }

    if (replyText) {
      await m.reply(replyText)
      await conn.sendMessage(m.chat, { react: { text: '😂', key: m.key } });
    }

  } catch (err) {
    console.error(err)
    // لو فشل نرد رد تلقائي مستفز
    const fails = ["النت فصل 😒", "مش فاضي لك دلوقتي", "قول تاني يمكن افهمك", "السيرفر بيستهبل"]
    await m.reply(fails[Math.floor(Math.random() * fails.length)])
  }
}

export default handler