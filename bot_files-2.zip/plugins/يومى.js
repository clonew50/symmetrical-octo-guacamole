let handler = async (m, { conn }) => {
    try {
        let userId = m.sender
        if (!global.db) global.db = { data: { users: {} } }
        if (!global.db.data) global.db.data = { users: {} }
        if (!global.db.data.users) global.db.data.users = {}
        if (!global.db.data.users[userId]) {
            global.db.data.users[userId] = { money: 0, diamond: 0, lastDaily: 0, exp: 0 }
        }
        let user = global.db.data.users[userId]

        let cooldown = 24 * 60 * 60 * 1000 // 24 ساعة
        let now = Date.now()
        let timeLeft = user.lastDaily + cooldown - now

        if (timeLeft > 0) {
            let hours = Math.floor(timeLeft / (1000 * 60 * 60))
            let minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60))
            let seconds = Math.floor((timeLeft % (1000 * 60)) / 1000)

            return conn.sendMessage(m.chat, {
                text: `* ━ ╼╃ ⌬〔⏳〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 مـازال بـاقـي لـك الـوقـت!*\n\n*〔 ⏰ 〕 الـوقـت الـمـتـبـقـي :*\n*› ${hours} سـاعـة و ${minutes} دقـيـقـة و ${seconds} ثـانـيـة*\n\n*تـعـال بـعـد مـا يـنـتـهـي الـوقـت*\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`
            }, { quoted: m })
        }

        // جوائز عشوائية
        let moneyReward = Math.floor(Math.random() * 1500) + 500 // من 500 الى 2000
        let diamondReward = Math.floor(Math.random() * 15) + 5 // من 5 الى 20
        let expReward = Math.floor(Math.random() * 100) + 50

        user.money = (user.money || 0) + moneyReward
        user.diamond = (user.diamond || 0) + diamondReward
        user.exp = (user.exp || 0) + expReward
        user.lastDaily = now

        let messages = [
            "يـومـك سـعـيـد يـا اسـطـورة 🏯",
            "الـرزق الـيـوم جـاك بـكـري 💸",
            "الـيـوم يـومـك والـحـظ مـعـاك 🍀",
            "جـمـعـت الـثـروة وغـادي تـولـي غـنـي قـريـب 👑",
            "الـبـوت كـيـحـبـك وعـطـاك هـديـة خـاصـة 🎁"
        ]
        let msg = messages[Math.floor(Math.random() * messages.length)]

        let txt = `
* ━ ╼╃ ⌬〔🎁〕⌬ ╄╾ ━ *
*〔 ♛ 〕 الـجـائـزة الـيـومـيـة 𝐆𝐎𝐉𝐎*
* ━ ╼╃ ⌬〔 💎 〕⌬ ╄╾ ━ *

*〔 👋 〕 اهـلا @${m.sender.split('@')[0]}*
*〔 💬 〕 ${msg}*

*〔 💰 〕 الـفـلـوس :* +${moneyReward} 💵
*〔 💎 〕 الالـمـاس :* +${diamondReward} 💠
*〔 🏯 〕 الـخـبـرة :* +${expReward}

*〔 📊 〕 رصـيـدك الان :*
*› 💵 ${user.money} فـلـوس*
*› 💎 ${user.diamond} الـمـاس*

*تـعـال غـدا لـجـائـزة اكـبـر!*
* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`.trim()

        await conn.sendMessage(m.chat, {
            text: txt,
            mentions: [m.sender]
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 خـطـأ:* ' + e.message + '\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })
    }
}

handler.help = ['يومي']
handler.tags = ['economy']
handler.command = ['يومي', 'يومى', 'daily', 'جائزتي']
handler.group = false

export default handler