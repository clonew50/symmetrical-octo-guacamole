import { WAMessageStubType } from '@whiskeysockets/baileys'

const allowedNumbers = [
  '9647882860837@s.whatsapp.net',
  '50010934747324@lid'
]

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const emoji = '☠️'
  const signature = '.⤹𝑴𝑨𝑬𝑺𝑻𝑹𝑶 ⚡𝑮𝑬𝑶⤾.☠️🩸'

  // تحقق من المالك
  if (!allowedNumbers.includes(m.sender)) {
    return conn.sendMessage(m.chat, { 
      text: `${emoji} ❌ غير مسموح لك باستخدام هذا الأمر.\n\n${signature}` 
    }, { quoted: m })
  }

  // يجب الرد على رسالة
  if (!m.quoted) {
    return conn.sendMessage(m.chat, { 
      text: `${emoji} ⚠️ يرجى الرد على رسالة الشخص المستهدف.\n\nمثال:\nرد على رسالته واكتب: *.بحبح*\n\n${signature}` 
    }, { quoted: m })
  }

  const target = m.quoted.sender
  const targetJid = target.split('@')[0]

  if (!target) {
    return conn.sendMessage(m.chat, { text: `${emoji} ⚠️ لا يمكن تحديد المستخدم.` }, { quoted: m })
  }

  // يعمل في الجروبات فقط
  if (!m.isGroup) {
    return conn.sendMessage(m.chat, { text: `${emoji} هذا الأمر يعمل في الجروبات فقط.` }, { quoted: m })
  }

  // رسالة التحذير
  const warningMsg = await conn.sendMessage(m.chat, {
    text: `@${targetJid} قول: **بح بح** خلال **10 ثواني** وإلا هتطرد!\n\n${emoji} الوقت بدأ...`,
    mentions: [target]
  }, { quoted: m.quoted })

  let responded = false
  const timeout = 10000 // 10 ثواني

  // استمع للرد
  const listener = async (update) => {
    const msg = update.messages?.[0]
    if (!msg || !msg.message) return
    if (msg.key.fromMe) return
    const messageText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || ''
    if (!['بح بح', 'بحبح', 'ب ح ب ح'].includes(messageText.trim())) return

    const msgSender = msg.key.participant || msg.key.remoteJid
    if (msgSender !== target) return

    responded = true
    conn.sendMessage(m.chat, {
      text: `${emoji} ✅ برافو يا @${targetJid}! نطقت **بح بح** ونجوت من الطرد! 😸\n\n${signature}`,
      mentions: [target]
    }, { quoted: warningMsg })

    conn.ev.removeListener('messages.upsert', listener)
  }

  conn.ev.on('messages.upsert', listener)

  // مهلة 10 ثواني
  setTimeout(async () => {
    if (responded) return

    conn.ev.removeListener('messages.upsert', listener)

    try {
      // رسالة قبل الطرد
      await conn.sendMessage(m.chat, {
        text: `${emoji} ⏰ انتهى الوقت! @${targetJid} ما قالش **بح بح**... وداعًا! 💀\n\n${signature}`,
        mentions: [target]
      })

      // طرد من الجروب
      await conn.groupParticipantsUpdate(m.chat, [target], 'remove')
    } catch (e) {
      conn.sendMessage(m.chat, { text: `${emoji} ⚠️ فشل الطرد: ${e.message}` }, { quoted: m })
    }
  }, timeout)
}

handler.help = ['بحبح (بالرد على رسالة)']
handler.tags = ['owner', 'group']
handler.command = /^بحبح$/i
handler.group = true
handler.owner = true

export default handler