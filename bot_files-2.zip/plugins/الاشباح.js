let handler = async (m, { conn }) => {
    const metadata = await conn.groupMetadata(m.chat);
    const participants = metadata.participants;

    // تصفية الأعضاء غير الأدمين
    let sider = participants.filter(p =>!p.admin);

    if (sider.length === 0) {
        return conn.reply(m.chat, `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 فـحـص الـخـمـول ┊ ˼‏ 👻˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
> *⚡️ هذا الجروب نشط ولا يوجد به أشباح 😎*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`, m);
    }

    let siderJid = sider.map(v => v.id) // مصفوفة المنشن
    let siderList = sider.map(v => {
        let num = v.id.split('@')[0] // خلي الرقم كما هو بدون +
        return `> *🥷🏻┊@${num}*`
    }).join('\n')

    const body = `> *📌 جروب:* ${metadata.subject}\n> *👥 عدد الأعضاء:* ${participants.length}\n> *👻 عدد الأشباح:* ${sider.length}\n\n*〔 👻 قائمة الأشباح 👻 〕*\n${siderList}`

    const result = `* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 فـحـص الـخـمـول ┊ ˼‏ 👻˹ ↶〕*

*🪖 ──¤﹝الـشـرح ↶ 🕸️﹞*
${body}
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
*𝐆𝐎𝐉𝐎 𝐁𝐎𝐓 🥷🏻*`

    // الحل: استعمل sendMessage مع contextInfo
    await conn.sendMessage(m.chat, {
        text: result,
        mentions: siderJid, // هنا السر
        contextInfo: {
            mentionedJid: siderJid
        }
    }, { quoted: m });
};

handler.help = ['الاشباح'];
handler.tags = ['مجموعة'];
handler.command = /^(الاشباح|sider)$/i;
handler.group = true;
handler.admin = true;

export default handler;