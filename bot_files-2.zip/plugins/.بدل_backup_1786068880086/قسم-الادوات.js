import fs from 'fs';
import path from 'path';

function getRandomMediaUrl() {
  try {
    const filePath = path.join(process.cwd(), 'media-links.txt');
    const data = fs.readFileSync(filePath, 'utf-8');
    const links = data.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (links.length === 0) return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
    return links[Math.floor(Math.random() * links.length)];
  } catch (e) {
    console.error('تعذر قراءة media-links.txt:', e.message);
    return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
  }
}

const handler = async (m, { conn }) => {

  const imageUrl = getRandomMediaUrl();

  const messageText = `
*『 مرحبا بك يا ⌊ ${m.pushName} ⌉ في جــــيـــو بــــ⚡_KAISER_ـــوت 』*

*⌝ قسم الادوات ┋🪄🩸⌞ ⇊*
*⎔ ⋅ ───━ •﹝🩸﹞• ━─── ⋅ ⎔*
🌐 *.كروم*  
⚠️ *.ابلاغ*  
🎵 *.اسم-الاغنية*  
📺 *.جوده*  
🎨 *.تحسين*  
🖌️ *.ارسم*  
🌤️ *.الطقس*  
📌 *.ايدي-جروب*  
🆔 *.ايدي*  
🏛️ *.بايدن*  
🎭 *.تاثير*  
🎤 *.تسجيل*  
📷 *.بروفايل*  
📏 *.مسافات*  
🖼️ *.ازالة-الخلفية*  
🔗 *.رابط*  
📊 *.الاحصائيات*  
🔗 *.لرابط2*  
🌍 *.دي-ان-اس*  
🗣️ *.انطق*  
🔤 *.ترجم*  
🌐 *.اي-بي*  
📌 *.توبتيف*  
📄 *.بي-دي-اف*  
🔗 *.لرابط1*  
🔗 *.لرابط2*  
🔗 *.لرابط3*  
🔊 *.لصوت*  
✂️ *.اختصر*  
🎨 *.واتستوك*  
🔄 *.تحريك-جانبي*  
🖼️ *.ازاله-الخلفيه2*  
⚠️ *.سبويلر*  
💬 *.تفاعل*  
📂 *.لباركود*  
📞 *.بحث-ارقام*  
🏷️ *.هيدر*  
📷 *.بروفايله*  
🔄 *.محول-الوسائط*  
🔑 *.كيوار*  
📩 *.بحث-رساله*  
👻 *.تخفي*  
🌍 *.فلسطين*  
📡 *.معلومات-القناه*  
🔍 *.فحص-الموقع*  
🥘 *.وصفه*  
🍳 *.طبخ*  
🔊 *.صوتكوبو*  
🗣️ *.انطق2*  
📑 *.نماذج*  
🗣️ *.انطق3*  
🔗 *.لرابط11*  
🔄 *.تبادل*  
🎭 *.جمال*  
🔗 *.لرابط12*  
🎭 *.ملصق*  
🎭 *.ملصق2*  
🎨 *.تحسين2*  
🎭 *.للللللملصق3*  
🎵 *.تفاصيل-الاغنيه*  
💰 *.عمله*  
🩸 *.تخيل*  
⚫ *.لاسود*  
*⎔ ⋅ ───━ •﹝🩸﹞• ━─── ⋅ ⎔*
> بــــ⚡_KAISER_ـــوت
  `.trim();

  await conn.sendMessage(m.chat, { text: "*_جاري إرسال القسم....... 💗🩸_*" }, { quoted: m });

  await conn.sendMessage(m.chat, {
    image: { url: imageUrl },
    caption: messageText
  }, { quoted: m });

  await conn.sendMessage(m.chat, { react: { text: '🩸', key: m.key } });
};

handler.command = /^قسم-الادوات$/i;
handler.tags = ["اوبيتو"];
handler.help = ["قسم-الادوات"];

export default handler;