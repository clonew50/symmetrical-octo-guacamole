import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';

// متغيرات لحفظ اخر فيديو وصوت تم ارسالهم
global.lastAllVideo = global.lastAllVideo || null
global.lastAllAudio = global.lastAllAudio || null

function getRandomNotSame(arr, last) {
    let filtered = arr.filter(v => v!== last)
    if(filtered.length === 0) filtered = arr
    let pick = filtered[Math.floor(Math.random() * filtered.length)]
    return pick
}

const handler = async (m, { conn }) => {

    const devNumber = '212674375708';
    const devName = '𝑌𝑂𝑁𝑂 👑';
    const botName = 'ِ🕷️⃝⃕🥷🏻 *GOJO* 𝆹َ𝅥🕷️ 𝒃𝒐𝒕 ';

    const messageText = `
* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
*┃ 👑┊❝ مـرحـبـاً بـك يـا ❪${m.pushName}❫ ❞┊👑┃*
*┃ 🌍┊❝ فـي كـوكـب 『𝐆𝐎𝐉𝐎-𝐁𝐎𝐓』 الـعـام ❞┊🌍┃*
*╰───⊰ 🌍❀⊱───╮*

*✦ ━━━━━ ❀👑❀ ━━━━━ ✦*
*┃ 📜┊ جــمــيــع الاوامــر ┊📜┃*
*✦ ━━━━━ ❀👑❀ ━━━━━ ✦*

*╭──⊰ 🔍 قــســم الــبــحــث 🔍 ⊱──╮*
📂 *.apk*
🔎 *.جيتهاب*
🔎 *.تابع-شغل*
🎵 *.تيك3*
📺 *.تيوبي*
🎶 *.شغل*
🔊 *.صو*
🎤 *.صوت*
🎧 *.صوتوي*
🖼️ *.صوره*
🎙️ *.فويس*
📹 *.فيد*
🎞️ *.فيديو*
📽️ *.فيديوي*
📝 *.كلمات*
🎼 *.ملف-صوت*
▶️ *.يوتيوب*
*╰──⊰ 🔍 ⊱──╯*

*╭──⊰ 🪄 قــســم الــفــعــالــيــات 🪄 ⊱──╮*
📝┊⇇『احزر』
📍┊⇇『علم』
🗃️┊⇇『عين』
⚽┊⇇『كوره』
📿┊⇇『دين』
*╰──⊰ 🪄 ⊱──╯*
*⚠️ هـذا الـقـسـم قـيـد الـتـطـويـر*

*╭──⊰ 🎭 قــســم الــتــرفــيــه 🎭 ⊱──╮*
👥┊⇇『اصحاب』
⚔️┊⇇『اعدام』
🏆┊⇇『توب』
🎭┊⇇『الشخصيه』
🗣️┊⇇『الصراحه』
⚽┊⇇『الكوره』
😈┊⇇『انحرافي』
🎸┊⇇『ايمو』
🐾┊⇇『بوستات』
📝┊⇇『بوست』
🚔┊⇇『بوليس』
💎┊⇇『بيبضني』
❤️┊⇇『بيحبني』
💔┊⇇『بيكرهني』
👑┊⇇『تاج』
💣┊⇇『تفجير』
🔠┊⇇『حروف』
🍀┊⇇『حظي』
🐏┊⇇『خروف』
💍┊⇇『خطوبه』
🧠┊⇇『ذكاء』
🦾┊⇇『رجولتي』
🧑‍🤝‍🧑┊⇇『رفيق』
🎭┊⇇『شخصيه』
🤝┊⇇『صديق』
🎤┊⇇『صراحتي』
💔┊⇇『طلاق』
💞┊⇇『علاقه』
❓┊⇇『فزوره』
🎥┊⇇『فيلم』
🔪┊⇇『قتل』
🐱┊⇇『قطه』
📖┊⇇『مقولات』
🎲┊⇇『نرد』
📊┊⇇『نوعيه』
🔍┊⇇『هذا』
❔┊⇇『هل』
⚰️┊⇇『وفاتي』
*╰──⊰ 🎭 ⊱──╯*
*⚠️ هـذا الـقـسـم قـيـد الـتـطـويـر*

*╭──⊰ 📥 قــســم الــتــحــمــيــلات 📥 ⊱──╮*
📝┊⇇『بين-فيديو』
📍┊⇇『تويتر』
🗃️┊⇇『جيبهاب』
🗄️┊⇇『جيبتهوب』
💌┊⇇『كابكات』
📤┊⇇『ايديت』
📥┊⇇『تطبيق』
📯┊⇇『انستا』
💎┊⇇『تيكتوك』
🛢️┊⇇『تيك-صوت』
⚙️┊⇇『تيك-جوده』
🖼️┊⇇『بين-صور』
*╰──⊰ 📥 ⊱──╯*

*╭──⊰ 🤖 قــســم الــصــوتــيــات 🤖 ⊱──╮*
🗿┊⇇『عميق』
⛓‍💥┊⇇『منفوخ』
🎐┊⇇『تخين』
⚽┊⇇『صاخب』
📿┊⇇『سريع』
📍┊⇇『تخينن』
🗃️┊⇇『رفيع』
📬┊⇇『تقطيع』
📕┊⇇『روبوت』
📆┊⇇『بطيء』
🗞️┊⇇『ناعم』
🐿️┊⇇『سنجاب』
🎙️┊⇇『tts2』
🗣️┊⇇『انطق』
🔊┊⇇『انطق2』
🎤┊⇇『انطق3』
🎚️┊⇇『تاثير』
📑┊⇇『تفاصيل-الأغنية』
🏆┊⇇『توبتيف』
🔁┊⇇『صوتكوبو』
🔇┊⇇『لصوت』
*╰──⊰ 🤖 ⊱──╯*

*╭──⊰ 🧰 قــســم الــادوات 🧰 ⊱──╮*
🌐 *.كروم*
⚠️ *.ابلاغ*
🎵 *.اسم-الاغنية*
📺 *.جوده*
🎨 *.تحسين*
🖌️ *.ارسم*
🌤️ *.الطقس*
📌 *.ايدي-جروب*
🆔 *.ايدي*
🏛️ *.بايدن*
🎭 *.تاثير*
🎤 *.تسجيل*
📷 *.بروفايل*
📏 *.مسافات*
🖼️ *.ازالة-الخلفية*
🔗 *.رابط*
📊 *.الاحصائيات*
🔗 *.لرابط2*
🌍 *.دي-ان-اس*
🗣️ *.انطق*
🔤 *.ترجم*
🌐 *.اي-بي*
📌 *.توبتيف*
📄 *.بي-دي-اف*
🔗 *.لرابط1*
🔗 *.لرابط2*
🔗 *.لرابط3*
🔊 *.لصوت*
✂️ *.اختصر*
🎨 *.واتستوك*
🔄 *.تحريك-جانبي*
🖼️ *.ازاله-الخلفيه2*
⚠️ *.سبويلر*
💬 *.تفاعل*
📜 *.لباركود*
📞 *.بحث-ارقام*
🏷️ *.هيدر*
📷 *.بروفايله*
🔄 *.محول-الوسائط*
🔑 *.كيوار*
📩 *.بحث-رساله*
🏯 *.تخفي*
🌍 *.فلسطين*
📡 *.معلومات-القناه*
🔍 *.فحص-الموقع*
🥘 *.وصفه*
🍳 *.طبخ*
🔊 *.صوتكوبو*
🗣️ *.انطق2*
📑 *.نماذج*
🗣️ *.انطق3*
🔗 *.لرابط11*
🔄 *.تبادل*
🎭 *.جمال*
🔗 *.لرابط12*
🎭 *.ملصق*
🎭 *.ملصق2*
🎨 *.تحسين2*
🎭 *.للملصق3*
🎵 *.تفاصيل-الplay*
💰 *.عمله*
🤖 *.تخيل*
⚫ *.لاسود*
*╰──⊰ 🧰 ⊱──╯*

*╭──⊰ 🕋 قــســم الــديــن 🕋 ⊱──╮*
🕋┊⇇『اذكاء-الصباح』
🕋┊⇇『اذكاء-المساء』
🕋┊⇇『اذكاء-النوم』
🕋┊⇇『دعاء』
🕋┊⇇『فيديو-قرأن』
🕋┊⇇『مواقيت_الصلاة』
🕋┊⇇『خطبة』
🕋┊⇇『دعاء-رمضان』
🕋┊⇇『الله』
🕋┊⇇『حديث』
*╰──⊰ 🕋 ⊱──╯*

*╭──⊰ 🔍 قــســم الاخــبــار 🔍 ⊱──╮*
🔍┊⇇『IP』
🔍┊⇇『اخبار-انمي』
🔍┊⇇『اخبار-كره』
🔍┊⇇『بحث-تيك』
🔍┊⇇『دروس』
🔍┊⇇『فري-فاير』
🔍┊⇇『مانجا』
🔍┊⇇『ناسا』
*╰──⊰ 🔍 ⊱──╯*

*╭──⊰ 🧠 قــســم الــذكــاء 🧠 ⊱──╮*
🧠┊⇇『اوبو』
🧠┊⇇『اوبيتو』
🧠┊⇇『بلاك』
🧠┊⇇『بوت』
🧠┊⇇『ديبسيك』
🧠┊⇇『عائلة』
*╰──⊰ 🧠 ⊱──╯*

*╭━─━─━─❀⚔️❀─━─━─━╮*
*┃ 👑┊ البوت: 『𝐆𝐎𝐉𝐎-𝐁𝐎𝐓』 ┊👑┃*
*┃ ⚔️┊ توقيع: 𝐘𝐎𝐍𝐎 𖠲 ┊⚔️┃*
*╰━─━─━─❀⚔️❀─━─━─━╯*
* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *
    `.trim();

    await conn.sendMessage(m.chat, { text: "[🕸️] جاري تجهيز جميع الاوامر وارسالها انتضر 🪖 ..." }, { quoted: m });

    // 🛡️ نفس التوثيق ديال الاوامر
    const verifiedMessage = {
        key: {
            participants: "0@s.whatsapp.net",
            fromMe: false,
            id: "OFFICIAL_VERIFIED_SERVICE"
        },
        message: {
            locationMessage: {
                name: `𖤍${botName}𖤍`,
                jpegThumbnail: await (await fetch('https://files.catbox.moe/39kria.jpg')).buffer(),
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${devName};;;\nFN:${devName}\nORG:${botName};\nTITLE:Developer\nitem1.TEL;waid=${devNumber}:+${devNumber}\nitem1.X-ABLabel:HULK SUPPORT\nX-WA-BIZ-DESCRIPTION:Official Verified Service\nX-WA-BIZ-NAME:${devName}\nEND:VCARD`
            }
        },
        participant: "0@s.whatsapp.net"
    };

    // 1️⃣ فيديو عشوائي
    const videoUrls = [
        'https://files.catbox.moe/jzbdkc.mp4',
        'https://files.catbox.moe/hgkawr.mp4',
        'https://files.catbox.moe/a4axym.mp4'
    ];
    const randomVideo = getRandomNotSame(videoUrls, global.lastAllVideo);
    global.lastAllVideo = randomVideo

    var messa = await prepareWAMessageMedia({
        video: { url: randomVideo },
        gifPlayback: true
    }, { upload: conn.waUploadToServer });

    await conn.relayMessage(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: messageText },
                    footer: { text: '『 𝐆𝐎𝐉𝐎 ⃝𝐁𝐎𝐓 』' },
                    header: { hasMediaAttachment: true, videoMessage: messa.videoMessage },
                    nativeFlowMessage: { buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: `🏠 الـرجـوع لـلـرئيـسـيـة`, id: '.اوامر' }) }] }
                }
            }
        }
    }, { quoted: verifiedMessage });

    // 2️⃣ صوت عشوائي
    const audioUrls = [
        'https://files.catbox.moe/a4axym.mp4',
        'https://files.catbox.moe/jzbdkc.mp4',
        'https://files.catbox.moe/hgkawr.mp4'
    ];
    const randomAudio = getRandomNotSame(audioUrls, global.lastAllAudio);
    global.lastAllAudio = randomAudio

    await conn.sendMessage(m.chat, { audio: { url: randomAudio }, mimetype: 'audio/mp4', ptt: true }, { quoted: verifiedMessage });
    await conn.sendMessage(m.chat, { react: { text: '👑', key: m.key } });
};

handler.command = /^جميع-الاوامر$/i;
handler.tags = ["main"];
handler.help = ["جميع-الاوامر"];

export default handler;