require('./settings');
const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const moment = require("moment-timezone");
const path = require("path")
const fileType = require('file-type')
const request = require('request');
const ffmpeg = require('fluent-ffmpeg');
const PhoneNumber = require('awesome-phonenumber')
const FormData = require('form-data')
const cheerio = require('cheerio');
const qs = require('qs');
const { exec, execSync, spawn } = require("child_process");
const crypto = require('crypto');
const { randomBytes } = crypto;
const { 
    makeWASocket, 
    makeCacheableSignalKeyStore, 
    downloadContentFromMessage, 
    generateWAMessageContent,
    generateWAMessageFromContent, 
    generateWAMessage,
    generateForwardMessageContent,
    prepareWAMessageMedia, 
    useSingleFileAuthState, 
    useMultiFileAuthState,
    fetchLatestBaileysVersion,
    MessageType,
    proto,
    Browsers,
    getContentType,
    DisconnectReason,
    areJidsSameUser,
	InteractiveMessage,
    WA_DEFAULT_EPHEMERAL    
} = require('@whiskeysockets/baileys')

const { smsg, await, clockString, delay, enumGetKey, fetchBuffer, fetchJson, libformat, formatDate, formatp, tanggal, generateProfilePicture, getBuffer, getGroupAdmins, getRandom, isUrl, json, logic, msToDate, parseMention, sizeLimit, runtime, sleep, sort, toNumber } = require('./lib/myfunction');
const { CatBox, TelegraPh, floNime, UploadFileUgu, uptotelegra } = require('./lib/uploader');

const owner = JSON.parse(fs.readFileSync('./database/owner.json'));
const premium = JSON.parse(fs.readFileSync('./database/premium.json'));
const ntlinkgc = JSON.parse(fs.readFileSync('./database/antilink.json'));
const nttagsw = JSON.parse(fs.readFileSync('./database/antitagsw.json'));
const afkData = JSON.parse(fs.readFileSync("./database/afk.json"))
const bannedList = JSON.parse(fs.readFileSync("./database/banuser.json")) 
let badwordList = []
try {
  if (fs.existsSync("./database/badword.json")) {
    badwordList = JSON.parse(fs.readFileSync("./database/badword.json"))
  }
} catch (e) {}

let antiBadwordData = {}
try {
  if (fs.existsSync("./database/antibadword.json")) {
    antiBadwordData = JSON.parse(fs.readFileSync("./database/antibadword.json"))
  }
} catch (e) {}

// ========== DATABASE PAYMENT ==========
let paymentData = {}
try {
  if (fs.existsSync("./database/payment.json")) {
    paymentData = JSON.parse(fs.readFileSync("./database/payment.json"))
  }
} catch (e) {}

let pendingPayments = {} // Menyimpan pembayaran pending { id: { user, product, price, timestamp, status, proof } }
let orderIdCounter = 1

// Load pending payments dari file
try {
  if (fs.existsSync("./database/pending.json")) {
    pendingPayments = JSON.parse(fs.readFileSync("./database/pending.json"))
    // Get max order id
    const ids = Object.keys(pendingPayments).map(id => parseInt(id))
    if (ids.length) orderIdCounter = Math.max(...ids) + 1
  }
} catch (e) {}

const pgroup = JSON.parse(fs.readFileSync('./database/groupadd.json'));
// ========== LOAD DATABASE ==========
// ========== LOAD DATABASE BADWORD ==========
let tebaklagu = []
let _family100 = []
let kuismath = []
let tebakgambar = []
let tebakkata = []
let transactionDetails = {};
let caklontong = []
let caklontong_desk = []
let tebakkalimat = []
let tebaklirik = []
let tebaktebakan = []
let tebakbendera = []
let tebakbendera2 = []
let tebakkabupaten = []
let tebakkimia = []
let tebakasahotak = []
let siapaaku = []
let tebaksusunkata = []
let tekateki = []

module.exports = satanic = async (satanic, m, chatUpdate, store) => {
try {

        const { type, quotedMsg, mentioned, now, fromMe } = m
        const body = (m.mtype === 'conversation') ? m.message.conversation : 
             (m.mtype === 'imageMessage') ? m.message.imageMessage?.caption : 
             (m.mtype === 'videoMessage') ? m.message.videoMessage?.caption : 
             (m.mtype === 'extendedTextMessage') ? m.message.extendedTextMessage?.text : 
             (m.mtype === 'buttonsResponseMessage') ? m.message.buttonsResponseMessage?.selectedButtonId : 
             (m.mtype === 'listResponseMessage') ? m.message.listResponseMessage?.singleSelectReply?.selectedRowId : 
             (m.mtype === 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage?.selectedId : 
             (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply?.selectedRowId || m.text) : 
             m.text || '';
const bady = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'interactiveResponseMessage') ? appenTextMessage(JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id, chatUpdate) : (m.mtype == 'templateButtonReplyMessage') ? appenTextMessage(m.msg.selectedId, chatUpdate) : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ' '

let budy = m.message.conversation || (m.message.extendedTextMessage && m.message.extendedTextMessage.text) || ``
    const prefix = global.prefix ? (Array.isArray(global.prefix) ? (global.prefix.slice().sort((a, b) => b.length - a.length).find(p => body.startsWith(p)) || global.prefix[0]) : global.prefix) : ""

async function appenTextMessage(text, chatUpdate) {
let messages = await generateWAMessage(m.chat, { text: text, mentions: m.mentionedJid }, {
userJid: satanic.user.id,
quoted: m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, satanic.user.id)
messages.key.id = m.key.id
messages.pushName = pushname
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
satanic.ev.emit('messages.upsert', msg)
}
   const chath = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == "listResponseMessage") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == "messageContextInfo") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : ''
        const pes = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text: ' '
        const messagesC = pes.slice(0).trim()
        const content = JSON.stringify(m.message)
const isCmd = body && typeof body === 'string' && body.startsWith(prefix)
        const from = m.key.remoteJid
       const messagesD = body ? body.slice(0).trim().split(/ +/).shift().toLowerCase() : ''
        const command = isCmd ? body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase() : ""
        const args = body ? body.trim().split(/ +/).slice(1) : []
        const userDb = global?.db?.users?.[m.sender]
        const pushname =
  (userDb?.registered && userDb?.name)
    ? userDb.name
    : (m.pushName || "Misterius")
        const botNumber = await satanic.decodeJid(satanic.user.id)
        const isCreator = owner.includes(m.sender);
        const text = args.join(" ")
        const q = text
        const quoted = m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
        const isMedia = /image|video|sticker|audio/.test(mime)
        const isImage = (type == 'imageMessage')
		const isVideo = (type == 'videoMessage')
		const isAudio = (type == 'audioMessage')
		const isSticker = (type == 'stickerMessage')
		const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
		const isQuotedViewOnce = type === 'extendedTextMessage' && content.includes('viewOnceMessageV2')
        const isQuotedLocation = type === 'extendedTextMessage' && content.includes('locationMessage')
        const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
        const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
        const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
        const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')
        const isQuotedDocument = type === 'extendedTextMessage' && content.includes('documentMessage')

        store.groupMetadata = store.groupMetadata || {};
        const invalidMembers = [];

        if (m.isGroup) {
            for (const [gid, meta] of Object.entries(store.groupMetadata || {})) {
                if (!meta.participants) continue;
                const missing = meta.participants.filter(p => !p.jid && !p.lid && p.id);
                if (missing.length) {
                    invalidMembers.push({
                        groupId: gid,
                        groupName: meta.subject || "(No Subject)",
                        members: missing
                    });
                }
            }

            if (Object.keys(store.groupMetadata).length === 0 || invalidMembers.length >= 1) {
                store.groupMetadata = await satanic.groupFetchAllParticipating();
            }
        }

        const groupMetadata = m.isGroup
            ? store.groupMetadata[m.chat]
            || (store.groupMetadata[m.chat] = await satanic.groupMetadata(m.chat).catch(e => {}))
            : '';

        const groupName = m.isGroup ? groupMetadata.subject : ''
        const participants = m.isGroup ? await groupMetadata.participants : ''

        if (m.isGroup && m.sender.endsWith("@lid")) {
            m.sender = participants.find(p => p.lid === m.sender)?.jid || m.sender;
        }

        const groupAdmins = m.isGroup ? participants.filter((v) => v.admin !== null && v.jid).map((i) => i.jid) : [];
        const groupOwner = m.isGroup ? groupMetadata.owner : ''
        const groupMembers = m.isGroup ? groupMetadata.participants : ''
    	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
    	const groupId = m.isGroup ? m.chat : null;
        const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
    	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
    	const Antilinkgc = m.isGroup ? ntlinkgc.includes(m.chat) : false
    const Antitagsw = m.isGroup ? nttagsw.includes(m.chat) : false
        const sender = m.sender
        const senderNumber = sender.split('@')[0]
        const isGroupss = pgroup.includes(m.chat);
    	const isPrem = premium.includes(m.sender)
    	
    	
if (isCmd && m.message && m.isGroup) {
    console.log(`
┌────────── [ GROUP CHAT LOG ] ──────────┐
│ 🕒 Time      : ${chalk.green(new Date().toISOString().slice(0, 19).replace('T', ' '))}
│ 📝 Message   : ${chalk.blue(budy || m.mtype)}
│ 👤 Sender    : ${chalk.magenta(pushname)} (${chalk.cyan(m.sender)})
│ 🏠 Group     : ${chalk.yellow(groupName)} (${chalk.cyan(m.chat)})
└────────────────────────────────────────┘
    `);
} else {
    console.log(`
┌───────── [ PRIVATE CHAT LOG ] ─────────┐
│ 🕒 Time      : ${chalk.green(new Date().toISOString().slice(0, 19).replace('T', ' '))}
│ 📝 Message   : ${chalk.blue(budy || m.mtype)}
│ 👤 Sender    : ${chalk.magenta(pushname)} (${chalk.cyan(m.sender)})
└────────────────────────────────────────┘
    `);
}
            
 const reply = (teks) => {
satanic.sendMessage(from, { text: teks }, { quoted : m})
}




// ANTI LINK GC - SIMPLE
if (Antilinkgc && !isAdmins && isBotAdmins) {
  if (budy.includes("chat.whatsapp.com") || budy.includes("whatsapp.com/channel")) {
    try {
      await satanic.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.key.participant
        }
      });
    } catch (e) {}
  }
}

// ==================== SIMPLE ANTI BADWORD (SEPERTI ANTILINK) ====================

// ==================== DEBUG VERSION ====================
// ==================== FUNCTION ====================

function getBadwordList() {
  try {
    if (fs.existsSync("./database/badword.json")) {
      return JSON.parse(fs.readFileSync("./database/badword.json"))
    }
  } catch (e) {}
  return []
}

function getAntiBadwordData() {
  try {
    if (fs.existsSync("./database/antibadword.json")) {
      return JSON.parse(fs.readFileSync("./database/antibadword.json"))
    }
  } catch (e) {}
  return {}
}

// ==================== AUTO DETECTION (SIMPEL) ====================

if (m.isGroup && isBotAdmins && !isAdmins) {
  const antiBadwordData = getAntiBadwordData()
  const Antibadwordgc = antiBadwordData[m.chat] || false
  
  if (Antibadwordgc) {
    const badwordList = getBadwordList()
    const teks = budy.toLowerCase()
    const found = badwordList.some(kata => teks.includes(kata.toLowerCase()))
    
    if (found) {
      try {
        await satanic.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant
          }
        })
        
        await satanic.sendMessage(m.chat, { 
          text: `⚠️ *BADWORD TERDETEKSI!*\n\n@${m.sender.split('@')[0]} menggunakan kata terlarang!\n\nPesan telah dihapus!`,
          mentions: [m.sender]
        })
      } catch (e) {}
    }
  }
}


// ANTI TAG SW - SIMPLE
if (Antitagsw && !isAdmins && isBotAdmins) {
  const isTagMessage = (m.mtype === 'groupStatusMentionMessage' || 
                        m.mtype === 'groupStatusMessageV2' ||
                        (m.mentionedJid && m.mentionedJid.length > 0) ||
                        (m.body && (m.body.includes("@semua") || m.body.includes("@all"))));
  
  if (isTagMessage) {
    try {
      await satanic.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.key.participant
        }
      });
    } catch (e) {}
  }
}
// ========== CEK AFK (MENTION & REPLY) ==========
if ((m.mentionedJid && m.mentionedJid.length > 0 && m.sender !== botNumber) || (m.quoted && m.quoted.sender)) {
  try {
    // Pastikan participants adalah array
    const participantsArray = Array.isArray(participants) ? participants : [];
    
    // Cek mention
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      for (let mention of m.mentionedJid) {
        const participant = participantsArray.find(p => p && (p.id === mention || p.jid === mention));
        const mentionJid = participant ? (participant.jid || participant.id) : mention;
        const mentionNomor = mentionJid.split('@')[0];
        
        if (afkData[mention] || afkData[mentionJid] || (participant?.id && afkData[participant.id])) {
          const afk = afkData[mention] || afkData[mentionJid] || (participant?.id && afkData[participant.id]);
          const duration = (Date.now() - afk.time) / 1000;
          const minutes = Math.floor(duration / 60);
          const reason = afk.reason || "Tidak ada alasan";
          
          await satanic.sendMessage(m.chat, {
            text: `🔕 *@${mentionNomor} sedang AFK*\n📝 Alasan: ${reason}\n⏰ ${minutes} menit yang lalu`,
            contextInfo: { mentionedJid: [mentionJid] }
          });
        }
      }
    }
    
    // Cek reply ke pesan user AFK
    if (m.quoted && m.quoted.sender) {
      const quotedSender = m.quoted.sender;
      const participant = participantsArray.find(p => p && (p.jid === quotedSender || p.id === quotedSender));
      const quotedJid = participant ? (participant.jid || participant.id) : quotedSender;
      const quotedNomor = quotedJid.split('@')[0];
      
      if (afkData[quotedJid] || afkData[participant?.id] || afkData[quotedSender]) {
        const afk = afkData[quotedJid] || afkData[participant?.id] || afkData[quotedSender];
        const duration = (Date.now() - afk.time) / 1000;
        const minutes = Math.floor(duration / 60);
        const reason = afk.reason || "Tidak ada alasan";
        
        await satanic.sendMessage(m.chat, {
          text: `🔕 *@${quotedNomor} sedang AFK*\n📝 Alasan: ${reason}\n⏰ ${minutes} menit yang lalu\n\n📌 Balasanmu tidak akan dibalas sekarang.`,
          contextInfo: { mentionedJid: [quotedJid] }
        });
      }
    }
    
  } catch (e) {
    console.log("Error cek mention/reply AFK:", e);
  }
}

// ========== HAPUS AFK SAAT USER BERAKTIVITAS ==========
try {
  // Pastikan participants adalah array
  const participantsArray = Array.isArray(participants) ? participants : [];
  const participant = participantsArray.find(p => p && (p.jid === m.sender || p.id === m.sender));
  const lid = participant ? (participant.id || participant.jid) : m.sender;
  
  if (afkData[lid] || afkData[m.sender]) {
    delete afkData[lid];
    delete afkData[m.sender];
    fs.writeFileSync("./database/afk.json", JSON.stringify(afkData, null, 2));
    await satanic.sendMessage(m.chat, { text: `👋 Selamat datang kembali! AFK dinonaktifkan.` }, { quoted: m });
  }
} catch (e) {
  console.log("Error hapus AFK:", e);
}

// ========== FUNGSI PAYMENT ==========
function savePaymentData() {
  fs.writeFileSync("./database/payment.json", JSON.stringify(paymentData, null, 2))
}

function savePendingPayments() {
  fs.writeFileSync("./database/pending.json", JSON.stringify(pendingPayments, null, 2))
}

// Format Rupiah
function formatRupiah(angka) {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(angka)
}

// Generate random order ID
function generateOrderId() {
  return orderIdCounter++
}


// Auto cancel expired orders (taruh di dalam try block sebelum end)
// Cek setiap 1 menit
setInterval(() => {
  const now = Date.now()
  let changed = false
  
  for (const [id, order] of Object.entries(pendingPayments)) {
    if (order.status === 'pending' && order.deadline && now > order.deadline) {
      order.status = 'cancelled'
      changed = true
      
      // Notifikasi ke user
      satanic.sendMessage(order.user, { text: `⏰ *ORDER KADALUARSA!*\nOrder ID: ${id}\nWaktu pembayaran sudah habis. Silakan order ulang.` }).catch(e => {})
    }
  }
  
  if (changed) savePendingPayments()
}, 60000)











// Di dalam command handler, setelah isCmd dan sebelum switch case
if (isCmd && bannedList.includes(m.sender)) {
  return reply(`🚫 *AKSES DITOLAK!*\n\nKamu telah di-ban oleh admin dan tidak dapat menggunakan perintah bot.`);
}

if (global.onlygrup && !isGroupss && !isCreator) {
    return;
}


if (global.autotyping) {
if (command) { 
satanic.readMessages([m.key]);
}
satanic.sendPresenceUpdate('composing', from);
}
        
if (global.autoread) {
satanic.readMessages([m.key]);
}


const sendButton = async (jid, text, footer, media, buttons, quoted) => {
            let mediaMessage = {};
            if (media) {
                try {
                    const preparedMedia = await prepareWAMessageMedia({ image: media }, { upload: satanic.waUploadToServer });
                    mediaMessage = { imageMessage: preparedMedia.imageMessage };
                } catch (e) {
                    console.error("Gagal upload media:", e);
                }
            }
            const msg = generateWAMessageFromContent(jid, {
                viewOnceMessage: {
                    message: {
                        "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: text }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: footer }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: !!media,
                                ...mediaMessage
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: buttons
                            })
                        })
                    }
                }
            }, { userJid: satanic.user.id, quoted: quoted });
            await satanic.relayMessage(jid, msg.message, { messageId: msg.key.id });
        }
        
satanic.family100 = satanic.family100 ? satanic.family100 : {};

if (from in satanic.family100 && !m.key.fromMe) {
    let similarity = require('similarity');
    let threshold = 0.72;
    let id = m.chat;
    let room = satanic.family100[id];
    let text = budy.toLowerCase().replace(/[^\w\s\-]+/, '');
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy);
    
    let perluUpdate = false; // flag untuk cek perlu kirim ulang caption atau tidak

    if (!isSurrender) {
        let matchedIndex = -1;
        let highestSimilarity = 0;
        
        for (let i = 0; i < room.jawaban.length; i++) {
            if (!room.terjawab[i]) {
                let sim = similarity(room.jawaban[i], text);
                if (sim >= threshold && sim > highestSimilarity) {
                    highestSimilarity = sim;
                    matchedIndex = i;
                }
            }
        }
        
        if (matchedIndex === -1 && highestSimilarity >= threshold) {
            return reply('Dikit lagi!');
        }
        
        if (matchedIndex !== -1) {
            if (room.terjawab[matchedIndex]) return;
            room.terjawab[matchedIndex] = m.sender;
            perluUpdate = true; // ada jawaban baru
        }
    } else {
        perluUpdate = true; // menyerah, perlu update
    }

    let isWin = room.terjawab.length === room.terjawab.filter(v => v).length;
    
    if (isWin || isSurrender) {
        perluUpdate = true;
    }

    // Hanya kirim caption jika perlu update
    if (perluUpdate) {
        let caption = `*GAME FAMILY100*
*Soal:* ${room.soal}
Terdapat ${room.jawaban.length} jawaban${room.jawaban.find(v => v.includes(' ')) ? `
(beberapa jawaban terdapat spasi)`
            : ''}
${isWin ? `*SEMUA JAWABAN TERJAWAB ✅*` : isSurrender ? '*MENYERAH ❌*' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
            return isSurrender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '✓ ' + room.terjawab[index].split('@')[0] : ''}`.trim() : false;
        }).filter(v => v).join('\n')}
        `.trim();
        
        let mentions = room.terjawab.filter(v => v).map(v => v + '@s.whatsapp.net');
        
        // Hapus pesan lama biar ga numpuk
        if (satanic.family100[id].msg) {
            await satanic.sendMessage(from, { delete: satanic.family100[id].msg.key }).catch(_ => _);
        }
        
        satanic.sendMessage(from, { text: caption, mentions: mentions }, { quoted: m }).then(msg => {
            satanic.family100[id].msg = msg;
        }).catch(_ => _);
    }

    if (isWin || isSurrender) {
        delete satanic.family100[id];
    }
}

satanic.tebakkimia = satanic.tebakkimia ? satanic.tebakkimia : {};
if (from in satanic.tebakkimia && !m.key.fromMe) {
    let id = m.chat
    let json = satanic.tebakkimia[id]
    let jawabanBenar = json.jawaban
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy)
    let isHint = /^(hint|bantuan)$/i.test(budy)
    
    // Fitur hint / bantuan
    if (isHint) {
        let jawaban = jawabanBenar.toLowerCase()
        let petunjuk = jawaban.split('').map((huruf, i) => {
            return i === 0 || i === jawaban.length - 1 ? huruf : '_'
        }).join('')
        return reply(`💡 *HINT / BANTUAN:*\n\n🔍 Petunjuk: ${petunjuk}\n📝 Panjang lambang: *${jawaban.length}* huruf\n🔤 Huruf awal: *${jawaban[0]}*\n🔚 Huruf akhir: *${jawaban[jawaban.length - 1]}*\n🧴 Unsur: ${json.unsur}`)
    }
    
    // Fitur nyerah
    if (isSurrender) {
        let teks = `😔 *MENYERAH*\n\nJawaban (Lambang) yang benar adalah: *${jawabanBenar}*\n🧴 Unsur: ${json.unsur}\n\nIngin mencoba lagi? Ketik *tebakkimia*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.tebakkimia[id]
        return
    }
    
    // Cek jawaban
    if (budy.toLowerCase() == jawabanBenar.toLowerCase().trim()) {
        let teks = `🎉 *BENAR!* 🎉\n\nLambang: *${jawabanBenar}*\n🧴 Unsur: ${json.unsur}\n\nIngin bermain lagi? Ketik *tebakkimia*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.tebakkimia[id]
    } else {
        
    }
}
satanic.tekateki = satanic.tekateki ? satanic.tekateki : {}
if (from in satanic.tekateki && !m.key.fromMe) {
    const similarity = require('similarity')
    const threshold = 0.72
    let id = m.chat
    let json = satanic.tekateki[id]
    let jawabanBenar = json.jawaban
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy)
    let isHint = /^(hint|bantuan)$/i.test(budy)
    
    // Fitur hint / bantuan
    if (isHint) {
        let jawaban = jawabanBenar.toLowerCase()
        let petunjuk = jawaban.split('').map((huruf, i) => {
            return i === 0 || i === jawaban.length - 1 ? huruf : '_'
        }).join('')
        return reply(`💡 *HINT / BANTUAN:*\n\n🔍 Petunjuk: ${petunjuk}\n📝 Panjang jawaban: *${jawaban.length}* huruf\n🔤 Huruf awal: *${jawaban[0]}*\n🔚 Huruf akhir: *${jawaban[jawaban.length - 1]}*`)
    }
    
    // Fitur nyerah
    if (isSurrender) {
        let teks = `😔 *MENYERAH*\n\nJawaban yang benar adalah: *${jawabanBenar}*\n\nIngin mencoba lagi? Ketik *tekateki*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.tekateki[id]
        return
    }
    
    // Cek similarity (dikit lagi)
    let similarityScore = similarity(budy.toLowerCase(), jawabanBenar.toLowerCase().trim())
    if (similarityScore >= threshold && similarityScore < 1) {
        return reply(`*Dikit lagi!* 🔥\n\nJawaban kamu hampir benar, coba sedikit lagi!`)
    }
    
    // Cek jawaban benar
    if (budy.toLowerCase() == jawabanBenar.toLowerCase().trim()) {
        let teks = `🎉 *BENAR!* 🎉\n\nJawaban: *${jawabanBenar}*\n\nIngin bermain lagi? Ketik *tekateki*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.tekateki[id]
    } else {
        
    }
}

satanic.tebakgambar = satanic.tebakgambar ? satanic.tebakgambar : {}
if (from in satanic.tebakgambar && !m.key.fromMe) {
    let id = m.chat
    let json = satanic.tebakgambar[id][1]
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy)
    let isHint = /^(hint|bantuan)$/i.test(budy)
    if (isHint) {
        let jawaban = json.jawaban.toLowerCase()
        let petunjuk = jawaban.split('').map((huruf, i) => {
            return i === 0 || i === jawaban.length - 1 ? huruf : '_'
        }).join('')
        return reply(`💡 *HINT / BANTUAN:*\n\n🔍 Petunjuk: ${petunjuk}\n📝 Panjang jawaban: *${jawaban.length}* huruf\n🔤 Huruf awal: *${jawaban[0]}*\n🔚 Huruf akhir: *${jawaban[jawaban.length - 1]}*`)
    }
    if (isSurrender) {
        let teks = `😔 *MENYERAH*\n\nJawaban yang benar adalah: *${json.jawaban}*\n\nIngin mencoba lagi? Ketik *tebakgambar*`
        reply(teks)
        clearTimeout(satanic.tebakgambar[id][2])
        delete satanic.tebakgambar[id]
        return
    }
    if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
        let teks = `🎉 *BENAR!* 🎉\n\nJawaban: *${json.jawaban}*\n\nIngin bermain lagi? Ketik *tebakgambar*`
        reply(teks)
        clearTimeout(satanic.tebakgambar[id][2])
        delete satanic.tebakgambar[id]
    } else {
        
    }
}

satanic.kuismath = satanic.kuismath ? satanic.kuismath : {};
if (from in satanic.kuismath && !m.key.fromMe) {
    let id = m.chat
    let json = satanic.kuismath[id]
    let jawabanBenar = json.jawaban
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy)
    
    // Fitur nyerah
    if (isSurrender) {
        let teks = `😔 *MENYERAH*\n\nJawaban yang benar adalah: *${jawabanBenar}*\n\nIngin mencoba lagi? Ketik *math*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.kuismath[id]
        return
    }
    
    // Cek jawaban
    if (budy.toLowerCase() == jawabanBenar.toLowerCase().trim()) {
        let teks = `🎉 *BENAR!* 🎉\n\nJawaban: *${jawabanBenar}*\n\nIngin bermain lagi? Ketik *math*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.kuismath[id]
    } else {        
    }
}
satanic.caklontong = satanic.caklontong ? satanic.caklontong : {};
if (from in satanic.caklontong && !m.key.fromMe) {
    let id = m.chat
    let json = satanic.caklontong[id]
    let jawabanBenar = json.jawaban
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy)
    let isHint = /^(hint|bantuan)$/i.test(budy)
    if (isHint) {
        let jawaban = jawabanBenar.toLowerCase()
        let petunjuk = jawaban.split('').map((huruf, i) => {
            return i === 0 || i === jawaban.length - 1 ? huruf : '_'
        }).join('')
        return reply(`💡 *HINT / BANTUAN:*\n\n🔍 Petunjuk: ${petunjuk}\n📝 Panjang jawaban: *${jawaban.length}* huruf\n🔤 Huruf awal: *${jawaban[0]}*\n🔚 Huruf akhir: *${jawaban[jawaban.length - 1]}*\n📖 Deskripsi: ${json.deskripsi}`)
    }
    if (isSurrender) {
        let teks = `😔 *MENYERAH*\n\nJawaban yang benar adalah: *${jawabanBenar}*\n📝 Deskripsi: ${json.deskripsi}\n\nIngin mencoba lagi? Ketik *caklontong*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.caklontong[id]
        return
    }
    if (budy.toLowerCase() == jawabanBenar.toLowerCase().trim()) {
        let teks = `🎉 *BENAR!* 🎉\n\nJawaban: *${jawabanBenar}*\n📝 Deskripsi: ${json.deskripsi}\n\nIngin bermain lagi? Ketik *caklontong*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.caklontong[id]
    } else {
        
    }
}

satanic.tebakasahotak = satanic.tebakasahotak ? satanic.tebakasahotak : {};
if (from in satanic.tebakasahotak && !m.key.fromMe) {
    let id = m.chat
    let json = satanic.tebakasahotak[id]
    let jawabanBenar = json.jawaban
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy)
    let isHint = /^(hint|bantuan)$/i.test(budy)
    
    // Fitur hint / bantuan
    if (isHint) {
        let jawaban = jawabanBenar.toLowerCase()
        let petunjuk = jawaban.split('').map((huruf, i) => {
            return i === 0 || i === jawaban.length - 1 ? huruf : '_'
        }).join('')
        return reply(`💡 *HINT / BANTUAN:*\n\n🔍 Petunjuk: ${petunjuk}\n📝 Panjang jawaban: *${jawaban.length}* huruf\n🔤 Huruf awal: *${jawaban[0]}*\n🔚 Huruf akhir: *${jawaban[jawaban.length - 1]}*`)
    }
    
    // Fitur nyerah
    if (isSurrender) {
        let teks = `😔 *MENYERAH*\n\nJawaban yang benar adalah: *${jawabanBenar}*\n\nIngin mencoba lagi? Ketik *asahotak*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.tebakasahotak[id]
        return
    }
    
    // Cek jawaban
    if (budy.toLowerCase() == jawabanBenar.toLowerCase().trim()) {
        let teks = `🎉 *BENAR!* 🎉\n\nJawaban: *${jawabanBenar}*\n\nIngin bermain lagi? Ketik *asahotak*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.tebakasahotak[id]
    } else {

    }
}
satanic.siapaaku = satanic.siapaaku ? satanic.siapaaku : {};
if (from in satanic.siapaaku && !m.key.fromMe) {
    let id = m.chat
    let json = satanic.siapaaku[id]
    let jawabanBenar = json.jawaban
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy)
    let isHint = /^(hint|bantuan)$/i.test(budy)
    
    // Fitur hint / bantuan
    if (isHint) {
        let jawaban = jawabanBenar.toLowerCase()
        let petunjuk = jawaban.split('').map((huruf, i) => {
            return i === 0 || i === jawaban.length - 1 ? huruf : '_'
        }).join('')
        return reply(`💡 *HINT / BANTUAN:*\n\n🔍 Petunjuk: ${petunjuk}\n📝 Panjang jawaban: *${jawaban.length}* huruf\n🔤 Huruf awal: *${jawaban[0]}*\n🔚 Huruf akhir: *${jawaban[jawaban.length - 1]}*`)
    }
    
    // Fitur nyerah
    if (isSurrender) {
        let teks = `😔 *MENYERAH*\n\nJawaban yang benar adalah: *${jawabanBenar}*\n\nIngin mencoba lagi? Ketik *siapaaku*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.siapaaku[id]
        return
    }
    
    // Cek jawaban
    if (budy.toLowerCase() == jawabanBenar.toLowerCase().trim()) {
        let teks = `🎉 *BENAR!* 🎉\n\nJawaban: *${jawabanBenar}*\n\nIngin bermain lagi? Ketik *siapaaku*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.siapaaku[id]
    } else {
        
    }
}
satanic.tebaktebakan = satanic.tebaktebakan ? satanic.tebaktebakan : {};
if (from in satanic.tebaktebakan && !m.key.fromMe) {
    let id = m.chat
    let json = satanic.tebaktebakan[id]
    let jawabanBenar = json.jawaban
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy)
    let isHint = /^(hint|bantuan)$/i.test(budy)
    if (isHint) {
        let jawaban = jawabanBenar.toLowerCase()
        let petunjuk = jawaban.split('').map((huruf, i) => {
            return i === 0 || i === jawaban.length - 1 ? huruf : '_'
        }).join('')
        return reply(`💡 *HINT / BANTUAN:*\n\n🔍 Petunjuk: ${petunjuk}\n📝 Panjang jawaban: *${jawaban.length}* huruf\n🔤 Huruf awal: *${jawaban[0]}*\n🔚 Huruf akhir: *${jawaban[jawaban.length - 1]}*`)
    }
    if (isSurrender) {
        let teks = `😔 *MENYERAH*\n\nJawaban yang benar adalah: *${jawabanBenar}*\n\nIngin mencoba lagi? Ketik *tebaktebakan*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.tebaktebakan[id]
        return
    }
    if (budy.toLowerCase() == jawabanBenar.toLowerCase().trim()) {
        let teks = `🎉 *BENAR!* 🎉\n\nJawaban: *${jawabanBenar}*\n\nIngin bermain lagi? Ketik *tebaktebakan*`
        reply(teks)
        clearTimeout(json.timeout)
        delete satanic.tebaktebakan[id]
    } else {
        
    }
}

satanic.tebakkata = satanic.tebakkata ? satanic.tebakkata : {}
if (from in satanic.tebakkata && !m.key.fromMe) {
    let id = m.chat
    let json = JSON.parse(JSON.stringify(satanic.tebakkata[id][1]))
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy)
    let isHint = /^(hint|bantuan)$/i.test(budy)
    if (isHint) {
        let jawaban = json.jawaban.toLowerCase()
        let petunjuk = jawaban.split('').map((huruf, i) => {
            return i === 0 || i === jawaban.length - 1 ? huruf : '_'
        }).join('')
        return reply(`💡 *HINT / BANTUAN:*\n\n🔍 Petunjuk: ${petunjuk}\n📝 Panjang jawaban: *${jawaban.length}* huruf\n🔤 Huruf awal: *${jawaban[0]}*\n🔚 Huruf akhir: *${jawaban[jawaban.length - 1]}*`)
    }
    if (isSurrender) {
        let teks = `😔 *MENYERAH*\n\nJawaban yang benar adalah: *${json.jawaban}*\n\nIngin mencoba lagi? Ketik *tebakkata*`
        reply(teks)
        clearTimeout(satanic.tebakkata[id][2])
        delete satanic.tebakkata[id]
        return
    }
    if (budy.toLowerCase() == json.jawaban.toLowerCase().trim()) {
        let teks = `🎉 *BENAR!* 🎉\n\nJawaban: *${json.jawaban}*\n\nIngin bermain lagi? Ketik *tebakkata*`
        reply(teks)
        clearTimeout(satanic.tebakkata[id][2])
        delete satanic.tebakkata[id]
    } else {
        
    }
}

   this.game = this.game ? this.game : {}
	    let room13 = Object.values(this.game).find(room13 => room13.id && room13.game && room13.state && room13.id.startsWith('tictactoe') && [room13.game.playerX, room13.game.playerO].includes(m.sender) && room13.state == 'PLAYING')
	    if (room13) {
	    let ok
	    let isWin = !1
	    let isTie = !1
	    let isSurrender = !1
	    //reply(`[DEBUG]\n${parseInt(m.text)}`)
	    if (!/^([1-9]|(me)?give up|surr?ender|off|skip)$/i.test(m.text)) return
	    isSurrender = !/^[1-9]$/.test(m.text)
	    if (m.sender !== room13.game.currentTurn) { 
	    if (!isSurrender) return !0
	    }
	    if (!isSurrender && 1 > (ok = room13.game.turn(m.sender === room13.game.playerO, parseInt(m.text) - 1))) {
	    reply({
	    '-3': 'Permainan Telah Berakhir',
	    '-2': 'Tidak sah',
	    '-1': 'Posisi Tidak Valid',
	    0: 'Posisi Tidak Valid',
	    }[ok])
	    return !0
	    }
	    if (m.sender === room13.game.winner) isWin = true
	    else if (room13.game.board === 511) isTie = true
	    let arr = room13.game.render().map(v => {
	    return {
	    X: '❌',
	    O: '⭕',
	    1: '1️⃣',
	    2: '2️⃣',
	    3: '3️⃣',
	    4: '4️⃣',
	    5: '5️⃣',
	    6: '6️⃣',
	    7: '7️⃣',
	    8: '8️⃣',
	    9: '9️⃣',
	    }[v]
	    })
	    if (isSurrender) {
	    room13.game._currentTurn = m.sender === room13.game.playerX
	    isWin = true
	    }
	    let winner = isSurrender ? room13.game.currentTurn : room13.game.winner
	    let str = `room13 ID: ${room13.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Won!` : isTie ? `Game Over` : `Turn ${['❌', '⭕'][1 * room13.game._currentTurn]} (@${room13.game.currentTurn.split('@')[0]})`}
❌: @${room13.game.playerX.split('@')[0]}
⭕: @${room13.game.playerO.split('@')[0]}

Ketik *surrender* untuk menyerah dan mengaku kalah`
	    if ((room13.game._currentTurn ^ isSurrender ? room13.x : room13.o) !== m.chat)
	    room13[room13.game._currentTurn ^ isSurrender ? 'x' : 'o'] = m.chat
	    if (room13.x !== room13.o) await satanic.sendText(room13.x, str, m, { mentions: parseMention(str) } )
	    await satanic.sendText(room13.o, str, m, { mentions: parseMention(str) } )
	    if (isTie || isWin) {
	    delete this.game[room13.id]
	    }
	    }
	    
const nanoQuickButton = (displayText, id) => ({
name: "quick_reply",
buttonParamsJson: JSON.stringify({
display_text: displayText,
id
})
})




async function sendNanoButtonMenu(chat, teks, listnye, jm) {
let msg = generateWAMessageFromContent(chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 999999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: "120363422340494910@newsletter",
newsletterName: `Channel ${namaowner}`,
serverMessageId: 145
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `${namaBot} | By ${namaowner}`
}),
header: proto.Message.InteractiveMessage.Header.create({
title: "",
thumbnailUrl: "",
gifPlayback: true,
subtitle: "",
hasMediaAttachment: true,
...(await prepareWAMessageMedia({ image: { url: global.thumbnail } }, { upload: satanic.waUploadToServer })),
}),
gifPlayback: true,
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
messageParamsJson: JSON.stringify({
limited_time_offer: {
text: global.linkgc,
url: global.linkgc,
copy_code: namaowner,
expiration_time: Date.now() * 999
},
bottom_sheet: {
in_thread_buttons_limit: 2,
divider_indices: [1, 2, 3, 4, 5, 999],
list_title: `${namaBot} Command Center`,
button_title: "𝐒𝐡𝐨𝐰 𝐅𝐢𝐭𝐮𝐫"
},
tap_target_configuration: {
title: "▸ satanicID ◂",
description: namaowner,
canonical_url: global.linkgc,
domain: "whatsapp.com",
button_index: 0
}
}),
buttons: [
{
name: "single_select",
buttonParamsJson: JSON.stringify({ has_multiple_buttons: true })
},
{
name: "call_permission_request",
buttonParamsJson: JSON.stringify({ has_multiple_buttons: true })
},
{
name: "single_select",
buttonParamsJson: JSON.stringify({
...listnye,
has_multiple_buttons: true
})
},
{
name: "cta_copy",
buttonParamsJson: JSON.stringify({
display_text: `𝘊𝘳𝘦𝘥𝘪𝘵𝘴 : ${namaowner}`,
id: "6283168758640",
copy_code: namaowner
})
},
{
name: "cta_url",
buttonParamsJson: JSON.stringify({
display_text: `SC BOT`,
url: "https://chat.whatsapp.com/CUoxno1rPe55ukSMup2BWG",
merchant_url: "https://chat.whatsapp.com/CUoxno1rPe55ukSMup2BWG"
})
},
{
name: "cta_url",
buttonParamsJson: JSON.stringify({
display_text: `DEVELOPER`,
url: "https://wa.me/6283168758640",
merchant_url: "https://wa.me/6283168758640"
})
},
{
name: "cta_url",
buttonParamsJson: JSON.stringify({
display_text: `Channel Bot`,
url: "https://whatsapp.com/channel/0029VbBOXZ6AojZ23z5ieI3z",
merchant_url: "https://whatsapp.com/channel/0029VbBOXZ6AojZ23z5ieI3z"
})
},
nanoQuickButton("MAIN MENU", ".menu"),
nanoQuickButton("ALL MENU", ".allmenu"),
nanoQuickButton("INFO SCRIPT", ".script"),
nanoQuickButton("OWNER", ".owner")

]
})
})}
}}, {quoted: m})
await satanic.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}	    

switch (command) {
 case 'install':
case 'npm': {
if (!isCreator) return 
    if (!text) return reply(`Mau install module apa?\nContoh: ${prefix + command} axios`)
    reply(`⏳ Sedang menginstall module *${text}*...\nMohon tunggu, bot akan restart otomatis jika berhasil.`)
    require('child_process').exec(`npm install ${text}`, (err, stdout, stderr) => {
        if (err) {
           
            return reply(`❌ Gagal menginstall module: ${err.message}`)
        }
        satanic.sendMessage(m.chat, { 
            text: `✅ Sukses install *${text}*!\n\n📝 Output:\n${stdout}\n\n♻️ Bot sedang merestart sistem...` 
        }, { quoted: m }).then(() => {
            setTimeout(() => {
                process.exit()
            }, 3000)
        })
    })
}
break        	
case 'myorder':
case 'statusorder': {
  const userOrders = Object.entries(pendingPayments).filter(([id, data]) => data.user === m.sender)
  
  if (userOrders.length === 0) {
    return reply('📭 Kamu belum memiliki order apapun.')
  }
  
  let statusList = '📋 *STATUS ORDER KAMU*\n\n'
  
  for (const [id, data] of userOrders) {
    let statusEmoji = ''
    let statusText = ''
    
    switch(data.status) {
      case 'pending':
        statusEmoji = '⏳'
        statusText = 'Menunggu Pembayaran'
        break
      case 'waiting_proof':
        statusEmoji = '🔄'
        statusText = 'Menunggu Konfirmasi Admin'
        break
      case 'confirmed':
        statusEmoji = '✅'
        statusText = 'Selesai'
        break
      case 'cancelled':
        statusEmoji = '❌'
        statusText = 'Dibatalkan'
        break
    }
    
    statusList += `${statusEmoji} *Order ID: ${id}*\n`
    statusList += `   📦 Produk: ${data.product}\n`
    statusList += `   💰 Harga: ${formatRupiah(data.price)}\n`
    statusList += `   📌 Status: ${statusText}\n`
    
    if (data.deadline && data.status === 'pending') {
      const sisaWaktu = Math.max(0, Math.floor((data.deadline - Date.now()) / 60000))
      statusList += `   ⏰ Sisa waktu: ${sisaWaktu} menit\n`
    }
    
    statusList += `   📅 Tanggal: ${new Date(data.timestamp).toLocaleString('id-ID')}\n\n`
  }
  
  reply(statusList)
}
break;
case 'block': {
		if (!isCreator) return reply('you are not owner')
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await satanic.updateBlockStatus(users, 'block')
		await reply(`*[ Done ]*`)
	}
	break
        case 'unblock': {
		if (!isCreator) return reply('you are not owner')
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await satanic.updateBlockStatus(users, 'unblock')
		await reply(`*[ Done ]*`)
	}
	break
case 'addproduk':
case 'addproduct': {
  if (!isCreator && !isPrem) return reply('❌ Hanya owner/premium yang bisa menambah produk!')
  
  // Format: .addproduk nama_produk|harga
  // Contoh: .addproduk Panel 2GB|5000
  
  if (!text) return reply('❌ Format: .addproduk nama_produk|harga\n\nContoh: .addproduk Panel 2GB|5000')
  
  const [namaProduk, harga] = text.split('|')
  if (!namaProduk || !harga || isNaN(harga)) {
    return reply('❌ Format salah!\nContoh: .addproduk Panel 2GB|5000')
  }
  
  const productId = Date.now().toString()
  paymentData[productId] = {
    id: productId,
    name: namaProduk.trim(),
    price: parseInt(harga),
    createdAt: new Date().toISOString()
  }
  
  savePaymentData()
  
  let listProduk = '📦 *DAFTAR PRODUK*\n\n'
  Object.values(paymentData).forEach((p, i) => {
    listProduk += `${i+1}. ${p.name}\n   💰 Harga: ${formatRupiah(p.price)}\n   🆔 ID: ${p.id}\n\n`
  })
  
  reply(`✅ Produk berhasil ditambahkan!\n\n${listProduk}`)
}
break;

case 'delproduk':
case 'deleteproduct': {
  if (!isCreator) return reply('❌ Hanya owner yang bisa menghapus produk!')
  
  if (!text) return reply('❌ Masukkan ID produk!\nGunakan .listproduk untuk melihat ID')
  
  if (!paymentData[text]) return reply('❌ Produk tidak ditemukan!')
  
  delete paymentData[text]
  savePaymentData()
  
  reply(`✅ Produk berhasil dihapus!`)
}
break;

case 'listproduk':
case 'products': {
  if (Object.keys(paymentData).length === 0) {
    return reply('📦 Belum ada produk. Owner bisa menambah dengan .addproduk')
  }
  
  let list = '📦 *DAFTAR PRODUK*\n\n'
  Object.values(paymentData).forEach((p, i) => {
    list += `${i+1}. *${p.name}*\n`
    list += `   💰 Harga: ${formatRupiah(p.price)}\n`
    list += `   🆔 Kode: \`${p.id}\`\n`
    list += `   📝 Cara beli: .buy ${p.id}\n\n`
  })
  list += `📌 *Cara Order:*\n.buy [kode_produk]\nContoh: .buy ${Object.values(paymentData)[0]?.id}`
  
  reply(list)
}
break;
case 'buy':
case 'order': {
  if (!text) return reply('❌ Masukkan kode produk!\nGunakan .listproduk untuk melihat produk')
  
  const product = paymentData[text]
  if (!product) return reply('❌ Produk tidak ditemukan!')
  
  // Cek apakah user sudah ada order pending
  const existingPending = Object.entries(pendingPayments).find(([id, data]) => data.user === m.sender && data.status === 'pending')
  if (existingPending) {
    return reply(`❌ Kamu masih memiliki order pending!\n🆔 Order ID: ${existingPending[0]}\nSelesaikan pembayaran atau hubungi owner untuk batal.`)
  }
  
  const orderId = generateOrderId()
  const paymentDeadline = Date.now() + (30 * 60 * 1000) // 30 menit
  
  pendingPayments[orderId] = {
    id: orderId,
    user: m.sender,
    userName: pushname,
    product: product.name,
    productId: product.id,
    price: product.price,
    timestamp: Date.now(),
    deadline: paymentDeadline,
    status: 'pending',
    proof: null
  }
  
  savePendingPayments()
  
  // Kirim QRIS dan instruksi pembayaran
  const qrisUrl = "https://c.termai.cc/i162/Zfgyz.jpg" // GANTI DENGAN URL QRIS ASLI
  
  const paymentMessage = `💳 *INVOICE PEMBAYARAN*
╔═════════════════════╗
║ 🆔 Order ID: *${orderId}*
║ 📦 Produk: *${product.name}*
║ 💰 Harga: *${formatRupiah(product.price)}*
║ 👤 Pembeli: *${pushname}*
║ ⏰ Batas Bayar: *30 Menit*
╚═════════════════════╝
📌 *CARA PEMBAYARAN:*
1. Scan QRIS di bawah
2. Transfer sesuai nominal *${formatRupiah(product.price)}*
3. Screenshot bukti transfer
4. Kirim bukti dengan command:
.confirm ${orderId}

⏰ Order akan kadaluarsa dalam 30 menit!

*Project By:* ${namaBot}`

  // Kirim QRIS
  await satanic.sendMessage(m.chat, {
    image: { url: qrisUrl },
    caption: paymentMessage
  }, { quoted: m })
  
  // Kirim notifikasi ke owner - PERBAIKAN DISINI
  const ownerNotif = `🛍️ *ORDER BARU!*
🆔 Order ID: ${orderId}
👤 Pembeli: ${pushname}
📱 User: ${m.sender}
📦 Produk: ${product.name}
💰 Harga: ${formatRupiah(product.price)}

Menunggu konfirmasi pembayaran...`
  
  // Pastikan owner adalah array
  if (Array.isArray(owner) && owner.length > 0) {
    for (let ownerId of owner) {
      try {
        await satanic.sendMessage(ownerId, { text: ownerNotif })
      } catch (err) {
        console.error(`Gagal kirim notifikasi ke ${ownerId}:`, err)
      }
    }
  } else {
    console.log('Owner list kosong atau bukan array')
  }
}
break;
case 'cancelorder':
case 'batalorder': {
  const args = text.trim().split(/\s+/)
  const orderId = parseInt(args[0])
  const confirm = args[1] // ambil kata 'ya' jika ada
  
  if (!text || !orderId) {
    // Tampilkan order pending user
    const userPending = Object.entries(pendingPayments).find(([id, data]) => data.user === m.sender && data.status === 'pending')
    if (!userPending) return reply('❌ Kamu tidak memiliki order pending!')
    
    return reply(`⚠️ *ORDER PENDING DITEMUKAN*
╔═════════════════════╗
║ 🆔 Order ID: *${userPending[0]}*
║ 📦 Produk: *${userPending[1].product}*
║ 💰 Harga: *${formatRupiah(userPending[1].price)}*
║ ⏰ Sisa Waktu: *${Math.floor((userPending[1].deadline - Date.now()) / 60000)} menit*
╚═════════════════════╝

Ketik .batalorder ${userPending[0]} ya untuk membatalkan order.`)
  }
  
  const order = pendingPayments[orderId]
  
  if (!order) return reply('❌ Order ID tidak ditemukan!')
  if (order.user !== m.sender) return reply('❌ Ini bukan order kamu!')
  if (order.status !== 'pending') return reply(`❌ Order sudah ${order.status === 'waiting_proof' ? 'dikirim buktinya' : order.status === 'confirmed' ? 'selesai' : 'dibatalkan'}!`)
  
  // Cek konfirmasi
  if (confirm !== 'ya') {
    return reply(`⚠️ *KONFIRMASI PEMBATALAN*
Apakah anda yakin ingin membatalkan order ID: ${orderId}?
Produk: ${order.product}
Harga: ${formatRupiah(order.price)}

Ketik: .batalorder ${orderId} ya
untuk membatalkan.`)
  }
  
  // Update status jadi cancelled
  order.status = 'cancelled'
  savePendingPayments()
  
  // Format tanggal dan jam pembatalan
  const now = new Date()
  const tanggal = now.toLocaleDateString('id-ID', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  })
  const jam = now.toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  })
  
  // Kirim notifikasi ke user
  const userMessage = `❌ *ORDER DIBATALKAN!*

🆔 Order ID: ${orderId}
📦 Produk: ${order.product}
💰 Harga: ${formatRupiah(order.price)}
📅 Tanggal: ${tanggal}
⏰ Jam: ${jam}

Order telah dibatalkan. Silakan order ulang jika masih berminat.`
  
  await satanic.sendMessage(m.chat, { text: userMessage })
  
  // Notifikasi ke owner
  const ownerNotif = `🚫 *ORDER DIBATALKAN USER*
🆔 Order ID: ${orderId}
👤 Pembeli: ${order.userName}
📱 User: ${m.sender}
📦 Produk: ${order.product}
💰 Harga: ${formatRupiah(order.price)}
📅 Tanggal Batal: ${tanggal}
⏰ Jam Batal: ${jam}`
  
  for (let ownerId of global.owner) {
    await satanic.sendMessage(ownerId, { text: ownerNotif }).catch(e => {})
  }
  
  reply(`✅ Order ${orderId} berhasil dibatalkan.`)
}
break;
case 'confirm':
case 'kirimbukti': {
  if (!text) return reply('❌ Masukkan Order ID!\nContoh: .confirm 12345')
  
  const orderId = parseInt(text)
  const order = pendingPayments[orderId]
  
  if (!order) return reply('❌ Order ID tidak ditemukan!')
  if (order.user !== m.sender) return reply('❌ Ini bukan order kamu!')
  if (order.status !== 'pending') return reply(`❌ Order sudah ${order.status === 'waiting_proof' ? 'menunggu konfirmasi' : order.status === 'confirmed' ? 'selesai' : 'dibatalkan'}!`)
  
  // Cek apakah ada quoted message (reply ke gambar)
  const quoted = m.quoted || m.message?.extendedTextMessage?.contextInfo?.quotedMessage || null
  if (!quoted) return reply(`❌ Balas gambar bukti transfer dengan caption .confirm ${orderId}\n\nContoh: reply/quote gambar lalu ketik .confirm 1`)
  
  const mime = (quoted.msg || quoted).mimetype || quoted.mimetype || ''
  
  // Cek apakah yang di-reply adalah gambar
  if (!/image/.test(mime)) return reply('❌ Yang direply BUKAN gambar! Silakan reply/quote gambar bukti transfer.')
  
  // Download gambar
  let media
  try {
    if (quoted.msg) {
      media = await quoted.msg.download()
    } else if (quoted.download) {
      media = await quoted.download()
    } else {
      // Alternatif download
      media = await satanic.downloadMediaMessage(quoted)
    }
  } catch (err) {
    console.error(err)
    return reply('❌ Gagal mengambil gambar bukti!')
  }
  
  if (!media) return reply('❌ Gagal mengambil gambar bukti!')
  
  // Update status
  order.status = 'waiting_proof'
  order.proof = {
    timestamp: Date.now(),
    data: media.toString('base64')
  }
  savePendingPayments()
  
  // Kirim ke owner untuk konfirmasi
  const adminMessage = `🔄 *KONFIRMASI PEMBAYARAN*
╔═════════════════════╗
║ 🆔 Order ID: *${orderId}*
║ 👤 Pembeli: *${order.userName}*
║ 📱 User: ${order.user}
║ 📦 Produk: *${order.product}*
║ 💰 Harga: *${formatRupiah(order.price)}*
╚═════════════════════╝

📌 *ACTION:*
✅ Ketik: .approve ${orderId} - Untuk approve
❌ Ketik: .reject ${orderId} | alasan - Untuk reject

*Bukti Transfer terlampir*`
  
  for (let ownerId of owner) {
    try {
      await satanic.sendMessage(ownerId, {
        image: media,
        caption: adminMessage
      })
    } catch (err) {
      console.error(`Gagal kirim ke ${ownerId}:`, err)
    }
  }
  
  reply(`✅ Bukti pembayaran terkirim! Silakan tunggu konfirmasi dari admin.`)
}
break;

// ==================== ADD BADWORD ====================
case 'addbadword': {
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  if (!text) return reply(`⚠️ Masukkan kata yang ingin ditambahkan!\n\nContoh: ${prefix + command} tolol`)
  
  let badwordList = []
  try {
    if (fs.existsSync("./database/badword.json")) {
      badwordList = JSON.parse(fs.readFileSync("./database/badword.json"))
    } else {
      fs.writeFileSync("./database/badword.json", "[]")
    }
  } catch (e) {
    badwordList = []
    fs.writeFileSync("./database/badword.json", "[]")
  }
  
  const word = text.toLowerCase().trim()
  
  if (!badwordList.includes(word)) {
    badwordList.push(word)
    fs.writeFileSync("./database/badword.json", JSON.stringify(badwordList, null, 2))
    reply(`✅ Badword *"${word}"* berhasil ditambahkan!\n\nTotal badword: ${badwordList.length}`)
  } else {
    reply(`❌ Badword *"${word}"* sudah ada dalam daftar!`)
  }
}
break
case 'approve':
case 'terima': {
  if (!isCreator) return reply('❌ Hanya owner yang bisa approve!')
  
  if (!text) return reply('❌ Masukkan Order ID!\nContoh: .approve 12345')
  
  const orderId = parseInt(text)
  const order = pendingPayments[orderId]
  
  if (!order) return reply('❌ Order ID tidak ditemukan!')
  if (order.status !== 'waiting_proof') return reply('❌ Order tidak menunggu konfirmasi!')
  
  // Update status
  order.status = 'confirmed'
  order.confirmedAt = Date.now()
  savePendingPayments()
  
  // Format tanggal dan jam
  const now = new Date()
  const tanggal = now.toLocaleDateString('id-ID', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  })
  const jam = now.toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  })
  
  // Kirim notifikasi ke user
  const userMessage = `✅ *PEMBAYARAN DISETUJUI!*

🆔 Order ID: ${orderId}
📦 Produk: ${order.product}
💰 Harga: ${formatRupiah(order.price)}
✅ Status: SUKSES
📅 Tanggal: ${tanggal}
⏰ Jam: ${jam}

Terima kasih sudah berbelanja!`
  
  await satanic.sendMessage(order.user, { text: userMessage })
  
  reply(`✅ Order ${orderId} telah disetujui! Notifikasi sudah dikirim ke user.`)
}
break;

case 'reject':
case 'tolak': {
  if (!isCreator) return reply('❌ Hanya owner yang bisa reject!')
  
  if (!text) return reply('❌ Masukkan Order ID!\nContoh: .reject 12345')
  
  const [orderId, alasan] = text.split('|')
  if (!orderId) return reply('❌ Format: .reject [order_id] | [alasan]')
  
  const order = pendingPayments[parseInt(orderId)]
  
  if (!order) return reply('❌ Order ID tidak ditemukan!')
  if (order.status !== 'waiting_proof') return reply('❌ Order tidak menunggu konfirmasi!')
  
  // Update status
  order.status = 'cancelled'
  savePendingPayments()
  
  const rejectReason = alasan || 'Bukti transfer tidak valid'
  
  // Format tanggal dan jam
  const now = new Date()
  const tanggal = now.toLocaleDateString('id-ID', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  })
  const jam = now.toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  })
  
  // Kirim notifikasi ke user
  const userMessage = `❌ *PEMBAYARAN DITOLAK!*

🆔 Order ID: ${orderId}
📦 Produk: ${order.product}
💰 Harga: ${formatRupiah(order.price)}
❌ Alasan: ${rejectReason}
📅 Tanggal: ${tanggal}
⏰ Jam: ${jam}

Silakan lakukan pembayaran ulang dengan benar.`
  
  await satanic.sendMessage(order.user, { text: userMessage })
  
  reply(`❌ Order ${orderId} telah ditolak! Notifikasi sudah dikirim ke user.`)
}
break;
// ==================== LIST BADWORD ====================
case 'listbadword': {
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  
  let badwordList = []
  try {
    if (fs.existsSync("./database/badword.json")) {
      badwordList = JSON.parse(fs.readFileSync("./database/badword.json"))
    }
  } catch (e) {}
  
  if (badwordList.length === 0) return reply('📋 Daftar badword kosong!')
  
  let teks = `📋 *DAFTAR BADWORD*\n\n`
  teks += `Total: ${badwordList.length} kata\n\n`
  
  for (let i = 0; i < badwordList.length; i++) {
    teks += `${i + 1}. ${badwordList[i]}\n`
  }
  
  reply(teks)
}
break

// ==================== DELETE BADWORD ====================
case 'delbadword': {
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  if (!text) return reply(`⚠️ Masukkan kata yang ingin dihapus!\n\nContoh: ${prefix + command} tolol`)
  
  let badwordList = []
  try {
    if (fs.existsSync("./database/badword.json")) {
      badwordList = JSON.parse(fs.readFileSync("./database/badword.json"))
    } else {
      return reply('📋 Daftar badword masih kosong!')
    }
  } catch (e) {
    return reply('📋 Daftar badword masih kosong!')
  }
  
  const word = text.toLowerCase().trim()
  const index = badwordList.indexOf(word)
  
  if (index !== -1) {
    badwordList.splice(index, 1)
    fs.writeFileSync("./database/badword.json", JSON.stringify(badwordList, null, 2))
    reply(`✅ Badword *"${word}"* berhasil dihapus!\n\nSisa badword: ${badwordList.length}`)
  } else {
    reply(`❌ Badword *"${word}"* tidak ditemukan!`)
  }
}
break

// ==================== ANTIBADWORD ON/OFF ====================
case 'antibadword': {
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  if (!m.isGroup) return reply('⚠️ Perintah ini hanya untuk grup!')
  
  let antiBadwordData = {}
  try {
    if (fs.existsSync("./database/antibadword.json")) {
      antiBadwordData = JSON.parse(fs.readFileSync("./database/antibadword.json"))
    } else {
      fs.writeFileSync("./database/antibadword.json", JSON.stringify(antiBadwordData))
    }
  } catch (e) {
    fs.writeFileSync("./database/antibadword.json", JSON.stringify(antiBadwordData))
  }
  
  const groupId = m.chat
  const currentStatus = antiBadwordData[groupId] || false
  
  if (!text) {
    return reply(`⚠️ Pilih on/off!\n\nContoh: ${prefix + command} on\n\nStatus saat ini: ${currentStatus ? 'ON ✅' : 'OFF ❌'}`)
  }
  
  const option = text.toLowerCase().trim()
  
  if (option === 'on') {
    antiBadwordData[groupId] = true
    fs.writeFileSync("./database/antibadword.json", JSON.stringify(antiBadwordData, null, 2))
    reply('✅ *AntiBadword diaktifkan untuk grup ini!*')
  } else if (option === 'off') {
    antiBadwordData[groupId] = false
    fs.writeFileSync("./database/antibadword.json", JSON.stringify(antiBadwordData, null, 2))
    reply('❌ *AntiBadword dinonaktifkan untuk grup ini!*')
  } else {
    reply('⚠️ Pilihan tidak valid! Gunakan on/off')
  }
}
break
// ========== CASE ADD BADWORD ==========

case 'developer': {
    try {                  
        let txt = `Jika ada kendala silahkan hubungin owner \n Sc Free ada di Community bot silahkan ambil sc nya di deskripsi\n Ingin beli sc bot atau ingin request sesuatu seperti buat bot costum bisa hubungi owner dibawah ini`;

        let buttons = [
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "Free Rest api",
                    url: "https://newcodingproject.vercel.app/",
                    merchant_url: "https://newcodingproject.vercel.app/"
                })
            },
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "Community Bot",
                    url: "https://chat.whatsapp.com/KSP74SqRcgqCP4xQSMALQl",
                    merchant_url: "https://chat.whatsapp.com/KSP74SqRcgqCP4xQSMALQl"
                })
            },
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "Sharing Developer Project",
                    url: "https://chat.whatsapp.com/HAQtcXHRnU9FxlPkCBH44G",
                    merchant_url: "https://chat.whatsapp.com/HAQtcXHRnU9FxlPkCBH44G"
                })
            },
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "Donasi Saweria",
                    url: "https://saweria.co/satanichaxor",
                    merchant_url: "https://github.com/username"
                })
            },
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "Channel Developer",
                    url: "https://whatsapp.com/channel/0029VbBOXZ6AojZ23z5ieI3z",
                    merchant_url: "https://whatsapp.com/channel/0029VbBOXZ6AojZ23z5ieI3z"
                })
            }
        ];

        // Download gambar dari URL menjadi buffer
        const response = await fetch('https://c.termai.cc/i108/58xw.jpg');
        const profilePicBuffer = Buffer.from(await response.arrayBuffer());

        await sendButton(from, txt, "Satanic Haxor", profilePicBuffer, buttons, m);
    } catch (e) {
        console.error(e);
        reply("Terjadi kesalahan.");
    }
}
break;
case 'welcome':
  if (!m.isGroup) return reply('⚠️ Fitur ini hanya untuk grup!')
  if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!')
  
  const welcomeData = JSON.parse(fs.readFileSync('./database/welcome.json'));
  
  if (text === 'on') {
    if (welcomeData.includes(m.chat)) return reply('✅ Welcome sudah aktif!')
    welcomeData.push(m.chat)
    fs.writeFileSync('./database/welcome.json', JSON.stringify(welcomeData))
    reply(`👋 *Welcome Activated!*`)
  } else if (text === 'off') {
    if (!welcomeData.includes(m.chat)) return reply('❌ Welcome tidak aktif!')
    const newData = welcomeData.filter(id => id !== m.chat)
    fs.writeFileSync('./database/welcome.json', JSON.stringify(newData))
    reply(`👋 *Welcome Deactivated!*`)
  } else {
    const status = welcomeData.includes(m.chat)
    reply(`⚙️ *Welcome Settings*\n\nStatus: ${status ? '✅ ACTIVE' : '❌ INACTIVE'}\n\nUsage:\n${prefix + command} on - Aktifkan\n${prefix + command} off - Nonaktifkan`)
  }
break

case 'leave':
  if (!m.isGroup) return reply('⚠️ Fitur ini hanya untuk grup!')
  if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!')
  
  const leaveData = JSON.parse(fs.readFileSync('./database/leave.json'));
  
  if (text === 'on') {
    if (leaveData.includes(m.chat)) return reply('✅ Leave sudah aktif!')
    leaveData.push(m.chat)
    fs.writeFileSync('./database/leave.json', JSON.stringify(leaveData))
    reply(`👋 *Leave Activated!*`)
  } else if (text === 'off') {
    if (!leaveData.includes(m.chat)) return reply('❌ Leave tidak aktif!')
    const newData = leaveData.filter(id => id !== m.chat)
    fs.writeFileSync('./database/leave.json', JSON.stringify(newData))
    reply(`👋 *Leave Deactivated!*`)
  } else {
    const status = leaveData.includes(m.chat)
    reply(`⚙️ *Leave Settings*\n\nStatus: ${status ? '✅ ACTIVE' : '❌ INACTIVE'}\n\nUsage:\n${prefix + command} on - Aktifkan\n${prefix + command} off - Nonaktifkan`)
  }
break
case 'requestjoin':
case 'rj':
  if (!m.isGroup) return reply(mess.group);
  if (!isAdmins && !isCreator) return reply(mess.admin);
  ;
  
  function formatWaktu(timestamp) {
    return new Date(parseInt(timestamp) * 1000).toLocaleString('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'Asia/Jakarta'
    });
  }
  
  let pecahan = text ? text.trim().split(/\s+/) : [];
  let instruksi = pecahan[0] ? pecahan[0].toLowerCase() : 'bantuan';
  let parameter = pecahan[1] ? pecahan[1].toLowerCase() : '';
  
  let daftarMasuk = [];
  try {
    const dataPermintaan = await satanic.groupRequestParticipantsList(m.chat);
    
    daftarMasuk = dataPermintaan.map((item, idx) => {
      // Ambil dari phone_number (nomor HP asli)
      let jid = item.phone_number || item.jid || item.id || item;
      let nomor = jid.replace(/@s\.whatsapp\.net|@lid/g, '');
      let nama = item.notify || item.pushname || nomor;
      
      return {
        urutan: idx,
        jid: jid,
        nomor: nomor,
        nama: nama,
        waktu: item.request_time,
        metode: item.request_method
      };
    });
  } catch (galat) {
    console.error(galat);
    return reply('❌ Gagal mengambil daftar permintaan');
  }

  if (instruksi === 'daftar' || instruksi === 'list' || instruksi === 'lihat') {
    if (daftarMasuk.length === 0) return reply('📭 Tidak ada permintaan');
    let teks = `📋 *DAFTAR PERMINTAAN*\n━━━━━━━━━━━━━━━━\n📊 Total: ${daftarMasuk.length}\n\n`;
    daftarMasuk.forEach((p, i) => {
      teks += `*${i+1}. ${p.nama}*\n`;
      teks += `   📞 ${p.nomor}\n`;
      teks += `   ⏰ ${formatWaktu(p.waktu)}\n`;
      teks += `   📝 ${p.metode}\n\n`;
    });
    teks += `━━━━━━━━━━━━━━━━\n📌 .rj setuju 1\n📌 .rj setuju semua\n📌 .rj tolak 1\n📌 .rj tolak semua`;
    return reply(teks);
  }

  if (instruksi === 'setuju' || instruksi === 'approve' || instruksi === 'terima') {
    if (daftarMasuk.length === 0) return reply('❌ Tidak ada permintaan');
    if (parameter === 'semua' || parameter === 'all') {
      await satanic.groupRequestParticipantsUpdate(m.chat, daftarMasuk.map(p => p.jid), 'approve');
      return reply(`✅ Berhasil setuju ${daftarMasuk.length} permintaan`);
    }
    let idx = parseInt(parameter) - 1;
    if (isNaN(idx) || idx < 0 || idx >= daftarMasuk.length) return reply('❌ Nomor tidak valid');
    await satanic.groupRequestParticipantsUpdate(m.chat, [daftarMasuk[idx].jid], 'approve');
    return reply(`✅ Setuju @${daftarMasuk[idx].nomor}`, { mentions: [daftarMasuk[idx].jid] });
  }

  if (instruksi === 'tolak' || instruksi === 'reject' || instruksi === 'decline') {
    if (daftarMasuk.length === 0) return reply('❌ Tidak ada permintaan');
    if (parameter === 'semua' || parameter === 'all') {
      await satanic.groupRequestParticipantsUpdate(m.chat, daftarMasuk.map(p => p.jid), 'reject');
      return reply(`❌ Berhasil tolak ${daftarMasuk.length} permintaan`);
    }
    let idx = parseInt(parameter) - 1;
    if (isNaN(idx) || idx < 0 || idx >= daftarMasuk.length) return reply('❌ Nomor tidak valid');
    await satanic.groupRequestParticipantsUpdate(m.chat, [daftarMasuk[idx].jid], 'reject');
    return reply(`❌ Tolak @${daftarMasuk[idx].nomor}`, { mentions: [daftarMasuk[idx].jid] });
  }

  reply(`🔧 *REQUEST JOIN*\n━━━━━━━━━━━━━━━━\n.rj daftar - Lihat\n.rj setuju 1 - Terima\n.rj setuju semua - Terima semua\n.rj tolak 1 - Tolak\n.rj tolak semua - Tolak semua`);
break;
case 'gpt-5.1':
case 'gpt-5-online':
case 'gpt-5':
case 'gpt-5-nano':
case 'gpt-5-mini':
case 'openai-o1':
case 'openai-o3':
case 'openai-o3-mini':
case 'gpt-4o':
case 'openai-o4-mini':
case 'gpt-4.1-mini':
case 'gpt-4.1-nano':
case 'gpt-5.3':
case 'gpt-5.4':
case 'gpt-5.5': {
    if (!text) return m.reply(`*Example :* .${command} Apa itu AI`);
    
    reply('wait be processed')
    
    let web = false;
    let image = false;
    let deep = false;
    let agent = false;
    
    if (command.includes('/')) {
        let parts = command.split('/');
        for (let i of parts.slice(1)) {
            if (i === 'websearch') web = true;
            if (i === 'imagegen') image = true;
            if (i === 'deep') deep = true;
            if (i === 'agent') agent = true;
        }
    }
    
    let model;
    switch (command.split('/')[0]) {
        case 'gpt-5.1':
            model = 'openai/gpt-5.1-thinking';
            break;
        case 'gpt-5-online':
            model = 'openai/gpt-5-chat:online';
            break;
        case 'gpt-5':
            model = 'openai/gpt-5-chat';
            break;
        case 'gpt-5-nano':
            model = 'openai/gpt-5-nano';
            break;
        case 'gpt-5-mini':
            model = 'openai/gpt-5-mini';
            break;
        case 'openai-o1':
            model = 'openai/o1';
            break;
        case 'openai-o3':
            model = 'openai/o3';
            break;
        case 'openai-o3-mini':
            model = 'openai/o3-mini';
            break;
        case 'gpt-4o':
            model = 'openai/gpt-4o';
            break;
        case 'openai-o4-mini':
            model = 'openai/o4-mini';
            break;
        case 'gpt-4.1-mini':
            model = 'openai/gpt-4-1-mini';
            break;
        case 'gpt-4.1-nano':
            model = 'openai/gpt-4-1-nano';
            break;
        case 'gpt-5.3':
            model = 'openai/gpt-5.3-chat';
            break;
        case 'gpt-5.4':
            model = 'openai/gpt-5.4';
            break;
        case 'gpt-5.5':
            model = 'openai/gpt-5.5';
            break;
        default:
            model = 'openai/gpt-5.3-chat';
            break;
    }
    
    const res = await fetch("https://fgsi.dpdns.org/api/ai/chatgpt", {
        method: "POST",
        headers: {
            "accept": "application/json",
            "content-type": "application/json"
        },
        body: JSON.stringify({
            apikey: global.fgsi,
            model: model,
            messages: [
                {
                    id: "",
                    role: "user",
                    parts: [
                        {
                            type: "text",
                            text: text
                        }
                    ]
                }
            ],
            isDeepResearchMode: deep,
            isWebSearchMode: web,
            isImageGenerationMode: image,
            isAgenticMode: agent
        })
    });
    
    const data = await res.json();
    
    if (data?.data?.images?.length) {
        return satanic.sendMessage(m.chat, { image: { url: data.data.images[0].url } }, { quoted: m });
    }
    
    m.reply(data?.data?.text);
}
break;
case 'hdvid':
case 'enhancevideo': {
    if (!quoted) return reply('Balas video dengan caption .hdvid');
    
    let mime = quoted.mimetype || '';
    
    if (!/video/.test(mime)) return reply('Hanya support video!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    let mee = await satanic.downloadAndSaveMediaMessage(quoted);
    let mem = await UploadFileUgu(mee);
    
    const apiUrl = `https://api.nexray.eu.cc/tools/hdvideo?url=${encodeURIComponent(mem.url)}`;
    const response = await axios.get(apiUrl);
    
    if (!response.data.status) {
        return reply('Gagal mengupgrade video. Coba lagi nanti.');
    }
    
    const videoUrl = response.data.result;
    
    await satanic.sendMessage(m.chat, { 
        video: { url: videoUrl },
        caption: '✨ Video berhasil diupgrade ke HD!'
    }, { quoted: m });
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'ephemeral': {
    if (!m.isGroup) return reply(mess.group);
    if (!isAdmins && !isCreator) return reply(mess.admin);
    ;
    
    // Cek apakah ada durasi spesifik dalam pesan
    
    
    try {
        if (text.includes('ephemeral 1')) {
            await satanic.groupToggleEphemeral(m.chat, 1*24*3600);
            reply('✅ Pesan sementara diatur 24 jam');
        }
        else if (text.includes('ephemeral 7')) {
            await satanic.groupToggleEphemeral(m.chat, 7*24*3600);
            reply('✅ Pesan sementara diatur 7 hari');
        }
        else if (text.includes('ephemeral 90')) {
            await satanic.groupToggleEphemeral(m.chat, 90*24*3600);
            reply('✅ Pesan sementara diatur 90 hari');
        }
        else if (text.includes('ephemeral off')) {
            await satanic.groupToggleEphemeral(m.chat, 0);
            reply('✅ Pesan sementara dinonaktifkan');
        }
        else {
            // Tampilkan panduan jika perintah tidak jelas
            reply(`ℹ️ *Format perintah:*\n\n` +
                 `• *ephemeral 1* - 24 jam\n` +
                 `• *ephemeral 7* - 7 hari\n` +
                 `• *ephemeral 90* - 90 hari\n` +
                 `• *ephemeral off* - matikan`);
        }
    } catch (err) {
        reply(`❌ Error: ${err.message}`);
    }
}
break;
case 'promotenotif':
  if (!m.isGroup) return reply('⚠️ Fitur ini hanya untuk grup!')
  if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!')
  
  const promoteData = JSON.parse(fs.readFileSync('./database/promote.json'));
  
  if (text === 'on') {
    if (promoteData.includes(m.chat)) return reply('✅ Promote notif sudah aktif!')
    promoteData.push(m.chat)
    fs.writeFileSync('./database/promote.json', JSON.stringify(promoteData))
    reply(`⭐ *Promote Notification Activated!*`)
  } else if (text === 'off') {
    if (!promoteData.includes(m.chat)) return reply('❌ Promote notif tidak aktif!')
    const newData = promoteData.filter(id => id !== m.chat)
    fs.writeFileSync('./database/promote.json', JSON.stringify(newData))
    reply(`⭐ *Promote Notification Deactivated!*`)
  } else {
    const status = promoteData.includes(m.chat)
    reply(`⚙️ *Promote Notif Settings*\n\nStatus: ${status ? '✅ ACTIVE' : '❌ INACTIVE'}\n\nUsage:\n${prefix + command} on - Aktifkan\n${prefix + command} off - Nonaktifkan`)
  }
break

case 'demotenotif':
  if (!m.isGroup) return reply('⚠️ Fitur ini hanya untuk grup!')
  if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!')
  
  const demoteData = JSON.parse(fs.readFileSync('./database/demote.json'));
  
  if (text === 'on') {
    if (demoteData.includes(m.chat)) return reply('✅ Demote notif sudah aktif!')
    demoteData.push(m.chat)
    fs.writeFileSync('./database/demote.json', JSON.stringify(demoteData))
    reply(`📉 *Demote Notification Activated!*`)
  } else if (text === 'off') {
    if (!demoteData.includes(m.chat)) return reply('❌ Demote notif tidak aktif!')
    const newData = demoteData.filter(id => id !== m.chat)
    fs.writeFileSync('./database/demote.json', JSON.stringify(newData))
    reply(`📉 *Demote Notification Deactivated!*`)
  } else {
    const status = demoteData.includes(m.chat)
    reply(`⚙️ *Demote Notif Settings*\n\nStatus: ${status ? '✅ ACTIVE' : '❌ INACTIVE'}\n\nUsage:\n${prefix + command} on - Aktifkan\n${prefix + command} off - Nonaktifkan`)
  }
break
case 'setwelcome': {
    if (!isAdmins && !isCreator) return reply('Hanya admin yang bisa!')

    
    const message = text.trim()
    
    if (!message) {
        return reply(`❌ Gunakan: ${prefix}setwelcome <text>\n\n*Contoh:*\n${prefix}setwelcome Selamat datang @user di @subject!\n\n*Placeholder:*\n@user - Username\n@subject - Group name\n@bio - User bio\n@date - Join date\n@desc - Group description`)
    }
    
    global.welcomeMessage = message
    global.welcome = true // Otomatis aktifkan welcome
    
    return reply('✅ Welcome message telah diatur!\nSistem welcome otomatis diaktifkan!')
    break
}
case 'requestjoin':
case 'rj':
  if (!m.isGroup) return reply(mess.group);
  if (!isAdmins && !isCreator) return reply(mess.admin);
  ;
  
  let perintah = args[0] ? args[0].toLowerCase() : 'help';
  let nomorUrut = args[1] ? args[1].toLowerCase() : '';
  
  let joinRequestList = [];
  try {
    joinRequestList = await satanic.groupRequestParticipantsList(m.chat);
  } catch (error) {
    console.error(error);
    return reply('❌ Gagal mengambil daftar permintaan');
  }

  const getJid = (p) => p.jid || p.id || p;
  const formatNomor = (jid) => jid ? jid.replace(/@s\.whatsapp\.net|@lid/g, '') : 'Unknown';
  const formatDate = (ts) => new Date(ts * 1000).toLocaleString('id-ID');

  const requests = joinRequestList.map((req, i) => ({
    index: i,
    jid: getJid(req),
    nomor: formatNomor(getJid(req)),
    name: req.notify || formatNomor(getJid(req)),
    time: req.request_time,
    method: req.request_method
  }));

  if (perintah === 'list' || perintah === 'daftar') {
    if (requests.length === 0) return reply('📭 Tidak ada permintaan bergabung');
    let txt = `📋 *DAFTAR PERMINTAAN*\n━━━━━━━━━━━━━━━━\n📊 Total: ${requests.length}\n\n`;
    requests.forEach((r, i) => {
      txt += `*${i+1}. ${r.name}*\n`;
      txt += `   📞 ${r.nomor}\n`;
      txt += `   ⏰ ${formatDate(r.time)}\n`;
      txt += `   📝 ${r.method}\n\n`;
    });
    txt += `━━━━━━━━━━━━━━━━\n📌 .rj approve 1\n📌 .rj approve all\n📌 .rj reject 1\n📌 .rj reject all`;
    return reply(txt);
  }

  if (perintah === 'approve' || perintah === 'terima' || perintah === 'acc') {
    if (requests.length === 0) return reply('❌ Tidak ada permintaan');
    if (nomorUrut === 'all') {
      await satanic.groupRequestParticipantsUpdate(m.chat, requests.map(r => r.jid), 'approve');
      return reply(`✅ Berhasil approve ${requests.length} permintaan`);
    }
    let idx = parseInt(nomorUrut) - 1;
    if (isNaN(idx) || idx < 0 || idx >= requests.length) return reply('❌ Nomor tidak valid');
    await satanic.groupRequestParticipantsUpdate(m.chat, [requests[idx].jid], 'approve');
    return reply(`✅ Berhasil approve @${requests[idx].nomor}`, { mentions: [requests[idx].jid] });
  }

  if (perintah === 'reject' || perintah === 'tolak' || perintah === 'decline') {
    if (requests.length === 0) return reply('❌ Tidak ada permintaan');
    if (nomorUrut === 'all') {
      await satanic.groupRequestParticipantsUpdate(m.chat, requests.map(r => r.jid), 'reject');
      return reply(`❌ Berhasil reject ${requests.length} permintaan`);
    }
    let idx = parseInt(nomorUrut) - 1;
    if (isNaN(idx) || idx < 0 || idx >= requests.length) return reply('❌ Nomor tidak valid');
    await satanic.groupRequestParticipantsUpdate(m.chat, [requests[idx].jid], 'reject');
    return reply(`❌ Berhasil reject @${requests[idx].nomor}`, { mentions: [requests[idx].jid] });
  }

  reply(`🔧 *REQUEST JOIN*\n━━━━━━━━━━━━━━━━\n.rj list - Lihat daftar\n.rj approve 1 - Terima\n.rj approve all - Terima semua\n.rj reject 1 - Tolak\n.rj reject all - Tolak semua`);
break;
case 'setleave': {
    if (!isAdmins && !isCreator) return reply('Hanya admin yang bisa!')

    
    const message = text.trim()
    
    if (!message) {
        return reply(`❌ Gunakan: ${prefix}setleave <text>\n\n*Contoh:*\n${prefix}setleave Goodbye @user dari @subject!\n\n*Placeholder:*\n@user - Username\n@subject - Group name\n@bio - User bio\n@date - Leave date\n@desc - Group description`)
    }
    
    global.leaveMessage = message
    global.leave = true // Otomatis aktifkan leave
    
    return reply('✅ Leave message telah diatur!\nSistem leave otomatis diaktifkan!')
    break
}
case 'afk':
  if (text) {
    try {
      const groupMeta = await satanic.groupMetadata(m.chat);
      const participant = groupMeta.participants.find(p => p.jid === m.sender);
      const lid = participant ? participant.id : m.sender;
      
      console.log("JID:", m.sender);
      console.log("LID (id):", lid);
      
      afkData[lid] = {
        reason: text,
        time: Date.now()
      };
      
      fs.writeFileSync("./database/afk.json", JSON.stringify(afkData));
      reply(`✅ AFK aktif!\n📝 Alasan: ${text}`);
    } catch (e) {
      console.log("Error:", e);
      reply(`⚠️ Gagal set AFK: ${e.message}`);
    }
  } else {
    reply(`⚠️ Masukkan alasan!\nContoh: ${prefix + command} lagi makan`);
  }
break
case 'ban':
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  
  let target = null
  
  if (m.quoted) {
    target = m.quoted.sender
  } else if (m.mentionedJid && m.mentionedJid.length > 0) {
    target = m.mentionedJid[0]
  } else if (text) {
    const nomor = text.replace(/[^0-9]/g, '')
    target = nomor + '@s.whatsapp.net'
  } else {
    return reply(`⚠️ Tag, reply, atau masukkan nomor user yang ingin di-ban!\n\nContoh: ${prefix + command} @user`)
  }
  
  if (target === botNumber) return reply('❌ Tidak bisa memban bot sendiri!')
  if (target === m.sender) return reply('❌ Tidak bisa memban diri sendiri!')
  
  if (!bannedList.includes(target)) {
    bannedList.push(target)
    fs.writeFileSync("./database/banuser.json", JSON.stringify(bannedList))
    reply(`✅ *User berhasil di-ban!*\n\n🚫 @${target.split('@')[0]} tidak dapat menggunakan perintah bot lagi.`, { mentions: [target] })
  } else {
    reply(`❌ User sudah dalam daftar ban!`)
  }
break
case 'unban':
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  
  let targetUnban = null
  
  if (m.quoted) {
    targetUnban = m.quoted.sender
  } else if (m.mentionedJid && m.mentionedJid.length > 0) {
    targetUnban = m.mentionedJid[0]
  } else if (text) {
    const nomor = text.replace(/[^0-9]/g, '')
    targetUnban = nomor + '@s.whatsapp.net'
  } else {
    return reply(`⚠️ Tag, reply, atau masukkan nomor user yang ingin di-unban!\n\nContoh: .unban 628xxx`)
  }
  
  const index = bannedList.indexOf(targetUnban)
  if (index !== -1) {
    bannedList.splice(index, 1)
    fs.writeFileSync("./database/banuser.json", JSON.stringify(bannedList))
    reply(`✅ *User berhasil di-unban!*\n\n✅ @${targetUnban.split('@')[0]} sekarang dapat menggunakan perintah bot lagi.`, { mentions: [targetUnban] })
  } else {
    reply(`❌ User tidak ditemukan dalam daftar ban!`)
  }
break
case 'listban':
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  
  if (bannedList.length === 0) {
    reply(`📋 *Daftar Ban*\n\nTidak ada user yang di-ban.`)
  } else {
    let text = `📋 *Daftar User yang Di-Ban*\n\n`
    for (let user of bannedList) {
      text += `👤 @${user.split('@')[0]}\n`
    }
    text += `\n📊 Total: ${bannedList.length} user`
    reply(text, { mentions: bannedList })
  }
break
 case 'menu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`

[ AQUA AI • v2.1.3 ]

> hai ${pushname}, salam dari satanic haxor ⚡
 klik tombol bawah untuk menu
 
type      :  case
version   :  2.1.3
developer :  satanic haxor
baileys   :  whiskeysockets/baileys

Do not spam call and meessage private chat bot 🚫

`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
break
 case 'groupmenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`

[ AQUA AI • v2.1.3 ]

> hai ${pushname}, salam dari satanic haxor ⚡

GROUP MENU : 
⭃ ${prefix}add
⭃ ${prefix}kick
⭃ ${prefix}warn
⭃ ${prefix}grup
⭃ ${prefix}leave <on/of>
⭃ ${prefix}poll
⭃ ${prefix}afk
⭃ ${prefix}ban
⭃ ${prefix}unban
⭃ ${prefix}listban
⭃ ${prefix}totag
⭃ ${prefix}rvo
⭃ ${prefix}getpp
⭃ ${prefix}opentime
⭃ ${prefix}closetime
⭃ ${prefix}tagadmin
⭃ ${prefix}grup <open/close>
⭃ ${prefix}promote
⭃ ${prefix}welcome <on/of>
⭃ ${prefix}demote
⭃ ${prefix}listwarn
⭃ ${prefix}resetwarn
⭃ ${prefix}delwarn
⭃ ${prefix}listonline
⭃ ${prefix}requestjoin
⭃ ${prefix}getppgc
⭃ ${prefix}setname
⭃ ${prefix}setppgc
⭃ ${prefix}setdesk
⭃ ${prefix}cekidch
⭃ ${prefix}cekidgc
⭃ ${prefix}antitagsw
⭃ ${prefix}antilink
⭃ ${prefix}hidetag
⭃ ${prefix}reactch
⭃ ${prefix}revoke
⭃ ${prefix}linkgc
⭃ ${prefix}upswgc
⭃ ${prefix}promotenotif
⭃ ${prefix}antibadword
⭃ ${prefix}addbadword
⭃ ${prefix}delbadword
⭃ ${prefix}listbadword 
⭃ ${prefix}demotenotif

`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
break
 case 'searchmenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`

[ AQUA AI • v2.1.3 ]

> hai ${pushname}, salam dari satanic haxor ⚡

SEARCH MENU :
⭃ ${prefix}pinterest
⭃ ${prefix}alquran
⭃ ${prefix}murotal
⭃ ${prefix}bingimage
⭃ ${prefix}ytsearch
⭃ ${prefix}npmsearch
⭃ ${prefix}spotifysearch 
⭃ ${prefix}applemusic
⭃ ${prefix}capcutsearch
⭃ ${prefix}snackvideosearch
⭃ ${prefix}xnxxsearch
⭃ ${prefix}xvideosearch
⭃ ${prefix}xvideodl
⭃ ${prefix}xnxxdl 


`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
break
case 'ownermenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`

[ AQUA AI • v2.1.3 ]

> hai ${pushname}, salam dari satanic haxor ⚡

OWNER MENU :
⭃ ${prefix}self
⭃ ${prefix}public
⭃ ${prefix}npm
⭃ ${prefix}autotyping
⭃ ${prefix}autoread
⭃ ${prefix}addcase
⭃ ${prefix}delcase
⭃ ${prefix}editcase
⭃ ${prefix}getcase
⭃ ${prefix}block
⭃ ${prefix}unblock
⭃ ${prefix}autoreadsw
⭃ ${prefix}addprem
⭃ ${prefix}delprem
⭃ ${prefix}statusgrup
⭃ ${prefix}addgb
⭃ ${prefix}delgb
⭃ ${prefix}jpm
⭃ ${prefix}upch
⭃ ${prefix}setppbot
⭃ ${prefix}addproduk
⭃ ${prefix}delproduk
⭃ ${prefix}batalorder
⭃ ${prefix}confirm
⭃ ${prefix}listproduk
⭃ ${prefix}approve
⭃ ${prefix}reject

`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
break
case 'stalkmenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`

[ AQUA AI • v2.1.3 ]

> hai ${pushname}, salam dari satanic haxor ⚡

STALK MENU :
⭃ ${prefix}igstalk
⭃ ${prefix}ttstalk
⭃ ${prefix}ffstalk
⭃ ${prefix}twstalk
⭃ ${prefix}robloxstalk
⭃ ${prefix}ghstalk
⭃ ${prefix}npmstalk
⭃ ${prefix}ytstalk


`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
        
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
break
case 'gamemenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`

[ AQUA AI • v2.1.3 ]

> hai ${pushname}, salam dari satanic haxor ⚡

GAME MENU :
⭃ ${prefix}truth
⭃ ${prefix}dare
⭃ ${prefix}ceksifat
⭃ ${prefix}asahotak
⭃ ${prefix}tekateki
⭃ ${prefix}siapaaku
⭃ ${prefix}mathquiz
⭃ ${prefix}family100
⭃ ${prefix}caklontong
⭃ ${prefix}tebakgambar
⭃ ${prefix}tebakkata 
⭃ ${prefix}tebaktebakan
⭃ ${prefix}tebakkimia
⭃ ${prefix}ulartangga
⭃ ${prefix}tictactoe
⭃ ${prefix}tebakbom
⭃ ${prefix}cekkodam
⭃ ${prefix}yatim
⭃ ${prefix}piatu
⭃ ${prefix}jomblo
⭃ ${prefix}waria
⭃ ${prefix}koruptor
⭃ ${prefix}psikopat
⭃ ${prefix}pedofil
⭃ ${prefix}miskin
⭃ ${prefix}tukangjajan
⭃ ${prefix}jelek
⭃ ${prefix}mokondo
⭃ ${prefix}penipu
⭃ ${prefix}tukangcopet
⭃ ${prefix}tukangbo
⭃ ${prefix}tukangcoli
⭃ ${prefix}tukangkawin
⭃ ${prefix}maling
⭃ ${prefix}pelakor
⭃ ${prefix}perampok
⭃ ${prefix}begal
⭃ ${prefix}wibu
⭃ ${prefix}janda
⭃ ${prefix}jodohku 
⭃ ${prefix}cekyatim
⭃ ${prefix}cekjelek
⭃ ${prefix}cekjodoh
⭃ ${prefix}cekmiskin
⭃ ${prefix}cekkaya
⭃ ${prefix}cektolol
⭃ ${prefix}ceknamabapak
⭃ ${prefix}cekwibu


`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        }, 
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },        
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
break
case 'downloadmenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`

[ AQUA AI • v2.1.3 ]

> hai ${pushname}, salam dari satanic haxor ⚡

DOWNDLOAD MENU :
⭃ ${prefix}ig
⭃ ${prefix}ttdl
⭃ ${prefix}fbdl
⭃ ${prefix}play
⭃ ${prefix}igslide
⭃ ${prefix}ttslide
⭃ ${prefix}igmp3 
⭃ ${prefix}ttmp3
⭃ ${prefix}ytmp4
⭃ ${prefix}ytmp3
⭃ ${prefix}videy
⭃ ${prefix}threads
⭃ ${prefix}spotify
⭃ ${prefix}terabox
⭃ ${prefix}capcut
⭃ ${prefix}mediafire
⭃ ${prefix}gitclone
⭃ ${prefix}cocofun
⭃ ${prefix}scdl
⭃ ${prefix}snackvideo
⭃ ${prefix}applemusicdl


`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
break
case 'aimenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`

[ AQUA AI • v2.1.3 ]

> hai ${pushname}, salam dari satanic haxor ⚡

AI MENU :
⭃ ${prefix}ai
⭃ ${prefix}felo
⭃ ${prefix}gita
⭃ ${prefix}aqua
⭃ ${prefix}gemini
⭃ ${prefix}chatai
⭃ ${prefix}openai
⭃ ${prefix}epsilon
⭃ ${prefix}copilot
⭃ ${prefix}webpilot
⭃ ${prefix}deepseek
⭃ ${prefix}illama-code
⭃ ${prefix}illama-vision
⭃ ${prefix}text2img
⭃ ${prefix}texttoimg
⭃ ${prefix}flux-schnell
⭃ ${prefix}gpt-5.1
⭃ ${prefix}gpt-5-online
⭃ ${prefix}gpt-5
⭃ ${prefix}gpt-5-nano
⭃ ${prefix}gpt-5-mini
⭃ ${prefix}openai-o1
⭃ ${prefix}openai-o3
⭃ ${prefix}openai-o3-mini
⭃ ${prefix}gpt-4o
⭃ ${prefix}openai-o4-mini
⭃ ${prefix}gpt-4.1-mini
⭃ ${prefix}gpt-4.1-nano
⭃ ${prefix}gpt-5.3
⭃ ${prefix}gpt-5.4
⭃ ${prefix}gpt-5.5 
⭃ ${prefix}img2img
⭃ ${prefix}talkingphoto
⭃ ${prefix}removecloth 
⭃ ${prefix}nanobanana
⭃ ${prefix}gpt2image
⭃ ${prefix}jadipresiden
⭃ ${prefix}jadibugil
⭃ ${prefix}jadianime
⭃ ${prefix}jadizombie
⭃ ${prefix}jadibiliard
⭃ ${prefix}jadifigure
⭃ ${prefix}jadimacbook
⭃ ${prefix}texttovideo


`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
break
case 'toolsmenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`

[ AQUA AI • v2.1.3 ]

> hai ${pushname}, salam dari satanic haxor ⚡

TOOLS MENU :
⭃ ${prefix}hd
⭃ ${prefix}Ocr
⭃ ${prefix}esrgan
⭃ ${prefix}cekresi
⭃ ${prefix}hdvid
⭃ ${prefix}google
⭃ ${prefix}tourl
⭃ ${prefix}tourl2
⭃ ${prefix}ssweb
⭃ ${prefix}translate
⭃ ${prefix}kodepos
⭃ ${prefix}removebg
⭃ ${prefix}removebg2
⭃ ${prefix}skiplink
⭃ ${prefix}brat
⭃ ${prefix}bratvid
⭃ ${prefix}smeme
⭃ ${prefix}iqc
⭃ ${prefix}translate
⭃ ${prefix}kalkulator
⭃ ${prefix}qc
⭃ ${prefix}fakedana
⭃ ${prefix}fakebangjago
⭃ ${prefix}fakeff
⭃ ${prefix}fakektp
⭃ ${prefix}ceknik
⭃ ${prefix}whatmusic
⭃ ${prefix}carbonify
⭃ ${prefix}tts 
⭃ ${prefix}texttospeech 
⭃ ${prefix}say
⭃ ${prefix}ttsgoku 
⭃ ${prefix}ttseminem 
⭃ ${prefix}ttsmickey
⭃ ${prefix}ttsnahida
⭃ ${prefix}ttselon 
⭃ ${prefix}ttsoptimus
⭃ ${prefix}sticker
⭃ ${prefix}toimg
⭃ ${prefix}tomp3
⭃ ${prefix}tomp4
⭃ ${prefix}togif
⭃ ${prefix}tovideo
⭃ ${prefix}toptv

`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
break
case 'allmenu': {
    try {                  
        let txt = `> Halo ${pushname} saya adalah ${global.namaBot} asisten ${global.namaowner}, berikut daftar list menu yang tersedia dibawah ini 
        
☆ Menu Group  ☆    
⭃ ${prefix}add
⭃ ${prefix}kick
⭃ ${prefix}warn
⭃ ${prefix}grup
⭃ ${prefix}leave <on/of>
⭃ ${prefix}poll
⭃ ${prefix}afk
⭃ ${prefix}ban
⭃ ${prefix}unban
⭃ ${prefix}listban
⭃ ${prefix}totag
⭃ ${prefix}rvo
⭃ ${prefix}getpp
⭃ ${prefix}opentime
⭃ ${prefix}closetime
⭃ ${prefix}tagadmin
⭃ ${prefix}grup <open/close>
⭃ ${prefix}promote
⭃ ${prefix}welcome <on/of>
⭃ ${prefix}demote
⭃ ${prefix}listwarn
⭃ ${prefix}resetwarn
⭃ ${prefix}delwarn
⭃ ${prefix}listonline
⭃ ${prefix}requestjoin
⭃ ${prefix}getppgc
⭃ ${prefix}setname
⭃ ${prefix}setppgc
⭃ ${prefix}setdesk
⭃ ${prefix}cekidch
⭃ ${prefix}cekidgc
⭃ ${prefix}antitagsw
⭃ ${prefix}antilink
⭃ ${prefix}hidetag
⭃ ${prefix}reactch
⭃ ${prefix}revoke
⭃ ${prefix}linkgc
⭃ ${prefix}upswgc
⭃ ${prefix}promotenotif
⭃ ${prefix}antibadword
⭃ ${prefix}addbadword
⭃ ${prefix}delbadword
⭃ ${prefix}listbadword 
⭃ ${prefix}demotenotif

☆ Menu Tools  ☆    
⭃ ${prefix}hd
⭃ ${prefix}Ocr
⭃ ${prefix}esrgan
⭃ ${prefix}cekresi
⭃ ${prefix}hdvid
⭃ ${prefix}google
⭃ ${prefix}tourl
⭃ ${prefix}tourl2
⭃ ${prefix}ssweb
⭃ ${prefix}translate
⭃ ${prefix}kodepos
⭃ ${prefix}removebg
⭃ ${prefix}removebg2
⭃ ${prefix}skiplink
⭃ ${prefix}brat
⭃ ${prefix}bratvid
⭃ ${prefix}smeme
⭃ ${prefix}iqc
⭃ ${prefix}translate
⭃ ${prefix}kalkulator
⭃ ${prefix}qc
⭃ ${prefix}fakedana
⭃ ${prefix}fakebangjago
⭃ ${prefix}fakeff
⭃ ${prefix}fakektp
⭃ ${prefix}ceknik
⭃ ${prefix}whatmusic
⭃ ${prefix}carbonify
⭃ ${prefix}tts 
⭃ ${prefix}texttospeech 
⭃ ${prefix}say
⭃ ${prefix}ttsgoku 
⭃ ${prefix}ttseminem 
⭃ ${prefix}ttsmickey
⭃ ${prefix}ttsnahida
⭃ ${prefix}ttselon 
⭃ ${prefix}ttsoptimus

☆ Menu Tools  ☆    
⭃ ${prefix}ig
⭃ ${prefix}ttdl
⭃ ${prefix}fbdl
⭃ ${prefix}play
⭃ ${prefix}igslide
⭃ ${prefix}ttslide
⭃ ${prefix}igmp3 
⭃ ${prefix}ttmp3
⭃ ${prefix}ytmp4
⭃ ${prefix}ytmp3
⭃ ${prefix}videy
⭃ ${prefix}threads
⭃ ${prefix}spotify
⭃ ${prefix}terabox
⭃ ${prefix}capcut
⭃ ${prefix}mediafire
⭃ ${prefix}gitclone
⭃ ${prefix}cocofun
⭃ ${prefix}scdl
⭃ ${prefix}snackvideo
⭃ ${prefix}applemusicdl

☆ Menu Stalk  ☆    
⭃ ${prefix}igstalk
⭃ ${prefix}ttstalk
⭃ ${prefix}ffstalk
⭃ ${prefix}twstalk
⭃ ${prefix}robloxstalk
⭃ ${prefix}ghstalk
⭃ ${prefix}npmstalk
⭃ ${prefix}ytstalk

☆ Menu Search  ☆    
⭃ ${prefix}pinterest
⭃ ${prefix}alquran
⭃ ${prefix}murotal
⭃ ${prefix}bingimage
⭃ ${prefix}ytsearch
⭃ ${prefix}npmsearch
⭃ ${prefix}spotifysearch 
⭃ ${prefix}applemusic
⭃ ${prefix}capcutsearch
⭃ ${prefix}snackvideosearch
⭃ ${prefix}xnxxsearch
⭃ ${prefix}xvideosearch
⭃ ${prefix}xvideodl
⭃ ${prefix}xnxxdl

☆ Menu Convert  ☆  
⭃ ${prefix}sticker
⭃ ${prefix}toimg
⭃ ${prefix}tomp3
⭃ ${prefix}tomp4
⭃ ${prefix}togif
⭃ ${prefix}tovideo
⭃ ${prefix}toptv

☆ Menu AI  ☆  
⭃ ${prefix}ai
⭃ ${prefix}felo
⭃ ${prefix}gita
⭃ ${prefix}aqua
⭃ ${prefix}gemini
⭃ ${prefix}chatai
⭃ ${prefix}openai
⭃ ${prefix}epsilon
⭃ ${prefix}copilot
⭃ ${prefix}webpilot
⭃ ${prefix}deepseek
⭃ ${prefix}illama-code
⭃ ${prefix}illama-vision
⭃ ${prefix}text2img
⭃ ${prefix}texttoimg
⭃ ${prefix}flux-schnell
⭃ ${prefix}gpt-5.1
⭃ ${prefix}gpt-5-online
⭃ ${prefix}gpt-5
⭃ ${prefix}gpt-5-nano
⭃ ${prefix}gpt-5-mini
⭃ ${prefix}openai-o1
⭃ ${prefix}openai-o3
⭃ ${prefix}openai-o3-mini
⭃ ${prefix}gpt-4o
⭃ ${prefix}openai-o4-mini
⭃ ${prefix}gpt-4.1-mini
⭃ ${prefix}gpt-4.1-nano
⭃ ${prefix}gpt-5.3
⭃ ${prefix}gpt-5.4
⭃ ${prefix}gpt-5.5 
⭃ ${prefix}img2img
⭃ ${prefix}talkingphoto
⭃ ${prefix}removecloth 
⭃ ${prefix}nanobanana
⭃ ${prefix}gpt2image
⭃ ${prefix}jadipresiden
⭃ ${prefix}jadibugil
⭃ ${prefix}jadianime
⭃ ${prefix}jadizombie
⭃ ${prefix}jadibiliard
⭃ ${prefix}jadifigure
⭃ ${prefix}jadimacbook
⭃ ${prefix}texttovideo

☆ Menu Game  ☆  
⭃ ${prefix}truth
⭃ ${prefix}dare
⭃ ${prefix}ceksifat
⭃ ${prefix}asahotak
⭃ ${prefix}tekateki
⭃ ${prefix}siapaaku
⭃ ${prefix}mathquiz
⭃ ${prefix}family100
⭃ ${prefix}caklontong
⭃ ${prefix}tebakgambar
⭃ ${prefix}tebakkata 
⭃ ${prefix}tebaktebakan
⭃ ${prefix}tebakkimia
⭃ ${prefix}ulartangga
⭃ ${prefix}tictactoe
⭃ ${prefix}tebakbom
⭃ ${prefix}cekkodam
⭃ ${prefix}yatim
⭃ ${prefix}piatu
⭃ ${prefix}jomblo
⭃ ${prefix}waria
⭃ ${prefix}koruptor
⭃ ${prefix}psikopat
⭃ ${prefix}pedofil
⭃ ${prefix}miskin
⭃ ${prefix}tukangjajan
⭃ ${prefix}jelek
⭃ ${prefix}mokondo
⭃ ${prefix}penipu
⭃ ${prefix}tukangcopet
⭃ ${prefix}tukangbo
⭃ ${prefix}tukangcoli
⭃ ${prefix}tukangkawin
⭃ ${prefix}maling
⭃ ${prefix}pelakor
⭃ ${prefix}perampok
⭃ ${prefix}begal
⭃ ${prefix}wibu
⭃ ${prefix}janda
⭃ ${prefix}jodohku 
⭃ ${prefix}cekyatim
⭃ ${prefix}cekjelek
⭃ ${prefix}cekjodoh
⭃ ${prefix}cekmiskin
⭃ ${prefix}cekkaya
⭃ ${prefix}cektolol
⭃ ${prefix}ceknamabapak
⭃ ${prefix}cekwibu

☆ Menu Owner  ☆  
⭃ ${prefix}self
⭃ ${prefix}public
⭃ ${prefix}npm
⭃ ${prefix}autotyping
⭃ ${prefix}autoread
⭃ ${prefix}autoreadsw
⭃ ${prefix}addcase
⭃ ${prefix}getcase
⭃ ${prefix}block
⭃ ${prefix}unblock
⭃ ${prefix}delcase
⭃ ${prefix}editcase
⭃ ${prefix}addprem
⭃ ${prefix}delprem
⭃ ${prefix}statusgrup
⭃ ${prefix}addgb
⭃ ${prefix}delgb
⭃ ${prefix}jpm
⭃ ${prefix}upch
⭃ ${prefix}setppbot
⭃ ${prefix}addproduk
⭃ ${prefix}delproduk
⭃ ${prefix}batalorder
⭃ ${prefix}confirm
⭃ ${prefix}listproduk
⭃ ${prefix}approve
⭃ ${prefix}reject


Powered by ${global.namaowner}
version 1.1.0
Developer Satanic Haxor`;

        let buttons = [
            // 1. CTA URL
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "Developer Satanic",
                    url: "https://wa.me/6283168758640",
                    merchant_url: "https://wa.me/6283168758640"
                })
            },          
            {
                name: "cta_call",
                buttonParamsJson: JSON.stringify({
                    display_text: "Celuller",
                    phone_number: "6283168758640"
                })
            },
            // 3. CTA COPY
            {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                    display_text: "Free Rest api",
                    copy_code: "https://free-restapi.biz.id/"
                })
            }
        ];
        const response = await fetch('https://c.termai.cc/i108/58xw.jpg');
        const profilePicBuffer = Buffer.from(await response.arrayBuffer());

        await sendButton(from, txt, "Satanic Haxor", profilePicBuffer, buttons, m);
    } catch (e) {
        console.error(e);
        reply("Terjadi kesalahan.");
    }
}
break;
// ========== CASE SC (SEMUA CTA LENGKAP) ==========
case 'infobot':
case 'script':
case 'sc': {
    try {                  
        let txt = `Sc In Free silahkan ambil script di comunity bot whastsapp, jika ingin buat bot costum atau beli sc no enc hubungin owner`;

        let buttons = [
            // 1. CTA URL
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "Developer Satanic",
                    url: "https://wa.me/6283168758640",
                    merchant_url: "https://wa.me/6283168758640"
                })
            },
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "Get Sc Free",
                    url: "https://chat.whatsapp.com/CUoxno1rPe55ukSMup2BWG",
                    merchant_url: "https://chat.whatsapp.com/CUoxno1rPe55ukSMup2BWG"
                })
            },
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "Channel Aqua AI",
                    url: "https://whatsapp.com/channel/0029VbBOXZ6AojZ23z5ieI3z",
                    merchant_url: "https://whatsapp.com/channel/0029VbBOXZ6AojZ23z5ieI3z"
                })
            },
            
            {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                    display_text: "Free Rest api",
                    copy_code: "https://free-restapi.biz.id/"
                })
            }
        ];

        // Download gambar dari URL menjadi buffer
        const response = await fetch('https://c.termai.cc/i108/58xw.jpg');
        const profilePicBuffer = Buffer.from(await response.arrayBuffer());

        await sendButton(from, txt, "Menu Source Code", profilePicBuffer, buttons, m);
    } catch (e) {
        console.error(e);
        reply("Terjadi kesalahan.");
    }
}
break;
case "warning":
case "warn":
{
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk grup!" }, { quoted: m });
    if (!isAdmins && !isCreator) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk admin grup!" }, { quoted: m });
    
    // Cek apakah ada yang di-tag atau reply
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : null);
    
    if (!target) {
        return satanic.sendMessage(m.chat, { 
            text: `❌ Tag atau reply pesan user yang ingin diberi warning!\nContoh: *${prefix + command}* @user alasan` 
        }, { quoted: m });
    }
    
    // Ambil alasan (text setelah mention)
    let alasan = text.replace(new RegExp(`@${target.split('@')[0]}\\s*`), '').trim();
    alasan = alasan || "Tidak ada alasan";
    
    // Load data warning
    let warnData = {};
    try {
        warnData = JSON.parse(fs.readFileSync("./database/warning.json"));
    } catch (e) {
        warnData = {};
    }
    
    // Inisialisasi grup jika belum ada
    if (!warnData[m.chat]) {
        warnData[m.chat] = {};
    }
    
    // Inisialisasi user jika belum ada
    if (!warnData[m.chat][target]) {
        warnData[m.chat][target] = 0;
    }
    
    // Tambah warning
    warnData[m.chat][target] += 1;
    let currentWarn = warnData[m.chat][target];
    
    // Simpan ke file
    fs.writeFileSync("./database/warning.json", JSON.stringify(warnData, null, 2));
    
    // Kirim notifikasi
    let teks = `⚠️ *WARNING SYSTEM* ⚠️\n\n`;
    teks += `┌  ○ *User* : @${target.split('@')[0]}\n`;
    teks += `│  ○ *Warning* : +1\n`;
    teks += `│  ○ *Total* : ${currentWarn} warning\n`;
    teks += `│  ○ *Alasan* : ${alasan}\n`;
    teks += `│  ○ *Admin* : @${sender.split('@')[0]}\n`;
    teks += `└  ○ *Batas* : 3 warning = kick\n\n`;
    
    // Cek jika warning mencapai batas (3)
    let batasWarn = 3;
    if (currentWarn >= batasWarn) {
        teks += `⚠️ *PERHATIAN!*\n`;
        teks += `User @${target.split('@')[0]} telah mencapai ${batasWarn} warning!\n`;
        teks += `🔴 *Tindakan: Dikeluarkan dari grup!*\n\n`;
        
        // Hapus data user
        delete warnData[m.chat][target];
        
        // Hapus grup jika kosong
        if (Object.keys(warnData[m.chat]).length === 0) {
            delete warnData[m.chat];
        }
        
        fs.writeFileSync("./database/warning.json", JSON.stringify(warnData, null, 2));
        
        // Kirim pesan sebelum kick
        await satanic.sendMessage(m.chat, { 
            text: teks,
            mentions: [target, sender]
        }, { quoted: m });
        
        // Kick user dari grup
        setTimeout(async () => {
            await satanic.groupParticipantsUpdate(m.chat, [target], "remove");
        }, 2000);
    } else {
        // Kirim notifikasi biasa
        await satanic.sendMessage(m.chat, { 
            text: teks,
            mentions: [target, sender]
        }, { quoted: m });
    }
}
break;
case 'tagadmin': {
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: mess.only.group });
    const groupMetadata = await satanic.groupMetadata(m.chat);
    const participants = groupMetadata.participants;

    let adminList = [];
    let adminNames = [];
    let adminIds = [];
    participants.forEach((participant) => {
        if (participant.admin === "admin" || participant.admin === "superadmin") {
            adminNames.push(participant.id.split('@')[0]);  
            adminIds.push(participant.id);  // ID admin
            adminList.push(`@${participant.id.split('@')[0]}`); 
        }
    });

    const groupPP = 'https://example.com/default-image.jpg'; 
    const groupName = groupMetadata.subject;

    if (adminList.length > 0) {
        let tagMessage = `🌟 *Admin Grup*:\n\n*Nama Grup:* ${groupName}\n\n${adminNames.map((name, i) => `*${name}* (@${adminIds[i].split('@')[0]})`).join('\n')}`;
        satanic.sendMessage(m.chat, {
            text: tagMessage,
            mentions: adminIds,
            caption: 'Daftar admin grup.',
            thumbnail: { url: groupPP }
        });
    } else {
        satanic.sendMessage(m.chat, { text: '😓 Tidak ada admin di grup ini.' });
    }
    break;
}
case "cekwarning":
case "cekwarn":
case "warning":
{
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk grup!" }, { quoted: m });
    
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : sender);
    
    let warnData = {};
    try {
        warnData = JSON.parse(fs.readFileSync("./database/warning.json"));
    } catch (e) {
        warnData = {};
    }
    
    let userWarn = warnData[m.chat]?.[target] || 0;
    
    // Buat progress bar visual
    let progress = "";
    for (let i = 1; i <= 3; i++) {
        progress += i <= userWarn ? "⬛" : "⬜";
    }
    
    let teks = `📊 *CEK WARNING* 📊\n\n`;
    teks += `○ *User* : @${target.split('@')[0]}\n`;
    teks += `○ *Warning* : ${userWarn} / 3\n`;
    teks += `○ *Progress* : ${progress}\n`;
    teks += `○ *Status* : ${userWarn >= 3 ? "🔴 AKAN DIKICK" : "🟢 AMAN"}`;
    
    satanic.sendMessage(m.chat, { 
        text: teks,
        mentions: [target]
    }, { quoted: m });
}
break;
case "delwarning":
case "delwarn":
case "kurangiwarning":
{
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk grup!" }, { quoted: m });
    if (!isAdmins && !isCreator) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk admin grup!" }, { quoted: m });
    
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : null);
    
    if (!target) {
        return satanic.sendMessage(m.chat, { 
            text: `❌ Tag atau reply pesan user yang ingin dikurangi warningnya!\nContoh: *${prefix + command}* @user` 
        }, { quoted: m });
    }
    
    let warnData = {};
    try {
        warnData = JSON.parse(fs.readFileSync("./database/warning.json"));
    } catch (e) {
        warnData = {};
    }
    
    if (!warnData[m.chat] || !warnData[m.chat][target]) {
        return satanic.sendMessage(m.chat, { 
            text: `✅ User @${target.split('@')[0]} tidak memiliki warning.`,
            mentions: [target]
        }, { quoted: m });
    }
    
    // Kurangi warning
    warnData[m.chat][target] -= 1;
    let sisaWarn = warnData[m.chat][target];
    
    // Hapus jika 0
    if (sisaWarn <= 0) {
        delete warnData[m.chat][target];
        
        // Hapus grup jika kosong
        if (Object.keys(warnData[m.chat]).length === 0) {
            delete warnData[m.chat];
        }
    }
    
    fs.writeFileSync("./database/warning.json", JSON.stringify(warnData, null, 2));
    
    let teks = `✅ *WARNING BERKURANG* ✅\n\n`;
    teks += `○ *User* : @${target.split('@')[0]}\n`;
    teks += `○ *Warning* : -1\n`;
    teks += `○ *Sisa* : ${sisaWarn || 0} warning`;
    
    satanic.sendMessage(m.chat, { 
        text: teks,
        mentions: [target]
    }, { quoted: m });
}
break;
case "resetwarning":
case "resetwarn":
{
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk grup!" }, { quoted: m });
    if (!isAdmins && !isOwner) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk admin grup!" }, { quoted: m });
    
    let warnData = {};
    try {
        warnData = JSON.parse(fs.readFileSync("./database/warning.json"));
    } catch (e) {
        warnData = {};
    }
    
    if (warnData[m.chat]) {
        delete warnData[m.chat];
        fs.writeFileSync("./database/warning.json", JSON.stringify(warnData, null, 2));
        satanic.sendMessage(m.chat, { text: "✅ Semua warning di grup ini telah direset!" }, { quoted: m });
    } else {
        satanic.sendMessage(m.chat, { text: "❌ Tidak ada data warning di grup ini." }, { quoted: m });
    }
}
break;
case "listwarning":
case "listwarn":
{
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk grup!" }, { quoted: m });
    if (!isAdmins && !isCreator) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk admin grup!" }, { quoted: m });
    
    let warnData = {};
    try {
        warnData = JSON.parse(fs.readFileSync("./database/warning.json"));
    } catch (e) {
        warnData = {};
    }
    
    if (!warnData[m.chat] || Object.keys(warnData[m.chat]).length === 0) {
        return satanic.sendMessage(m.chat, { text: "✅ Tidak ada user yang memiliki warning di grup ini." }, { quoted: m });
    }
    
    let teks = "📋 *DAFTAR WARNING GROUP* 📋\n\n";
    let no = 1;
    let mentions = [];
    
    // Urutkan dari warning terbanyak
    let sortedWarn = Object.entries(warnData[m.chat]).sort((a, b) => b[1] - a[1]);
    
    for (let [user, warn] of sortedWarn) {
        let progress = "";
        for (let i = 1; i <= 3; i++) {
            progress += i <= warn ? "⬛" : "⬜";
        }
        teks += `${no++}. @${user.split('@')[0]} : ${warn} warning ${progress}\n`;
        mentions.push(user);
    }
    
    teks += `\nTotal: ${sortedWarn.length} user terkena warning`;
    
    satanic.sendMessage(m.chat, { 
        text: teks,
        mentions: mentions
    }, { quoted: m });
}
break;
  case 'owner':
case 'creator': {
    let vcard = 'BEGIN:VCARD\n' +
        'VERSION:3.0\n' +
        `N:;${global.namaowner};;;\n` +
        `FN:${global.namaowner}\n` +
        `ORG:${global.namaowner};\n` +  // ganti Creator Satanic
        `item1.TEL;type=CELL;type=VOICE;waid=${global.owner}:+${global.owner}\n` +
        `item1.X-ABLabel:${global.namaowner}\n` +  // ganti Creator Satanic
        'item2.EMAIL;type=INTERNET:-\n' +
        'item2.X-ABLabel:Email\n' +
        'item3.URL:https://instagram.com/stnic1_\n' +
        'item3.X-ABLabel:Instagram\n' +
        'item4.ADR:;;Indonesia;;;;\n' +
        'item4.X-ABLabel:Region\n' +
        `item5.X-ABLabel:${global.namaowner}\n` +  // ganti Creator
        'END:VCARD';

    satanic.sendMessage(m.chat, {
        contacts: {
            displayName: `${global.namaowner}`,
            contacts: [{ vcard }]
        }
    }, { quoted: m });
}
break;
case 'autoread':
  if (!isCreator) return reply(mess.owner)
  
  if (text === 'on') {
    global.autoread = true
    reply('✅ Auto read ON')
  } else if (text === 'off') {
    global.autoread = false
    reply('✅ Auto read OFF')
  } else {
    reply(`📱 Auto Read: ${global.autoreadsw ? 'ON' : 'OFF'}\n\nUse: .readsw on/off`)
  }
break
case 'autotyping':
  if (!isCreator) return reply(mess.owner)
  
  if (text === 'on') {
    global.autotyping = true
    reply('✅ Auto typing status ON')
  } else if (text === 'off') {
    global.autotyping = false
    reply('✅ Auto typing status OFF')
  } else {
    reply(`📱 Auto typing Status: ${global.typing ? 'ON' : 'OFF'}\n\nUse: .readsw on/off`)
  }
break
case 'addgb':           
case "addgroup": {
if (!isCreator) return
    const inputText = m.text.slice(prefix.length + command.length).trim();
    let groupId;
    if (!inputText && m.isGroup) {
        groupId = m.chat;
    } 
    else if (inputText) {
        groupId = inputText.split(' ')[0];
        if (!groupId.includes('@g.us')) {
            groupId = groupId + '@g.us';
        }
        groupId = groupId.replace(/[^0-9@.usg]/g, '').replace(/(.*?)@g\.us$/, '$1@g.us');
    }
    else {
        return reply(`Penggunaan:\n1. Di dalam grup: ${prefix + command}\n2. Di chat pribadi: ${prefix + command} <id_group>\nContoh: ${prefix + command} 718191010191@g.us`);
    }
    if (pgroup.includes(groupId)) {
        return reply(`❌ Grup dengan ID: ${groupId}\nSudah terdaftar sebagai grup premium!`);
    }
    pgroup.push(groupId);
    fs.writeFileSync("./database/groupadd.json", JSON.stringify(pgroup));
    reply(`✅ *Sukses Menambahkan Grup Premium!*\n┌  *ID Grup:* ${groupId}\n└  *Status:* Aktif Premium`);
}
break;
case 'cry':
case 'kill':
case 'hug':
case 'pat':
case 'lick':
case 'kiss':
case 'bite':
case 'loli':
case 'yeet':
case 'neko':
case 'bully':
case 'bonk':
case 'wink':
case 'poke':
case 'nom':
case 'slap':
case 'waifu':
case 'smile':
case 'wave':
case 'awoo':
case 'blush':
case 'smug':
case 'glomp':
case 'happy':
case 'dance':
case 'cringe':
case 'cuddle':
case 'highfive':
case 'shinobu':
case 'megumin':
case 'handhold':
    try {
        // Kirim reply "wait" dulu
        await reply(mess.wait || 'Tunggu sebentar...')
        
        // Ambil data dari API
        const { data } = await axios.get(`https://api.waifu.pics/sfw/${command}`)
        
        // Kirim gambar dengan caption
        await satanic.sendMessage(m.chat, {
            image: { url: data.url },
            caption: 'Done'
        }, { quoted: m })
    } catch (error) {
        console.error('Error fetching waifu image:', error)
        
        // Kirim pesan error yang lebih informatif
        let errorMessage = 'Gagal mengambil gambar'
        if (error.response) {
            errorMessage = `API Error: ${error.response.status}`
        } else if (error.request) {
            errorMessage = 'Tidak ada response dari server'
        }
        
        await reply(errorMessage)
    }
    break
case 'delgb':
case "delgroup": {
if (!isCreator) return
    const inputText = m.text.slice(prefix.length + command.length).trim();
    let groupId;
    if ((inputText.toLowerCase() === 'me' || !inputText) && m.isGroup) {
        groupId = m.chat;
    }
    else if (inputText && inputText.toLowerCase() !== 'me') {
        groupId = inputText.split(' ')[0];
        if (!groupId.includes('@g.us')) {
            groupId = groupId + '@g.us';
        }
        groupId = groupId.replace(/[^0-9@.usg]/g, '').replace(/(.*?)@g\.us$/, '$1@g.us');
    }
    else {
        return reply(`Penggunaan:\n1. Di dalam grup: ${prefix + command} atau ${prefix + command} me\n2. Di chat pribadi: ${prefix + command} <id_group>\nContoh: ${prefix + command} 718191010191@g.us`);
    }
    if (!pgroup.includes(groupId)) {
        return reply(`❌ Grup dengan ID: ${groupId}\nTidak ditemukan dalam daftar premium!`);
    }
    const index = pgroup.indexOf(groupId);
    pgroup.splice(index, 1);
    fs.writeFileSync("./database/groupadd.json", JSON.stringify(pgroup));
    reply(`✅ *Sukses Menghapus Grup Premium!*\n┌  *ID Grup:* ${groupId}\n└  *Status:* Premium Dihapus`);
}
break;
case "addprem":
case "prem":
case "premium":
{
    if (!isCreator) {
        return reply(mess.owner);
    }
    if (!q) {
        return reply(`Use ${prefix + command} number\nContoh ${prefix + command} 6285813708397`);
    }
    premi = `${q.split("|")[0].replace(/[^0-9]/g, "")}@s.whatsapp.net`;
    let cekprem = await satanic.onWhatsApp(premi);
    if (cekprem.length == 0) {
        return reply(`Masukkan nomor yang valid dan terdaftar di WhatsApp!!!`);
    }
    premium.push(premi);
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
    reply(`The Number ${premi} Has Been premium`);
}
break;
case "delpremium":
case "delprem":
    if (!isCreator) {
        return reply(mess.owner);
    }
    if (!q) {
        return reply(`Use ${prefix + command} nomor\nContoh ${prefix + command} 6285813708397`);
    }
    yaprem = `${q.split("|")[0].replace(/[^0-9]/g, "")}@s.whatsapp.net`;
    unprem = premium.indexOf(yaprem);
    premium.splice(unprem, 1);
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
    reply(`The Number ${ya} Has Been Removed premium!`);
    break;
    case 'autoreadsw':
  if (!isCreator) return reply(mess.owner)
  
  if (text === 'on') {
    global.autoreadsw = true
    reply('✅ Auto read status ON')
  } else if (text === 'off') {
    global.autoreadsw = false
    reply('✅ Auto read status OFF')
  } else {
    reply(`📱 Auto Read Status: ${global.autoreadsw ? 'ON' : 'OFF'}\n\nUse: .readsw on/off`)
  }
break
 case 'autoreactsw':
  if (!isCreator) return reply(mess.owner)
  
  if (text === 'on') {
    global.autoreactsw = true
    reply('✅ Auto react status ON')
  } else if (text === 'off') {
    global.autoreactsw = false
    reply('✅ Auto react status OFF')
  } else {
    reply(`📱 Auto Read Status: ${global.autoreactsw ? 'ON' : 'OFF'}\n\nUse: .readsw on/off`)
  }
break
case 'self': 
if (!isCreator) return
 satanic.public = false;
 reply(`✅ Successfully changed to ${command} mode`);
break;
case 'delcase': {
		if (!isCreator) return reply('you are not owner')
		if (!text) return reply('Tuliskan nama atau identifier case yang ingin dihapus');

		const fs = require('fs');
		const namaFile = 'satanic.js';
		const caseTarget = text.trim();

		fs.readFile(namaFile, 'utf8', (err, data) => {
			if (err) {
				console.error('Terjadi kesalahan saat membaca file:', err);
				return reply('❌ Gagal membaca file.');
			}
			const regexCase = new RegExp(`case '${caseTarget}':[\\s\\S]*?break;`, 'g');
			if (!regexCase.test(data)) {
				return reply(`❌ Case '${caseTarget}' tidak ditemukan.`);
			}

			const dataBaru = data.replace(regexCase, '');

			fs.writeFile(namaFile, dataBaru, 'utf8', (err) => {
				if (err) {
					console.error('Terjadi kesalahan saat menulis file:', err);
					return reply('❌ Gagal menulis file.');
				}
				reply(`✅ Case '${caseTarget}' berhasil dihapus.`);
			});
		});
	}
	break;
case 'editcase': {
    if (!isCreator) return reply('you are not premium')
    if (!text) return reply('Format salah!\n\nContoh:\n.editcase nama_case | kode_baru');
    const fs = require('fs');
    const namaFile = 'satanic.js';
    const bagian = text.split('|');
    if (bagian.length < 2) return reply('Mana kode barunya? Gunakan pemisah |');

    const target = bagian[0].trim();
    const newCode = bagian.slice(1).join('|').trim();

    fs.readFile(namaFile, 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return reply('❌ Gagal membaca file.');
        }
        const regexCase = new RegExp(`case '${target}':[\\s\\S]*?break;?`, 'g');
        if (!data.match(regexCase)) {
            return reply(`❌ Case '${target}' tidak ditemukan di ${namaFile}.`);
        }
        const dataBaru = data.replace(regexCase, newCode);

        fs.writeFile(namaFile, dataBaru, 'utf8', (err) => {
            if (err) {
                console.error(err);
                return reply('❌ Gagal menulis perubahan ke file.');
            }
            reply(`✅ Case '${target}' berhasil diperbarui!`);
        });
    });
}
break;
case 'intro': 
case 'intronya': {
reply(`—————————𖤝𖣂—————————
樂 - *Kartu Perkenalan*
Nama:
Domisili:
instagram:
tiktok:
————————𖤝:𖣂—————————`)
}
break
case 'getcase':
if (!isCreator) return reply('you are not owner')
const getCase = (cases) => {
return "case"+`'${cases}'`+fs.readFileSync("satanic.js").toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"
}
reply(`${getCase(q)}`)
break
case 'addcase': {
    if (!isCreator) return reply('you are not owner')
    if (!text) return reply('Mana case nya');
    const fs = require('fs');
const namaFile = 'satanic.js';

const caseBaru = `${text}`;

fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }

    // Cari posisi awal dari kumpulan case 'gimage'
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        // Tambahkan case baru tepat di atas case 'gimage'
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);

        // Tulis kembali file dengan case baru
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                reply('Case baru berhasil ditambahkan di atas case gimage.');
            }
        });
    } else {
        reply('Tidak dapat menemukan case gimage dalam file.');
    }
});

}
break;
case 'public': 
if (!isCreator) return
satanic.public = true;
reply(`✅ Successfully changed to ${command} mode`);
break;    
case 'delete':
case 'del': {
    if (!isAdmins && !isCreator) return reply(mess.admin)
    if (!m.quoted) return reply('reply chat')
    let { id, sender } = m.quoted
    let isOriginalSender = m.sender === sender
    if (isOriginalSender || isAdmins || isCreator) {
        await satanic.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: isOriginalSender ? false : true,
                id: id,
                participant: sender
            }
        })
    } else {
        return reply('Kamu hanya bisa menghapus pesanmu sendiri!')
    }
}
break
case 'tomp4':
case 'tovideo':
case 'tovid': {
  async function webp2mp4File(path) {
    return new Promise(async (resolve, reject) => {
      try {
        const form = new FormData()
        form.append('new-image-url', '')
        form.append('new-image', fs.createReadStream(path))
        
        const { data: firstPage } = await axios({
          method: 'post',
          url: 'https://ezgif.com/webp-to-mp4',
          data: form,
          headers: {
            'Content-Type': `multipart/form-data; boundary=${form._boundary}`
          }
        })
        
        const $ = cheerio.load(firstPage)
        const file = $('input[name="file"]').attr('value')
        
        if (!file) {
          throw new Error('Tidak dapat menemukan file input pada halaman')
        }
        
        const formDataThen = new FormData()
        formDataThen.append('file', file)
        formDataThen.append('convert', "Convert WebP to MP4!")
        
        const { data: secondPage } = await axios({
          method: 'post',
          url: `https://ezgif.com/webp-to-mp4/${file}`,
          data: formDataThen,
          headers: {
            'Content-Type': `multipart/form-data; boundary=${formDataThen._boundary}`
          }
        })
        
        const $$ = cheerio.load(secondPage)
        
        // Coba beberapa selector alternatif
        let videoSrc = $$('div#output video source').attr('src')
        if (!videoSrc) videoSrc = $$('#output video source').attr('src')
        if (!videoSrc) videoSrc = $$('video source').attr('src')
        if (!videoSrc) videoSrc = $$('.outfile video source').attr('src')
        
        if (!videoSrc) {
          // Coba cari link download langsung
          const downloadLink = $$('a#download').attr('href')
          if (downloadLink) {
            videoSrc = downloadLink
          } else {
            throw new Error('Tidak dapat menemukan URL video hasil konversi')
          }
        }
        
        // Pastikan URL lengkap
        let resultUrl = videoSrc
        if (videoSrc.startsWith('//')) {
          resultUrl = 'https:' + videoSrc
        } else if (!videoSrc.startsWith('http')) {
          resultUrl = 'https://ezgif.com' + (videoSrc.startsWith('/') ? videoSrc : '/' + videoSrc)
        }
        
        resolve({
          status: true,
          message: "Xeorz",
          result: resultUrl
        })
        
      } catch (err) {
        reject(err)
      }
    })
  }

  if (!quoted) return reply('⚠️ Balas ke stiker untuk dikonversi.')
  
  const mime = (quoted.msg || quoted).mimetype || ''
  if (!/webp/i.test(mime)) return reply(`⚠️ Format tidak didukung. Gunakan perintah *${prefix + command}* pada stiker.`)

  reply('await be processed')

  let media = null
  try {
    media = await satanic.downloadAndSaveMediaMessage(quoted)
    if (!media || !fs.existsSync(media)) {
      throw new Error('Gagal mendownload media')
    }
    
    const webpToMp4 = await webp2mp4File(media)
    
    if (!webpToMp4 || !webpToMp4.result) {
      throw new Error('Hasil konversi kosong')
    }
    
    await satanic.sendMessage(m.chat, {
      video: { url: webpToMp4.result },
      caption: '✅ Berhasil dikonversi dari stiker ke video.',
      gifPlayback: false // Set true jika ingin jadi GIF
    }, { quoted: m })
    
  } catch (err) {
    console.error('tomp4 error:', err.message || err)
    reply(`❌ Terjadi kesalahan: ${err.message || 'Gagal mengonversi stiker ke video.'}`)
  } finally {
    if (media && fs.existsSync(media)) {
      try {
        await fs.unlinkSync(media)
      } catch (e) {
        console.error('Gagal hapus file:', e)
      }
    }
  }
}
break
case 'text2img':
case 'generate': {
    if (!text) return reply('Masukkan deskripsi gambar!\n\nContoh: .text2img kucing lucu');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://free-restapi.biz.id/api/text2img?text=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
    
    await satanic.sendMessage(m.chat, { 
        image: response.data,
        caption: `🎨 *TEXT TO IMAGE*\n\nPrompt: ${text}`
    }, { quoted: m });
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'texttoimg':
case 'generate': {
    if (!text) return reply('Masukkan deskripsi gambar!\n\nContoh: .texttoimg kucing lucu');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://free-restapi.biz.id/api/texttoimg?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
    
    await satanic.sendMessage(m.chat, { 
        image: response.data,
        caption: `🎨 *TEXT TO IMAGE*\n\nPrompt: ${text}`
    }, { quoted: m });
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'flux':
case 'fluxschnell':
case 'flux-img': {
    if (!text) return reply('Masukkan deskripsi gambar!\n\nContoh: .flux kucing lucu');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://free-restapi.biz.id/api/flux-img?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
    
    await satanic.sendMessage(m.chat, { 
        image: response.data,
        caption: `🎨 *FLUX SCHNELL*\n\nPrompt: ${text}`
    }, { quoted: m });
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
  case 'togif': {
  async function webp2GifFile(path) {
    return new Promise(async (resolve, reject) => {
      try {
        const form = new FormData()
        form.append('new-image-url', '')
        form.append('new-image', fs.createReadStream(path))
        
        const { data: firstPage } = await axios({
          method: 'post',
          url: 'https://ezgif.com/webp-to-mp4',
          data: form,
          headers: {
            'Content-Type': `multipart/form-data; boundary=${form._boundary}`
          }
        })
        const $ = cheerio.load(firstPage)
        const file = $('input[name="file"]').attr('value')
        if (!file) {
          throw new Error('Tidak dapat menemukan file input pada halaman')
        }
        const formDataThen = new FormData()
        formDataThen.append('file', file)
        formDataThen.append('convert', "Convert WebP to MP4!")
        
        const { data: secondPage } = await axios({
          method: 'post',
          url: `https://ezgif.com/webp-to-mp4/${file}`,
          data: formDataThen,
          headers: {
            'Content-Type': `multipart/form-data; boundary=${formDataThen._boundary}`
          }
        })
        const $$ = cheerio.load(secondPage)
        let videoSrc = $$('div#output video source').attr('src')
        if (!videoSrc) videoSrc = $$('#output video source').attr('src')
        if (!videoSrc) videoSrc = $$('video source').attr('src')
        if (!videoSrc) videoSrc = $$('.outfile video source').attr('src')
        if (!videoSrc) {
          const downloadLink = $$('a#download').attr('href')
          if (downloadLink) {
            videoSrc = downloadLink
          } else {
            throw new Error('Tidak dapat menemukan URL video hasil konversi')
          }
        }
        let resultUrl = videoSrc
        if (videoSrc.startsWith('//')) {
          resultUrl = 'https:' + videoSrc
        } else if (!videoSrc.startsWith('http')) {
          resultUrl = 'https://ezgif.com' + (videoSrc.startsWith('/') ? videoSrc : '/' + videoSrc)
        }
        resolve({
          status: true,
          message: "SATANIC HAXOR (NEWCODING)",
          result: resultUrl
        })
        
      } catch (err) {
        reject(err)
      }
    })
  }

  if (!quoted) return reply('⚠️ Balas ke stiker untuk dikonversi ke GIF.')
  
  const mime = (quoted.msg || quoted).mimetype || ''
  if (!/webp/i.test(mime)) return reply(`⚠️ Format tidak didukung. Gunakan perintah *${prefix + command}* pada stiker.`)

  reply('wait be processed')

  let media = null
  try {
    media = await satanic.downloadAndSaveMediaMessage(quoted)
    if (!media || !fs.existsSync(media)) {
      throw new Error('Gagal mendownload media')
    }
    
    const webpToGif = await webp2GifFile(media)
    
    if (!webpToGif || !webpToGif.result) {
      throw new Error('Hasil konversi kosong')
    }
    
    await satanic.sendMessage(m.chat, {
      video: { url: webpToGif.result },
      caption: '✅ Berhasil dikonversi dari stiker ke GIF.',
      gifPlayback: true  // true = tampil sebagai GIF (loop, tanpa suara)
    }, { quoted: m })
    
  } catch (err) {
    console.error('togif error:', err.message || err)
    reply(`❌ Terjadi kesalahan: ${err.message || 'Gagal mengonversi stiker ke GIF.'}`)
  } finally {
    if (media && fs.existsSync(media)) {
      try {
        await fs.unlinkSync(media)
      } catch (e) {
        console.error('Gagal hapus file:', e)
      }
    }
  }
}
break
 case 'toimg': {
				if (!quoted) return reply('Reply Image')
				if (!/webp/.test(mime)) return reply(`Reply sticker dengan caption *${prefix + command}*`)
				let media = await satanic.downloadAndSaveMediaMessage(quoted)
				let ran = await getRandom('.png')
				exec(`ffmpeg -i ${media} ${ran}`, (err) => {
					fs.unlinkSync(media)
					if (err) throw err
					let buffer = fs.readFileSync(ran)
					satanic.sendMessage(m.chat, { image: buffer }, { quoted: m })
					fs.unlinkSync(ran)
				})
			}		
			break;		 
case 'toptv': {		
				let q = m.quoted ? m.quoted : m;
				if (!/video|audio/.test(mime)) return reply(`Hmm, Kamu harus balas video atau voice note yang mau dijadikan MP3 ya, jangan lupa pakai caption *${prefix + command}* 😉`);
				try {
					let media = await q.download();
					let dataVideo = {
						ptvMessage: m.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage
					};
					satanic.relayMessage(m.chat, dataVideo, {});
				} catch (error) {
					console.log(error);
					reply("Aduh, ada yang salah nih kak 😟. Coba lagi ya!");
				}
			}
			
			break
case 'toaud': case 'tomp3': case 'toaudio': {
            if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Send/Reply Video/Audio You Want to Use as Audio With Caption ${prefix + command}`)
            if (!quoted) return reply(`Send/Reply Video/Audio You Want to Use as Audio With Caption ${prefix + command}`)
            reply(mess.wait)
            let media = await quoted.download()
            let { toAudio } = require('./lib/converter')
            let audio = await toAudio(media, 'mp4')
            satanic.sendMessage(m.chat, {audio: audio, mimetype: 'audio/mpeg'}, { quoted : m })
            }
break
            case 'tovn': case 'toptt': {
            if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Reply Video/Audio That You Want To Be VN With Caption ${prefix + command}`)
            if (!quoted) return reply(`Reply Video/Audio That You Want To Be VN With Caption ${prefix + command}`)
            reply(mess.wait)
            let media = await quoted.download()
            let { toPTT } = require('./lib/converter')
            let audio = await toPTT(media, 'mp4')
            satanic.sendMessage(m.chat, {audio: audio, mimetype:'audio/mpeg', ptt:true }, {quoted:m})
            }
            break
  case 's': case 'sticker': case 'stiker': {
				if (!quoted) return reply(`Kirim atau balas gambar/video/gif dengan caption ${prefix + command}\nDurasi video 1-9 detik ya!`);
				if (!mime) return reply(`Kirim atau balas gambar/video/gif dengan caption ${prefix + command}\nDurasi video 1-9 detik ya!`);
				if (/image/.test(mime)) {
					
					let media = await satanic.downloadAndSaveMediaMessage(quoted);
					await satanic.sendImageAsSticker(m.chat, media, m, { packname: global.packname, author: global.author });
				} else if (/video/.test(mime)) {
					if ((quoted.msg || quoted).seconds > 9) return reply(`Durasi video terlalu panjang! 🕒 Kirim video dengan durasi 1-9 detik ya!`);

					let media = await satanic.downloadAndSaveMediaMessage(quoted);
					await satanic.sendVideoAsSticker(m.chat, media, m, { packname: global.packname, author: global.author });
				} else {
					reply(`Kirim atau balas gambar/video/gif dengan caption ${prefix + command}\nDurasi video 1-9 detik ya!`);
				}
			}		
			break;
case 'swm': case 'steal': case 'stickerwm': case 'take': {
    if (!quoted) return reply(`Kirim atau balas gambar/video/gif dengan caption ${prefix + command}\nDurasi video 1-9 detik ya!`);
    if (!mime) return reply(`Kirim atau balas gambar/video/gif dengan caption ${prefix + command}\nDurasi video 1-9 detik ya!`);
    
    // Ambil text dari pesan utama, bukan args
    const fullText = m.body || "";
    // Hapus prefix dan command dari text
    const textAfterCommand = fullText.replace(new RegExp(`^${prefix}${command}\\s*`), "").trim();
    
    // Split berdasarkan pipe (|)
    const swn = textAfterCommand || "";
    const pcknm = swn.split("|")[0]?.trim() || "";
    const atnm = swn.split("|")[1]?.trim() || "";
    
    // Default values jika tidak ada input
    const packName = pcknm || "Sticker";
    const authorName = atnm || "Bot";
    
    if (m.quoted.isAnimated === true) {
        let media = await satanic.downloadAndSaveMediaMessage(quoted);
        satanic.sendMessage(m.chat, { 
            sticker: media 
        }, m, { 
            packname: packName, 
            author: authorName 
        });
    } else if (/image/.test(mime)) {
        let media = await satanic.downloadAndSaveMediaMessage(quoted);
        await satanic.sendImageAsSticker(m.chat, media, m, { 
            packname: packName, 
            author: authorName 
        });
    } else if (/video/.test(mime)) {
        if ((quoted.msg || quoted).seconds > 9) return reply('Video terlalu panjang, maksimal 9 detik ya! ⏳');
        let media = await satanic.downloadAndSaveMediaMessage(quoted);
        await satanic.sendVideoAsSticker(m.chat, media, m, { 
            packname: packName, 
            author: authorName 
        });
    } else {
        reply(`Kirim foto/video untuk dipakai ya, kak!`);
    }
    break;
}			           
case 'statusgrup':
case 'statusgroup': {
    if (!isCreator) return 
    
    const { fromBuffer } = require("file-type");
    const fs = require("fs");
    const path = require("path");

    let content = {};
    let buffer, ext, tempFile;

    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    if (m.quoted) {
        try {
            buffer = await m.quoted.download();
            if (!buffer) return reply("❌ Gagal mengambil media quoted.");
            
            const fileTypeRes = await fromBuffer(buffer);
            ext = fileTypeRes ? fileTypeRes.ext : 'bin';
            tempFile = path.join(__dirname, `tmp_${Date.now()}.${ext}`);
            fs.writeFileSync(tempFile, buffer);

            const quotedType = m.quoted.mtype || Object.keys(m.quoted.message || {})[0] || '';
            if (/image|video|audio/.test(quotedType)) {
                if (/image/.test(quotedType)) {
                    content.image = { url: tempFile };
                    if (text) content.caption = text;
                } else if (/video/.test(quotedType)) {
                    content.video = { url: tempFile };
                    if (text) content.caption = text;
                } else if (/audio/.test(quotedType)) {
                    if (text) {
                        fs.unlinkSync(tempFile);
                        return reply("Audio tidak boleh disertai caption.");
                    }
                    content.audio = { url: tempFile };
                    content.ptt = false;
                }
            } else {
                fs.unlinkSync(tempFile);
                return reply("Reply harus berupa image/video/audio.");
            }
        } catch (e) {
            return reply("❌ Media tidak valid atau gagal diproses.");
        }
    } else if (text) {
        content.text = text;
    } else {
        return reply("Kirim media (foto/video/audio) atau teks, bisa dengan reply atau langsung.");
    }

    if (content.text && !content.text.trim()) return reply("Teks tidak boleh kosong.");

    let getGroups = await satanic.groupFetchAllParticipating();
    let groups = Object.values(getGroups);

    let validGroups = [];
    
    validGroups.push({
        title: "All Group",
        description: `Kirim ke ${groups.length} grup`,
        id: `.sendstatus all ${encodeURIComponent(JSON.stringify(content))}`
    });

    for (let group of groups) {
        validGroups.push({
            title: group.subject || "Group",
            description: group.id,
            id: `.sendstatus ${group.id} ${encodeURIComponent(JSON.stringify(content))}`
        });
    }

    if (validGroups.length <= 1) {
        if (tempFile && fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
        return reply("Tidak ada grup valid yang bisa dipilih.");
    }

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: {
                    body: { text: "```Pilih Grup Tujuan ♨️```" },
                    nativeFlowMessage: {
                        buttons: [{
                            name: "single_select",
                            buttonParamsJson: JSON.stringify({
                                title: "PILIH GRUP",
                                sections: [{ title: "Daftar Grup", rows: validGroups }]
                            })
                        }]
                    }
                }
            }
        }
    }, { quoted: m });

    await satanic.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;

case 'sendstatus': {
    if (!isCreator) return 
    const fs = require("fs");
    const crypto = require("crypto");

    const [groupId, ...contentARR] = args;
    const contentDecoded = JSON.parse(decodeURIComponent(contentARR.join(' ')));

    async function groupStatus(jid, contentObj) {
        let content = { ...contentObj };
        const { backgroundColor } = content;
        delete content.backgroundColor;
        
        const inside = await generateWAMessageContent(content, {
            upload: satanic.waUploadToServer,
            backgroundColor
        });
        
        const messageSecret = crypto.randomBytes(32);
        const mStatus = generateWAMessageFromContent(jid, {
            messageContextInfo: {
                messageSecret
            },
            groupStatusMessageV2: {
                message: {
                    ...inside,
                    messageContextInfo: {
                        messageSecret
                    }
                }
            }
        }, {});
        
        await satanic.relayMessage(jid, mStatus.message, {
            messageId: mStatus.key.id
        });
        return mStatus;
    }

    let getGroups = await satanic.groupFetchAllParticipating();
    let groups = Object.values(getGroups).map(v => v.id);

    let success = 0;
    let failed = 0;

    if (groupId === 'all') {
        for (let gid of groups) {
            try {
                await groupStatus(gid, contentDecoded);
                success++;
                await sleep(2000); 
            } catch (e) {
                failed++;
            }
        }
        reply(`✅ Berhasil ${success} group\n❌ Gagal: ${failed} group`);
    } else {
        try {
            await groupStatus(groupId, contentDecoded);
            reply(`✅ Berhasil dikirim ke grup`);
        } catch (e) {
            reply(`❌ Gagal mengirim ke grup yang dituju`);
        }
    }

    try {
        if (contentDecoded?.image?.url && fs.existsSync(contentDecoded.image.url)) fs.unlinkSync(contentDecoded.image.url);
        if (contentDecoded?.video?.url && fs.existsSync(contentDecoded.video.url)) fs.unlinkSync(contentDecoded.video.url);
        if (contentDecoded?.audio?.url && fs.existsSync(contentDecoded.audio.url)) fs.unlinkSync(contentDecoded.audio.url);
    } catch (e) {}

    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'upswgc':          
 case "swgroup":
case "swgc": {
if (!m.isGroup) return reply(mess.group);
  if (!isAdmins && !isCreator) return reply(mess.admin);

    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || "";

    const body = m.body || "";
    const caption = body
        .replace(new RegExp(`^\\${prefix}${command}\\s*`, "i"), "")
        .trim();

    const jid = m.chat;

    if (/image/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(jid, {
            groupStatusMessage: {
                image: buffer,
                caption
            }
        });
        satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key }})

    } else if (/video/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(jid, {
            groupStatusMessage: {
                video: buffer,
                caption
            }
        });
        satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key }})

    } else if (/audio/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(jid, {
            groupStatusMessage: {
                audio: buffer
            }
        });
        satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key }})

    } else if (caption) {
        await satanic.sendMessage(jid, {
            groupStatusMessage: {
                text: caption
            }
        });
        satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key }})

    } else {
        await reply(
            `Contoh penggunaan:\n` +
            `${prefix + command} halo gais\n` +
            `atau reply media dengan caption`
        );
    }
}
break;
case 'upch':
case 'upstatuschannel':
case 'upchannel': {
    if (!text) return reply('Masukkan ID Channel dan pesan!\n\nContoh: .upchannel 120363422340494910@newsletter halo guys dan bisa juga reply media seperti audio video gambar lalu masukin text atau biarkan saja, jangan lupa masukin input ch nya');
    const parts = text.split(' ');
    const channelId = parts[0];
    const captionText = parts.slice(1).join(' ');
    if (!channelId.includes('@newsletter') && !channelId.includes('@g.us') && !channelId.includes('@broadcast')) {
        return reply('ID Channel harus berakhiran @newsletter, @g.us, atau @broadcast');
    }
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || "";
    if (/image/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(channelId, { image: buffer, caption: captionText });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } else if (/video/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(channelId, { video: buffer, caption: captionText });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } else if (/audio/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(channelId, { audio: buffer, mimetype: 'audio/mpeg' });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } else if (captionText) {
        await satanic.sendMessage(channelId, { text: captionText });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } else {
        reply('Masukkan pesan atau reply media!');
    }
}
break;

case 'delcase': {
if (!isCreator) return
  if (!text) return reply('Mana nama case-nya?');
  const namaFile = 'satanic.js';
  fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) return reply('Gagal membaca file');
    const regex = new RegExp(`case\\s+'${text}'[\\s\\S]*?break`, 'i');
    if (!regex.test(data)) return reply('Case tidak ditemukan');
    const fileBaru = data.replace(regex, '');
    fs.writeFile(namaFile, fileBaru, 'utf8', (err) => {
      if (err) return reply('Gagal menulis file');
      reply(`Case ${text} berhasil dihapus`);
    });
  });
}
break
/////////// GEOUP MENU/////////
case 'promote':
case 'pm': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
if (!m.mentionedJid[0] && !m.quoted && !text) return reply(`Hmm... Kamu mau ${command} siapa? 🤔`)
await satanic.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => reply(mess.done)).catch((err) => reply(mess.error))
}
break
case 'demote':
case 'dm': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
if (!m.mentionedJid[0] && !m.quoted && !text) return reply(`Hmm... Kamu mau ${command} siapa? 🤔`)
await satanic.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => reply(mess.done)).catch((err) => reply(mess.error))
}
break
case 'opentime': {
if (!m.isGroup) return reply('only group')
if (!isAdmins && !isCreator) return reply('Khusus Admin!!')
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
reply(`Open Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const open = `*On time* Group Opened By Admin\n Now Members Can Send Messages`
satanic.groupSettingUpdate(from, 'not_announcement')
reply(open)
}, timer)
}
break
case 'closetime': {
if (!m.isGroup) return reply('only group')
if (!isAdmins && !isCreator) return reply('Khusus Admin!!')

if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
reply(`Close Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const close = `*On time* Group Closed By Admin\nNow Only Admins Can Send Messages`
satanic.groupSettingUpdate(from, 'announcement')
reply(close)
}, timer)
}
break
case 'kick': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await satanic.groupParticipantsUpdate(m.chat, [users], 'remove')
await reply(`Done`)
}
break
case 'kickme': {
  if (!m.isGroup) return reply(mess.group);
  let sender = m.sender;  
  await satanic.groupParticipantsUpdate(m.chat, [sender], 'remove');
  reply(`Anda telah keluar dari grup ini.`);
}
break;
case 'add': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await satanic.groupParticipantsUpdate(m.chat, [users], 'add')
await reply(`Done`)
}
break
case "get": case ".g": {
  if (m.key.fromMe) return
  if (!text) return reply("https://example.com");
  try {
    const url = text.trim();
    if (!isUrl(url)) return reply("Link tidak valid.");

    await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    const res = await axios.get(url, {
      responseType: "arraybuffer",
      validateStatus: () => true
    });

    const headers = res.headers || {};
    const contentType = (headers["content-type"] || "").split(";")[0].toLowerCase();
    const contentDisp = headers["content-disposition"] || "";

    let filename = "download";
    try {
      const u = new URL(url);
      const last = decodeURIComponent(u.pathname.split("/").filter(Boolean).pop() || "");
      if (last) filename = last;
    } catch {}
    const cdMatch = contentDisp.match(/filename\*?=(?:UTF-8'')?"?([^";]+)/i);
    if (cdMatch) filename = decodeURIComponent(cdMatch[1].replace(/"/g, ""));
    if (!/\.[a-z0-9]{2,}$/i.test(filename) && contentType) {
      const ctExt = contentType.includes("/") ? contentType.split("/")[1] : "bin";
      const safeExt = (ctExt || "bin").replace(/[^a-z0-9]/gi, "");
      filename = `${filename}.${safeExt || "bin"}`;
    }

    const buf = Buffer.from(res.data);
    const fileSizeMB = buf.length / (1024 * 1024);

    const sendAs = async (kind, extra = {}) => {
      return satanic.sendMessage(
        m.chat,
        { [kind]: buf, mimetype: contentType || "application/octet-stream", fileName: filename, ...extra },
        { quoted: m }
      );
    };

    if (contentType.startsWith("image/")) {
      await sendAs("image", { caption: filename });
    } else if (contentType.startsWith("video/")) {
      if (fileSizeMB > 100) {
        await sendAs("document");
      } else {
        await sendAs("video");
      }
    } else if (contentType.startsWith("audio/")) {
      await sendAs("audio");
    } else if (
      contentType === "application/octet-stream" ||
      (contentType.startsWith("application/") && !contentType.includes("json"))
    ) {
      await sendAs("document");
    } else if (
      contentType.startsWith("text/") ||
      contentType.includes("json") ||
      contentType === ""
    ) {
      let body;
      try {
        body = buf.toString("utf8");
      } catch {
        body = "(Tidak dapat mendekode konten teks)";
      }
      await m.reply(body);
    } else {
      await sendAs("document");
    }

    await satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (e) {
    console.error("GET error:", e);
    await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
  }
}
break;
case 'xnxxsearch': {
if (!isPrem) return reply('you are not premium')
    if (!text) return reply(`Enter Query`);
    const apiUrlxnxx = `https://free-restapi.biz.id/api/xnxxsearch?query=${encodeURIComponent(text)}&apikey=satanic16`;
    const resxnx = await axios.get(apiUrlxnxx);
    const results = resxnx.data?.result?.result;
    if (!results || !Array.isArray(results) || results.length === 0) {
        return reply(`No results found for: ${text}`);
    }
    let ffxnx = results.map((v, i) => 
        `${i + 1}┃ *Title:* ${v.title}\n*Link:* ${v.link}\n*Info:* ${v.info.trim()}`
    ).join('\n\n');
    reply(ffxnx);
}
break;
case 'xvideosearch': {
if (!isPrem) return reply('you are not premium')
    if (!text) return reply(`Enter Query`);
    const apiUrlxvideos = `https://free-restapi.biz.id/api/xvideosearch?query=${encodeURIComponent(text)}&apikey=satanic16`;
    const resxvids = await axios.get(apiUrlxvideos);
    
    // Response langsung berupa array di result
    const results = resxvids.data?.result;
    
    if (!results || !Array.isArray(results) || results.length === 0) {
        return reply(`No results found for: ${text}`);
    }
    
    let ffxvids = results.map((v, i) => 
        `${i + 1}┃ *Title:* ${v.title}\n*Duration:* ${v.duration}\n*Link:* ${v.url}\n*Quality:* ${v.quality || '-'}`
    ).join('\n\n');
    
    reply(ffxvids);
}
break;  
case 'xnxxdl': {
if (!isPrem) return reply('you are not premium')
    if (!text) return reply(`Enter URL`);
    
    const apiUrldl = `https://free-restapi.biz.id/api/xnxxdl?url=${encodeURIComponent(text)}&apikey=satanic16`;
    const resdl = await axios.get(apiUrldl);
    
    const data = resdl.data?.result?.result;
    
    if (!data) {
        return reply(`Failed to get download link`);
    }
    

    const videoUrl = data.files?.high || data.files?.low || data.files?.HLS;
    
    if (!videoUrl) {
        return reply(`No video URL found`);
    }
    
    let msg = `*Title:* ${data.title}\n`;
    msg += `*Duration:* ${Math.floor(data.duration / 60)}min ${data.duration % 60}detik\n`;
    msg += `*Info:* ${(data.info || '').trim()}\n\n`;
    msg += `*Download Links:*\n`;
    msg += `📱 Low (240p): ${data.files?.low || '-'}\n`;
    msg += `🎥 High (360p): ${data.files?.high || '-'}\n`;
    msg += `📺 HLS: ${data.files?.HLS || '-'}`;
    
    // Kirim video
    await satanic.sendMessage(m.chat, { 
        video: { url: videoUrl }, 
        caption: msg 
    }, { quoted: m });
}
break;
case 'xvideodl': {
if (!isPrem) return reply('you are not premium')
    if (!text) return reply(`Enter URL`);
    
    const apiUrldl = `https://free-restapi.biz.id/api/xvideodl?url=${encodeURIComponent(text)}&apikey=satanic16`;
    const resdl = await axios.get(apiUrldl);
    
    const data = resdl.data?.result?.result;
    
    if (!data) {
        return reply(`Failed to get download link`);
    }
    
    let msg = `*Title:* ${data.title}\n`;
    msg += `*Tags:* ${data.keyword}`;
       
    await satanic.sendMessage(m.chat, { 
        video: { url: data.url }, 
        caption: msg 
    }, { quoted: m });
}
break;
 case 'liston':
case 'listonline': {
    try {
        let id = (args && args.length > 0 && /\d+\-\d+@g.us/.test(args[0])) ? args[0] : m.chat
        if (!id.endsWith('@g.us')) {
            return reply('❌ Fitur ini hanya bisa digunakan di group!');
        }
        if (!store || !store.presences || !store.presences[id]) {
            return reply('⚠️ Tidak ada data online untuk group ini.\nCoba refresh atau tunggu beberapa saat.');
        }
        const presenceData = store.presences[id];
        if (typeof presenceData !== 'object' || presenceData === null) {
            return reply('❌ Data online tidak valid untuk group ini.');
        }
        let onlineUsers = Object.keys(presenceData);
        if (!onlineUsers || onlineUsers.length === 0) {
            return reply('📭 Tidak ada user yang sedang online di group ini.');
        }
if (botNumber && !onlineUsers.includes(botNumber)) {
onlineUsers.push(botNumber);
        }
        const onlineList = onlineUsers
            .filter(user => user && typeof user === 'string')
            .map(user => {
                const number = user.split('@')[0] || user;
                return `⭔ @${number}`;
            })
            .join('\n');
 const messageText = `📱 *List Online*\n\n${onlineList}\n\n*Total:* ${onlineUsers.length} user`;
 await satanic.sendMessage(m.chat, { text: messageText, mentions: onlineUsers.filter(user => user && typeof user === 'string')}, { quoted: m });
 } catch (error) {
 console.error('Error in listonline command:', error);
 reply('❌ Terjadi kesalahan saat mengambil daftar online.\n' + error.message);
    }
}
break
case 'setppbot': case 'setppbot2':{
if (!isCreator) return reply(mess.owner)
const { S_WHATSAPP_NET } = require('@whiskeysockets/baileys');

	async function generateProfilePicture(media) {
    const image = await jimp.read(media);
    const min = image.getWidth();
    const max = image.getHeight();
    const cropped = image.crop(0, 0, min, max);
    return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp.MIME_JPEG),
        preview: await cropped.normalize().getBufferAsync(jimp.MIME_JPEG)
    };
}
if (!quoted) return reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)

let media = await satanic.downloadAndSaveMediaMessage(quoted);
const { img } = await generateProfilePicture(media);
await satanic.query({
	tag: 'iq',
	attrs: {
	    target: undefined,
        to: S_WHATSAPP_NET,
		type:'set',
		xmlns: 'w:profile:picture'
	},
	content: [
		{
			tag: 'picture',
			attrs: { type: 'image' },
			content: img
		} 
	]
})
reply(mess.done);
}
break
case 'jpm':
case 'broadcast': {
  if (!isCreator) return reply(mess.owner);
  
  const quoted = m.quoted ? m.quoted : m;
  const mime = (quoted.msg || quoted).mimetype || "";
  
  let body = m.body || "";
  let text = body.replace(new RegExp(`^\\${prefix}${command}\\s*`, "i"), "").trim();
  
  let groups = Object.values(await satanic.groupFetchAllParticipating());
  
  if (/image/.test(mime)) {
    const buffer = await quoted.download();
    reply(`📡 Mengirim broadcast GAMBAR ke ${groups.length} grup...`);
    
    let success = 0;
    for (let group of groups) {
      try {
        await satanic.sendMessage(group.id, {
          image: buffer,
          caption: `「 *BROADCAST* 」\n\n${text}`
        });
        success++;
        await sleep(800);
      } catch {}
    }
    
    reply(`✅ ${success}/${groups.length} grup berhasil diterima`);
    
  } else if (/video/.test(mime)) {
    const buffer = await quoted.download();
    reply(`📡 Mengirim broadcast VIDEO ke ${groups.length} grup...`);
    
    let success = 0;
    for (let group of groups) {
      try {
        await satanic.sendMessage(group.id, {
          video: buffer,
          caption: `「 *BROADCAST* 」\n\n${text}`
        });
        success++;
        await sleep(800);
      } catch {}
    }
    
    reply(`✅ ${success}/${groups.length} grup berhasil diterima`);
    
  } else if (/audio/.test(mime)) {
    const buffer = await quoted.download();
    reply(`📡 Mengirim broadcast AUDIO ke ${groups.length} grup...`);
    
    let success = 0;
    for (let group of groups) {
      try {
        await satanic.sendMessage(group.id, {
          audio: buffer
        });
        success++;
        await sleep(800);
      } catch {}
    }
    
    reply(`✅ ${success}/${groups.length} grup berhasil diterima`);
    
  } else if (text) {
    reply(`📡 Mengirim broadcast TEKS ke ${groups.length} grup...\n\n📝 Pesan: ${text.substring(0, 50)}${text.length > 50 ? '...' : ''}`);
    
    let success = 0;
    for (let group of groups) {
      try {
        await satanic.sendMessage(group.id, {
          text: `「 *BROADCAST* 」\n\n${text}`
        });
        success++;
        await sleep(800);
      } catch {}
    }
    
    reply(`✅ ${success}/${groups.length} grup berhasil diterima`);
    
  } else {
    reply(`📢 *BROADCAST (JPM)*\n━━━━━━━━━━━━━━━━\n📌 Mengirim pesan ke semua grup\n\nContoh:\n${prefix + command} Halo semua!\n\nAtau reply media (gambar/video/audio) dengan caption`);
  }
}
break;
case 'setppgc': case 'setppgroup':{
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)
const { S_WHATSAPP_NET } = require('@whiskeysockets/baileys');
	async function generateProfilePicture(media) {
    const image = await jimp.read(media);
    const min = image.getWidth();
    const max = image.getHeight();
    const cropped = image.crop(0, 0, min, max);
    return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp.MIME_JPEG),
        preview: await cropped.normalize().getBufferAsync(jimp.MIME_JPEG)
    };
}
if (!quoted) return reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)

				let media = await satanic.downloadAndSaveMediaMessage(quoted);
				const group = m.chat;
				const { img } = await generateProfilePicture(media);
				await satanic.query({
					tag: 'iq',
					attrs: {					
                        target: group,
                        to: S_WHATSAPP_NET,
						type:'set',
						xmlns: 'w:profile:picture'
					},
					content: [
						{
							tag: 'picture',
							attrs: { type: 'image' },
							content: img
						} 
					]
				})
				reply(mess.done);
			}
			break
case "reactch": { 
if (!text) return reply(`${prefix} < ch url > 😂😂😂😂\n`);
  const match = text.match(/https:\/\/whatsapp\.com\/channel\/(\w+)(?:\/(\d+))?/);
  if (!match) return reply("URL tidak valid. Silakan periksa kembali.");
const channelId = match[1];
const chatId = match[2];
if (!chatId) return reply("ID chat tidak ditemukan dalam link yang diberikan.");
 satanic.newsletterMetadata("invite", channelId).then(data => {
 if (!data) return reply("Newsletter tidak ditemukan atau terjadi kesalahan.");
 satanic.newsletterReactMessage(data.id, chatId, text.split(" ").slice(1).join(" ") || "😀");
 });
reply(`sukses mengirimkan custom reaction ke channel tersebut`)
}
break;		
case 'easemate':
case 'chatimage': {
    if (!isCreator) return reply("❌ Khusus owner!");
    
    const crypto = require('crypto');
    const FormData = require('form-data');
    
    // ========== CLASS EaseMate DENGAN TOKEN OTOMATIS ==========
    class EaseMate {
        constructor() {
            this.API_URL_BASE = "https://api.easemate.ai/api2";
            this.AUTH_URL_BASE = "https://www.easemate.ai/lh-account-api";
            this.DEVICE_UUID = this._generateUUID();
            this.LOCATION_HOST = "www.easemate.ai";
            this.BROWSER_PLATFORM = "Android,Chrome";
            this.LANG = "en";
            this.LANGUAGE = "en-US";
            this.MODEL_ID = 3;
            this.token = null;
        }
        
        _generateUUID() {
            return crypto.randomBytes(16).toString('hex');
        }
        
        _md5(data) {
            return crypto.createHash('md5').update(data).digest('hex');
        }
        
        _getTimestamp() {
            return Math.floor(Date.now() / 1000);
        }
        
        _jsonParse(e) {
            try {
                return JSON.parse(e);
            } catch (err) {
                return null;
            }
        }
        
        _sortParams(obj) {
            if (typeof obj !== 'object' || obj === null) return obj;
            if (Array.isArray(obj)) return obj.map(v => this._sortParams(v));
            
            const sorted = {};
            Object.keys(obj).sort().forEach(key => {
                sorted[key] = this._sortParams(obj[key]);
            });
            return sorted;
        }
        
        _buildQueryString(params) {
            const parts = [];
            for (const [key, value] of Object.entries(params)) {
                if (value === null || value === undefined) continue;
                if (typeof value === 'object') {
                    parts.push(this._buildQueryString(value));
                } else {
                    parts.push(`${key}=${value}`);
                }
            }
            return parts.join('&');
        }
        
        _getSigns(body) {
            const timestamp = this._getTimestamp();
            const appKey = "TB";
            const deviceId = this.DEVICE_UUID;
            
            let params = {};
            if (body && typeof body === 'object') {
                params = JSON.parse(JSON.stringify(body));
            }
            
            params.appKey = appKey;
            params.timestamp = timestamp;
            
            const sortedParams = this._sortParams(params);
            const queryString = this._buildQueryString(sortedParams);
            const signString = `${deviceId}${queryString}${deviceId}`;
            const sign = this._md5(signString);
            
            return { sign, timestamp: String(timestamp) };
        }
        
        // GENERATE TOKEN OTOMATIS
        async _generateToken() {
            console.log('🔄 Generating auto token...');
            
            const timestamp = this._getTimestamp();
            const deviceId = this.DEVICE_UUID;
            
            // Buat signature untuk generate token
            const signData = {
                device_id: deviceId,
                device_type: 'web',
                timestamp: timestamp,
                appKey: 'TB'
            };
            
            const sortedSign = this._sortParams(signData);
            const queryString = this._buildQueryString(sortedSign);
            const signString = `${deviceId}${queryString}${deviceId}`;
            const sign = this._md5(signString);
            
            // Kirim request ke endpoint login
            const loginPayload = {
                device_id: deviceId,
                device_type: 'web',
                timestamp: timestamp,
                sign: sign
            };
            
            try {
                const response = await fetch(`${this.AUTH_URL_BASE}/auth/device_login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                        'device-uuid': deviceId,
                        'timestamp': String(timestamp),
                        'sign': sign
                    },
                    body: JSON.stringify(loginPayload)
                });
                
                const data = await response.json();
                
                if (data.code === 200 && data.data?.token) {
                    this.token = data.data.token;
                    console.log('✅ Token generated:', this.token.substring(0, 30) + '...');
                    return this.token;
                } else {
                    // Fallback: buat token sendiri
                    console.log('⚠️ Using fallback token');
                    this.token = this._md5(deviceId + timestamp);
                    return this.token;
                }
            } catch (error) {
                console.log('❌ Token generation failed, using fallback');
                this.token = this._md5(deviceId + timestamp);
                return this.token;
            }
        }
        
        async _apiCall(path, method, body, isUpload = false, isStream = false, isAuth = false, token = null) {
            const baseUrl = isAuth ? this.AUTH_URL_BASE : this.API_URL_BASE;
            const url = isUpload ? path : `${baseUrl}${path}`;
            
            const headers = {
                "Accept": "application/json, text/plain, */*",
                "Accept-Language": "id-ID,id;q=0.9",
                "Connection": "keep-alive",
                "Origin": "https://www.easemate.ai",
                "Referer": "https://www.easemate.ai/",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36"
            };
            
            if (!isAuth && !isUpload) {
                const { sign, timestamp } = this._getSigns(body);
                headers['sign'] = sign;
                headers['timestamp'] = timestamp;
                headers['device-uuid'] = this.DEVICE_UUID;
                headers['device-identifier'] = this.DEVICE_UUID;
                headers['device-platform'] = this.BROWSER_PLATFORM;
                headers['device-type'] = 'web';
                headers['client-name'] = 'chatpdf';
                headers['client-type'] = 'web';
                headers['lang'] = this.LANG;
                headers['language'] = this.LANGUAGE;
                headers['site'] = this.LOCATION_HOST;
            }
            
            if (token) headers['Authorization'] = `Bearer ${token}`;
            if (isStream) headers['Accept'] = 'text/event-stream';
            
            let requestBody = null;
            if (body) {
                if (isUpload) {
                    requestBody = body;
                } else {
                    requestBody = JSON.stringify(body);
                    headers['Content-Type'] = 'application/json';
                }
            }
            
            const response = await fetch(url, { method, headers, body: requestBody });
            const responseText = await response.text();
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${responseText.substring(0, 200)}`);
            }
            
            if (isStream) {
                let result = '';
                const lines = responseText.split('\n');
                for (const line of lines) {
                    if (line.startsWith('data:')) {
                        try {
                            const json = JSON.parse(line.substring(5).trim());
                            if (json.data) {
                                const parsed = this._jsonParse(json.data);
                                if (parsed?.answer) result += parsed.answer;
                            }
                        } catch (e) {}
                    }
                }
                return result;
            }
            
            const data = JSON.parse(responseText);
            if (data.code && data.code !== 200 && data.code !== 0) {
                throw new Error(`API Error ${data.code}: ${data.message || 'Unknown'}`);
            }
            
            return data.data || data;
        }
        
        async chat({ imageUrl = null, prompt = "Describe this picture", ...rest }) {
            // Generate token otomatis jika belum ada
            if (!this.token) {
                await this._generateToken();
            }
            
            // Buat session
            const session = await this._apiCall("/task/create_pure_session", "POST", {
                model_id: this.MODEL_ID,
                ...rest
            }, false, false, false, this.token);
            
            const objectInfo = [];
            
            if (imageUrl) {
                const timestamp = Date.now();
                const s3Name = `${this._generateUUID()}_${timestamp}.jpg`;
                const s3Path = `pro/${this.DEVICE_UUID}/${s3Name}`;
                
                const uploadInfo = await this._apiCall("/task/query_upload_url", "POST", {
                    key: s3Path,
                    value: s3Name
                }, false, false, false, this.token);
                
                const imgRes = await fetch(imageUrl);
                const imgBuffer = await imgRes.arrayBuffer();
                
                await fetch(uploadInfo.upload_url, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'image/jpeg' },
                    body: imgBuffer
                });
                
                objectInfo.push({
                    img_info: {
                        s3_name: s3Name,
                        s3_url: uploadInfo.download_url,
                        size: imgBuffer.byteLength,
                        origin_name: "image.jpg"
                    }
                });
            }
            
            const result = await this._apiCall("/stream/exec_operation", "POST", {
                model_id: this.MODEL_ID,
                session_id: session.session_id,
                operation_info: {
                    operation: prompt,
                    id: 10000
                },
                object_info: objectInfo,
                ...rest
            }, false, true, false, this.token);
            
            return result;
        }
    }
    
    // Upload ke uguu.se
    async function uploadToUguu(buffer) {
        const form = new FormData();
        form.append('file', buffer, { filename: 'image.jpg' });
        
        const response = await fetch('https://uguu.se/upload.php', {
            method: 'POST',
            body: form
        });
        
        const text = await response.text();
        try {
            const json = JSON.parse(text);
            if (json.files?.[0]?.url) return json.files[0].url;
        } catch (e) {}
        
        throw new Error('Upload failed');
    }
    
    // Process command
    let q = m.quoted || m;
    let prompt = (q.text || m.text).replace(/^\.(easemate|chatimage)/i, '').trim();
    const isImage = q.msg?.mimetype?.startsWith('image/');
    
    if (!prompt && !isImage) {
        return reply(`⚠️ *Cara penggunaan:*\n• .chatimage *pertanyaan*\n• Reply gambar + .chatimage *pertanyaan*`);
    }
    
    if (!prompt && isImage) prompt = "Describe this image";
    
    let imageUrl = null;
    
    if (isImage) {
        if (q.msg.fileLength > 10 * 1024 * 1024) {
            return reply('❌ Maksimal 10MB');
        }
        
        reply('📤 Uploading image...');
        try {
            const buffer = await q.download();
            imageUrl = await uploadToUguu(buffer);
        } catch (err) {
            return reply(`❌ Upload gagal: ${err.message}`);
        }
    }
    
    reply(`🤖 *EaseMate AI Processing...*\n📝 Prompt: ${prompt.substring(0, 50)}${prompt.length > 50 ? '...' : ''}\n⏳ Mohon tunggu 30-60 detik`);
    
    try {
        const ease = new EaseMate();
        const result = await ease.chat({ imageUrl, prompt });
        
        if (result && result.length > 0) {
            const maxLen = 4000;
            const text = result.length > maxLen ? result.substring(0, maxLen) + '\n\n... (truncated)' : result;
            await satanic.sendMessage(m.chat, { 
                text: `✨ *EaseMate AI Response:*\n\n${text}` 
            }, { quoted: m });
        } else {
            reply('❌ Tidak ada respons dari AI');
        }
    } catch (err) {
        console.error('Error:', err);
        reply(`❌ Error: ${err.message || err}`);
    }
}
break;
 case "rvo": case "readviewonce": {
if (!m.quoted) return reply("reply pesan viewOnce nya!")
let msg = m?.quoted?.message?.imageMessage || m?.quoted?.message?.videoMessage || m?.quoted?.message?.audioMessage || m?.quoted
if (!msg.viewOnce && m.quoted.mtype !== "viewOnceMessageV2" && !msg.viewOnce) return reply("Pesan itu bukan viewonce!")
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
let media = await downloadContentFromMessage(msg, msg.mimetype == 'image/jpeg' ? 'image' : msg.mimetype == 'video/mp4' ? 'video' : 'audio')
    let type = msg.mimetype
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return satanic.sendMessage(m.chat, {video: buffer, caption: msg.caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return satanic.sendMessage(m.chat, {image: buffer, caption: msg.caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return satanic.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break
case 'antilink':
  if (!m.isGroup) return reply('⚠️ Fitur ini hanya dapat digunakan di dalam grup!')

  if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!')
  
  if (text === 'on') {
    if (Antilinkgc) return reply('✅ Antilink sudah aktif di grup ini')
    
    ntlinkgc.push(from)
    fs.writeFileSync("./database/antilink.json", JSON.stringify(ntlinkgc))
    reply(`🔒 *Antilink has been activated in this group!*\n\nNobody is allowed to send other group/channel links!`)
    
  } else if (text === 'off') {
    if (!Antilinkgc) return reply('❌ Antilink sudah nonaktif di grup ini')
    
    let off = ntlinkgc.indexOf(from)
    ntlinkgc.splice(off, 1)
    fs.writeFileSync("./database/antilink.json", JSON.stringify(ntlinkgc))
    reply(`🔓 *Antilink has been deactivated in this group!*`)
    
  } else {
    reply(`⚙️ *Antilink Settings*\n\n` +
          `📌 Current status: ${Antilinkgc ? '✅ ACTIVE' : '❌ INACTIVE'}\n\n` +
          `📝 *Usage:*\n` +
          `➤ ${prefix + command} on  - Activate antilink\n` +
          `➤ ${prefix + command} off - Deactivate antilink`)
  }
break
case 'antitagsw':
  if (!m.isGroup) return reply('⚠️ Fitur ini hanya dapat digunakan di dalam grup!')

  if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!')
  
  if (text === 'on') {
    if (Antitagsw) return reply('✅ Anti Tag sudah aktif di grup ini')
    
    nttagsw.push(from)
    fs.writeFileSync("./database/antitagsw.json", JSON.stringify(nttagsw))
    reply(`🔒 *Anti Tag has been activated in this group!*\n\nNobody is allowed to send tag/mention messages!`)
    
  } else if (text === 'off') {
    if (!Antitagsw) return reply('❌ Anti Tag sudah nonaktif di grup ini')
    
    let off = nttagsw.indexOf(from)
    nttagsw.splice(off, 1)
    fs.writeFileSync("./database/antitagsw.json", JSON.stringify(nttagsw))
    reply(`🔓 *Anti Tag has been deactivated in this group!*`)
    
  } else {
    reply(`⚙️ *Anti Tag Settings*\n\n` +
          `📌 Current status: ${Antitagsw ? '✅ ACTIVE' : '❌ INACTIVE'}\n\n` +
          `📝 *Usage:*\n` +
          `➤ ${prefix + command} on  - Activate anti tag\n` +
          `➤ ${prefix + command} off - Deactivate anti tag`)
  }
break
 case "h":
case "hidetag": {
if (!isAdmins && !isCreator) return reply(mess.admin)

if (m.quoted) {
satanic.sendMessage(m.chat, {
forward: m.quoted.fakeObj,
mentions: participants.map(a => a.id)
})
}
if (!m.quoted) {
satanic.sendMessage(m.chat, {
text: text ? text : '',
mentions: participants.map(a => a.id)
}, { quoted: m })
}
}
break
case 'resetlinkgc':
case 'resetlinkgroup':
case 'resetlinkgrup':
case 'revoke':
case 'resetlink':
case 'resetgrouplink':
case 'resetgclink':
case 'resetgruplink': {
if (!isAdmins && !isCreator) return reply(mess.admin)

satanic.groupRevokeInvite(m.chat)
}
break
case 'joingc': {
 if (!isCreator) return 
 if (!text) return reply(`Contoh penggunaan:\n${prefix + command} https://chat.whatsapp.com/xxx`)
    let link = text.trim()
    const urlRegex = /(https?:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]{22,})/gi
    const match = link.match(urlRegex)
    
    if (match) {
        link = match[0]
    }
    if (!link.includes('chat.whatsapp.com')) {
        return reply('❌ *Link Invalid!*\n\nPastikan link adalah link undangan grup WhatsApp.\nContoh: https://chat.whatsapp.com/xxxxxxxxxxxxx')
    }
    let result = link.split('https://chat.whatsapp.com/')[1]
    if (!result) {
        // Coba method alternatif
        result = link.replace('https://chat.whatsapp.com/', '')
        if (result.includes('/')) {
            result = result.split('/')[0]
        }
    }
    if (!result || result.length < 22) {
        return reply('❌ *Link Invalid!*\n\nKode undangan tidak valid atau terlalu pendek.')
    }
    reply(mess.wait)
    try {
        await satanic.groupAcceptInvite(result)
        reply('✅ *Berhasil join ke grup!*')
    } catch (err) {
        console.error('Join Error:', err)
        let errorStr = String(err)
        
        if (errorStr.includes('400')) return reply('❌ *Grup Tidak Ditemukan!*\n\nPastikan link undangan masih aktif.')
        if (errorStr.includes('401')) return reply('❌ *Bot Di Kick Dari Grup Tersebut!*\n\nBot tidak bisa join karena pernah dikick.')
        if (errorStr.includes('409')) return reply('❌ *Bot Sudah Join!*\n\nBot sudah berada di grup tersebut.')
        if (errorStr.includes('410')) return reply('❌ *Link Kadaluarsa!*\n\nLink undangan telah direset oleh admin grup.')
        if (errorStr.includes('500')) return reply('❌ *Grup Penuh!*\n\nGrup sudah mencapai batas maksimal anggota.')
        
        reply(`❌ *Gagal Join!*\n\nError: ${errorStr.substring(0, 200)}\n\nPastikan:\n1. Link undangan masih aktif\n2. Bot tidak diblokir\n3. Grup tidak penuh`)
    }
}
break
case 'poll': {
 let [poll, opt] = text.split("|")
 if (text.split("|") < 2)
return await reply(
`Sebutkan pertanyaan dan minimal 2 pilihan\nContoh: ${prefix}poll Siapa admin terbaik?|Akbar,Hydro,Furina...`
)
 let options = []
 for (let i of opt.split(',')) {
options.push(i)
}
 await satanic.sendMessage(m.chat, {
poll: {
name: poll,
values: options
}
 })
}
break
case 'mediafire':
case 'mf': {
    if (!text || !text.includes("mediafire.com"))
        return reply(`📌 Contoh penggunaan:\n${prefix + command} https://www.mediafire.com/file/abc123/example.zip/file`);

    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    const cheerio = require("cheerio");
    const mime = require("mime-types");
    const fs = require("fs");
    const path = require("path");

    // Fungsi ambil link langsung dari MediaFire
    async function getDirectMediaFireLink(pageUrl) {
        try {
            const res = await fetch(pageUrl);
            const html = await res.text();
            const $ = cheerio.load(html);
            const directLink = $("a#downloadButton").attr("href");
            const fileName = $("div.filename").text().trim() || "mediafire_file";

            if (!directLink) throw new Error("Link unduhan tidak ditemukan.");
            return { fileName, directLink };
        } catch (err) {
            return { error: true, message: err.message };
        }
    }

    // Fungsi untuk menentukan tipe file berdasarkan MIME
    function getFileType(mimeType) {
        if (mimeType.startsWith('image/')) return 'image';
        if (mimeType.startsWith('video/')) return 'video';
        if (mimeType.startsWith('audio/')) return 'audio';
        return 'document';
    }

    try {
        const result = await getDirectMediaFireLink(text.trim());

        if (!result || result.error || !result.directLink) {
            await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return reply(`❌ Gagal mengambil link download.\n${result?.message || "Link tidak valid atau server error."}`);
        }

        const fileName = result.fileName;
        const fileUrl = result.directLink;
        const mimeType = mime.lookup(fileName) || "application/octet-stream";
        const fileType = getFileType(mimeType);
        
        const caption = `📦 *MediaFire Downloader*\n\n📁 *Nama File:* ${fileName}\n✅ *Status:* Siap diunduh`;

        // Pastikan folder ./temp/ ada
        const tempDir = path.join(__dirname, 'temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

        // Simpan file ke ./temp/
        const safeName = fileName.replace(/[^a-z0-9._-]/gi, "_");
        const tempPath = path.join(tempDir, `mf_${Date.now()}_${safeName}`);

        const res = await fetch(fileUrl);
        if (!res.ok) throw new Error("Gagal mengunduh file dari MediaFire.");

        const fileStream = fs.createWriteStream(tempPath);
        await new Promise((resolve, reject) => {
            res.body.pipe(fileStream);
            res.body.on("error", reject);
            fileStream.on("finish", resolve);
        });

        const buffer = fs.readFileSync(tempPath);

        // Kirim sesuai tipe file
        if (fileType === 'image') {
            await satanic.sendMessage(m.chat, {
                image: buffer,
                caption: caption,
                mimetype: mimeType
            }, { quoted: m });
        } 
        else if (fileType === 'video') {
            await satanic.sendMessage(m.chat, {
                video: buffer,
                caption: caption,
                mimetype: mimeType
            }, { quoted: m });
        }
        else if (fileType === 'audio') {
            await satanic.sendMessage(m.chat, {
                audio: buffer,
                mimetype: mimeType,
                ptt: false // set true jika ingin jadi voice note
            }, { quoted: m });
        }
        else {
            // document untuk file lain (zip, pdf, apk, dll)
            await satanic.sendMessage(m.chat, {
                document: buffer,
                fileName: fileName,
                mimetype: mimeType,
                caption: caption
            }, { quoted: m });
        }

        fs.unlinkSync(tempPath); // hapus setelah terkirim
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`❌ Gagal mengirim file:\n${err.message}`);
    }

    break;
}
case 'git': case 'github': case 'gitclone': {
if (!args[0]) return reply(`Mana linknya?\nExample :\n${prefix}${command} https://github.com/DGXeon/XeonMedia`)
if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Link invalid!!`)
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
    let [, user, repo] = args[0].match(regex1) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    satanic.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: m })
}
break
case 'getppgc': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

try {
avatarr = await satanic.profilePictureUrl(m.chat, "image")
} catch {
avatarr = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
}
satanic.sendMessage(m.chat, {image: {url: avatarr }, caption: `©satanic` }, {quoted: m })
}
break
case "getpp": {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)
let target = m.quoted ? m.quoted.sender : m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : null
if (!target) return reply("Reply/@tag target nya")

var ppuser
try {
ppuser = await satanic.profilePictureUrl(target, 'image')
} catch (err) {
ppuser = 'https://files.catbox.moe/ejy4ky.jpg'
}
return satanic.sendMessage(m.chat, {image: {url: ppuser}, caption: `Sukses mengambil profil @${target.split("@")[0]}`, mentions: target}, {quoted: m})
}
break 
case 'setdeskch':
    if (!isCreator) return reply(mess.owner)
    if (!text) return reply('❌ Masukan teks deskripsi\n\n📌 Contoh pemakaian:\n• Pakai default channel: !setdeskch Halo selamat datang\n• Manual ID channel: !setdeskch 120363123456|Halo selamat datang')
    
    let chDesk = global.idch
    let deskText = text
    if (text.split('|')[0].match(/^\d+$/)) {
        chDesk = text.split('|')[0]
        deskText = text.split('|')[1]
    }
    await satanic.newsletterUpdateDescription(chDesk, deskText)
    reply(`✅ Deskripsi channel ${chDesk} berhasil diupdate`)
    break

case 'setnamech':
  if (!text) return reply('❌ Masukan nama channel\n\n📌 Contoh pemakaian:\n• Pakai default channel: !setnamech Channel Baru\n• Manual ID channel: !setnamech 120363123456|Channel Baru')
    let chName = global.idch
    let nameText = text
    if (text.split('|')[0].match(/^\d+$/)) {
        chName = text.split('|')[0]
        nameText = text.split('|')[1]
    }
    await satanic.newsletterUpdateName(chName, nameText)
    reply(`✅ Nama channel ${chName} berhasil diubah menjadi ${nameText}`)
 break
case 'demoteadminch':
    if (!text) return reply('❌ Masukan target admin\n\n📌 Contoh pemakaian:\n• Pakai default channel: !demoteadminch @628123456789\n• Manual ID channel: !demoteadminch 120363123456|@628123456789\n• Balas pesan admin: !demoteadminch')
 if (!isAdmins && !isCreator) return reply('Khusus Admin!!')
    let chDem = global.idch
    let userDem = text
    if (text.split('|')[0].match(/^\d+$/)) {
        chDem = text.split('|')[0]
        userDem = text.split('|')[1]
    }
    let users = userDem.match(/\d+/) ? userDem.match(/\d+/)[0] + '@s.whatsapp.net' : m.mentionedJid[0] || (m.quoted ? m.quoted.sender : '')
    if (!users) return reply('User tidak ditemukan')
    await satanic.newsletterDemote(chDem, [users], 'demote')
    reply(`✅ Berhasil demote admin dari channel ${chDem}`)
    break
case 'followch':
    if (!text) return reply('❌ Masukan ID channel\n\n📌 Contoh pemakaian:\n!followch 1203631234567890')
    await satanic.newsletterFollow(text)
    reply(`✅ Berhasil follow channel ${text}`)
    break
case 'unfollowch':
    if (!text) return reply('❌ Masukan ID channel\n\n📌 Contoh pemakaian:\n!unfollowch 1203631234567890')
    await satanic.newsletterUnfollow(text)
    reply(`✅ Berhasil unfollow channel ${text}`)
    break
case 'createch':
    if (!isCreator) return reply(mess.owner)
    if (!args.join(" ")) return reply(`❌ Masukan nama channel\n\n📌 Contoh pemakaian:\n${prefix + command} Channel Official Saya`)
    let cret = await satanic.newsletterCreate(args.join(" "), [])
    let idolg = `✅ Berhasil membuat channel!\n\n▸ Nama: ${cret.subject}\n▸ ID: ${cret.id}\n▸ Owner: @${cret.owner.split("@")[0]}\n▸ Dibuat: ${moment(cret.creation * 1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`
reply(idolg)
 break
case 'setppch':
    if (!isCreator) return reply(mess.owner)
    if (!m.quoted || !/image/.test(m.quoted.mimetype)) return reply('❌ Balas gambar yang akan dijadikan foto profile channel\n\n📌 Contoh pemakaian:\n• Pakai default channel: balas gambar lalu kirim !setppch\n• Manual ID channel: balas gambar lalu kirim !setppch 120363123456')
    let chPp = global.idch
    if (text && text.match(/^\d+$/)) chPp = text
    let img = await m.quoted.download()
    if (!img) return reply('Gambar tidak ditemukan')
    await satanic.newsletterUpdatePicture(chPp, img)
    reply(`✅ Foto profil channel ${chPp} berhasil diupdate`)
    break
case 'delppch':
    if (!isCreator) return reply(mess.owner)
    let chDel = global.idch
    if (text && text.match(/^\d+$/)) chDel = text
    await satanic.newsletterRemovePicture(chDel)
    reply(`✅ Foto profil channel ${chDel} berhasil dihapus`)
    break
case 'setnamegc':
case 'setsubject':
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

if (!text) return reply('Mau di namain apa kak grupnya? 🤔');
await satanic.groupUpdateSubject(m.chat, text);
reply(mess.done);
break;
case 'setdesc':
case 'setdesk':
if (!m.m.isGroup) return reply(mess.group);
if (!isAdmins && !m.isGroupOwner && !isCreator) return reply(mess.admin);
if (!text) return reply('Text ?')
await satanic.groupUpdateDescription(m.chat, text)
reply(mess.done)
break;
case 'cleardesc':
case 'cleardesk':{
if (!m.m.isGroup) return reply('Perintah ini hanya dapat digunakan dalam grup.');
if (!isAdmins && !isCreator) return reply('Perintah ini hanya dapat digunakan oleh admin.');
try {
await satanic.groupUpdateDescription(m.chat, null);
reply('Deskripsi grup berhasil dihapus.');
} catch (err) {
console.error(err);
reply('Gagal menghapus deskripsi grup.');
}
}
break;
case 'getnamegc':
case 'getsubject': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

try {
reply(groupName);
} catch (error) {
console.log(error);
reply('Gagal saat melakukan tindakan, jika anda pemilik silahkan cek console.');
};
};
break
case 'getdesk':
case 'metadatadesc':
case 'getdesc': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

try {
reply(groupMetadata.desc)
} catch (error) {
console.log(error);
reply('Gagal saat melakukan tindakan, jika anda pemilik silahkan cek console.');
};
};
break
case 'colongsw':
            if (m.quoted?.chat != 'status@broadcast') return reply(`Quote Pesan Status`)
	try {
		let buffer = await m.quoted.download()
		satanic.sendMessage(m.chat, { image: buffer }, { quoted: m })
	} catch (e) {
		console.log(e)
		await reply(m.chat, m.quoted.text, m)
	}
	break
case 'inspect':
case 'cekid': 
case 'idch': 
case 'idgb': 
case 'idgc': 
case 'cekidch': 
case 'cekidgc': 
case 'cekidsaluran': 
case 'cekidgb': 
case 'cekidgroup': {
    if (!text) return reply(`input id nya`)
    const isChannel = text.includes('https://whatsapp.com/channel/')
    const grupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/i
    const boolStatus = (v) => (v === true ? 'Aktif' : v === false ? 'Tidak Aktif' : (v ?? '-'))

    if (!isChannel && !grupRegex.test(text)) return replytolak(global.mess.query.link)

    try {
        if (isChannel) {
            const code = text.split('https://whatsapp.com/channel/')[1]
            if (!code) return reply('link tidak valid')

            const res = await satanic.newsletterMetadata('invite', code)

            const channelId = res.id || ''
            const channelName = res.name || ''

            const teks = `\`\`\`📢 Informasi Channel WhatsApp\`\`\`

🗒️ *Nama:* ${channelName || '-'}
🆔 *ID:* ${channelId || '-'}
👥 *Total Pengikut:* ${res.subscribers ?? '-'}
📌 *Status:* ${res.state || '-'}
✅ *Verifikasi:* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`

            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: "" }),
                            header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "📋 Salin ID",
                                            copy_code: `${channelId}`
                                        })
                                    },
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "📋 Salin Nama",
                                            copy_code: `${channelName}`
                                        })
                                    }
                                ]
                            })
                        })
                    }
                }
            }, { quoted: m })

            return satanic.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
        }

        const inviteCode = text.match(grupRegex)[1]
        const g = await satanic.groupGetInviteInfo(inviteCode)

        let pp = null
        try {
            pp = await satanic.profilePictureUrl(g.id, 'image')
        } catch {
            pp = null
        }

        const admins = (g.participants || []).filter(v => v.admin)
        const groupId = g.id || ''
        const groupName = g.subject || '-'
        const creator = g.owner ? '@' + g.owner.split('@')[0] : '-'

        const teks = `\`\`\`👥 Informasi Grup WhatsApp\`\`\`

🗒️ *Nama:* ${groupName || '-'}
🆔 *ID:* ${groupId || '-'}
👥 *Total Member:* ${g.size || g.participants?.length || '-'}
📅 *Dibuat:* ${g.creation ? new Date(g.creation * 1000).toLocaleString() : '-'}
👑 *Creator:* ${creator}

⚙️ \`\`\`Pengaturan  Group\`\`\`
🔒 *Restrict:* ${boolStatus(g.restrict)}
📢 *Announce:* ${boolStatus(g.announce)}
🏘️ *Community:* ${boolStatus(g.isCommunity)}
✅ *Join Approval:* ${boolStatus(g.joinApprovalMode)}
➕ *Member Add Mode:* ${boolStatus(g.memberAddMode)}

📝 \`\`\`Deskripsi\`\`\`
${g.desc || '-'}

👮 \`\`\`Admin\`\`\`
${admins.length ? admins.map(a => `- @${a.id.split('@')[0]} (${a.admin})`).join('\n') : '-'}`

        const mentioned = [
            ...(g.owner ? [g.owner] : []),
            ...admins.map(a => a.id)
        ]

        if (pp) {
            const media = await prepareWAMessageMedia(
                { image: { url: pp } },
                { upload: satanic.waUploadToServer }
            )

            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: "" }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: true,
                                imageMessage: media.imageMessage
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "📋 Salin ID",
                                            copy_code: `${groupId}`
                                        })
                                    },
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "📋 Salin Nama",
                                            copy_code: `${groupName !== '-' ? groupName : ''}`
                                        })
                                    }
                                ]
                            })
                        })
                    }
                }
            }, { quoted: m })

            msg.message.viewOnceMessage.message.interactiveMessage.contextInfo = { mentionedJid: mentioned }

            return satanic.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
        }

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "" }),
                        header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📋 Salin ID",
                                        copy_code: `${groupId}`
                                    })
                                },
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📋 Salin Nama",
                                        copy_code: `${groupName !== '-' ? groupName : ''}`
                                    })
                                }
                            ]
                        })
                    })
                }
            }
        }, { quoted: m })

        msg.message.viewOnceMessage.message.interactiveMessage.contextInfo = { mentionedJid: mentioned }
return satanic.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
    } catch (err) {
        console.log(err)
        return reply('eror')
    }
}
break
///////search menu//////
case 'pin':
case 'pinterest': {
    async function getCookies() {
      try {
        const response = await axios.get('https://www.pinterest.com/csrf_error/');
        const setCookieHeaders = response.headers['set-cookie'];
        if (setCookieHeaders) {
          const cookies = setCookieHeaders.map(cookieString => {
            const cookieParts = cookieString.split(';');
            const cookieKeyValue = cookieParts[0].trim();
            return cookieKeyValue;
          });
          return cookies.join('; ');
        } else {
          console.warn('No set-cookie headers found in the response.');
          return null;
        }
      } catch (error) {
        console.error('Error fetching cookies:', error);
        return null;
      }
    }
    
 async function pinterest(query) {
      try {
        const cookies = await getCookies();
        if (!cookies) {
          console.log('Failed to retrieve cookies. Exiting.');
          return;
        }

        const url = 'https://www.pinterest.com/resource/BaseSearchResource/get/';

        const params = {
          source_url: `/search/pins/?q=${query}`,
          data: JSON.stringify({
            "options": {
              "isPrefetch": false,
              "query": query,
              "scope": "pins",
              "no_fetch_context_on_resource": false
            },
            "context": {}
          }),
          _: Date.now()
        };

        const headers = {
          'accept': 'application/json, text/javascript, */*, q=0.01',
          'accept-encoding': 'gzip, deflate',
          'accept-language': 'en-US,en;q=0.9',
          'cookie': cookies,
          'dnt': '1',
          'referer': 'https://www.pinterest.com/',
          'sec-ch-ua': '"Not(A:Brand";v="99", "Microsoft Edge";v="133", "Chromium";v="133"',
          'sec-ch-ua-full-version-list': '"Not(A:Brand";v="99.0.0.0", "Microsoft Edge";v="133.0.3065.92", "Chromium";v="133.0.6943.142"',
          'sec-ch-ua-mobile': '?0',
          'sec-ch-ua-model': '""',
          'sec-ch-ua-platform': '"Windows"',
          'sec-ch-ua-platform-version': '"10.0.0"',
          'sec-fetch-dest': 'empty',
          'sec-fetch-mode': 'cors',
          'sec-fetch-site': 'same-origin',
          'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0',
          'x-app-version': 'c056fb7',
          'x-pinterest-appstate': 'active',
          'x-pinterest-pws-handler': 'www/[username]/[slug].js',
          'x-pinterest-source-url': '/hargr003/cat-pictures/',
          'x-requested-with': 'XMLHttpRequest'
        };

        const {
          data
        } = await axios.get(url, {
          headers: headers,
          params: params
        })

        const container = [];
        const results = data.resource_response.data.results.filter((v) => v.images?.orig);
        results.forEach((result) => {
          container.push({
            upload_by: result.pinner.username,
            fullname: result.pinner.full_name,
            followers: result.pinner.follower_count,
            caption: result.grid_title,
            image: result.images.orig.url,
            source: "https://id.pinterest.com/pin/" + result.id,
          });
        });

        return container;
      } catch (error) {
        console.log(error);
        return [];
      }
    }
    
      if (!text) return reply(`Format salah, contoh: \n${prefix + command} Anime`)
      
      await satanic.sendMessage(m.chat, {
        react: {
          text: '⏳',
          key: m.key
        }
      })

      let anutrest = await pinterest(text) // Ambil hasil pencarian
      if (!anutrest || anutrest.length === 0) return reply("Error, Foto Tidak Ditemukan")

      // Ambil maksimal 10 gambar biar nggak terlalu panjang
      let selectedImages = anutrest.slice(0, 10);
      let anu = []

      for (let i = 0; i < selectedImages.length; i++) {
        let imgsc = await prepareWAMessageMedia({
          image: {
            url: selectedImages[i].image
          }
        }, {
          upload: satanic.waUploadToServer
        })

        anu.push({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: `Gambar ke *${i + 1}*`,
            hasMediaAttachment: true,
            ...imgsc
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [{
              name: "cta_url",
              buttonParamsJson: JSON.stringify({
                display_text: "Lihat di Pinterest",
                url: selectedImages[i].source || selectedImages[i].image
              })
            }]
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "© Satanic Haxor"
          })
        })
      }

      // Buat format `carouselMessage`
      const msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `🔎 Berikut hasil pencarian gambar untuk *${text}*`
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: anu
              })
            })
          }
        }
      }, {
        userJid: sender,
        quoted: m
      })
      satanic.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
      })
    }
break
case "bingimage":
case "bingimg":
{
    if (!text) return reply(`❌ *Cara penggunaan:* ${prefix + command} kata kunci\nContoh: ${prefix + command} kucing lucu`);

    await satanic.sendMessage(m.chat, {
        react: {
            text: '⏳',
            key: m.key
        }
    });

    try {
        const query = text.trim();
        const limit = 10; // Jumlah gambar yang diambil
        const headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
        };

        // Format query untuk URL
        const q = query.split(/\s+/).join('+');
        const url = `https://www.bing.com/images/search?q=${q}&FORM=HDRSC2`;

        // Request ke Bing
        const res = await axios.get(url, { headers });
        const $ = cheerio.load(res.data);

        let images = [];

        // Scrape gambar dari elemen a.iusc
        $('a.iusc').each((i, el) => {
            if (i >= limit) return false; // Batasi sesuai limit

            try {
                const mRaw = $(el).attr('m') || '{}';
                const madRaw = $(el).attr('mad') || '{}';

                const m = JSON.parse(mRaw);
                const mad = JSON.parse(madRaw);

                const original_url = m?.murl;
                const preview_url = mad?.turl;
                const title = m?.t || 'Gambar';

                if (!original_url) return;

                images.push({
                    title: title,
                    preview_url: preview_url || original_url,
                    original_url: original_url,
                    source: original_url
                });
            } catch (e) {
                // Abaikan error parsing
            }
        });

        // Cek apakah ada gambar ditemukan
        if (images.length === 0) {
            return reply(`❌ Tidak ditemukan gambar untuk *${query}*`);
        }

        // Ambil maksimal 10 gambar
        let selectedImages = images.slice(0, 10);
        let anu = [];

        for (let i = 0; i < selectedImages.length; i++) {
            let imgsc = await prepareWAMessageMedia({
                image: {
                    url: selectedImages[i].original_url
                }
            }, {
                upload: satanic.waUploadToServer
            });

            anu.push({
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: `Gambar ke *${i + 1}*`,
                    hasMediaAttachment: true,
                    ...imgsc
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Lihat Gambar",
                            url: selectedImages[i].original_url
                        })
                    }]
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: "© Bing Image Search"
                })
            });
        }

        // Buat format `carouselMessage`
        const msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `🔎 *Hasil Pencarian Gambar dari Bing*\n📝 *Query:* ${query}\n📊 *Ditemukan:* ${images.length} gambar`
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: anu
                        })
                    })
                }
            }
        }, {
            userJid: sender,
            quoted: m
        });

        await satanic.relayMessage(m.chat, msg.message, {
            messageId: msg.key.id
        });

    } catch (error) {
        console.error("Error BingImage:", error);
        reply(`❌ Gagal mengambil gambar: ${error.message}`);
    }
}
break;
case "enc": case "encrypt": {
        if (!isCreator && !isPrem) return reply(mess.premium)
        if (!m.quoted) return reply("dengan reply file .js")
        if (mime !== "application/javascript" && mime !== "text/javascript") return reply("Reply file .js")
        let media = await m.quoted.download()
        let filename = m.quoted.fileName
        await fs.writeFileSync(`./database/${filename}`, media)
        await reply("Memproses encrypt code . . .")
        await JsConfuser.obfuscate(await fs.readFileSync(`./database/${filename}`).toString(), {
          target: "node",
          preset: "high",
          calculator: true,
          compact: true,
          hexadecimalNumbers: true,
          controlFlowFlattening: 0.75,
          deadCode: 0.2,
          dispatcher: true,
          duplicateLiteralsRemoval: 0.75,
          flatten: true,
          globalConcealing: true,
          identifierGenerator: "randomized",
          minify: true,
          movedDeclarations: true,
          objectExtraction: true,
          opaquePredicates: 0.75,
          renameVariables: true,
          renameGlobals: true,
          shuffle: { hash: 0.5, true: 0.5 },
          stack: true,
          stringConcealing: true,
          stringCompression: true,
          stringEncoding: true,
          stringSplitting: 0.75,
          rgf: false
        }).then(async (obfuscated) => {
          await fs.writeFileSync(`./database/${filename}`, obfuscated)
          await satanic.sendMessage(m.chat, { document: fs.readFileSync(`./database/${filename}`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt file sukses ✅" }, { quoted: m })
        }).catch(e => reply("Error :" + e))
        await fs.unlinkSync(`./database/${filename}`)
      }
        break
      case 'enchard': {
        if (!isCreator && !isPrem) return reply(mess.owner)
        if (!m.quoted) return reply(`\`Format Salah!\`\n*Contoh: ${command} reply file.js*`);
        if (mime !== "application/javascript") return replyvici(`\`Format Salah!\`\n*Contoh: ${prefix + command} reply file.js*`)
        let a = await m.quoted.download(),
          b = m.quoted.fileName;
        await fs.writeFileSync(`./@hardenc${b}.js`, a);
        await reply("\`Memproses encrypt hard code . . .\`");

        await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${b}.js`).toString(), {
          target: "node",
          preset: "high",
          compact: true,
          minify: true,
          flatten: true,
          identifierGenerator: function () {
            const c = "素晴座素晴難satanicSYZ素晴座素晴難" + "素晴座素晴難AlisaMD素晴座素晴難",
              d = x => x.replace(/[^a-zA-Z座barmodss素Official素晴]/g, ''),
              e = y => [...Array(y)].map(() => "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".charAt(Math.random() * 52 | 0)).join('');
            return d(c) + e(2);
          },
          renameVariables: true,
          renameGlobals: true,
          stringEncoding: true,
          stringSplitting: 0,
          stringConcealing: true,
          stringCompression: true,
          duplicateLiteralsRemoval: 1,
          shuffle: { hash: 0, true: 0 },
          stack: true,
          controlFlowFlattening: 1,
          opaquePredicates: 0.9,
          deadCode: 0,
          dispatcher: true,
          rgf: false,
          calculator: true,
          hexadecimalNumbers: true,
          movedDeclarations: true,
          objectExtraction: true,
          globalConcealing: true
        }).then(async f => {
          await fs.writeFileSync(`./@hardenc${b}.js`, f);
          await satanic.sendMessage(
            m.chat,
            { document: fs.readFileSync(`./@hardenc${b}.js`), mimetype: "application/javascript", fileName: b, caption: "\`Encrypt Hard File JS Sukses!\`" },
            { quoted: m }
          );
        }).catch(g => reply("Error :" + g));
      }
        break
      case 'encarab':
      case 'encryptarab':
      case 'encrypt-arab':
      case 'arabenc':
      case 'arab-encrypt':
      case 'enc-arab': {
        if (!m.quoted) return reply('dengan reply file .js!')
        try {

          const fileName = quoted.fileName || ''
          if (mime !== "application/javascript" && mime !== "text/javascript") return reply("Reply file .js")
          await reply("Memproses encrypt code . . .")

          const arab = ['أ', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي']
          const genArab = () => Array.from({
            length: Math.floor(Math.random() * 4) + 3
          }, () => arab[Math.floor(Math.random() * arab.length)]).join('')

          const getArabObf = () => ({
            target: 'node',
            compact: true,
            renameVariables: true,
            renameGlobals: true,
            identifierGenerator: genArab,
            stringEncoding: true,
            stringSplitting: true,
            controlFlowFlattening: 0.95,
            shuffle: true,
            duplicateLiteralsRemoval: true,
            deadCode: true,
            calculator: true,
            opaquePredicates: true,
            lock: {
              selfDefending: true,
              antiDebug: true,
              integrity: true,
              tamperProtection: true
            }
          })

          const bar = (p) => {
            const t = 20
            const f = Math.round(p / 5)
            return `[${'█'.repeat(f)}${' '.repeat(t - f)}] ${p}%`
          }

          let media = await downloadContentFromMessage(quoted, 'document')
          let buffer = Buffer.from([])
          for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
          const raw = buffer.toString('utf8')

          try {
            new Function(raw)
          } catch (e) {
            return reply(`❌ File JS tidak valid:\n${e.message}`)
          }

          const obf = await JsConfuser.obfuscate(raw, getArabObf())
          const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

          const outName = `arab-encrypted-${Date.now()}.js`
          const outPath = path.join(__dirname, outName)
          fs.writeFileSync(outPath, code, 'utf8')

          const fileBuffer = fs.readFileSync(outPath)
          await satanic.sendMessage(m.chat, {
            document: fileBuffer,
            mimetype: 'application/javascript',
            fileName: outName,
            caption: '✅ *Arab encrypted!*'
          }, {
            quoted: m
          })

          try {
            fs.unlinkSync(outPath)
          } catch (e) { }
        } catch (err) {
          console.error(err)
          reply(`❌ Terjadi kesalahan: ${err && err.message ? err.message : String(err)}`)
        }
      }
        break
      case 'encchina':
      case 'encryptchina':
      case 'encrypt-china':
      case 'chinaenc':
      case 'china-encrypt':
      case 'encchina':
      case 'encmandarin':
      case 'encryptmandarin':
      case 'encrypt-mandarin':
      case 'mandarinenc':
      case 'mandarin-encrypt':
      case 'enc-mandarin': {
        if (!m.quoted) return reply('dengan reply file .js!')
        try {

          const fileName = quoted.fileName || ''
          if (mime !== "application/javascript" && mime !== "text/javascript") return reply("Reply file .js")
          await reply("Memproses encrypt code . . .")

          const mandarin = [
            "龙", "虎", "风", "云", "山", "河", "天", "地", "雷", "电", "火", "水",
            "木", "金", "土", "星", "月", "日", "光", "影", "峰", "泉", "林", "海",
            "雪", "霜", "雾", "冰", "焰", "石"
          ]
          const genMandarin = () => Array.from({
            length: Math.floor(Math.random() * 4) + 3
          }, () => mandarin[Math.floor(Math.random() * mandarin.length)]).join('')

          const getMandarinObf = () => ({
            target: 'node',
            compact: true,
            renameVariables: true,
            renameGlobals: true,
            identifierGenerator: genMandarin,
            stringEncoding: true,
            stringSplitting: true,
            controlFlowFlattening: 0.95,
            shuffle: true,
            duplicateLiteralsRemoval: true,
            deadCode: true,
            calculator: true,
            opaquePredicates: true,
            lock: {
              selfDefending: true,
              antiDebug: true,
              integrity: true,
              tamperProtection: true
            }
          })

          const bar = (p) => {
            const t = 20
            const f = Math.round(p / 5)
            return `[${'█'.repeat(f)}${' '.repeat(t - f)}] ${p}%`
          }

          let media = await downloadContentFromMessage(quoted, 'document')
          let buffer = Buffer.from([])
          for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
          const raw = buffer.toString('utf8')

          try {
            new Function(raw)
          } catch (e) {
            return reply(`❌ File JS tidak valid:\n${e.message}`)
          }

          const obf = await JsConfuser.obfuscate(raw, getMandarinObf())
          const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

          const outName = `china-encrypted-${Date.now()}.js`
          const outPath = path.join(__dirname, outName)
          fs.writeFileSync(outPath, code, 'utf8')

          const fileBuffer = fs.readFileSync(outPath)
          await satanic.sendMessage(m.chat, {
            document: fileBuffer,
            mimetype: 'application/javascript',
            fileName: outName,
            caption: '✅ *Mandarin encrypted!*'
          }, {
            quoted: m
          })

          try {
            fs.unlinkSync(outPath)
          } catch (e) { }
        } catch (err) {
          console.error(err)
          reply(`❌ Terjadi kesalahan: ${err && err.message ? err.message : String(err)}`)
        }
      }
        break

      case 'enccustom':
      case 'encryptcustom':
      case 'encrypt-custom':
      case 'customenc':
      case 'custom-encrypt':
      case 'enc-custom': {
        if (!m.quoted) return reply('dengan reply file .js!')
        try {

          
          const customName = (args[0] || '').replace(/[^a-zA-Z0-9_]/g, '')
          if (!customName) return reply(`Format: ${cmd} <nama>\nContoh: ${cmd} myid`)

          const fileName = quoted.fileName || ''
          if (mime !== "application/javascript" && mime !== "text/javascript") return reply("Reply file .js")
          await reply("Memproses encrypt code . . .")

          const idGen = () => {
            const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
            let suf = ''
            for (let i = 0; i < Math.floor(Math.random() * 3) + 2; i++) suf += chars[Math.floor(Math.random() * chars.length)]
            return `${customName}_${suf}`
          }

          const getCustomObf = () => ({
            target: 'node',
            compact: true,
            renameVariables: true,
            renameGlobals: true,
            identifierGenerator: idGen,
            stringEncoding: true,
            stringSplitting: true,
            controlFlowFlattening: 0.75,
            shuffle: true,
            duplicateLiteralsRemoval: true,
            deadCode: true,
            calculator: true,
            opaquePredicates: true,
            lock: {
              selfDefending: true,
              antiDebug: true,
              integrity: true,
              tamperProtection: true
            }
          })

          const bar = (p) => {
            const t = 20
            const f = Math.round(p / 5)
            return `[${'█'.repeat(f)}${' '.repeat(t - f)}] ${p}%`
          }

          let media = await downloadContentFromMessage(quoted, 'document')
          let buffer = Buffer.from([])
          for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
          const raw = buffer.toString('utf8')

          try {
            new Function(raw)
          } catch (e) {
            return reply(`❌ File JS tidak valid:\n${e.message}`)
          }

          const obf = await JsConfuser.obfuscate(raw, getCustomObf())
          const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

          const outName = `custom-encrypted-${customName}-${Date.now()}.js`
          const outPath = path.join(__dirname, outName)
          fs.writeFileSync(outPath, code, 'utf8')

          const fileBuffer = fs.readFileSync(outPath)
          await satanic.sendMessage(m.chat, {
            document: fileBuffer,
            mimetype: 'application/javascript',
            fileName: outName,
            caption: `✅ *Custom encrypted (${customName})!*`
          }, {
            quoted: m
          })

          try {
            fs.unlinkSync(outPath)
          } catch (e) { }
        } catch (err) {
          console.error(err)
          reply(`❌ Terjadi kesalahan: ${err && err.message ? err.message : String(err)}`)
        }
      }
        break

      case 'encinvis':
      case 'encryptinvis':
      case 'encrypt-invis':
      case 'invisenc':
      case 'invis-encrypt':
      case 'enc-invis':
      case 'encinvisible':
      case 'encryptinvisible':
      case 'encrypt-invisible':
      case 'invisibleenc':
      case 'invisible-encrypt':
      case 'enc-invisible': {
        if (!m.quoted) return reply('dengan reply file .js!')
        try {

          const fileName = quoted.fileName || ''
          if (mime !== "application/javascript" && mime !== "text/javascript") return reply("Reply file .js")
          await reply("Memproses encrypt code . . .")
          const genInvis = () => '_'.repeat(Math.floor(Math.random() * 4) + 3) + Math.random().toString(36).slice(2, 5)
          const getInvisObf = () => ({
            target: 'node',
            compact: true,
            renameVariables: true,
            renameGlobals: true,
            identifierGenerator: genInvis,
            stringEncoding: true,
            stringSplitting: true,
            controlFlowFlattening: 0.95,
            shuffle: true,
            duplicateLiteralsRemoval: true,
            deadCode: true,
            calculator: true,
            opaquePredicates: true,
            lock: {
              selfDefending: true,
              antiDebug: true,
              integrity: true,
              tamperProtection: true
            }
          })

          const bar = (p) => {
            const t = 20
            const f = Math.round(p / 5)
            return `[${'█'.repeat(f)}${' '.repeat(t - f)}] ${p}%`
          }

          let media = await downloadContentFromMessage(quoted, 'document')
          let buffer = Buffer.from([])
          for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
          const raw = buffer.toString('utf8')

          try {
            new Function(raw)
          } catch (e) {
            return reply(`❌ File JS tidak valid:\n${e.message}`)
          }

          const obf = await JsConfuser.obfuscate(raw, getInvisObf())
          const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

          const outName = `invis-encrypted-${Date.now()}.js`
          const outPath = path.join(__dirname, outName)
          fs.writeFileSync(outPath, code, 'utf8')

          const fileBuffer = fs.readFileSync(outPath)
          await satanic.sendMessage(m.chat, {
            document: fileBuffer,
            mimetype: 'application/javascript',
            fileName: outName,
            caption: '✅ *Invisible encrypted siap!*'
          }, {
            quoted: m
          })

          try {
            fs.unlinkSync(outPath)
          } catch (e) { }
        } catch (err) {
          console.error(err)
          reply(`❌ Terjadi kesalahan: ${err && err.message ? err.message : String(err)}`)
        }
      }
        break

      case 'encsiu':
      case 'encryptsiu':
      case 'encrypt-siu':
      case 'siuenc':
      case 'siu-encrypt':
      case 'enc-siu': {
        if (!m.quoted) return reply('dengan reply file .js!')
        try {

          const fileName = quoted.fileName || ''
          if (!fileName.endsWith('.js')) return reply('Kutip file `.js` untuk dienkripsi!')
          if (mime !== "application/javascript" && mime !== "text/javascript") return reply("Reply file .js")
          await reply("Memproses encrypt code . . .")
          const genSiu = () => {
            const abc = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
            let r = ''
            for (let i = 0; i < 6; i++) r += abc[Math.floor(Math.random() * abc.length)]
            return `CalceKarik和SiuSiu${r}`
          }

          const getSiuObf = () => ({
            target: 'node',
            compact: true,
            renameVariables: true,
            renameGlobals: true,
            identifierGenerator: genSiu,
            stringCompression: true,
            stringEncoding: true,
            stringSplitting: true,
            controlFlowFlattening: 0.95,
            flatten: true,
            shuffle: true,
            duplicateLiteralsRemoval: true,
            deadCode: true,
            calculator: true,
            opaquePredicates: true,
            lock: {
              selfDefending: true,
              antiDebug: true,
              integrity: true,
              tamperProtection: true
            }
          })

          const bar = (p) => {
            const t = 20
            const f = Math.round(p / 5)
            return `[${'█'.repeat(f)}${' '.repeat(t - f)}] ${p}%`
          }

          let media = await downloadContentFromMessage(quoted, 'document')
          let buffer = Buffer.from([])
          for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
          const raw = buffer.toString('utf8')

          try {
            new Function(raw)
          } catch (e) {
            return reply(`❌ File JS tidak valid:\n${e.message}`)
          }

          const obf = await JsConfuser.obfuscate(raw, getSiuObf())
          const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

          const outName = `siu-encrypted-${Date.now()}.js`
          const outPath = path.join(__dirname, outName)
          fs.writeFileSync(outPath, code, 'utf8')

          const fileBuffer = fs.readFileSync(outPath)
          await satanic.sendMessage(m.chat, {
            document: fileBuffer,
            mimetype: 'application/javascript',
            fileName: outName,
            caption: '✅ *Calcrick Chaos Core encrypted!*'
          }, {
            quoted: m
          })

          try {
            fs.unlinkSync(outPath)
          } catch (e) { }
        } catch (err) {
          console.error(err)
          reply(`❌ Terjadi kesalahan: ${err && err.message ? err.message : String(err)}`)
        }
      }
 break
 case 'smeme': case 'stickermeme': case 'stickmeme': {
    await satanic.sendMessage(m.chat, {react: {text: '🚀', key: m.key}})
    
    if (!text) return reply(`Usage: ${cmd} text1|text2`)
    
    let atas = text.split('|')[0] ? text.split('|')[0] : '-'
    let bawah = text.split('|')[1] ? text.split('|')[1] : '-'
    
    if (!quoted) return reply(`Balas gambar/sticker dengan caption ${cmd} text1|text2`)
    let mime = quoted.mimetype || ''
    let memeUrl = ''
    if (/image/.test(mime)) {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted)
        let mem = await UploadFileUgu(mee)
        memeUrl = `https://newcodingproject.vercel.app/api/smeme?atas=${encodeURIComponent(atas)}&bawah=${encodeURIComponent(bawah)}&background=${mem.url}&apikey=SK-F68D971CC86742FDF2A923BA`
    }
    else if (/webp/.test(mime)) {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted)
        let mem = await UploadFileUgu(mee)
        memeUrl = `https://newcodingproject.vercel.app/api/smeme?atas=${encodeURIComponent(atas)}&bawah=${encodeURIComponent(bawah)}&background=${mem.url}&apikey=SK-F68D971CC86742FDF2A923BA`
    }
    else {
        return reply(`Hanya bisa menerima gambar atau sticker`)
    }
    const response = await axios.get(memeUrl, { responseType: 'arraybuffer' })
    await satanic.sendImageAsSticker(m.chat, response.data, m, {
        packname: `satanic`,
    })
}
break
case 'removecloth3': {
if (!isCreator) return
    if (!quoted) return reply('Balas gambar yang akan diganti bajunya!');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Yang Anda balas bukan gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let media = await satanic.downloadAndSaveMediaMessage(quoted);
        let uploadUrl = await UploadFileUgu(media);

        const apiUrl = `https://free-restapi.biz.id/api/removecloth3?url=${encodeURIComponent(uploadUrl)}&apikey=${global.sakey}`;
        
        const response = await axios.get(apiUrl);
        
        if (response.data && response.data.status === 200 && response.data.result) {
            await satanic.sendMessage(m.chat, {
                image: { url: response.data.result },
                caption: '✅ Berhasil!'
            }, { quoted: m });
            
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            throw new Error('Gagal memproses gambar');
        }
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengganti baju.');
    }
}
break;
case 'brat':
case 'bratgambar':
case 'bratimg': {
  if (!text) return reply('teksnya')
  const brat = `https://brat.siputzx.my.id/image?text=${encodeURIComponent(text)}&background=%23ffffff&color=%23000000&emojiStyle=apple`
  const response = await axios.get(brat, { responseType: 'arraybuffer' })
  await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname })
}
break
	case 'nikparse':
	case 'ceknik': {

    if (!text) return m.reply(`Contoh:\n${prefix + command} 181005415784847`);

    const nik = text.trim();

    if (nik.length !== 16 || !/^\d+$/.test(nik)) {
        return m.reply("❌ NIK harus 16 digit angka!");
    }

    satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    try {

        const api = `https://api.siputzx.my.id/api/tools/nik-checker?nik=${nik}`;
        const res = await fetchJson(api);

        if (!res.status || !res.data) {
            return m.reply("❌ Tidak dapat mengambil data dari server!");
        }

        const d = res.data.data;     
        const meta = res.data.metadata; 
        const lhp = res.data.data_lhp?.[0]; 

        let teks = `*🔍 HASIL CEK NIK*\n`;
        teks += `──────────────────────\n`;
        teks += `👤 *Nama*: ${d.nama}\n`;
        teks += `🆔 *NIK*: ${res.data.nik}\n`;
        teks += `👨‍⚕️ *Jenis Kelamin*: ${d.kelamin}\n`;
        teks += `🎂 *Tanggal Lahir*: ${d.tempat_lahir}\n`;
        teks += `📅 *Usia*: ${d.usia}\n`;
        teks += `⭐ *Zodiak*: ${d.zodiak}\n`;
        teks += `🎉 *Ultah Mendatang*: ${d.ultah_mendatang}\n`;
        teks += `🗓️ *Pasaran*: ${d.pasaran}\n\n`;

        teks += `*📍 ALAMAT & WILAYAH*\n`;
        teks += `• Provinsi: ${d.provinsi}\n`;
        teks += `• Kabupaten/Kota: ${d.kabupaten}\n`;
        teks += `• Kecamatan: ${d.kecamatan}\n`;
        teks += `• Kelurahan: ${d.kelurahan}\n`;
        teks += `• TPS: ${d.tps}\n`;
        teks += `• Alamat: ${d.alamat}\n\n`;

        teks += `*🌍 KOORDINAT*\n`;
        teks += `• Lat: ${d.koordinat.lat}\n`;
        teks += `• Lon: ${d.koordinat.lon}\n\n`;

        teks += `*📌 METADATA*\n`;
        teks += `• Kode Wilayah: ${meta.kode_wilayah}\n`;
        teks += `• Nomor Urut: ${meta.nomor_urut}\n`;
        teks += `• Kategori Usia: ${meta.kategori_usia}\n`;
        teks += `• Jenis Wilayah: ${meta.jenis_wilayah}\n`;
        teks += `• Metode: ${meta.metode_pencarian}\n\n`;

        if (lhp) {
            teks += `*🗂️ DATA LHP*\n`;
            teks += `• Nama: ${lhp.nama}\n`;
            teks += `• Kecamatan: ${lhp.kecamatan}\n`;
            teks += `• Kelurahan: ${lhp.kelurahan}\n`;
            teks += `• TPS: ${lhp.tps}\n`;
            teks += `• Sumber: ${lhp.source}\n`;
            teks += `• Alamat: ${lhp.alamat}\n`;
        }

        await satanic.sendMessage(m.chat, {
            text: teks,
            contextInfo: {
                externalAdReply: {
                    title: "NIK Checker",
                    body: "Alya chan",
                    mediaType: 1,
                    thumbnailUrl: "https://raw.githubusercontent.com/yuusuke1101/Yuugames/refs/heads/main/IMG-20251228-WA0077.jpg",
                    sourceUrl: "https://youtube.com/yuuyamada1101",
                    renderLargerThumbnail: true
                }
            }
        });

        satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.log(e);
        m.reply("❌ Terjadi kesalahan server!");
    }
}
break;
case 'fakeff':
case 'lobyff':
case 'lobbyff': {
   
    if (!text || !text.includes('|')) {
        return reply(`🎮 *FREE FIRE LOBBY MAKER*

Contoh:
${prefix + command} 1|Jagoan FF
${prefix + command} random|Jagoan FF

Pilihan template: 1 - 22 atau ketik *random*`)
    }

    let [numStr, name] = text.split('|').map(v => v.trim())
    numStr = numStr.toLowerCase()

    const imageUrls = {
        1: 'https://cloud-fukushima.vercel.app/uploader/8fjhd6ftps.jpg',
        2: 'https://cloud-fukushima.vercel.app/uploader/oz8hb4ow75.jpg',
        3: 'https://cloud-fukushima.vercel.app/uploader/tvz1cie8df.jpg',
        4: 'https://cloud-fukushima.vercel.app/uploader/yo9sg4vmo3.jpg',
        5: 'https://i.ibb.co/twtSvQXv/image.jpg',
        6: 'https://i.ibb.co/n80Bc1wV/image.jpg',
        7: 'https://i.ibb.co/mCwmt019/image.jpg',
        8: 'https://i.ibb.co/JwG60TwF/image.jpg',
        9: 'https://i.ibb.co/zWNLw6bV/image.jpg',
        10: 'https://i.ibb.co/d4DvnHw6/image.jpg',
        11: 'https://i.ibb.co/hxMGbx9v/image.jpg',
        12: 'https://i.ibb.co/jvd5xfvK/image.jpg',
        13: 'https://i.ibb.co/KxTQ0r0x/image.jpg',
        14: 'https://i.ibb.co/rRyxvrJW/image.jpg',
        15: 'https://i.ibb.co/PG5jwG6S/image.jpg',
        16: 'https://i.ibb.co/MDdH7kjG/image.jpg',
        17: 'https://i.ibb.co/6cnHvL31/image.jpg',
        18: 'https://i.ibb.co/dwg4CGdf/image.jpg',
        19: 'https://i.ibb.co/pvx1PZyW/image.jpg',
        20: 'https://i.ibb.co/kVkbxhwg/image.jpg',
        21: 'https://i.ibb.co/rK8ZTPbt/image.jpg',
        22: 'https://i.ibb.co/vC3p8NjP/image.jpg'
    }

    const max = Object.keys(imageUrls).length
    let num

    if (numStr === 'random') {
        num = Math.floor(Math.random() * max) + 1
    } else {
        num = parseInt(numStr)
        if (isNaN(num) || num < 1 || num > max) {
            return reply(`❌ Template tidak valid!\nPilih 1 - ${max} atau random`)
        }
    }

    await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

    try {
        const imgUrl = imageUrls[num]
        const temp = `./temp_${Date.now()}.jpg`
        const out = `./out_${Date.now()}.jpg`
        const font = './lib/AGENCYB.TTF'

        if (!fs.existsSync(font)) {
            await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
            return reply('❌ Font AGENCYB.TTF tidak ditemukan di folder /lib')
        }

        // PERBAIKAN: Menggunakan Axios
        const axios = require('axios')
        const response = await axios({
            method: 'get',
            url: imgUrl,
            responseType: 'arraybuffer'
        })
        
        fs.writeFileSync(temp, Buffer.from(response.data))

        let fontSize
        if (name.length <= 6) fontSize = 'w*0.055'
        else if (name.length <= 10) fontSize = 'w*0.045'
        else if (name.length <= 15) fontSize = 'w*0.038'
        else fontSize = 'w*0.030'

        const safeText = name.replace(/'/g, "\\'")
        const safeFont = font.replace(/\\/g, '/')

        const cmd = `ffmpeg -i "${temp}" -vf "drawtext=fontfile='${safeFont}':text='${safeText}':x=(w-text_w)/2:y=h*0.80-(text_h/2):fontsize=${fontSize}:fontcolor=yellow:shadowcolor=black:shadowx=3:shadowy=3" "${out}"`

        exec(cmd, async (err) => {
            if (err) {
                console.error(err)
                if (fs.existsSync(temp)) fs.unlinkSync(temp)
                await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
                return reply('❌ FFMPEG error! Pastikan sudah terinstall.')
            }

            await satanic.sendMessage(m.chat, {
                image: fs.readFileSync(out),
                caption: `🎮 *FREE FIRE LOBBY*

👤 Name : ${name.toUpperCase()}
🖼️ Template : ${num}`
            }, { quoted: m })

            if (fs.existsSync(temp)) fs.unlinkSync(temp)
            if (fs.existsSync(out)) fs.unlinkSync(out)

            await satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
        })

    } catch (e) {
        console.error(e)
        await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
        reply('❌ Terjadi error saat proses gambar!')
    }
}
break
	case 'ektp':
	case 'fakektp': {
		satanic.sendMessage(m.chat, { react: { text: '🪪', key: m.key } });

		try {
			const { uploadToCatbox, generateEKTP } = require('./lib/ektp');

			let pasPhotoURL = "";

			if (m.quoted && /image/.test(m.quoted.mimetype)) {
				let media = await m.quoted.download();
				let up = await uploadToCatbox(media);

				if (!up.success) {
					return reply(`❌ Gagal upload foto!\n${up.error}`);
				}

				pasPhotoURL = up.url;
			}

			let parts = text ? text.split("|").map(v => v.trim()) : [];

			const [
				provinsi = "",
				kota = "",
				nik = "",
				nama = "",
				ttl = "",
				jenis_kelamin = "",
				golongan_darah = "",
				alamat = "",
				rt_rw = "",
				kel_desa = "",
				kecamatan = "",
				agama = "",
				status = "",
				pekerjaan = "",
				kewarganegaraan = "",
				masa_berlaku = "",
				terbuat = "",
				pasfoto_input = ""
			] = parts;

			if (!pasPhotoURL) pasPhotoURL = pasfoto_input;

			if (!provinsi || !kota || !nik || !nama || !ttl || !pasPhotoURL) {
				return reply(
					`⚠️ *Format salah!*\n\nGunakan format:\n` +
					`${prefix + command} Provinsi|Kota|NIK|Nama|TTL|JK|GolDar|Alamat|RT/RW|Kel/Desa|Kecamatan|Agama|Status|Pekerjaan|Kewarganegaraan|Masa Berlaku|Terbuat|URLFoto\n\n` +
					`Atau *reply foto* dengan caption:\n${prefix + command} Lampung|Bandar Lampung|15615489465187|ALYA KUJOU|Lampung, 22-09-2009|Perempuan|A|Tokyo|12/21|Tokyo|Tokyo|Unknown|Single|Pelajar|Jepang|SEUMUR HIDUP|12-12-2025`
				);
			}

			const params = {
				provinsi,
				kota,
				nik,
				nama,
				ttl,
				jenis_kelamin,
				golongan_darah,
				alamat,
				rt_rw,
				kel_desa,
				kecamatan,
				agama,
				status,
				pekerjaan,
				kewarganegaraan,
				masa_berlaku,
				terbuat,
				pas_photo: pasPhotoURL
			};
			let result = await generateEKTP(params);

			if (!result.success) {
				return reply(`❌ API Error:\n${result.error}`);
			}

			await satanic.sendMessage(
				m.chat,
				{
					image: result.buffer,
					caption: `🪪 *eKTP Berhasil Dibuat!*\n\n👤 Nama: *${nama}*\n🆔 NIK: *${nik}*`
				},
				{ quoted: m }
			);

		} catch (e) {
			reply(`❌ Error:\n${e.message}`);
		}
	}
	break;
case 'fakedana': {
if (!text) {
        return reply(`💳 *FAKE DANA MAKER*

Contoh:
${prefix + command} 1000000`)
    }

    await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })    

    let skia
    try {
        skia = require('skia-canvas')
    } catch {
        await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
        return reply("❌ Install dulu: npm install skia-canvas")
    }

    const { Canvas, loadImage, FontLibrary } = skia

    const fontDir = path.resolve(process.cwd(), 'lib')
    if (!fs.existsSync(fontDir)) fs.mkdirSync(fontDir, { recursive: true })

    const fontPath = path.join(fontDir, 'DanaFont.otf')

    try {
        if (!fs.existsSync(fontPath)) {
            let f = await axios.get('https://s.id/tvNgt', { responseType: 'arraybuffer' })
            fs.writeFileSync(fontPath, Buffer.from(f.data))
        }
        FontLibrary.use('DanaFont', fontPath)
    } catch {
        return reply('❌ Gagal load font!')
    }

    try {
        let angkaRaw = text.replace(/[^0-9]/g, '')
        if (!angkaRaw) return reply('❌ Nominal tidak valid!')

        let angka = Number(angkaRaw).toLocaleString('id-ID')

        const bgUrl = 'https://raw.githubusercontent.com/uploader762/dat3/main/uploads/9c18e0-1772932032348.jpg'
        const logoUrl = 'https://raw.githubusercontent.com/uploader762/dat3/main/uploads/d0f081-1772929197100.png'

        const bg = await loadImage(bgUrl)
        const logo = await loadImage(logoUrl)

        const canvas = new Canvas(bg.width, bg.height)
        const ctx = canvas.getContext('2d')

        ctx.drawImage(bg, 0, 0)

        ctx.font = '205px DanaFont'
        ctx.fillStyle = '#ffffff'
        ctx.textBaseline = 'top'

        const x = 664
        const y = 293

        ctx.fillText(angka, x, y)

        const textWidth = ctx.measureText(angka).width
        const logoSize = 370

        ctx.drawImage(
            logo,
            x + textWidth + 11,
            y - 31,
            logoSize,
            logoSize
        )

        const buffer = await canvas.png

        const tanggal = new Date().toLocaleDateString('id-ID', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        })

        await satanic.sendMessage(m.chat, {
            image: buffer,
            caption: `💳 *FAKE DANA*

💰 Nominal : Rp ${angka}
✅ Status  : Sukses`
        }, { quoted: m })

        await satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } })

    } catch (e) {
        console.error(e)
        await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
        reply(`❌ Error:\n${e.message}`)
    }
}
break
case 'fakebangjago': {
if (!text || !text.includes(',')) {
        return reply(`❌ *Format salah!*

Contoh:
${prefix + command} Ryuu, 1000000`)
    }
     await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })    
    let skia
    try {
        skia = require('skia-canvas')
    } catch (e) {
        return reply('❌ Module *skia-canvas* belum terinstall!\n\nKetik di panel:\n```npm install skia-canvas```')
    }

    const { Canvas, loadImage, FontLibrary } = skia

    async function ensureFile(url, file) {
        const dir = path.dirname(file)
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

        if (!fs.existsSync(file)) {
            const res = await axios.get(url, { responseType: 'arraybuffer' })
            fs.writeFileSync(file, res.data)
        }
    }

    async function generateImage(saldo, greet) {
        const bgUrl = "https://raw.githubusercontent.com/uploader762/dat2/main/uploads/52e39f-1773064858080.jpg"
        const fontUrl = "https://raw.githubusercontent.com/uploader762/dat2/main/uploads/49bbd8-1773045557233.otf"
        const font2Url = "https://raw.githubusercontent.com/uploader762/dat1/main/uploads/203827-1773063086445.ttf"

        const font1 = "./media/fonts/ceraroundpro-medium.otf"
        const font2 = "./media/fonts/Roboto_Medium.ttf"

        await ensureFile(fontUrl, font1)
        await ensureFile(font2Url, font2)

        FontLibrary.use("CustomFont", font1)
        FontLibrary.use("GreetingFont", font2)

        const bgRes = await axios.get(bgUrl, { responseType: 'arraybuffer' })
        const bg = await loadImage(bgRes.data)

        const canvas = new Canvas(bg.width, bg.height)
        const ctx = canvas.getContext("2d")

        ctx.drawImage(bg, 0, 0, bg.width, bg.height)

        ctx.font = "125px CustomFont"
        ctx.fillStyle = "black"

        const numberWidth = ctx.measureText(saldo).width
        const numberX = 2470 - numberWidth

        ctx.fillText(saldo, numberX, 894)

        const rpWidth = ctx.measureText("Rp").width
        const rpX = numberX - rpWidth - 4

        ctx.fillText("Rp", rpX, 894)

        ctx.font = "93px GreetingFont"
        ctx.fillStyle = "gray"
        ctx.fillText(greet, 98, 86)

        return await canvas.toBuffer("image/png")
    }

    try {
        const args = text.split(',')
        const nama = args[0].trim()
        const saldoRaw = args[1].trim()

        const saldo = Number(saldoRaw.replace(/[^0-9]/g, ''))
            .toLocaleString('id-ID')

        const moment = require('moment-timezone')
        const h = parseInt(moment.tz('Asia/Jakarta').format('HH'))

        let waktu = 'Malam'
        if (h >= 4 && h < 11) waktu = 'Pagi'
        else if (h >= 11 && h < 15) waktu = 'Siang'
        else if (h >= 15 && h < 18) waktu = 'Sore'

        const buffer = await generateImage(
            saldo,
            `Selamat ${waktu}, ${nama}`
        )
        await satanic.sendMessage(m.chat, {
            image: buffer,
            caption: `🎨 *Fake Saldo bank Jago Berhasil Dibuat!*`
        }, { quoted: m })

        await satanic.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        })

    } catch (err) {
        console.error(err)

        await satanic.sendMessage(m.chat, {
            react: { text: "❌", key: m.key }
        })

        reply('❌ Gagal membuat gambar.')
    }
}
break
case 'qc': {
  if (!text) return reply('teksnya')
 const sender = m.sender
const username = await satanic.getName(m.quoted ? m.quoted.sender : sender)
const avatar = await satanic.profilePictureUrl(m.quoted ? m.quoted.sender : sender, "image").catch(() => 'https://8030.us.kg/file/P2LpaOHxWlJt.jpg')
  const qchat = `https://newcodingproject.vercel.app/api/qc?text=${encodeURIComponent(text)}&name=${encodeURIComponent(username)}&ppurl=${encodeURIComponent(avatar)}&apikey=${global.sakey}`
  const response = await axios.get(qchat, { responseType: 'arraybuffer' })
  await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname })
}
break
case 'bratvid':
case 'bratvideo': {
  if (!text) return reply('Mana Text Nya')
  var image = `https://skyzxu-brat.hf.space/brat-animated?text=${encodeURIComponent(text)}`
  const response = await axios.get(image, { responseType: 'arraybuffer' })
  await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: foother })
  satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
break
/////////download menu//////
case 'ttmp3':
case 'tiktokmp3': {
    if (!text) return reply('Masukkan URL TikTok!\n\nContoh: .ttmp3 https://www.tiktok.com/@username/video/xxx');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://newcodingproject.vercel.app/api/ttdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl);
    
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari TikTok');
    }
    
    const result = response.data.result;
    const videoUrl = result.videos.find(v => v.type === 'nowatermark')?.url || result.videos[0]?.url;
    
    await satanic.sendMessage(m.chat, { 
        audio: { url: videoUrl },
        mimetype: 'audio/mpeg'
    }, { quoted: m });
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'igmp3':
case 'igaudio': {
    if (!text) return reply('Masukkan URL Instagram reels/video!\n\nContoh: .igmp3 https://www.instagram.com/reel/xxx');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const endpoint = `https://free-restapi.biz.id/api/igdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const hasil = await axios.get(endpoint);
        
        if (hasil.data.status !== 200) {
            return reply('Gagal mengambil data dari Instagram');
        }
        
        const datas = hasil.data;
        const videoUrl = datas.url?.[0];
        const metadata = datas.metadata;
        
        if (!videoUrl) {
            return reply('Tidak ada video yang ditemukan');
        }
        
        if (!metadata?.isVideo) {
            return reply('URL ini bukan video!');
        }
        
        // Download video dulu
        const videoBuffer = await axios.get(videoUrl, { responseType: 'arraybuffer' });
        
        // Convert ke audio (pake API eksternal atau ffmpeg)
        // Sementara pakai API konversi
        const audioUrl = `https://api.audioconverter.io/convert?url=${encodeURIComponent(videoUrl)}`;
        
        let info = `🎵 *INSTAGRAM TO MP3*\n\n`;
        info += `👤 *Username:* ${metadata?.username || '-'}\n`;
        info += `❤️ *Like:* ${metadata?.like?.toLocaleString() || '-'}\n`;
        info += `💬 *Comment:* ${metadata?.comment?.toLocaleString() || '-'}\n`;
        if (metadata?.caption) {
            info += `📝 *Caption:* ${metadata.caption.substring(0, 100)}${metadata.caption.length > 100 ? '...' : ''}\n`;
        }
        info += `\n📥 *Project By:* ${namaBot}`;
        
        // Kirim audio
        await satanic.sendMessage(m.chat, { 
            audio: videoBuffer.data,
            mimetype: 'audio/mpeg',
            caption: info
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengkonversi video ke audio.');
    }
}
break;

case 'ttslide':
case 'tiktokslide': {
    if (!text) return reply('Masukkan URL TikTok slide/photo!\n\nContoh: .ttslide https://www.tiktok.com/@username/video/xxx');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const endpoint = `https://free-restapi.biz.id/api/ttdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const hasil = await axios.get(endpoint);
        
        if (hasil.data.status !== 200) {
            return reply('Gagal mengambil data dari TikTok');
        }
        
        const datas = hasil.data;
        const result = datas.result;
        
        if (!result.videos || result.videos.length === 0) {
            return reply('Tidak ada foto/video yang ditemukan');
        }
        
        // Filter hanya photo
        const photos = result.videos.filter(v => v.type === 'photo');
        
        if (photos.length === 0) {
            return reply('Tidak ada slide foto yang ditemukan');
        }
        
        let daftarCard = await Promise.all(photos.map(async (photo, index) => {
            const mediaFoto = await prepareWAMessageMedia({ 
                image: { url: photo.url } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            
            const keterangan = `📸 *Slide ${index+1} dari ${photos.length}*\n\n📝 Title: ${result.title || '-'}\n👤 Author: ${result.author?.nickname || '-'} (@${result.author?.id || '-'})\n❤️ Likes: ${result.stats?.likes?.toLocaleString() || '-'}\n💬 Comments: ${result.stats?.comment?.toLocaleString() || '-'}\n📨 Shares: ${result.stats?.share?.toLocaleString() || '-'}`;
            
            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...mediaFoto,
                    title: '',
                    subtitle: `Slide ${index+1}`,
                    hasMediaAttachment: true
                }),
                body: { text: keterangan },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📥 Download",
                            url: photo.url
                        })
                    }]
                }
            };
        }));
        
        let pesan = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `🎵 TikTok Slide dari @${result.author?.id || 'user'}` },
                            carouselMessage: {
                                cards: daftarCard,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: m }
        );
        
        await satanic.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data TikTok.');
    }
}
break;
case 'igphoto':
case 'igslide': {
    if (!text) return reply('Masukkan URL Instagram slide!\n\nContoh: .igslid https://www.instagram.com/p/xxx');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const endpoint = `https://free-restapi.biz.id/api/igdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const hasil = await axios.get(endpoint);
        
        if (hasil.data.status !== 200) {
            return reply('Gagal mengambil data dari Instagram');
        }
        
        const datas = hasil.data;
        const mediaUrls = datas.url;
        const infoAkun = datas.metadata;
        
        if (!mediaUrls || mediaUrls.length === 0) {
            return reply('Tidak ada gambar slide yang ditemukan');
        }
        
        const hanyaGambar = mediaUrls.filter(url => !infoAkun?.isVideo);
        
        if (hanyaGambar.length === 0) {
            return reply('Tidak ada gambar slide yang ditemukan');
        }
        
        let daftarCard = await Promise.all(hanyaGambar.map(async (gambar, index) => {
            const mediaGambar = await prepareWAMessageMedia({ 
                image: { url: gambar } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            
            const keterangan = `📸 *Slide ${index+1} dari ${hanyaGambar.length}*\n\n👤 Username: ${infoAkun?.username || '-'}\n❤️ Like: ${infoAkun?.like?.toLocaleString() || '-'}\n💬 Comment: ${infoAkun?.comment?.toLocaleString() || '-'}`;
            
            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...mediaGambar,
                    title: '',
                    subtitle: `Slide ${index+1}`,
                    hasMediaAttachment: true
                }),
                body: { text: keterangan },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📥 Download",
                            url: gambar
                        })
                    }]
                }
            };
        }));
        
        let pesan = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `📸 Instagram Slide dari @${infoAkun?.username || 'user'}` },
                            carouselMessage: {
                                cards: daftarCard,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: m }
        );
        
        await satanic.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data Instagram.');
    }
}
break;
case 'igdl':
case 'ig': {
    if (!text) return reply('Masukkan URL Instagramnya!\n\nContoh: .ig https://www.instagram.com/reel/xxx')
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    const apiUrl = `https://newcodingproject.vercel.app/api/igdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari Instagram')
    }
    const data = response.data
    const urls = data.url
    const metadata = data.metadata
    if (!metadata.isVideo) {
        return reply('URL ini bukan video Instagram (hanya support video)')
    }
    let info = `INSTAGRAM VIDEO DOWNLOADER\n\n`
    info += `Username: ${metadata.username}\n`
    info += `Like: ${metadata.like}\n`
    info += `Comment: ${metadata.comment}\n`    
    info += `Project By: ${global.namaBot}`
    
    for (let url of urls) {
        await satanic.sendMessage(m.chat, { 
            video: { url: url }, 
            caption: info 
        }, { quoted: m })
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'tt':
case 'ttdl':
case 'tiktok':
case 'tiktokdl': {
    if (!text) return reply('Masukkan URL TikToknya!\n\nContoh: .tt https://www.tiktok.com/@username/video/xxx')
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    const apiUrl = `https://newcodingproject.vercel.app/api/ttdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari TikTok')
    }
    const result = response.data.result
    let info = `TIKTOK DOWNLOADER\n\n`
    info += `Title: ${result.title}\n`
    info += `Duration: ${result.duration}\n`
    info += `Region: ${result.region}\n`
    info += `Taken At: ${result.taken_at}\n\n`
    info += `AUTHOR\n`
    info += `Nickname: ${result.author.nickname}\n`
    info += `Username: ${result.author.id}\n\n`
    info += `STATS\n`
    info += `Views: ${result.stats.views}\n`
    info += `Likes: ${result.stats.likes}\n`
    info += `Comments: ${result.stats.comment}\n`
    info += `Shares: ${result.stats.share}\n`
    info += `Downloads: ${result.stats.download}\n\n`
    info += `Project By: ${global.namaBot}`
    const videoUrl = result.videos.find(v => v.type === 'nowatermark')?.url || result.videos[0]?.url
    await satanic.sendMessage(m.chat, { 
        video: { url: videoUrl }, 
        caption: info 
    }, { quoted: m })
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'capcut':
case 'cc': {
    if (!text) return reply('Masukkan URL CapCutnya!\n\nContoh: .capcut https://www.capcut.com/t/xxx')
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const apiUrl = `https://newcodingproject.vercel.app/api/capcut?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    if (!response.data.success) {
        return reply('Gagal mengambil data dari CapCut')
    }
    const result = response.data
    let info = `CAPCUT DOWNLOADER\n\n`
    info += `Title: ${result.title}\n`
    info += `Author: ${result.author}\n`
    info += `Project By: ${namaBot}`
    
    await satanic.sendMessage(m.chat, { 
        video: { url: result.videoUrl }, 
        caption: info 
    }, { quoted: m })
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'xnxxdl': {
async function xnxxdl(URL) {
  return new Promise((resolve, reject) => {
    fetch(`${URL}`, {method: 'get'}).then((res) => res.text()).then((res) => {
      const $ = cheerio.load(res, {xmlMode: false});
      const title = $('meta[property="og:title"]').attr('content');
      const duration = $('meta[property="og:duration"]').attr('content');
      const image = $('meta[property="og:image"]').attr('content');
      const videoType = $('meta[property="og:video:type"]').attr('content');
      const videoWidth = $('meta[property="og:video:width"]').attr('content');
      const videoHeight = $('meta[property="og:video:height"]').attr('content');
      const info = $('span.metadata').text();
      const videoScript = $('#video-player-bg > script:nth-child(6)').html();
      const files = {
        low: (videoScript.match('html5player.setVideoUrlLow\\(\'(.*?)\'\\);') || [])[1],
        high: videoScript.match('html5player.setVideoUrlHigh\\(\'(.*?)\'\\);' || [])[1],
        HLS: videoScript.match('html5player.setVideoHLS\\(\'(.*?)\'\\);' || [])[1],
        thumb: videoScript.match('html5player.setThumbUrl\\(\'(.*?)\'\\);' || [])[1],
        thumb69: videoScript.match('html5player.setThumbUrl169\\(\'(.*?)\'\\);' || [])[1],
        thumbSlide: videoScript.match('html5player.setThumbSlide\\(\'(.*?)\'\\);' || [])[1],
        thumbSlideBig: videoScript.match('html5player.setThumbSlideBig\\(\'(.*?)\'\\);' || [])[1]};
      resolve({status: 200, result: {title, URL, duration, image, videoType, videoWidth, videoHeight, info, files}});
    }).catch((err) => reject({code: 503, status: false, result: err}));
  });
}  
if (!text) return reply(`masukan url? `)
try {
let dlbkp = await xnxxdl(text)
let dno = `done`
return satanic.sendMessage(m.chat, {video: { url: dlbkp.result.files.high}, caption: dno}, {quoted: m})
} catch(e) {
console.error(e)
return reply(`error`)
}
break
}

case 'xvideodl': {
async function xvideosdl(url) {
  return new Promise((resolve, reject) => {
    fetch(`${url}`, { method: 'get' })
      .then(res => res.text())
      .then(res => {
        let $ = cheerio.load(res, { xmlMode: false });
        const title = $("meta[property='og:title']").attr("content")
        const keyword = $("meta[name='keywords']").attr("content")
        const views = $("div#video-tabs > div > div > div > div > strong.mobile-hide").text() + " views"
        const vote = $("div.rate-infos > span.rating-total-txt").text()
        const likes = $("span.rating-good-nbr").text()
        const deslikes = $("span.rating-bad-nbr").text()
        const thumb = $("meta[property='og:image']").attr("content")
        const url = $("#html5video > #html5video_base > div > a").attr("href")
        resolve({ status: 200, result: { title, url, keyword, views, vote, likes, deslikes, thumb } })
      })
  })
};
if (!text) return reply(`masukan url? `)
try {
let dlbkpl = await xvideosdl(text)
let dnol = `done`
return satanic.sendMessage(m.chat, {video: { url: dlbkpl.result.url}, caption: dnol}, {quoted: m})
} catch(e) {
console.error(e)
return reply(`error`)
}
break
}
case 'terabox':
case 'tb': {
    if (!text) return reply('Masukkan URL Teraboxnya!\n\nContoh: .terabox https://www.terabox.com/xxx')
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const apiUrl = `https://newcodingproject.vercel.app/api/terabox?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari Terabox')
    }
    const result = response.data.result
    const file = result.list[0]
    let info = `TERABOX DOWNLOADER\n\n`
    info += `Name: ${file.name}\n`
    info += `Size: ${file.size_formatted}\n`
    info += `Type: ${file.type}\n`
    info += `Duration: ${file.duration}\n`
    info += `Quality: ${file.quality}\n`
    info += `Project By: ${namaBot}`
    const zipUrl = file.zip_dlink
    await satanic.sendMessage(m.chat, { 
        document: { url: zipUrl }, 
        mimetype: 'application/zip',
        fileName: `${file.name}.zip`,
        caption: info 
    }, { quoted: m })
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'tourl': {
    if (!quoted) return reply('Reply media (foto/video/file) yang ingin diupload.');

    const FormData = require("form-data");
    const mime = require("mime-types");
    const fs = require("fs");
    const path = require("path");
    const { fromBuffer } = require("file-type");
    const axios = require("axios");
    const cheerio = require("cheerio");

    // === CONFIG UNTUK TERMAI API ===
    const termaiKey = "AIzaBj7z2z3xBjsk"; // jangan diganti
    const termaiDomain = 'https://c.termai.cc';

    // === CONFIG UNTUK IMGBB ===
    const imgbbApiKey = '06fd47f20c573d4795a47af91f081932';

    async function uploadTermai(fileBuffer) {
        try {
            const { ext } = await fromBuffer(fileBuffer);
            const formData = new FormData();
            formData.append('file', fileBuffer, { filename: 'file.' + ext });

            const res = await axios.post(`${termaiDomain}/api/upload?key=${termaiKey}`, formData, {
                headers: formData.getHeaders(),
                timeout: 120000
            });

            if (res.data && res.data.status && res.data.path) {
                return res.data.path;
            }
            throw new Error("Upload ke Termai gagal");
        } catch (err) {
            console.error("Termai Error:", err.message);
            return null;
        }
    }

    // Upload ke qu.ax
    async function pomf2(filePath) {
        try {
            if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan");
            const contentType = mime.lookup(filePath) || "application/octet-stream";
            const fileName = path.basename(filePath);
            const form = new FormData();
            form.append("files[]", fs.createReadStream(filePath), {
                contentType,
                filename: fileName,
            });
            const response = await axios.post("https://qu.ax/upload.php", form, {
                headers: { ...form.getHeaders() },
            });
            if (!response.data.success || !response.data.files?.length) throw new Error("Upload ke qu.ax gagal");
            return response.data.files[0].url;
        } catch (err) {
            console.error("Pomf2 Error:", err.message);
            return null;
        }
    }

    // Upload ke tmpfiles.org
    async function uploadTmpFiles(filePath) {
        try {
            if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan");
            const form = new FormData();
            form.append("file", fs.createReadStream(filePath));
            const res = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
                headers: form.getHeaders(),
                timeout: 120000
            });
            if (res.data && res.data.data && res.data.data.url) {
                const idMatch = res.data.data.url.match(/\/(\d+)(?:\/|$)/);
                const fileName = path.basename(filePath);
                if (idMatch) {
                    return `https://tmpfiles.org/dl/${idMatch[1]}/${fileName}`;
                }
            }
            throw new Error("Upload ke tmpfiles.org gagal");
        } catch (err) {
            console.error("TmpFiles Error:", err.message);
            return null;
        }
    }

    // Upload ke put.icu
    async function uploadPutIcu(filePath) {
        try {
            if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan");
            const contentType = mime.lookup(filePath) || "application/octet-stream";
            const res = await axios.put(`https://put.icu/upload/`, fs.createReadStream(filePath), {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': contentType
                },
                maxBodyLength: Infinity,
                maxContentLength: Infinity,
                timeout: 120000
            });
            if (res.data && res.data.direct_url) {
                return res.data.direct_url;
            }
            if (res.data && res.data.url) {
                return res.data.url;
            }
            throw new Error("Upload ke put.icu gagal");
        } catch (err) {
            console.error("PutIcu Error:", err.message);
            return null;
        }
    }

    // Upload ke uguu.se
    async function uploadUgu(filePath) {
        try {
            const form = new FormData();
            form.append("files[]", fs.createReadStream(filePath));
            
            const response = await axios.post("https://uguu.se/upload.php", form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                },
                timeout: 120000
            });
            
            if (response.data && response.data.success && response.data.files && response.data.files[0]) {
                return response.data.files[0].url;
            }
            throw new Error("Upload ke uguu.se gagal");
        } catch (err) {
            console.error("Ugu Error:", err.message);
            return null;
        }
    }

    // Upload ke upload.ee
    async function uploadUploadEE(filePath) {
        try {
            const baseUrl = "https://www.upload.ee";
            
            const response = await axios.get(`${baseUrl}/ubr_link_upload.php?rnd_id=${Date.now()}`);
            const uploadId = (response.data.match(/startUpload\("(.+?)"/) || [])[1];
            if (!uploadId) throw new Error("Unable to obtain Upload ID");

            const formData = new FormData();
            formData.append("upfile_0", fs.createReadStream(filePath));
            formData.append("link", "");
            formData.append("email", "");
            formData.append("category", "cat_file");
            formData.append("big_resize", "none");
            formData.append("small_resize", "120x90");

            const uploadResponse = await axios.post(`${baseUrl}/cgi-bin/ubr_upload.pl?X-Progress-ID=${encodeURIComponent(uploadId)}&upload_id=${encodeURIComponent(uploadId)}`, formData, {
                headers: {
                    ...formData.getHeaders(),
                    Referer: baseUrl
                },
                timeout: 120000
            });

            const firstData = uploadResponse.data;
            const $ = cheerio.load(firstData);
            const viewUrl = $("input#file_src").val() || "";
            if (!viewUrl) throw new Error("File upload failed");

            const viewResponse = await axios.get(viewUrl);
            const finalData = viewResponse.data;
            const downUrl = cheerio.load(finalData)("#d_l").attr("href") || "";
            if (!downUrl) throw new Error("File upload failed");

            return downUrl;
        } catch (error) {
            console.error("UploadEE Error:", error.message);
            return null;
        }
    }

    // Upload ke ImgBB
    async function uploadToImgBB(filePath) {
        try {
            if (!fs.existsSync(filePath)) {
                throw new Error("File not found");
            }

            const form = new FormData();
            form.append('image', fs.createReadStream(filePath));

            const response = await axios.post(`https://api.imgbb.com/1/upload?key=${imgbbApiKey}`, form, {
                headers: {
                    ...form.getHeaders()
                },
                timeout: 120000
            });

            if (response.status === 200 && response.data.data && response.data.data.url) {
                return response.data.data.url;
            } else {
                throw new Error(`Upload failed with status: ${response.status}`);
            }
        } catch (err) {
            console.error("ImgBB Error:", err.message);
            return null;
        }
    }

    // Upload ke Litterbox.catbox.moe
    async function uploadToLitterbox(fileBuffer, filename) {
        try {
            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('time', '72h');
            form.append('fileToUpload', fileBuffer, {
                filename: filename,
                contentType: mime.lookup(filename) || 'application/octet-stream'
            });

            const response = await axios.post('https://litterbox.catbox.moe/resources/internals/api.php', form, {
                headers: form.getHeaders(),
                timeout: 30000
            });

            if (response.status !== 200) throw new Error('Litterbox gagal');
            const url = response.data;
            if (!url.startsWith('http')) throw new Error('Invalid response');
            return { host: 'Litterbox', url, expires: '72 jam' };
        } catch (err) {
            console.error("Litterbox Error:", err.message);
            return null;
        }
    }

    try {
        const media = await satanic.downloadAndSaveMediaMessage(quoted);
        const buffer = fs.readFileSync(media);
        const { ext } = await fromBuffer(buffer) || {};
        const filename = `file_${Date.now()}.${ext || 'bin'}`;

        let [quaxLink, tmpFilesLink, putIcuLink, termaiLink, uguLink, uploadEELink, imgbbLink, litterboxResult] = await Promise.all([
            pomf2(media),
            uploadTmpFiles(media),
            uploadPutIcu(media),
            uploadTermai(buffer),
            uploadUgu(media),
            uploadUploadEE(media),
            uploadToImgBB(media),
            uploadToLitterbox(buffer, filename)
        ]);

        const litterboxLink = litterboxResult ? litterboxResult.url : null;
        const litterboxExpiry = litterboxResult ? litterboxResult.expires : null;

        if (!quaxLink && !tmpFilesLink && !putIcuLink && !termaiLink && !uguLink && !uploadEELink && !imgbbLink && !litterboxLink) {
            throw new Error("Semua uploader gagal");
        }

        const formatLink = (link) => link ? link : 'Down / Bermasalah';

        let caption = `╭─ 「 UPLOAD SUCCESS 」
📂 Size: ${(buffer.length / 1024).toFixed(2)} KB
🌍 Qu.ax: ${formatLink(quaxLink)}
🌍 TmpFiles: ${formatLink(tmpFilesLink)} ( *60* Minutes )
🌍 Put.icu: ${formatLink(putIcuLink)} ( *1* Days )
🌍 Termai: ${formatLink(termaiLink)}
🌍 Uguu.se: ${formatLink(uguLink)}
🌍 Upload.ee: ${formatLink(uploadEELink)}
🌍 ImgBB: ${formatLink(imgbbLink)}
🌍 Litterbox: ${formatLink(litterboxLink)} ${litterboxExpiry ? `( *${litterboxExpiry}* )` : ''}
╰───────────────`;

        let msg = {
            interactiveMessage: proto.Message.InteractiveMessage.create({
                header: proto.Message.InteractiveMessage.Header.create({
                    hasMediaAttachment: false
                }),
                body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: "Tekan tombol di bawah untuk menyalin tautan."
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [
                        ...(quaxLink ? [{ name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Link qu.ax", copy_code: quaxLink }) }] : []),
                        ...(tmpFilesLink ? [{ name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Link TmpFiles", copy_code: tmpFilesLink }) }] : []),
                        ...(putIcuLink ? [{ name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Link Put.icu", copy_code: putIcuLink }) }] : []),
                        ...(termaiLink ? [{ name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Link Termai", copy_code: termaiLink }) }] : []),
                        ...(uguLink ? [{ name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Link Uguu.se", copy_code: uguLink }) }] : []),
                        ...(uploadEELink ? [{ name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Link Upload.ee", copy_code: uploadEELink }) }] : []),
                        ...(imgbbLink ? [{ name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Link ImgBB", copy_code: imgbbLink }) }] : []),
                        ...(litterboxLink ? [{ name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Link Litterbox", copy_code: litterboxLink }) }] : []),
                    ]
                })
            })
        };

        await satanic.relayMessage(m.chat, msg, { messageId: m.key.id });
        fs.unlinkSync(media);
    } catch (err) {
        reply(`❌ Gagal: ${err.message}`);
    }
}
break;
case 'spotify':
case 'sp': {
    if (!text) return reply('Masukkan URL Spotifynya!\n\nContoh: .spotify https://open.spotify.com/track/xxx')
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    const apiUrl = `https://newcodingproject.vercel.app/api/spotify?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' })
    
    await satanic.sendMessage(m.chat, { 
        audio: response.data, 
        mimetype: 'audio/mpeg'
    }, { quoted: m })
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'fbdl':
case 'fb': {
    if (!text) return reply('Masukkan URL Facebooknya!\n\nContoh: .fb https://www.facebook.com/xxx')
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    const apiUrl = `https://newcodingproject.vercel.app/api/fbdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari Facebook')
    }
    
    const result = response.data.result
    
    let info = `FACEBOOK DOWNLOADER\n\n`
    info += `Title: ${result.title}\n`
    info += `Project By: ${namaBot}`
    
    await satanic.sendMessage(m.chat, { 
        video: { url: result.hd }, 
        caption: info 
    }, { quoted: m })
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'videydl':
case 'videy': {
  async function videydl(url) {
    try {
      const objcturl = new URL(url);
      const videoId = objcturl.searchParams.get('id');

      if (!videoId) throw new Error('Invalid Videy URL');

      const ext = videoId.length === 9 && videoId[8] === '2' ? '.mov' : '.mp4';
      const urlvideo = `https://cdn.videy.co/${videoId}${ext}`;

      return urlvideo;
    } catch (error) {
      throw new Error(`Download failed: ${error.message}`);
    }
  }

  // Ambil URL dari reply atau dari teks command
  let url = text || (m.quoted && m.quoted.text);
  
  if (!url) {
    return m.reply(`⚠️ *Cara penggunaan:*\n\nKirim link Videy:\n>.videy https://videy.co/xxx\n\nAtau reply pesan yang berisi link Videy`);
  }



  try {
    await m.reply('⏳ *Mengunduh video...*');

    const videoUrl = await videydl(url);
    
    await satanic.sendMessage(m.chat, {
      video: { url: videoUrl },
      caption: `> *Video berhasil diunduh*\n🔗 Link: ${url}`
    }, { quoted: m });
    
  } catch (error) {
    console.error('[Videy Error]:', error);
    m.reply(`❌ *Gagal mengunduh:*\n${error.message}`);
  }
  break;
}
case 'twitter':
case 'tw':
case 'x': {
    if (!text) return reply('Masukkan URL Twitter/X nya!\n\nContoh: .twitter https://twitter.com/xxx/status/xxx')
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    const apiUrl = `https://free-restapi.biz.id/api/twitter?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari Twitter')
    }
    const result = response.data.result
    if (result.type !== 'video') {
        return reply('URL ini bukan video Twitter')
    }
    const videoUrl = result.variants[0]
    await satanic.sendMessage(m.chat, { 
        video: { url: videoUrl },
        caption: result.full_text ? result.full_text : ''
    }, { quoted: m })
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'scdl':
case 'soundcloud': {
    if (!text) return reply('Masukkan URL SoundCloudnya!\n\nContoh: .scdl https://soundcloud.com/xxx/xxx')
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    const apiUrl = `https://free-restapi.biz.id/api/scdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    
    if (!response.data.success) {
        return reply('Gagal mengambil data dari SoundCloud')
    }
    
    const result = response.data
    const audioUrl = result.audioUrl
    const title = result.title
    
    // Download audio terlebih dahulu sebagai buffer
    const audioBuffer = await axios.get(audioUrl, { 
        responseType: 'arraybuffer'
    })
    
    await satanic.sendMessage(m.chat, { 
        audio: audioBuffer.data,
        mimetype: 'audio/mpeg',
        fileName: `${title}.mp3`
    }, { quoted: m })
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'cocofun':
case 'coco': {
    if (!text) return reply('Masukkan URL Cocofunnya!\n\nContoh: .cocofun https://www.cocofun.com/xxx')
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    const apiUrl = `https://free-restapi.biz.id/api/cocofun?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    
    if (!response.data.success) {
        return reply('Gagal mengambil data dari Cocofun')
    }
    
    const result = response.data
    
    let info = `COCOFUN DOWNLOADER\n\n`
    info += `Topic: ${result.topic}\n`
    info += `Caption: ${result.caption}\n`
    info += `Duration: ${result.statistic.duration} detik\n`
    info += `Play: ${result.statistic.play}\n`
    info += `Like: ${result.statistic.like}\n`
    info += `Share: ${result.statistic.share}\n`
    info += `Project By: ${namaBot}`
    
    const videoUrl = result.videoUrl || result.watermark
    
    await satanic.sendMessage(m.chat, { 
        video: { url: videoUrl },
        caption: info
    }, { quoted: m })
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'threads':
case 'th': {
    if (!text) return reply('Masukkan URL Threadsnya!\n\nContoh: .threads https://www.threads.net/@username/post/id')
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    const apiUrl = `https://free-restapi.biz.id/api/threads?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari Threads')
    }
    
    const result = response.data.result
    
    let info = `THREADS DOWNLOADER\n\n`
    info += `Username: ${result.user.username}\n`
    info += `Text: ${result.text}\n`
    info += `Project By: ${namaBot}`
    
    // Jika ada video, kirim langsung tanpa button
    if (result.videos && result.videos.length > 0) {
        for (let i = 0; i < result.videos.length; i++) {
            let videoUrl = result.videos[i]
            await satanic.sendMessage(m.chat, { 
                video: { url: videoUrl },
                caption: info
            }, { quoted: m })
        }
    }
    
    // Jika ada gambar, pake button carousel
    if (result.images && result.images.length > 0) {
        let selectedImages = result.images.slice(0, 10);
        let anu = []
        
        for (let i = 0; i < selectedImages.length; i++) {
            let imgUrl = selectedImages[i][0].url
            let imgsc = await prepareWAMessageMedia({
                image: { url: imgUrl }
            }, {
                upload: satanic.waUploadToServer
            })

            anu.push({
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: `Gambar ke *${i + 1}*`,
                    hasMediaAttachment: true,
                    ...imgsc
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Lihat di Threads",
                            url: result.url
                        })
                    }]
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: info
                })
            })
        }
        
        const msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `📱 Hasil Threads dari @${result.user.username}`
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: anu
                        })
                    })
                }
            }
        }, {
            userJid: sender,
            quoted: m
        })
        satanic.relayMessage(m.chat, msg.message, {
            messageId: msg.key.id
        })
    }
    
    if (!result.videos && !result.images) {
        return reply('Tidak ada video atau gambar yang ditemukan')
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'snackvideo':
async function snackvideo(url) {
  let data = qs.stringify({
    'ic-request': 'true',
    'id': url,
    'locale': 'id',
    'ic-element-id': 'main_page_form',
    'ic-id': '1',
    'ic-target-id': 'active_container',
    'ic-trigger-id': 'main_page_form',
    'ic-current-url': '/id/how-to-download-snack-video',
    'ic-select-from-response': '#id1',
    '_method': 'POST'
  });

  let config = {
    method: 'POST',
    url: 'https://getsnackvideo.com/results',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 8.1.0; CPH1803; Build/OPM1.171019.026) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.4280.141 Mobile Safari/537.36 KiToBrowser/124.0',
      'Accept': 'text/html-partial, */*; q=0.9',
      'accept-language': 'id-ID',
      'referer': 'https://getsnackvideo.com/id/how-to-download-snack-video',
      'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'x-ic-request': 'true',
      'x-http-method-override': 'POST',
      'x-requested-with': 'XMLHttpRequest',
      'origin': 'https://getsnackvideo.com',
      'alt-used': 'getsnackvideo.com',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'priority': 'u=0',
      'te': 'trailers',
      'Cookie': '_ga_TBLWJYRGPZ=GS1.1.1736227224.1.1.1736227279.0.0.0; _ga=GA1.1.1194697262.1736227224'
    },
    data: data
  };

  try {
    const response = await axios.request(config);
    const $ = cheerio.load(response.data);
    const downloadUrl = $('.download_link.without_watermark').attr('href');
    const thumbnail = $('.img_thumb img').attr('src');
    return {
      thumbnail: thumbnail || 'Thumbnail not found',
      downloadUrl: downloadUrl || 'Download URL not found'
    };
  } catch (error) {
    console.error('Error:', error);
  }
}
  if (!text) return reply('masukan link SnackVideo')
  
  try {
    const resultn = await snackvideo(text)
    if (!resultn?.downloadUrl) return reply('❌ Gagal mengambil video')

    // Download video dulu
    const videoRes = await axios.get(resultn.downloadUrl, { 
      responseType: 'arraybuffer',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; RMX2185 Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.60 Mobile Safari/537.36',
        'Referer': 'https://www.snackvideo.com/'
      }
    })

    await satanic.sendMessage(m.chat, { 
      video: Buffer.from(videoRes.data),
      caption: '✅ *Video Snack berhasil didownload*'
    }, { quoted: m })
    
  } catch (error) {
    reply('❌ Error: ' + error.message)
  }
  break
case 'ttsearch':
case 'tiktoksearch': {
    if (!text) return reply(`Contoh: ${prefix}ttsearch Furina`);
    try {
        const { TikTokSearch } = require('./lib/tiktoksearch');
        const result = await TikTokSearch.search(text);
        
        if (!result.success || !result.payload || result.payload.length === 0) {
            return reply('Video tidak ditemukan.');
        }

        const videos = result.payload.slice(0, 10);

        let cards = await Promise.all(videos.map(async (item, i) => {
            const videoData = await prepareWAMessageMedia({ 
                video: { url: item.media.no_watermark } 
            }, { 
                upload: satanic.waUploadToServer 
            });

            const videoInfo = `*${item.title}*
      
🕐 Durasi: ${item.duration}s
👤 Creator: ${item.author.nickname} (@${item.author.unique_id})
👍 Likes: ${item.stats.digg_count}
💬 Komentar: ${item.stats.comment_count}
📨 Shares: ${item.stats.share_count}`;

            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...videoData,
                    title: '',
                    subtitle: `Video ${i + 1} dari ${videos.length}`,
                    hasMediaAttachment: true
                }),
                body: { text: videoInfo },
                nativeFlowMessage: { buttons: [] }
            };
        }));

        let msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `Hasil pencarian video TikTok untuk *${text}*` },
                            carouselMessage: {
                                cards: cards,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: m }
        );

        await satanic.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil video.');
    }
}
break;
case 'capcutsearch':
case 'ccsearch': {
    if (!text) return reply(`Contoh: ${prefix}capcutsearch anime`);
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/capcutsearch?query=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200 || !response.data.result.data || response.data.result.data.length === 0) {
            return reply('Video tidak ditemukan.');
        }
        
        const videos = response.data.result.data.slice(0, 10);
        
        let cards = await Promise.all(videos.map(async (item, i) => {
            const videoData = await prepareWAMessageMedia({ 
                video: { url: item.download.video_original } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            
            const videoInfo = `*${item.title}*\n\n🕐 Durasi: ${item.duration_seconds} detik\n👤 Creator: ${item.author.full_name} (@${item.author.username})\n👍 Like: ${item.statistics.like}\n💬 Komentar: ${item.statistics.comment}\n📨 Pengguna: ${item.statistics.usage}\n⭐ Favorite: ${item.statistics.favorite}\n▶️ Play: ${item.statistics.play}`;
            
            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...videoData,
                    title: '',
                    subtitle: `Video ${i + 1} dari ${videos.length}`,
                    hasMediaAttachment: true
                }),
                body: { text: videoInfo },
                nativeFlowMessage: { buttons: [] }
            };
        }));
        
        let msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `Hasil pencarian video CapCut untuk *${text}*` },
                            carouselMessage: {
                                cards: cards,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: m }
        );
        
        await satanic.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil video.');
    }
}
break;
case 'spotifysearch':
case 'spsearch': {
    if (!text) return reply(`Contoh: ${prefix}spotifysearch dhyo haw`);
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/spotifysearch?query=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200 || !response.data.result.tracks || response.data.result.tracks.length === 0) {
            return reply('Lagu tidak ditemukan.');
        }
        
        const tracks = response.data.result.tracks.slice(0, 10);
        
        // Simpan hasil search untuk digunakan di spotifyget
        global.spotifySearchResults = {};
        
        let cards = await Promise.all(tracks.map(async (item, i) => {
            const index = (i + 1).toString();
            global.spotifySearchResults[index] = {
                name: item.name,
                url: item.url,
                artist: item.artists.map(a => a.name).join(', ')
            };
            
            const albumImage = item.album.images && item.album.images.length > 0 ? item.album.images[0].url : 'https://i.scdn.co/image/ab67616d00001e02c7ef9493c18667b50745b811';
            
            const imageData = await prepareWAMessageMedia({ 
                image: { url: albumImage } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            
            const durationSec = Math.floor(item.duration_ms / 1000);
            const minutes = Math.floor(durationSec / 60);
            const seconds = durationSec % 60;
            
            const trackInfo = `*${item.name}*\n\n👤 Artist: ${item.artists.map(a => a.name).join(', ')}\n⏱️ Durasi: ${minutes}:${seconds.toString().padStart(2, '0')}\n💿 Album: ${item.album.name}\n\n🔗 Link: ${item.url}\n\nKetik .spotifyget ${index} untuk download`;
            
            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...imageData,
                    title: '',
                    subtitle: `Lagu ${i + 1} dari ${tracks.length}`,
                    hasMediaAttachment: true
                }),
                body: { text: trackInfo },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📋 Copy Link",
                            copy_code: item.url
                        })
                    }]
                }
            };
        }));
        
        let msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `Hasil pencarian lagu Spotify untuk *${text}*` },
                            carouselMessage: {
                                cards: cards,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: m }
        );
        
        await satanic.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mencari lagu.');
    }
}
break;
case 'spotifyget':
case 'spget': {
    if (!text) return reply('Masukkan URL Spotify atau angka dari hasil pencarian!\n\nContoh: .spotifyget 1');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    // Cek apakah input berupa angka (pilihan dari search)
    if (!isNaN(text) && global.spotifySearchResults && global.spotifySearchResults[text]) {
        const selectedTrack = global.spotifySearchResults[text];
        const apiUrl = `https://free-restapi.biz.id/api/spotify?url=${encodeURIComponent(selectedTrack.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            audio: response.data, 
            mimetype: 'audio/mpeg',
            fileName: `${selectedTrack.name}.mp3`
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } 
    // Jika input berupa link langsung
    else if (text.includes('spotify.com')) {
        const apiUrl = `https://free-restapi.biz.id/api/spotify?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            audio: response.data, 
            mimetype: 'audio/mpeg'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } 
    else {
        reply('Format salah! Gunakan .spotifyget 1 (dari hasil search) atau .spotifyget link_spotify');
    }
}
break;
case 'applemusic':
case 'applemusicsearch':
case 'amsearch': {
    if (!text) return reply(`Contoh: ${prefix}applemusicsearch dhyo haw`);
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/applemusic?query=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200 || !response.data.result.data.results || response.data.result.data.results.length === 0) {
            return reply('Lagu tidak ditemukan.');
        }
        
        const tracks = response.data.result.data.results.slice(0, 10);
        
        // Simpan hasil search untuk digunakan di applemusicdl
        global.appleMusicSearchResults = {};
        
        let cards = await Promise.all(tracks.map(async (item, i) => {
            const index = (i + 1).toString();
            
            // Simpan data track
            global.appleMusicSearchResults[index] = {
                title: item.title,
                artist: item.artist,
                songLink: item.songLink,
                albumName: item.albumName
            };
            
            // Ambil artwork dari Apple Music (gunakan placeholder)
            const artworkUrl = `https://c.termai.cc/i101/xvVZ.jpg`;
            
            const imageData = await prepareWAMessageMedia({ 
                image: { url: artworkUrl } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            
            const trackInfo = `*${item.title}*\n\n👤 Artist: ${item.artist}\n💿 Album: ${item.albumName}\n\n🔗 Link: ${item.songLink}\n\nKetik .amdl ${index} untuk download`;
            
            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...imageData,
                    title: '',
                    subtitle: `Lagu ${i + 1} dari ${tracks.length}`,
                    hasMediaAttachment: true
                }),
                body: { text: trackInfo },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📋 Copy Link",
                            copy_code: item.songLink
                        })
                    }]
                }
            };
        }));
        
        let msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `Hasil pencarian lagu Apple Music untuk *${text}*` },
                            carouselMessage: {
                                cards: cards,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: m }
        );
        
        await satanic.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mencari lagu.');
    }
}
break;
case 'kodepos':
case 'kode_pos': {
    if (!text) return reply('Masukkan nama kota atau kecamatan!\n\nContoh: .kodepos jakarta');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/kodepos?kodepos=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Kode pos tidak ditemukan.');
        }
        
        const result = response.data.result;
        const data = result.data.slice(0, 15);
        
        let info = `📍 *KODE POS INDONESIA*\n\n`;
        info += `🔍 *Pencarian:* ${text}\n`;
        info += `📊 *Total Ditemukan:* ${result.total}\n`;
        info += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        for (let i = 0; i < data.length; i++) {
            const item = data[i];
            info += `${i+1}. *${item.kodepos}*\n`;
            info += `   📍 Desa/Kel: ${item.desa}\n`;
            info += `   🏘️ Kecamatan: ${item.kecamatan}\n`;
            info += `   🏙️ Kota: ${item.kota}\n`;
            info += `   🌏 Provinsi: ${item.provinsi}\n\n`;
        }
        
        if (result.total > 15) {
            info += `*dan ${result.total - 15} data lainnya...*\n\n`;
        }
        
        info += `📥 *Project By:* ${namaBot}`;
        
        await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mencari kode pos.');
    }
}
break;
case 'ssweb':
case 'screenshotweb': {
    if (!text) return reply('Masukkan URL website!\n\nContoh: .ssweb https://google.com\n\nDevice: desktop, tablet, mobile\nContoh: .ssweb https://google.com tablet');
    
    
    const url = args[0];
    let device = args[1] ? args[1].toLowerCase() : 'desktop';
    
    if (!['desktop', 'tablet', 'mobile'].includes(device)) {
        return reply('Device tidak valid! Gunakan: desktop, tablet, atau mobile');
    }
    
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        return reply('URL harus lengkap dengan http:// atau https://');
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ssweb?url=${encodeURIComponent(url)}&device=${device}&apikey=${global.sakey}`;
        
        await satanic.sendMessage(m.chat, {
            image: { url: apiUrl },
            caption: `*SSWEB RESULT*\n\nURL: ${url}\nDevice: ${device}\n\nProject By: ${namaBot}`
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil screenshot website.');
    }
}
break;
case 'play':{
if(!text)return reply('Masukkan judul lagu!');

try{
await satanic.sendMessage(m.chat,{react:{text:'🎵',key:m.key}});

const yts=require('yt-search');
const search=await yts(text);
if(!search.all.length)return reply('❌ Lagu tidak ditemukan');

const video=search.all[0];
const videoUrl=video.url;
const title=video.title;
const thumbnail=video.thumbnail;
const duration=video.timestamp;
const views=video.views;

// Kirim info lengkap dengan thumbnail
await satanic.sendMessage(m.chat,{
image:{url:thumbnail},
caption:`🎵 *${title}*\n\n⏱️ *Durasi:* ${duration}\n👁️ *Views:* ${views.toLocaleString()}\n🔗 *Link:* ${videoUrl}\n\n📥 *Mengunduh audio...\n\n> Jika ingin download video : \n.ytmp4 ${videoUrl}*`
},{quoted:m});

const response=await axios.get(`https://free-restapi.biz.id/api/ytmp3?url=${encodeURIComponent(videoUrl)}&apikey=${global.sakey}`,{
responseType:'arraybuffer'
});

const audioBuffer=Buffer.from(response.data);

await satanic.sendMessage(m.chat,{
audio:audioBuffer,
mimetype:'audio/mpeg',
ptt:false
},{quoted:m});

await satanic.sendMessage(m.chat,{react:{text:'✅',key:m.key}});
}catch(error){
reply('❌ Gagal: '+error.message);
}
break;
}
case 'ytsearch':
case 'youtube': {
    if (!text) return reply(`Contoh: ${prefix}ytsearch anime`);
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const search = require('yt-search');
        const results = await search(text);
        const videos = results.videos.slice(0, 10);
        
        if (!videos || videos.length === 0) {
            return reply('Video tidak ditemukan.');
        }
        
        let cards = await Promise.all(videos.map(async (item, i) => {
            const thumb = item.thumbnail || 'https://i.ytimg.com/vi/default.jpg';
            const imageData = await prepareWAMessageMedia({ 
                image: { url: thumb } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            
            const videoInfo = `*${item.title}*\n\n🕐 Durasi: ${item.timestamp}\n👤 Channel: ${item.author.name}\n👁️ Views: ${item.views.toLocaleString()}\n🔗 Link: ${item.url}`;
            
            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...imageData,
                    title: '',
                    subtitle: `Video ${i + 1} dari ${videos.length}`,
                    hasMediaAttachment: true
                }),
                body: { text: videoInfo },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📺 Watch on YouTube",
                            url: item.url
                        })
                    }]
                }
            };
        }));
        
        let msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `🎬 Hasil pencarian YouTube untuk *${text}*` },
                            carouselMessage: {
                                cards: cards,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: m }
        );
        
        await satanic.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mencari video.');
    }
}
break;
case 'ytmp3':{
if(!text)return reply('Masukkan judul lagu!');

try{
await satanic.sendMessage(m.chat,{react:{text:'🎵',key:m.key}});

const response=await axios.get(`https://free-restapi.biz.id/api/ytmp3?url=${encodeURIComponent(text)}&apikey=${global.sakey}`,{
responseType:'arraybuffer'
});

const audioBuffer=Buffer.from(response.data);

await satanic.sendMessage(m.chat,{
audio:audioBuffer,
mimetype:'audio/mpeg',
ptt:false
},{quoted:m});

await satanic.sendMessage(m.chat,{react:{text:'✅',key:m.key}});
}catch(error){
reply('❌ Gagal: '+error.message);
}
break;
}
case 'ytmp4':
case 'ytvideo': {
    if (!text) return reply('Masukkan URL YouTube!\n\nContoh: .ytmp4 https://youtu.be/xxx');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ytmp4?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { 
            responseType: 'arraybuffer',
            timeout: 30000 // 5 menit timeout
        });
        
        await satanic.sendMessage(m.chat, { 
            video: Buffer.from(response.data)
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        if (err.code === 'ECONNABORTED') {
            reply('Download timeout, video terlalu besar atau server sibuk.');
        } else {
            reply('Terjadi kesalahan saat mendownload video.');
        }
    }
}
break;
case 'applemusicdl':
case 'amdl': {
    if (!text) return reply('Masukkan nomor dari hasil pencarian atau URL Apple Music!\n\nContoh: .amdl 1\nAtau: .amdl https://music.apple.com/id/song/xxx');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let songUrl = text;
        
        // Cek apakah input berupa angka (hasil dari search)
        if (!isNaN(text) && global.appleMusicSearchResults && global.appleMusicSearchResults[text]) {
            songUrl = global.appleMusicSearchResults[text].songLink;
        }
        
        const apiUrl = `https://free-restapi.biz.id/api/applemusicdl?url=${encodeURIComponent(songUrl)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Gagal mengambil data dari Apple Music');
        }
        
        const result = response.data.result;
        let audioUrl = result.mp3;
        
        if (!audioUrl) {
            return reply('URL audio tidak ditemukan');
        }
        
        audioUrl = audioUrl.replace(/ /g, '%20');        
        const audioBuffer = await axios.get(audioUrl, { 
            responseType: 'arraybuffer',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': 'https://aaplmusicdownloader.com/',
                'Accept': '*/*'
            }
        });
        
        await satanic.sendMessage(m.chat, { 
            audio: audioBuffer.data,
            mimetype: 'audio/mpeg',
            fileName: `${result.title}.mp3`
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mendownload lagu.');
    }
}
break;
/////////stalk menu///////
case 'githubstalk':
case 'ghstalk': {
if (!text) return reply(`Kirim perintah ${prefix + command} username\nContoh: ${prefix + command} whiskeysockets`);
try {
 const res = await axios.get(`https://api.github.com/users/${text}`);
const user = res.data;
let txt = `*GITHUB PROFILE STALK*\n👤 *Username:* ${user.login}\n🆔 *ID:* ${user.id}\n🏷️ *Name:* ${user.name || '-'}\n📝 *Bio:* ${user.bio || '-'}\n📦 *Repos: ${user.public_repos}\n👥 *Followers:* ${user.followers}\n👣 *Following:* ${user.following}\n📍 *Location:* ${user.location || '-'}\n🔗 *URL:* ${user.html_url}`;
 await satanic.sendMessage(from, { image: { url: user.avatar_url }, caption: txt }, { quoted: m });
} catch (e) {
console.error(e);
  reply("Username tidak ditemukan atau terjadi kesalahan.");
}
}
break;
case 'igstalk': {
    if (!text) return reply('Masukkan username Instagram!\n\nContoh: .igstalk jokowi');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/igstalk?username=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        

        if (!response.data || response.data.status !== 200 || !response.data.result) {
            return reply('Gagal mengambil data dari Instagram');
        }
        
        const data = response.data.result;
        const profile = data.profile;
        const stats = data.stats;
        
        let info = `*INSTAGRAM STALKER V2*\n\n`;
        info += `👤 Username: @${profile.username}\n`;
        info += `📛 Nama: ${profile.full_name || '-'}\n`;
        info += `📝 Bio: ${profile.biography || '-'}\n`;
        info += `🔗 Link: ${profile.external_url || '-'}\n\n`;
        
        info += `*STATISTIK*\n`;
        info += `👥 Followers: ${stats.formatted_followers || stats.followers || '0'}\n`;
        info += `👣 Following: ${stats.formatted_following || stats.following || '0'}\n`;
        info += `📸 Posts: ${stats.formatted_posts || stats.posts || '0'}\n\n`;
        
        info += `*INFO LAINNYA*\n`;
        info += `✅ Verifikasi: ${profile.is_verified ? 'Ya' : 'Tidak'}\n`;
        info += `🔒 Private: ${profile.is_private ? 'Ya' : 'Tidak'}\n`;
        info += `🆔 ID User: ${profile.id || '-'}\n\n`;
        
        info += `📅 Scraped: ${data.metadata.scraped_at ? new Date(data.metadata.scraped_at).toLocaleString('id-ID') : '-'}\n`;
        info += `🔗 Profil: ${data.metadata.url || `https://instagram.com/${profile.username}`}\n`;
        info += `\nProject By: ${namaBot}`;
        
        // Kirim gambar profil jika tersedia
        if (profile.profile_pic_url) {
            await satanic.sendMessage(m.chat, {
                image: { url: profile.profile_pic_url },
                caption: info
            }, { quoted: m });
        } else {
            await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data Instagram.');
    }
}
break;
case 'igstalk2':
case 'instagramstalk2': {
    if (!text) return reply('Masukkan username Instagram!\n\nContoh: .igstalk2 jokowi');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/igstalk2?username=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        // Cek struktur response berdasarkan JSON yang diberikan
        if (!response.data || response.data.status !== 200 || !response.data.result) {
            return reply('Gagal mengambil data dari Instagram');
        }
        
        const user = response.data.result;
        
        let info = `*INSTAGRAM STALKER*\n\n`;
        info += `Username: ${user.username}\n`;
        info += `Full Name: ${user.full_name || '-'}\n`;
        info += `Bio: ${user.bio || '-'}\n`;
        info += `Followers: ${user.followers_count || 0}\n`;
        info += `Following: ${user.follows_count || 0}\n`;
        info += `Posts: ${user.posts_count || 0}\n`;
        info += `ID: ${user.id || '-'}\n`;
        info += `Link: https://instagram.com/${user.username}\n`;
        
        // Tambahan info opsional
        if (user.is_professional) info += `Verified: ✅ Professional Account\n`;
        info += `\nProject By: ${namaBot}`;
        
        // Kirim gambar profil jika tersedia
        if (user.profile_pic_url_hd || user.profile_pic_url) {
            const profilePic = user.profile_pic_url_hd || user.profile_pic_url;
            await satanic.sendMessage(m.chat, {
                image: { url: profilePic },
                caption: info
            }, { quoted: m });
        } else {
            await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data Instagram.');
    }
}
break;
case 'ytstalk':
case 'youtubestalk': {
    if (!text) return reply('Masukkan username atau handle YouTube!\n\nContoh: .ytstalk Dhot\nAtau: .ytstalk @Dhot');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://free-restapi.biz.id/api/ytstalk?q=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl);
    
    const result = response.data.result;
    
    let info = `🎥 *YOUTUBE STALKER*\n\n`;
    info += `📛 *Nama:* ${result.nama}\n`;
    info += `🆔 *Channel ID:* ${result.channelId}\n`;
    info += `🔗 *Handle:* ${result.handle}\n`;
    info += `👥 *Subscribers:* ${result.subscriberCount}\n`;
    info += `✅ *Verified:* ${result.verified || 'Tidak'}\n`;
    info += `🔗 *URL:* ${result.url}\n`;
    info += `\n📥 *Project By:* ${namaBot}`;
    
    if (result.avatar) {
        await satanic.sendMessage(m.chat, {
            image: { url: result.avatar },
            caption: info
        }, { quoted: m });
    } else {
        await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'ttstalk':
case 'tiktokstalk': {
    if (!text) return reply('Masukkan username TikTok!\n\nContoh: .ttstalk jokowi');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ttstalk?username=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Gagal mengambil data dari TikTok');
        }
        
        const result = response.data.result;
        
        let info = `🎵 *TIKTOK STALKER*\n\n`;
        info += `👤 *Username:* ${result.username}\n`;
        info += `📛 *Nama:* ${result.nama || '-'}\n`;
        info += `📝 *Bio:* ${result.bio || '-'}\n`;
        info += `✅ *Verifikasi:* ${result.verifikasi ? 'Ya' : 'Tidak'}\n`;
        info += `👥 *Followers:* ${result.totalfollowers.toLocaleString()}\n`;
        info += `❤️ *Total Disukai:* ${result.totaldisukai.toLocaleString()}\n`;
        info += `🎬 *Total Video:* ${result.totalvideo.toLocaleString()}\n`;
        info += `🔗 *Link:* https://tiktok.com/@${result.username}\n`;
        info += `📥 *Project By:* ${namaBot}`;
        
        // Kirim avatar dan info
        if (result.avatar) {
            await satanic.sendMessage(m.chat, {
                image: { url: result.avatar },
                caption: info
            }, { quoted: m });
        } else {
            await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data TikTok.');
    }
}
break;
case 'robloxstalk':
case 'rblxstalk': {
    if (!text) return reply('Masukkan username Roblox!\n\nContoh: .robloxstalk Simoon68');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/robloxstalk?username=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Gagal mengambil data dari Roblox');
        }
        
        const result = response.data.result;
        const account = result.account;
        const stats = result.stats;
        const presence = result.presence;
        
        let info = `🎮 *ROBLOX STALKER*\n\n`;
        info += `🆔 *User ID:* ${result.userId}\n`;
        info += `👤 *Username:* ${account.username}\n`;
        info += `📛 *Display Name:* ${account.displayName}\n`;
        info += `📝 *Bio:* ${account.description || '-'}\n`;
        info += `📅 *Bergabung:* ${account.created}\n`;
        info += `✅ *Verifikasi:* ${account.hasVerifiedBadge ? '✅ Ya' : '❌ Tidak'}\n`;
        info += `🚫 *Banned:* ${account.isBanned ? '⚠️ Ya' : '✅ Tidak'}\n\n`;
        
        info += `📊 *STATISTIK*\n`;
        info += `👥 *Teman:* ${stats.friendCount.toLocaleString()}\n`;
        info += `👣 *Followers:* ${stats.followers.toLocaleString()}\n`;
        info += `👤 *Following:* ${stats.following.toLocaleString()}\n`;
        info += `📦 *Inventory:* ${stats.inventoryCount.toLocaleString()}\n\n`;
        
        info += `🟢 *PRESENCE*\n`;
        info += `📱 *Online:* ${presence.isOnline ? '🟢 Online' : '⚫ Offline'}\n`;
        if (presence.recentGame && presence.recentGame !== 'Studio') {
            info += `🎮 *Game Terakhir:* ${presence.recentGame}\n`;
        }
        
        // Tambahkan groups
        if (result.groups && result.groups.groups && result.groups.groups.length > 0) {
            info += `\n👥 *GROUP (${result.groups.total} total)*\n`;
            info += `━━━━━━━━━━━━━━━━━━━━━\n`;
            for (let i = 0; i < Math.min(result.groups.groups.length, 15); i++) {
                const group = result.groups.groups[i];
                const roleName = group.role?.name || 'Member';
                const rank = group.role?.rank || 0;
                info += `${i+1}. ${group.name}\n`;
                info += `   👑 Role: ${roleName} (Rank ${rank})\n`;
                if (group.url) info += `   🔗 ${group.url}\n`;
                info += `\n`;
            }
            if (result.groups.groups.length > 15) {
                info += `*dan ${result.groups.groups.length - 15} grup lainnya...*\n`;
            }
        } else {
            info += `\n👥 *Group:* Tidak ada grup\n`;
        }
        
        info += `━━━━━━━━━━━━━━━━━━━━━\n`;
        info += `🔗 *Link Profile:* https://www.roblox.com/users/${result.userId}/profile\n`;
        info += `📥 *Project By:* ${namaBot}`;
        
        // Kirim avatar dan info dalam satu pesan
        if (account.profilePicture) {
            await satanic.sendMessage(m.chat, {
                image: { url: account.profilePicture },
                caption: info
            }, { quoted: m });
        } else {
            // Jika caption terlalu panjang, kirim teks terpisah
            if (info.length > 4000) {
                await satanic.sendMessage(m.chat, { text: info.substring(0, 4000) }, { quoted: m });
                await satanic.sendMessage(m.chat, { text: info.substring(4000) }, { quoted: m });
            } else {
                await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
            }
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data Roblox.');
    }
}
break;
case 'npmstalk':
case 'stalknpm': {
    if (!text) return reply('Masukkan nama package NPM!\n\nContoh: .npmstalk axios');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/npmstalk?package=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Gagal mengambil data dari NPM');
        }
        
        const result = response.data.result;
        
        let info = `📦 *NPM PACKAGE STALKER*\n\n`;
        info += `📌 *Package:* ${result.name}\n`;
        info += `⭐ *Version Latest:* ${result.versionLatest}\n`;
        info += `📅 *Latest Publish:* ${new Date(result.latestPublishTime).toLocaleDateString('id-ID')} ${new Date(result.latestPublishTime).toLocaleTimeString('id-ID')}\n`;
        info += `🔧 *Version Publish:* ${result.versionPublish || '-'}\n`;
        info += `📆 *Publish Time:* ${new Date(result.publishTime).toLocaleDateString('id-ID')}\n`;
        info += `🔄 *Version Update:* ${result.versionUpdate}\n`;
        info += `📦 *Latest Dependencies:* ${result.latestDependencies}\n`;
        info += `📦 *Publish Dependencies:* ${result.publishDependencies}\n\n`;
        info += `📥 *Project By:* ${namaBot}`;
        
        await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data NPM.');
    }
}
break;
case 'ffstalk':
case 'freefirestalk': {
    if (!text) return reply('Masukkan UID Free Fire!\n\nContoh: .ffstalk 946716486');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ffstalk?uid=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Gagal mengambil data dari Free Fire');
        }
        
        const result = response.data.result;
        
        let info = `🔥 *FREE FIRE STALKER*\n\n`;
        info += `🆔 *UID:* ${result.uid}\n`;
        info += `👤 *Nickname:* ${result.name}\n`;
        info += `⭐ *Level:* ${result.level}\n`;
        info += `📊 *Exp:* ${result.exp.toLocaleString()}\n`;
        info += `🌍 *Region:* ${result.region}\n`;
        info += `❤️ *Likes:* ${result.likes.toLocaleString()}\n`;
        info += `📅 *Bergabung:* ${new Date(result.created_at).toLocaleDateString('id-ID')}\n`;
        info += `🕐 *Last Login:* ${new Date(result.last_login).toLocaleDateString('id-ID')}\n`;
        info += `📝 *Signature:* ${result.signature || '-'}\n\n`;
        
        info += `🎮 *RANK*\n`;
        info += `🏆 *BR Max Rank:* ${result.br_max_rank}\n`;
        info += `🏆 *CS Max Rank:* ${result.cs_max_rank}\n`;
        info += `🎯 *BR Rank Point:* ${result.br_rank_point}\n\n`;
        
        info += `🦎 *PET*\n`;
        info += `🐾 *Nama Pet:* ${result.pet_name || '-'}\n`;
        info += `⭐ *Level Pet:* ${result.pet_level}\n`;
        info += `📊 *Exp Pet:* ${result.pet_exp.toLocaleString()}\n\n`;
        
        info += `👥 *GUILD*\n`;
        info += `🏷️ *Nama Guild:* ${result.guild_name || '-'}\n`;
        info += `🆔 *Guild ID:* ${result.guild_id || '-'}\n`;
        if (result.guild_level) info += `⭐ *Guild Level:* ${result.guild_level}\n`;
        if (result.guild_members) info += `👥 *Anggota:* ${result.guild_members}\n`;
        
        info += `\n📥 *Project By:* ${namaBot}`;
        
        await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data Free Fire.');
    }
}
break;
case 'twstalk':
case 'twitterstalk': {
    if (!text) return reply('Masukkan username Twitter!\n\nContoh: .twstalk jokowi');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/twstalk?username=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Gagal mengambil data dari Twitter');
        }
        
        const result = response.data.result;
        
        let info = `🐦 *TWITTER STALKER*\n\n`;
        info += `👤 *Username:* @${result.username}\n`;
        info += `📛 *Name:* ${result.name}\n`;
        info += `📝 *Bio:* ${result.bio || '-'}\n`;
        info += `📍 *Location:* ${result.location || '-'}\n`;
        info += `✅ *Verified:* ${result.verified ? 'Ya' : 'Tidak'}\n`;
        if (result.verification_type) {
            info += `🔐 *Verification Type:* ${result.verification_type}\n`;
        }
        info += `🔒 *Protected:* ${result.protected ? 'Ya' : 'Tidak'}\n`;
        info += `📅 *Joined:* ${new Date(result.joined).toLocaleDateString('id-ID')}\n`;
        info += `\n📊 *STATISTIK*\n`;
        info += `👥 *Followers:* ${result.followers.toLocaleString()}\n`;
        info += `👣 *Following:* ${result.following.toLocaleString()}\n`;
        info += `❤️ *Likes:* ${result.likes.toLocaleString()}\n`;
        info += `🐦 *Tweets:* ${result.tweets.toLocaleString()}\n`;
        info += `📷 *Media Count:* ${result.media_count.toLocaleString()}\n`;
        info += `\n🔗 *Link:* ${result.url}\n`;
        info += `📥 *Project By:* ${namaBot}`;
        
        // Kirim avatar dan info
        if (result.avatar_url) {
            await satanic.sendMessage(m.chat, {
                image: { url: result.avatar_url },
                caption: info
            }, { quoted: m });
        } else {
            await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data Twitter.');
    }
}
break;
case 'npmsearch':
case 'npmsearch': {
    if (!text) return reply(`Contoh: ${prefix}npmsearch axios`);
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(text)}&size=20`;
        const response = await axios.get(apiUrl);
        
        if (!response.data || !response.data.objects || response.data.objects.length === 0) {
            return reply('Package NPM tidak ditemukan.');
        }
        
        let info = `📦 *NPM SEARCH RESULTS*\n\n`;
        info += `🔍 *Keyword:* ${text}\n`;
        info += `📊 *Total Found:* ${response.data.total || response.data.objects.length}\n`;
        info += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        for (let i = 0; i < response.data.objects.length; i++) {
            const pkg = response.data.objects[i].package;
            const score = response.data.objects[i].score;
            
            info += `*${i+1}. ${pkg.name}*\n`;
            info += `📝 *Description:* ${pkg.description || '-'}\n`;
            info += `🔖 *Latest Version:* ${pkg.version}\n`;
            info += `📅 *Published:* ${pkg.date ? new Date(pkg.date).toLocaleDateString('id-ID') + ' ' + new Date(pkg.date).toLocaleTimeString('id-ID') : '-'}\n`;
            info += `🔗 *NPM Link:* https://www.npmjs.com/package/${pkg.name}\n`;
            
            if (pkg.publisher && pkg.publisher.username) {
                info += `👤 *Publisher:* ${pkg.publisher.username}\n`;
            }
            
            if (pkg.keywords && pkg.keywords.length > 0) {
                info += `🏷️ *Keywords:* ${pkg.keywords.join(', ')}\n`;
            }
            
            if (score && score.final) {
                info += `⭐ *Score:* ${(score.final * 100).toFixed(1)}%\n`;
            }
            
            info += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        }
        
        info += `📥 *Project By:* ${namaBot}`;
        
        await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mencari package NPM.');
    }
}
break;
case 'cekresi':
case 'resi': {
    if (!text) return reply('📦 *CEK RESI*\n\nMasukkan kurir dan nomor resi!\n\nContoh: .cekresi jne 123456789\n\n*Daftar Kurir:*\n• jne\n• pos\n• tiki\n• wahana\n• jnt\n• sicepat\n• ninja\n• spx (shopee express)\n• anteraja\n• lionparcel\n• ncs\n• pcp\n• rpx\n• sap\n• jet\n• indahlogistik\n• dse\n• firstlogistics\n• idexpress\n• lalamove\n• paxel\n• pandu\n• sentral\n• star\n• tiki\n• cargo\n• etc');
    
    
    if (args.length < 2) return reply('⚠️ Format salah!\n\nContoh: .cekresi jne 123456789');
    
    const kurir = args[0].toLowerCase();
    const noResi = args[1];
    
    const listKurir = ['jne', 'pos', 'tiki', 'wahana', 'jnt', 'sicepat', 'ninja', 'spx', 'anteraja', 'lionparcel', 'ncs', 'pcp', 'rpx', 'sap', 'jet', 'indahlogistik', 'dse', 'firstlogistics', 'idexpress', 'lalamove', 'paxel', 'pandu', 'sentral', 'star', 'cargo', 'etc'];
    
    if (!listKurir.includes(kurir)) {
        return reply(`❌ Kurir *${kurir}* tidak dikenal!\n\n📋 *Daftar Kurir:*\n${listKurir.join(', ')}`);
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/cekresi?kurir=${kurir}&resi=${noResi}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply(`❌ Resi tidak ditemukan untuk kurir *${kurir.toUpperCase()}* dengan nomor *${noResi}*`);
        }
        
        const result = response.data.result;
        
        let info = `📦 *CEK RESI*\n\n`;
        info += `🚚 *Expedisi:* ${result.expedisi || kurir.toUpperCase()}\n`;
        info += `📝 *No Resi:* ${result.no_resi}\n`;
        info += `✅ *Status:* ${result.status}\n`;
        if (result.tanggal_kirim) {
            info += `📅 *Tanggal Kirim:* ${result.tanggal_kirim}\n`;
        }
        info += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        info += `📜 *RIWAYAT PENGIRIMAN*\n\n`;
        
        if (result.riwayat && result.riwayat.length > 0) {
            for (let i = 0; i < result.riwayat.length; i++) {
                const r = result.riwayat[i];
                info += `${i+1}. ${r.waktu || '-'}\n`;
                info += `   📍 ${r.deskripsi || r.deskripsi_original || '-'}\n`;
                if (r.lokasi) info += `   📌 Lokasi: ${r.lokasi}\n`;
                info += `\n`;
            }
        } else {
            info += `Tidak ada riwayat pengiriman.\n`;
        }
        
        info += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        info += `📥 *Project By:* ${namaBot}`;
        
        if (info.length > 4096) {
            let parts = info.match(/[\s\S]{1,4096}/g) || [];
            for (let part of parts) {
                await satanic.sendMessage(m.chat, { text: part }, { quoted: m });
            }
        } else {
            await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('❌ Terjadi kesalahan saat melacak resi.');
    }
}
break;
case 'removebg':
case 'rmbg': {
    if (!quoted) return reply('Balas gambar dengan caption .removebg');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/removebg?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Background berhasil dihapus!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal menghapus background. Coba lagi nanti.');
    }
}
break;
case 'removebg2':
case 'rmbg2': {
    if (!quoted) return reply('Balas gambar dengan caption .removebg2');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/removebg?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Background berhasil dihapus!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal menghapus background. Coba lagi nanti.');
    }
}
break;
case 'hdr':
case 'hd':
case 'enhance': {
    if (!quoted) return reply('Balas gambar dengan caption .hd');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/hd?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil diupgrade ke HD!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti.');
    }
}
break;
case 'removecloth': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
    if (!quoted) return reply('Balas gambar dengan caption .bugill');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/removecloth?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil '
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti silahkan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadibugil': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
    if (!quoted) return reply('Balas gambar dengan caption .jadibugill');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/jadibugil?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil '
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti silahkan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadimacbook': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
    if (!quoted) return reply('Balas gambar dengan caption .jadimacbook');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/jadimacebook?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil '
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti silahkan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadibiliard': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
    if (!quoted) return reply('Balas gambar dengan caption .jadipresiden');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        const prompt = `buat gambar realistis tanpa merubah wajah sedikit pun, lalu bergaya sedang berdiri dalam ruangan billiard ,sedang bersandar pada meja billiard, sambil memang stik Billiard,iya menggunakan pakaian keren seperti kaos atau kemeja, menggunakan kalung celana jeans hitam,kaus kaki putih polos pendek,dan sepatu putih new balance 530 putih silver, suasana terang dengan lampu gantung, beberapa meja billiard di latar belakang, dan beberapa org sendang bermain billiard, nuansa yang di tampilkan santai, urban dan sporty.saran gaya (opsional): gaya fotografi:sinematik,kedalam bidang dangkel, percayaan cerah, sudut kamera: seluruh tubuh,dari depan secara langsung gaya model meliat ke bawah suasana: percaya diri,keren,santai seperti nongkrong tone warna: seimbang,campuran percayaan hangat dan dingin, note : jangan ubah object muka aslinya  pertahankan muka asli saya`
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(mem.url)}&prompt=${prompt}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'jadianime': {
    if (!isPrem) {
        return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    }

    if (!quoted) {
        return reply('Balas gambar dengan caption .jadibugill');
    }

    let mime = quoted.mimetype || '';

    if (!/image/.test(mime)) {
        return reply('Hanya support gambar!');
    }

    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        const prompt = `change to anime realistic`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(mem.url)}&prompt=${prompt}&apikey=${global.sakey}`;

        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

        await satanic.sendMessage(m.chat, {
            image: response.data,
            caption: '✨ Gambar berhasil.'
        }, { quoted: m });

        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadizombie': {
    if (!isPrem) {
        return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    }

    if (!quoted) {
        return reply('Balas gambar dengan caption .jadibugill');
    }

    let mime = quoted.mimetype || '';

    if (!/image/.test(mime)) {
        return reply('Hanya support gambar!');
    }

    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        const prompt = `change to zombie realistic`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(mem.url)}&prompt=${prompt}&apikey=${global.sakey}`;

        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

        await satanic.sendMessage(m.chat, {
            image: response.data,
            caption: '✨ Gambar berhasil.'
        }, { quoted: m });

        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadibotak': {
    if (!isPrem) {
        return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    }

    if (!quoted) {
        return reply('Balas gambar dengan caption .jadibugill');
    }

    let mime = quoted.mimetype || '';

    if (!/image/.test(mime)) {
        return reply('Hanya support gambar!');
    }

    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        const prompt = `buat karakter ini tidak memiliki rambut atau jadikan karakter ini botak`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(mem.url)}&prompt=${prompt}&apikey=${global.sakey}`;

        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

        await satanic.sendMessage(m.chat, {
            image: response.data,
            caption: '✨ Gambar berhasil.'
        }, { quoted: m });

        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadifigure': {
    if (!isPrem) {
        return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    }

    if (!quoted) {
        return reply('Balas gambar dengan caption .jadibugill');
    }

    let mime = quoted.mimetype || '';

    if (!/image/.test(mime)) {
        return reply('Hanya support gambar!');
    }

    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        const prompt = `Using the model, create a 1/7 scale commercialized figurine of the characters in the picture, in a realistic style, in a real environment. 
The figurine is placed on a computer desk. 
The figurine has a round transparent acrylic base, with no text on the base. 
The content on the computer screen is the ZBrush modeling process of this figurine. 
Next to the computer screen is a BANDAI-style toy packaging box printed with the original artwork. 
The packaging features two-dimensional flat illustrations`
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(mem.url)}&prompt=${prompt}&apikey=${global.sakey}`;

        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

        await satanic.sendMessage(m.chat, {
            image: response.data,
            caption: '✨ Gambar berhasil.'
        }, { quoted: m });

        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'texttovideo': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
    let prompttt = args.join(' ').trim();
    
    if (!prompttt) return reply('Contoh: .texttovideo a beautiful girls sunset');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let apiUrl = `https://free-restapi.biz.id/api/texttovideo?prompt=${encodeURIComponent(prompttt)}&ratio=16:9&apikey=${global.sakey}`;
        let response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) throw new Error('Gagal');
        
        let videoUrl = response.data.result.video_url;
        let video = await axios.get(videoUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            video: video.data,
            caption: `✅ Berhasil!\n📝 ${prompttt}`
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        reply('❌ Gagal!');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'removecloth2': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
    if (!quoted) return reply('Balas gambar dengan caption .removecloth2');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/removecloth?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'jadipresiden': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
    if (!quoted) return reply('Balas gambar dengan caption .jadipresiden');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/jadipresiden?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'hdvid2': {

    if (!quoted) return reply('Balas gambar dengan caption .jadipresiden');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/hdvid?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            video: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'jadipresiden2': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
    if (!quoted) return reply('Balas gambar dengan caption .jadipresiden');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/jadipresiden2?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'gpt2image': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
if (!text) return reply('input prompt')
    if (!quoted) return reply('Balas gambar dengan caption .gpt2image');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/gpt2image?url=${encodeURIComponent(mem.url)}&prompt=${text}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'nanobanana': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
if (!text) return reply('input prompt')
    if (!quoted) return reply('Balas gambar dengan caption .gpt2image');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(mem.url)}&prompt=${text}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'img2img': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
if (!text) return reply('input prompt')
    if (!quoted) return reply('Balas gambar dengan caption .gpt2image');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/img2img?image_url=${encodeURIComponent(mem.url)}&prompt=${text}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'upscale': {
    if (!quoted) return reply('Balas gambar dengan caption .upscale');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/upscale?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil diupgrade ke HD!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti.');
    }
}
break;
case 'talkingphoto': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
    let argsFull = args.join(' ');
    let voice = 'woman1'; // default voice
    
    // Cek apakah ada parameter voice dengan format | voice_name
    let voiceMatch = argsFull.match(/\|\s*(woman1|woman2|man1|man2)\s*$/i);
    if (voiceMatch) {
        voice = voiceMatch[1].toLowerCase();    
        argsFull = argsFull.replace(/\|\s*(woman1|woman2|man1|man2)\s*$/i, '').trim();
    }
    
    let prompt = argsFull.replace(/^\.talkingphoto\s*/i, '').trim();
    
    if (!prompt) return reply(`*📢 TALKING PHOTO*\n\nContoh:\n.talkingphoto aku adalah aqua ai asisten satanic haxor yang akan membantu anda | woman1\n.talkingphoto aku adalah aquai\n\n*List Voice:*\n👩 woman1 (default)\n👩 woman2\n👨 man1\n👨 man2\n\n*Note:* Gunakan format *| voice* di akhir kalimat`);
    if (!quoted) return reply('Balas gambarnya terlebih dahulu!');
    if (!/image/.test(quoted.mimetype || '')) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        let apiUrl = `https://free-restapi.biz.id/api/talkingphoto?url=${mem.url}&text=${encodeURIComponent(prompt)}&voice=${voice}&apikey=${global.sakey}`;
        let response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            video: response.data, 
            caption: `✅ Berhasil!\n📝 Teks: ${prompt.substring(0, 50)}${prompt.length > 50 ? '...' : ''}\n🎤 Voice: ${voice}` 
        }, { quoted: m });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('❌ Gagal membuat talking photo! Coba lagi nanti.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'esrgan':
case '4k': {
    if (!quoted) return reply('Balas gambar dengan caption .esrgan');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        
        const apiUrl = `https://free-restapi.biz.id/api/esrgan?url=${encodeURIComponent(mem.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil diupgrade ke 4K dengan ESRGAN!'
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti.');
    }
}
break;
case 'ping':
case 'runtime':
case 'infobot': {
  reply(`> 🏓 Status bot online\nRUNTIME: ${runtime(process.uptime())}
`)
}
break
case 'gita': {
    if (!text) return reply('Masukkan pertanyaan atau bab/ayat Gita!\n\nContoh: .gita Karma\nAtau: .gita bab 2');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ai/gita?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status === 200 && response.data.result) {
            const result = response.data.result;
            
            await satanic.sendMessage(m.chat, { text: result }, { quoted: m });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            return reply('Gagal mendapatkan kutipan dari Bhagavad Gita.');
        }
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil kutipan Gita.');
    }
}
break;
case 'epsilon':
case 'search': {
    if (!text) return reply('Masukkan kata kunci pencarian!\n\nContoh: .epsilon Indonesia');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/epsilon?message=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data.success) {
            return reply('Gagal mendapatkan hasil pencarian dari Epsilon.');
        }
        
        const result = response.data.result;
        
        await satanic.sendMessage(m.chat, { text: result }, { quoted: m });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat menghubungi Epsilon.');
    }
}
break;
case 'kimi':
case 'dola':
if (!text) return reply('*Contoh:* .kimi buatkan aku script userbot')
try {
    const response = await fetch(`https://api.qasimdev.dpdns.org/api/kimi/ai?prompt=${encodeURIComponent(text)}&apiKey=qasim-dev`)
    const result = await response.json()
    if (result.success) {
        reply(`*Hasil:*\n\n${result.data.result}`)
    } else {
        reply(`*Error:* ${result.error || 'Gagal mendapatkan response'}`)
    }
} catch (error) {
    reply(`*Error:* ${error.message}`)
}
break
case 'illama-code':
if (!text) return reply('*Contoh:* .illama-code buatkan aku script userbot')
try {
    const response = await fetch(`https://api.qasimdev.dpdns.org/api/mistral/advanced?text=${encodeURIComponent(text)}&apiKey=qasim-dev&model=codestral-2501`)
    const result = await response.json()
    if (result.success) {
        reply(`*Hasil Code:*\n\n${result.data.result}`)
    } else {
        reply(`*Error:* ${result.error || 'Gagal mendapatkan response'}`)
    }
} catch (error) {
    reply(`*Error:* ${error.message}`)
}
break
case 'chatai': {
  if (!text) return reply(
    `Contoh:\n${prefix + command} siapa presiden indo`
  )

  try {
    const payload = {
      model: {
        id: 'gpt-3.5-turbo',
        name: 'GPT-3.5',
        maxLength: 12000,
        tokenLimit: 4000,
        completionTokenLimit: 2500,
        deploymentName: 'gpt-35'
      },
      messages: [
        {
          role: 'user',
          content: `hallo saya Aqua AI asisten Satanic Haxor👋 untuk membantu anda, ${text}`,
        }
      ],
      temperature: 0.5,
      enableConversationPrompt: false
    }

    const res = await axios.post(
      'https://chateverywhere.app/api/chat',
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent':
            'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/143 Mobile Safari/537.36'
        }
      }
    )

    let hasil = ''

    if (typeof res.data === 'string') {
      hasil = res.data.trim()
    } else {
      hasil =
        res.data?.choices?.[0]?.message?.content ||
        res.data?.message ||
        res.data?.content ||
        ''
    }

    if (!hasil) return reply('Respon AI kosong')

    await satanic.sendMessage(
      m.chat,
      { text: hasil },
      { quoted: m }
    )
  } catch (e) {
    console.error(e)
    reply(e?.message || 'Terjadi kesalahan')
  }
}
break
case 'gemini':
case 'aqua': {
    if (!text && !m.quoted) return reply('Masukkan pertanyaan atau reply gambar!\n\nContoh: .gemini Halo\nAtau reply gambar dengan caption .gemini deskripsikan ini');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || "";
        
        let mediaUrl = '';
        let prompt = text || '';
        
        // Jika ada gambar, ambil buffer dan convert ke base64
        if (/image/.test(mime)) {
            const mediaBuffer = await quoted.download();
            const base64 = mediaBuffer.toString('base64');
            mediaUrl = `data:${mime};base64,${base64}`;
        }
        
        const apiUrl = `https://free-restapi.biz.id/api/gemini?prompt=${encodeURIComponent(prompt)}&url=${encodeURIComponent(mediaUrl)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data.success) {
            return reply('Gagal mendapatkan respons dari Gemini AI.');
        }
        
        const result = response.data.result;
        
        await satanic.sendMessage(m.chat, { text: result }, { quoted: m });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat menghubungi Gemini AI.');
    }
}
break;
case 'felo': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .felo Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ai/felo?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status === 200 && response.data.result) {
            const answer = response.data.result.answer;
            
            await satanic.sendMessage(m.chat, { text: answer }, { quoted: m });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            return reply('Gagal mendapatkan respons dari Felo AI.');
        }
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat menghubungi Felo AI.');
    }
}
break;
case 'copilot': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .copilot Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/copilot?message=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data.success) {
            return reply('Gagal mendapatkan respons dari Copilot.');
        }
        
        const result = response.data.result;
        
        await satanic.sendMessage(m.chat, { text: result }, { quoted: m });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat menghubungi Copilot.');
    }
}
break;
case 'deepseek': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .deepseek Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/deepai?message=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data.success) {
            return reply('Gagal mendapatkan respons dari DeepSeek.');
        }
        
        const result = response.data.result;
        
        await satanic.sendMessage(m.chat, { text: result }, { quoted: m });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat menghubungi DeepSeek.');
    }
}
break;
case 'ai':
case 'gemini':
case 'aqua': {
    if (!text && !m.quoted) return reply('Masukkan pertanyaan atau reply gambar!\n\nContoh: .gemini Halo\nAtau reply gambar dengan caption .gemini deskripsikan ini');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let prompt = text || '';
        
        const apiUrl = `https://free-restapi.biz.id/api/gemini?prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data.success) {
            return reply('Gagal mendapatkan respons dari Gemini AI.');
        }
        
        const result = response.data.result;
        
        await satanic.sendMessage(m.chat, { text: result }, { quoted: m });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat menghubungi Gemini AI.');
    }
}
break;
case 'skiplink':
case 'bypass': {
    if (!text) return reply('Masukkan URL shortener!\n\nContoh: .skiplink https://sfl.gl/xxx');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://fgsi.dpdns.org/api/tools/skip/tutwuri?apikey=${global.fgsi}&url=${encodeURIComponent(text)}`;
    const response = await axios.get(apiUrl);
    
    if (!response.data.status) {
        return reply('Gagal melewati link!');
    }
    
    const resultUrl = response.data.data.url;
    
    let info = `🔗 *SKIP LINK BYPASSER*\n\n`;
    info += `📌 *Original URL:* ${text}\n`;
    info += `✅ *Destination URL:* ${resultUrl}\n\n`;
    info += `📥 *Download by:* ${namaBot}`;
    
    await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'whatmusic':
case 'whatsong':
case 'identify': {
    if (!quoted) return reply(`🎵 *WHAT MUSIC - Identify Song* 🎵\n\n> Mengidentifikasi lagu dari file audio/video\n\n📌 *Cara penggunaan:*\n\n1️⃣ *Dengan URL audio:*\n\`\`\`${prefix + command} <url_audio>\`\`\`\n\n2️⃣ *Reply ke pesan audio/video:*\n\`\`\`Reply ke pesan audio/vn/video lalu kirim ${prefix + command}\`\`\``);
    
    let mime = quoted.mimetype || '';
    let audioUrl = null;
    
    // Fungsi upload ke Litterbox
    async function uploadToLitterbox(fileBuffer, filename) {
        try {
            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('time', '72h');
            form.append('fileToUpload', Buffer.from(fileBuffer), {
                filename: filename,
                contentType: require('mime').lookup(filename) || 'application/octet-stream'
            });

            const response = await axios.post('https://litterbox.catbox.moe/resources/internals/api.php', form, {
                headers: form.getHeaders(),
                timeout: 30000
            });

            if (response.status !== 200) throw new Error('Litterbox gagal');
            const url = response.data;
            if (!url.startsWith('http')) throw new Error('Invalid response');
            return url;
        } catch (err) {
            console.error("Litterbox Error:", err.message);
            return null;
        }
    }
    
    // Jika command langsung dengan URL
    let directUrl = text;
    if (directUrl && (directUrl.includes('http') || directUrl.includes('cdn'))) {
        audioUrl = directUrl;
    }
    // Jika reply ke pesan audio/video
    else if (quoted && (/audio/.test(mime) || /video/.test(mime))) {
        const mediaBuffer = await quoted.download();
        
        // Upload ke Litterbox
        const extension = mime.split('/')[1] || 'mp3';
        const filename = `audio.${extension}`;
        audioUrl = await uploadToLitterbox(mediaBuffer, filename);
        
        if (!audioUrl) {
            return reply('Gagal upload audio ke Litterbox');
        }
    }
    else {
        return reply(`Kirim atau reply file audio/video!`);
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const identifyEndpoint = `https://api.neoxr.eu/api/whatmusic?url=${encodeURIComponent(audioUrl)}&apikey=${global.neoxr}`;
    const identifyResponse = await axios.get(identifyEndpoint);
    const identifyResult = identifyResponse.data;
    
    if (!identifyResult.status) return reply('Gagal mengidentifikasi lagu');
    
    const songData = identifyResult.data;
    
    let balasan = `🎵 *WHAT MUSIC - SONG IDENTIFIER* 🎵\n\n`;
    balasan += `━━━━━━━━━━━━━━━━━━━━━━\n`;
    balasan += `🎤 *Judul:* ${songData.title}\n`;
    balasan += `👨‍🎤 *Artis:* ${songData.artist}\n`;
    balasan += `💿 *Album:* ${songData.album}\n`;
    balasan += `📅 *Rilis:* ${songData.release}\n`;
    balasan += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    
    balasan += `🔗 *TAUTAN MUSIK:*\n\n`;
    
    if (songData.links?.spotify) {
        balasan += `🎧 *Spotify*\n`;
        balasan += `   • 🔗 https://open.spotify.com/track/${songData.links.spotify.track.id}\n\n`;
    }
    
    if (songData.links?.deezer) {
        balasan += `🎵 *Deezer*\n`;
        balasan += `   • 🔗 https://deezer.com/track/${songData.links.deezer.track.id}\n\n`;
    }
    
    if (songData.links?.youtube) {
        balasan += `📺 *YouTube*\n`;
        balasan += `   • 🔗 https://youtu.be/${songData.links.youtube.vid}\n\n`;
    }
    
    if (songData.links?.soundcloud) {
        balasan += `🎙️ *SoundCloud*\n`;
        balasan += `   • 🔗 ${songData.links.soundcloud.url || 'https://soundcloud.com/'}\n\n`;
    }
    
    balasan += `━━━━━━━━━━━━━━━━━━━━━━\n`;
    balasan += `📥 *Project By:* ${namaBot}`;
    
    await satanic.sendMessage(m.chat, { text: balasan }, { quoted: m });
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'ocr':
case 'readtext': {
    if (!quoted) return reply('Balas gambar dengan caption .ocr\n\nContoh: reply gambar lalu kirim .ocr');
    
    let mime = quoted.mimetype || '';
    
    if (!/image/.test(mime)) return reply('Hanya support gambar!');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    // Fungsi upload ke Litterbox
    async function uploadToLitterbox(fileBuffer, filename) {
        try {
            const FormData = require('form-data');
            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('time', '72h');
            form.append('fileToUpload', Buffer.from(fileBuffer), {
                filename: filename,
                contentType: require('mime').lookup(filename) || 'image/jpeg'
            });

            const response = await axios.post('https://litterbox.catbox.moe/resources/internals/api.php', form, {
                headers: form.getHeaders(),
                timeout: 30000
            });

            if (response.status !== 200) throw new Error('Litterbox gagal');
            const url = response.data;
            if (!url.startsWith('http')) throw new Error('Invalid response');
            return url;
        } catch (err) {
            console.error("Litterbox Error:", err.message);
            return null;
        }
    }
    
    let mediaBuffer = await quoted.download();
    let extension = mime.split('/')[1] || 'jpg';
    let imageUrl = await uploadToLitterbox(mediaBuffer, `image.${extension}`);
    
    if (!imageUrl) {
        return reply('Gagal upload gambar ke Litterbox');
    }
    
    const apiUrl = `https://free-restapi.biz.id/api/ocr?image_url=${encodeURIComponent(imageUrl)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl);
    
    if (response.data.status !== 200) {
        return reply('Gagal membaca teks dari gambar.');
    }
    
    const result = response.data.result;
    
    let info = `🔍 *OCR - TEXT EXTRACTOR*\n\n`;
    info += `📊 *Total Karakter:* ${result.total_characters}\n`;
    info += `📄 *Total Baris:* ${result.total_lines}\n`;
    info += `🎯 *Confidence:* ${result.ocr_confidence}\n\n`;
    info += `━━━━━━━━━━━━━━━━━━━━━━\n`;
    info += `📝 *HASIL TEKS:*\n\n${result.text}\n`;
    info += `━━━━━━━━━━━━━━━━━━━━━━\n`;
    info += `📥 *Project By:* ${namaBot}`;
    
    await satanic.sendMessage(m.chat, { text: info }, { quoted: m });
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'tourl2': {
    if (!m.quoted) return reply('Reply gambar/video/audio yang ingin diupload ke Catbox!');
    
    const quoted = m.quoted;
    const mime = (quoted.msg || quoted).mimetype || "";
    
    if (!/image|video|audio/.test(mime)) return reply('Hanya support gambar, video, atau audio!');
    
    try {
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const mediaBuffer = await quoted.download();
        const form = new FormData();
        form.append('userhash', '');
        form.append('reqtype', 'fileupload');
        
        // Tentukan extension berdasarkan mime
        let ext = 'jpg';
        if (mime.includes('video')) ext = 'mp4';
        else if (mime.includes('audio')) ext = 'mp3';
        else if (mime.includes('png')) ext = 'png';
        else if (mime.includes('gif')) ext = 'gif';
        
        form.append('fileToUpload', mediaBuffer, `${Date.now()}.${ext}`);
        
        const { headers } = await axios.get('https://catbox.moe/');
        const { data } = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: {
                ...form.getHeaders(),
                cookie: headers['set-cookie']?.join('; ') || '',
                origin: 'https://catbox.moe',
                referer: 'https://catbox.moe/',
                'user-agent': 'Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (Chrome) Mobile Safari/537.36',
                'x-requested-with': 'XMLHttpRequest'
            }
        });
        
        if (!data || !data.startsWith('https://')) {
            return reply('❌ Gagal upload ke Catbox');
        }
        
        let type = 'gambar';
        if (mime.includes('video')) type = 'video';
        else if (mime.includes('audio')) type = 'audio';
        
        await satanic.sendMessage(m.chat, {
            text: `✅ *Upload Berhasil!*\n\n📁 *Tipe:* ${type}\n🔗 *Link:* ${data}`
        }, { quoted: m });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error(error);
        reply('❌ Gagal upload: ' + error.message);
    }
}
break;
case 'fakedana':
    if (!text) return reply('Masukkan nominalnya');
    
    await satanic.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

    try {
        
        const res = await fetch(`https://api.zenzxz.my.id/maker/fakedanav2?nominal=${text}`);
        const buffer = Buffer.from(await res.arrayBuffer());
        
        await satanic.sendMessage(m.chat, { 
            image: buffer, 
            caption: `Done` 
        }, { quoted: m });
        
    } catch (e) {
        reply('Gagal: ' + e.message);
    }
    break;
    case 'translate': {
  async function translate(query = "", lang) {
    if (!query.trim()) return "";
    const url = new URL("https://translate.googleapis.com/translate_a/single");
    url.searchParams.append("client", "gtx");
    url.searchParams.append("sl", "auto");
    url.searchParams.append("dt", "t");
    url.searchParams.append("tl", lang);
    url.searchParams.append("q", query);

    try {
      const response = await fetch(url.href);
      const data = await response.json();
      if (data && data[0]) {
        return data[0].map(item => item[0].trim()).join("\n");
      }
      return "";
    } catch (err) {
      throw err;
    }
  }

  let textToTranslate = "";
  let targetLang = "id";

  if (text && text.trim()) {
    const firstWord = text.trim().split(" ")[0];
    if (firstWord.length === 2 && /^[a-z]{2}$/i.test(firstWord)) {
      targetLang = firstWord.toLowerCase();
      textToTranslate = text.trim().split(" ").slice(1).join(" ");
    } else {
      textToTranslate = text;
    }
  }
  
  if (!textToTranslate && m.quoted && m.quoted.text) {
    textToTranslate = m.quoted.text;
  }

  if (!textToTranslate || !textToTranslate.trim()) {
    return reply(`⚠️ *Contoh penggunaan semua bahasa:*\n\n\
🌏 *ASIA*\n\
└ .translate id Good morning → selamat pagi\n\
└ .translate en Selamat pagi → good morning\n\
└ .translate ja Selamat pagi → おはようございます\n\
└ .translate ko Selamat pagi → 좋은 아침이에요\n\
└ .translate zh Selamat pagi → 早上好\n\
└ .translate th Selamat pagi → อรุณสวัสดิ์\n\
└ .translate vi Selamat pagi → chào buổi sáng\n\
└ .translate hi Selamat pagi → सुप्रभात\n\
└ .translate ms Selamat pagi → selamat pagi\n\
└ .translate tl Selamat pagi → magandang umaga\n\n\
🇪🇺 *EROPA*\n\
└ .translate es Selamat pagi → buenos días\n\
└ .translate fr Selamat pagi → bonjour\n\
└ .translate de Selamat pagi → guten morgen\n\
└ .translate it Selamat pagi → buongiorno\n\
└ .translate pt Selamat pagi → bom dia\n\
└ .translate ru Selamat pagi → доброе утро\n\
└ .translate nl Selamat pagi → goedemorgen\n\
└ .translate pl Selamat pagi → dzień dobry\n\n\
🌍 *TIMUR TENGAH & AFRIKA*\n\
└ .translate ar Selamat pagi → صباح الخير\n\
└ .translate tr Selamat pagi → günaydın\n\
└ .translate sw Selamat pagi → habari za asubuhi\n\n\
📝 *Cara pakai:*\n\
└ Ketik: .translate [kode] [teks]\n\
└ Atau reply pesan + .translate [kode]`);
  }

  try {
    const result = await translate(textToTranslate, targetLang);
    if (!result) return reply("❌ Gagal menerjemahkan teks.");
    reply(result);
  } catch (error) {
    reply(`❌ Error: ${error.message}`);
  }
  break;
}
case 'linkgroup':
case 'linkgc':
case 'gclink':
case 'grouplink': {
    if (!m.isGroup) return reply('Perintah ini hanya bisa digunakan di dalam grup!');
 
    
    let response = await satanic.groupInviteCode(m.chat);
    let groupMetadata = await satanic.groupMetadata(m.chat);
    
    await satanic.sendMessage(m.chat, { 
        text: `🔗 *GROUP LINK*\n\n📌 *Nama Grup:* ${groupMetadata.subject}\n🔗 *Link:* https://chat.whatsapp.com/${response}\n\n📥 *Download by:* ${namaBot}`,
        detectLink: true
    }, { quoted: m });
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'resetlinkgroup':
case 'resetlinkgrup':
case 'revoke':
case 'resetlink':
case 'resetgrouplink':
case 'resetgclink':
case 'resetgruplink': {
    if (!m.isGroup) return reply('Perintah ini hanya bisa digunakan di dalam grup!');
 
    if (!isAdmins && !isCreator) return reply('Hanya admin grup yang bisa menggunakan perintah ini!');
    
    await satanic.groupRevokeInvite(m.chat);
    let groupMetadata = await satanic.groupMetadata(m.chat);
    let newLink = await satanic.groupInviteCode(m.chat);
    
    await satanic.sendMessage(m.chat, { 
        text: `🔗 *LINK GROUP RESET*\n\n📌 *Nama Grup:* ${groupMetadata.subject}\n🔗 *Link Baru:* https://chat.whatsapp.com/${newLink}\n\n📥 *Download by:* ${namaBot}`
    }, { quoted: m });
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;

case 'react': {
    if (!isCreator) return reply('Perintah ini hanya untuk owner!');
    if (!quoted) return reply('Reply pesan yang ingin direaksi!');
    
    let emoji = args[0];
    if (!emoji) return reply(`Contoh: ${prefix}react 🐱`);
    
    await satanic.sendMessage(m.chat, { react: { text: emoji, key: quoted.key } });
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;

case 'group':
case 'gc': {
    if (!m.isGroup) return reply('Perintah ini hanya bisa digunakan di dalam grup!');
    if (!isAdmins && !isCreator) return reply('Hanya admin grup yang bisa menggunakan perintah ini!');
  
    if (!args[0]) return reply(`Kirim perintah ${command} _options_\nOptions: close & open\nContoh: ${command} close`);
    
    if (args[0] == 'close') {
        await satanic.sendMessage(m.chat, { text: '🔒 *Grup ditutup!*\\n\\nTidak ada anggota yang bisa mengirim pesan kecuali admin.' });
        await satanic.groupSettingUpdate(m.chat, 'announcement');
    } else if (args[0] == 'open') {
        await satanic.sendMessage(m.chat, { text: '🔓 *Grup dibuka!*\\n\\nSemua anggota bisa mengirim pesan.' });
        await satanic.groupSettingUpdate(m.chat, 'not_announcement');
    } else {
        reply(`Contoh: ${prefix + command} close/open`);
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case "kalkulator":{
 val = text
.replace(/[^0-9\-\/+*×÷πEe()piPI/]/g, '')
.replace(/×/g, '*')
.replace(/÷/g, '/')
.replace(/π|pi/gi, 'Math.PI')
.replace(/e/gi, 'Math.E')
.replace(/\/+/g, '/')
.replace(/\++/g, '+')
.replace(/-+/g, '-')
let format = val
.replace(/Math\.PI/g, 'π')
.replace(/Math\.E/g, 'e')
.replace(/\//g, '÷')
.replace(/\*×/g, '×')
try {
let result = (new Function('return ' + val))()
if (!result) return reply(result)
reply(`*${format}* = _${result}_`)
} catch (e) {
if (e == undefined) return reply('Isinya?')
reply('Format salah, hanya 0-9 dan Simbol -, +, *, /, ×, ÷, π, e, (, ) yang disupport')
}
}
break
 case 'tts': case 'texttospeech': case 'say':
case 'ttsgoku': case 'ttseminem': case 'ttsmickey':
case 'ttsnahida': case 'ttselon': case 'ttsoptimus': {
    const _ttsT=text?.trim();
    if (!_ttsT) return reply(`🎤 *ᴛᴛs*\n\nVoice tersedia: tts, ttsgoku, ttseminem, ttsmickey, ttsnahida, ttselon\nFormat: \`${prefix}tts <teks>\`\n\nContoh: \`${prefix}ttsgoku Hai semuanya!\``);
    const _ttsVK={ttsgoku:'goku',ttseminem:'eminem',ttsmickey:'mickey_mouse',ttsnahida:'nahida',ttselon:'elon_musk',ttsoptimus:'optimus_prime'};
    const _ttsVoice=_ttsVK[command]||null;
    satanic.sendMessage(m.chat,{react:{text:'🎤',key:m.key}});
    await reply(`⏳ *Generating ${_ttsVoice||'random'} voice...*\n_Teks: ${_ttsT}_`);
    if (!fs.existsSync('./temp')) fs.mkdirSync('./temp',{recursive:true});
    const _ttsTs=Date.now(),_ttsWav=`./temp/tts_${_ttsTs}.wav`,_ttsOgg=`./temp/tts_${_ttsTs}.ogg`;
    try {
        const _ttsR=await axios.get(`https://api.emiliabot.my.id/tools/text-to-speech?text=${encodeURIComponent(_ttsT)}`,{timeout:60000});
        if (!_ttsR.data?.status||!_ttsR.data?.result?.length) throw new Error('API tidak merespon atau kosong');
        const _ttsVoices=_ttsR.data.result.filter(v=>!v.error);
        if (!_ttsVoices.length) throw new Error('Semua model TTS error');
        let _ttsObj=_ttsVoice?_ttsVoices.find(v=>v[_ttsVoice]):null;
        if (!_ttsObj) _ttsObj=_ttsVoices[Math.floor(Math.random()*_ttsVoices.length)];
        const _ttsAK=Object.keys(_ttsObj).find(k=>!['channel_id','voice_name','voice_id'].includes(k)&&String(_ttsObj[k]).startsWith('https://'));
        if (!_ttsAK) throw new Error('Audio URL tidak ditemukan dari API');
        const _ttsAR=await axios.get(_ttsObj[_ttsAK],{responseType:'arraybuffer',timeout:30000});
        fs.writeFileSync(_ttsWav,Buffer.from(_ttsAR.data));
        execSync(`ffmpeg -y -i "${_ttsWav}" -c:a libopus -b:a 64k "${_ttsOgg}"`,{stdio:'ignore',timeout:30000});
        await satanic.sendMessage(m.chat,{audio:fs.readFileSync(_ttsOgg),mimetype:'audio/ogg; codecs=opus',ptt:true},{quoted:m});
        satanic.sendMessage(m.chat,{react:{text:'✅',key:m.key}});
    } catch(e){satanic.sendMessage(m.chat,{react:{text:'❌',key:m.key}});reply(`❌ *TTS Gagal!*\n\n${e.message.slice(0,150)}`);}
    finally{try{if(fs.existsSync(_ttsWav))fs.unlinkSync(_ttsWav);}catch{}try{if(fs.existsSync(_ttsOgg))fs.unlinkSync(_ttsOgg);}catch{}}}
    break;   
case 'iqc':
    if (!text) return reply('📝 Format: teks|provider|jam|baterai\nContoh: .iqc Halo semua|Telkomsel|10:30|75');

    await satanic.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

    try {
        let [messageText, carrierName, time, batteryPercentage] = text.split('|');
        
        if (!messageText || !carrierName || !time || !batteryPercentage) {
            return reply('❌ Semua field harus diisi!\nContoh: .iqc Halo semua|Telkomsel|10:30|75');
        }

        // Bersihkan baterai (ambil angka saja)
        batteryPercentage = batteryPercentage.replace(/\D/g, '');
        if (!batteryPercentage) return reply('❌ Baterai harus angka');

        const url = `https://brat.siputzx.my.id/iphone-quoted?messageText=${encodeURIComponent(messageText)}&carrierName=${encodeURIComponent(carrierName)}&time=${encodeURIComponent(time)}&batteryPercentage=${encodeURIComponent(batteryPercentage)}&signalStrength=4`;
        
        const res = await fetch(url);
        
        // Handle error 502
        if (res.status === 502) {
            return reply('❌ Server API sedang sibuk (502 Bad Gateway). Coba lagi nanti');
        }
        
        if (!res.ok) {
            throw new Error(`HTTP Error ${res.status}`);
        }
        
        const buffer = Buffer.from(await res.arrayBuffer());
        
        await satanic.sendMessage(m.chat, { 
            image: buffer,
            caption: `✅ *iPhone Quote Created!*\n\n💬 Pesan: ${messageText}\n📱 Provider: ${carrierName}\n⏰ Jam: ${time}\n🔋 Baterai: ${batteryPercentage}%`
        }, { quoted: m });
        
    } catch (e) {
        reply('❌ Gagal: ' + e.message);
    }
    break;
case 'webpilot':
case 'browse': {
    if (!text) return reply('Masukkan URL atau pertanyaan!\n\nContoh: .webpilot https://example.com\nAtau: .webpilot apa itu hai');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ai/webpilot?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status === 200 && response.data.result) {
            const result = response.data.result;
            
            await satanic.sendMessage(m.chat, { text: result }, { quoted: m });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            return reply('Gagal mendapatkan hasil dari WebPilot.');
        }
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat menghubungi WebPilot.');
    }
}
break;
case 'openai':
case 'chatgpt':
case 'gpt': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .openai Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/openai?message=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data.success) {
            return reply('Gagal mendapatkan respons dari OpenAI.');
        }
        
        const result = response.data.result;
        
        await satanic.sendMessage(m.chat, { text: result }, { quoted: m });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat menghubungi OpenAI.');
    }
}
break;
case 'illama-vision': 
    async function uploadTmpFiles(filePath) {
        try {
            if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan");
            const form = new FormData();
            form.append("file", fs.createReadStream(filePath));
            const res = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
                headers: form.getHeaders(),
                timeout: 120000
            });
            if (res.data && res.data.data && res.data.data.url) {
                const idMatch = res.data.data.url.match(/\/(\d+)(?:\/|$)/);
                const fileName = path.basename(filePath);
                if (idMatch) {
                    return `https://tmpfiles.org/dl/${idMatch[1]}/${fileName}`;
                }
            }
            throw new Error("Upload ke tmpfiles.org gagal");
        } catch (err) {
            console.error("TmpFiles Error:", err.message);
            return null;
        }
    }
    
    if (!quoted && !text) return reply(`*Contoh:* .illama-vision reply gambar/video/audio dengan prompt`)
    let prompt = text || "Apa isi dari media ini?";
    if (!quoted || !quoted.mimetype) {
        return reply(`*Error:* Reply media yang valid!`);
    }
    await reply('*Processing...*');
    try {
        const media = await quoted.download();
        const fs = require('fs');
        const path = require('path');
        const tmpDir = './tmp';
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);
        let ext;
        if (quoted.mimetype.startsWith('image/')) {
            ext = quoted.mimetype.split('/')[1] || 'jpg';
        } else if (quoted.mimetype.startsWith('video/')) {
            ext = quoted.mimetype.split('/')[1] || 'mp4';
        } else if (quoted.mimetype.startsWith('audio/')) {
            ext = quoted.mimetype.split('/')[1] || 'mp3';
        } else {
            return reply(`*Error:* Tipe media tidak didukung!`);
        }
        
        const fileName = `media_${Date.now()}.${ext}`;
        const filePath = path.join(tmpDir, fileName);
        fs.writeFileSync(filePath, media);
        const uploadResponse = await uploadTmpFiles(filePath);
        fs.unlinkSync(filePath);     
        if (!uploadResponse) return reply('*Error:* Gagal upload media');

        const apiUrl = `https://api.qasimdev.dpdns.org/api/mistral/vision?text=${encodeURIComponent(prompt)}&image_url=${encodeURIComponent(uploadResponse)}&apiKey=qasim-dev&model=pixtral-12b-2409`
        const response = await fetch(apiUrl);
        const result = await response.json();
        if (result.success) {
            await reply(`*Hasil:*\n\n${result.data.result}`);
        } else {
            await reply(`*Error:* ${result.error || 'Gagal'}`);
        }
    } catch (error) {
        reply(`*Error:* ${error.message}`);
    }
    break;
case 'carbonify':
if (!text) return reply(`Example: ${prefix + command} story wa anime`);   
    try {
        const response = await fetch("https://carbonara.solopov.dev/api/cook", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ "code": text })
        });

        if (!response.ok) throw new Error(`API error: ${response.status}`);

        const blob = await response.blob();
        const arrayBuffer = await blob.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);

        await satanic.sendMessage(m.chat, { 
            image: buffer 
        }, { 
            quoted: m 
        });
        
    } catch (error) {
        console.error('Carbonify error:', error);
        reply('❌ Gagal membuat gambar carbon. Coba lagi nanti.');
    }
    break;
case 'tebakkata': {
    if (!m.isGroup) return reply('only group')
    let timeout = 60000
    let id = m.chat
    if (id in satanic.tebakkata) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
    
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `🔤 *TEBAK KATA* 🔤\n\n📖 Soal: ${json.soal}\n⏰ Waktu: 60 detik\n💡 Ketik *hint* atau *bantuan* untuk petunjuk\n😔 Ketik *nyerah* untuk menyerah`
    
    satanic.tebakkata[id] = [
        await reply(`${caption}`),
        json,
        setTimeout(() => {
            if (satanic.tebakkata[id]) {
                reply(`⏰ *WAKTU HABIS!*\n\nJawaban: *${json.jawaban}*\n\nIngin bermain lagi? Ketik *tebakkata*`)
                delete satanic.tebakkata[id]
            }
        }, timeout)
    ]
}
break    
case 'mathquiz': case 'math': {
    if (!m.isGroup) return reply('only group')
    let id = m.chat
    if (id in satanic.kuismath) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
    
    let { genMath, modes } = require('./lib/math')
    if (!text) return reply(`📐 *MODE MATEMATIKA*\n\nMode tersedia: ${Object.keys(modes).join(' | ')}\n\n📝 Contoh: ${prefix}math medium`)
    
    let result = await genMath(text.toLowerCase())
    
    let caption = `🧮 *KUIS MATEMATIKA* 🧮\n\n📊 Soal: ${result.soal}\n⏰ Waktu: ${(result.waktu / 1000).toFixed(2)} detik\n😔 Ketik *nyerah* untuk menyerah`
    
    let msg = await reply(caption)
    
    let timeoutId = setTimeout(() => {
        if (satanic.kuismath[id]) {
            reply(`⏰ *WAKTU HABIS!*\n\nJawaban: *${result.jawaban}*\n\nIngin bermain lagi? Ketik *${prefix}math ${text}*`)
            delete satanic.kuismath[id]
        }
    }, result.waktu)
    
    satanic.kuismath[id] = {
        msg: msg,
        jawaban: result.jawaban.toString().toLowerCase(),
        soal: result.soal,
        timeout: timeoutId
    }
}
break
case 'tebakgambar': {
    if (!m.isGroup) return reply('only group')
    let timeout = 60000
    let id = m.chat
    if (id in satanic.tebakgambar) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
    
    async function tebakgambar() {
        let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
        let result = anu[Math.floor(Math.random() * anu.length)]
        return {
            img: result.img,
            jawaban: result.jawaban,
            deskripsi: result.deskripsi
        }
    }
    
    let tos = await tebakgambar()
    let caption = `🎮 *TEBAK GAMBAR* 🎮\n\nDeskripsi: ${tos.deskripsi}\n⏰ Waktu: 60 detik\n💡 Ketik *hint* untuk petunjuk\n😔 Ketik *nyerah* untuk menyerah`
    
    let msg = await satanic.sendMessage(from, { caption: caption, image: { url: tos.img } }, { quoted: m })
    
    satanic.tebakgambar[id] = [
        msg,
        tos,
        setTimeout(() => {
            if (satanic.tebakgambar[id]) {
                reply(`⏰ *WAKTU HABIS!*\n\nJawaban: *${tos.jawaban}*\n\nIngin bermain lagi? Ketik *tebakgambar*`)
                delete satanic.tebakgambar[id]
            }
        }, timeout)
    ]
}
break    
case 'tebaktebakan': {
    if (!m.isGroup) return reply('only group')
    let timeout = 60000
    let id = m.chat
    if (id in satanic.tebaktebakan) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
    
    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaktebakan.json')
    let result = anu[Math.floor(Math.random() * anu.length)]
    
    let caption = `❓ *TEBAK-TEBAKAN* ❓\n\n📖 Soal: ${result.soal}\n⏰ Waktu: 60 detik\n💡 Ketik *hint* atau *bantuan* untuk petunjuk\n😔 Ketik *nyerah* untuk menyerah`
    
    let msg = await reply(caption)
    
    let timeoutId = setTimeout(() => {
        if (satanic.tebaktebakan[id]) {
            reply(`⏰ *WAKTU HABIS!*\n\nJawaban: *${result.jawaban}*\n\nIngin bermain lagi? Ketik *tebaktebakan*`)
            delete satanic.tebaktebakan[id]
        }
    }, timeout)
    
    satanic.tebaktebakan[id] = {
        msg: msg,
        jawaban: result.jawaban.toLowerCase(),
        soal: result.soal,
        timeout: timeoutId
    }
}
break
case 'caklontong': {
    if (!m.isGroup) return reply('only group')
    let timeout = 60000
    let id = m.chat
    if (id in satanic.caklontong) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
    
    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')
    let result = anu[Math.floor(Math.random() * anu.length)]
    
    let caption = `🍚 *CAK LONTONG* 🍚\n\n📖 Soal: ${result.soal}\n⏰ Waktu: 60 detik\n💡 Ketik *hint* atau *bantuan* untuk petunjuk\n😔 Ketik *nyerah* untuk menyerah`
    
    let msg = await reply(caption)
    
    let timeoutId = setTimeout(() => {
        if (satanic.caklontong[id]) {
            reply(`⏰ *WAKTU HABIS!*\n\nJawaban: *${result.jawaban}*\n📝 Deskripsi: ${result.deskripsi}\n\nIngin bermain lagi? Ketik *caklontong*`)
            delete satanic.caklontong[id]
        }
    }, timeout)
    
    satanic.caklontong[id] = {
        msg: msg,
        jawaban: result.jawaban.toLowerCase(),
        soal: result.soal,
        deskripsi: result.deskripsi,
        timeout: timeoutId
    }
}
break
case 'asahotak': {
    if (!m.isGroup) return reply('only group')
    let timeout = 60000
    let id = m.chat
    if (id in satanic.tebakasahotak) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
    
    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/asahotak.json')
    let result = anu[Math.floor(Math.random() * anu.length)]
    
    let caption = `🧠 *ASAH OTAK* 🧠\n\n📖 Soal: ${result.soal}\n⏰ Waktu: 60 detik\n💡 Ketik *hint* atau *bantuan* untuk petunjuk\n😔 Ketik *nyerah* untuk menyerah`
    
    let msg = await reply(caption)
    
    let timeoutId = setTimeout(() => {
        if (satanic.tebakasahotak[id]) {
            reply(`⏰ *WAKTU HABIS!*\n\nJawaban: *${result.jawaban}*\n\nIngin bermain lagi? Ketik *asahotak*`)
            delete satanic.tebakasahotak[id]
        }
    }, timeout)
    
    satanic.tebakasahotak[id] = {
        msg: msg,
        jawaban: result.jawaban.toLowerCase(),
        soal: result.soal,
        timeout: timeoutId
    }
}
break
case 'siapaaku': {
    if (!m.isGroup) return reply('only group')
    let timeout = 60000
    let id = m.chat
    if (id in satanic.siapaaku) return reply('Masih ada soal belum terjawab di chat ini')
    
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/siapakahaku.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `🕵️ *SIAPA AKU?* 🕵️\n\n📖 Soal: ${json.soal}\n⏰ Waktu: ${(timeout / 1000).toFixed(2)} detik\n💡 Ketik *hint* atau *bantuan* untuk petunjuk\n😔 Ketik *nyerah* untuk menyerah`
    
    let msg = await reply(caption)
    
    let timeoutId = setTimeout(() => {
        if (satanic.siapaaku[id]) {
            reply(`⏰ *WAKTU HABIS!*\n\nJawaban: *${json.jawaban}*\n\nIngin bermain lagi? Ketik *siapaaku*`)
            delete satanic.siapaaku[id]
        }
    }, timeout)
    
    satanic.siapaaku[id] = {
        msg: msg,
        jawaban: json.jawaban.toLowerCase(),
        soal: json.soal,
        timeout: timeoutId
    }
}
break
case 'tebakkimia': {
    if (!m.isGroup) return reply('only group')
    let timeout = 60000
    let id = m.chat
    if (id in satanic.tebakkimia) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
    
    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkimia.json')
    let result = anu[Math.floor(Math.random() * anu.length)]
    
    let caption = `🧪 *TEBAK KIMIA* 🧪\n\n🧴 Unsur: ${result.unsur}\n⏰ Waktu: 60 detik\n💡 Ketik *hint* atau *bantuan* untuk petunjuk\n😔 Ketik *nyerah* untuk menyerah`
    
    let msg = await reply(caption)
    
    let timeoutId = setTimeout(() => {
        if (satanic.tebakkimia[id]) {
            reply(`⏰ *WAKTU HABIS!*\n\nJawaban (Lambang): *${result.lambang}*\n\nIngin bermain lagi? Ketik *tebakkimia*`)
            delete satanic.tebakkimia[id]
        }
    }, timeout)
    
    satanic.tebakkimia[id] = {
        msg: msg,
        jawaban: result.lambang.toLowerCase(),
        unsur: result.unsur,
        timeout: timeoutId
    }
}
break
case 'tekateki': {
    if (!m.isGroup) return reply('only group')
    let timeout = 60000
    let id = m.chat
    if (id in satanic.tekateki) return reply('Masih ada soal belum terjawab di chat ini')
    
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tekateki.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `🧩 *TEKA-TEKI* 🧩\n\n📖 Soal: ${json.soal}\n⏰ Waktu: ${(timeout / 1000).toFixed(2)} detik\n💡 Ketik *hint* atau *bantuan* untuk petunjuk\n😔 Ketik *nyerah* untuk menyerah`
    
    let msg = await reply(caption)
    
    let timeoutId = setTimeout(() => {
        if (satanic.tekateki[id]) {
            reply(`⏰ *WAKTU HABIS!*\n\nJawaban: *${json.jawaban}*\n\nIngin bermain lagi? Ketik *tekateki*`)
            delete satanic.tekateki[id]
        }
    }, timeout)
    
    satanic.tekateki[id] = {
        msg: msg,
        jawaban: json.jawaban.toLowerCase(),
        soal: json.soal,
        timeout: timeoutId
    }
}
break
case 'family100': {
    if (!m.isGroup) return reply('only group')
    let id = m.chat
    if (id in satanic.family100) return reply('Masih Ada Sesi Yang Belum Diselesaikan!')
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    let hasil = `*Jawablah Pertanyaan Berikut :*\n\nSoal : ${json.soal}\n\nTerdapat *${json.jawaban.length}* Jawaban ${json.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}`.trim()
    satanic.family100[id] = {
        id,
        msg: await reply(`${hasil}`),
        ...json,
        terjawab: Array.from(json.jawaban, () => false),
    }
}
break
 case 'dare':
              const dare =[
"Makan 2 sendok makan nasi tanpa lauk apapun, jika terasa berat, kamu bisa minum.",
"Sebutkan orang yang membuatmu terdiam",
"Telepon gebetan/pacar sekarang dan kirim tangkapan layar di sini",
"Kirim emot hanya setiap kali kamu mengetik di grup obrolan/obrolan pribadi selama 1 hari.",
"Ucapkan 'Selamat datang di Who Wants To Be a Millionaire!' ke semua grup yang kamu punya",
"Telepon mantan dengan mengatakan rindu",
"nyanyikan chorus dari lagu terakhir yang kamu mainkan",
"Rekam suara untuk mantan/pacar/gebemmu, katakan 'Hai (nama), ingin menelepon, tunggu sebentar. Aku sangat merindukanmu'",
"Pukul meja (yang ada di rumah) sampai kamu dimarahi karena berisik",
"Katakan pada orang asing 'Aku baru saja diberitahu bahwa aku adalah saudaramu yang pertama, kami berpisah, lalu aku melakukan operasi plastik. Dan ini hal paling 'ciyusss'",
"Sebutkan nama mantan",
"buat 1 sajak untuk anggota grup!",
"Kirim daftar percakapan WhatsAppmu",
"Obrol dengan orang asing dengan bahasa ghetto lalu tangkap layar di sini",
"Ceritakan versimu sendiri tentang hal-hal memalukan",
"Tag orang yang kamu benci",
"Pura-pura seperti terkena pengaruh, misalnya: terkena pengaruh anjing, terkena pengaruh belalang, terkena pengaruh lemari es, dll.",
"Ubah nama menjadi *I AM DONKEY* selama 24 jam",
"Teriak *ma chuda ma chuda ma chuda* di depan rumahmu",
"Ambil foto/potret pacar atau gebetanmu dan kirimkan di sini",
"Ceritakan tipe pacar yang kamu sukai!",
"Ucapkan *aku naksir kamu, maukah kamu menjadi pacarku?* kepada lawan jenis, terakhir kali kamu berbicara dengannya (kirim di WA/Telegram), tunggu sampai dia membalas, jika sudah, berikan di sini",
"Rekam suaramu yang membaca *titar ke age do titar, titar ke piche do titar*",
"Chatingan lelucon dengan mantan dan katakan *aku mencintaimu, tolong kembalilah.* tanpa menyebutkan bahwa itu adalah tantangan!",
"Obrol dengan kontak WhatsApp berurutan sesuai dengan persentase baterai ponselmu, lalu katakan 'Aku beruntung memiliki kamu!'",
"Ubah nama menjadi *I am a child of randi* selama 5 jam",
"Ketik dalam bahasa Bengali selama 24 jam",
"Gunakan foto Selmon Bhoi selama 3 hari",
"Kirim kutipan lagu lalu tag anggota yang cocok untuk kutipan tersebut",
"Kirim pesan suara dengan ucapan 'Bolehkah aku memanggilmu sayang?'",
"Tangkapan layar percakapan terakhir di WhatsAppmu",
"Ucapkan *KAMU SANGAT CANTIK, JANGAN BERBOHONG* kepada teman pria!",
"Telepon salah satu anggota grup dan katakan kata kasar kepada mereka",
"Berlakulah seperti ayam di depan orangtua kamu",
"Ambil sebuah buku secara acak dan bacakan satu halaman secara keras dan rekam suara lalu kirimkan di sini",
"Buka pintu depan rumahmu dan menyalak seperti serigala selama 10 detik",
"Ambil foto selfie yang memalukan dan jadikan sebagai foto profilmu",
"Biar grup memilih sebuah kata dan lagu yang dikenal. Kamu harus menyanyikan lagu tersebut dan kirim dalam bentuk pesan suara di sini",
"Berjalanlah dengan menopang dengan siku dan lutut selama yang kamu bisa",
"nyanyikan lagu kebangsaan dalam pesan suara",
"Lakukan breakdance selama 30 detik di ruang tamu",
"Ceritakan cerita sedih yang kamu ketahui",
"Buat video tari twerk singkat dan unggah sebagai status selama 5 menit",
"Makan sepotong bawang putih mentah",
"Tunjukkan lima orang terakhir yang kamu kirim pesan dan isi pesan mereka",
"Jadikan nama lengkapmu sebagai status selama 5 jam",
"Buat video tari singkat tanpa filter hanya dengan musik dan unggah sebagai status selama 5 jam",
"Telepon sahabatmu, omong kosong",
"Jadikan foto dirimu tanpa filter sebagai status selama 10 menit",
"Ucapkan 'aku cinta Oli London' dalam pesan suara 😄",
"Kirim pesan kepada mantanmu dan katakan bahwa kamu masih menyukainya",
"Telepon gebetan/pacar/sahabatmu sekarang dan tangkapan layar di sini",
"Berkata kasar pada salah satu anggota grup di percakapan pribadi dan katakan 'kamu jelek, beban'",
"Ucapkan 'KAMU CANTIK/GANTENG' pada salah satu orang yang ada di atas pinlistmu atau orang pertama di daftar percakapanmu",
"Kirim pesan suara dan katakan 'Bisakah aku memanggilmu sayang?'. Jika kamu seorang pria, sebutkan nama seorang wanita. Jika kamu seorang wanita, sebutkan nama seorang pria",
"Tulis 'Aku mencintaimu (nama anggota grup acak yang sedang online) dalam percakapan pribadi (jika kamu pria, tulis nama wanita; jika kamu wanita, tulis nama pria), ambil tangkapan layar dan kirimkan di sini",
"Gunakan foto aktor Bollywood sebagai foto profilmu selama 3 hari",
"Jadikan foto crushmu sebagai status dengan caption 'Ini adalah crushku'",
"Ubah nama menjadi *I AM GAY* selama 5 jam",
"Obrol dengan salah satu kontak di WhatsApp dan katakan 'Aku akan menjadi pacarmu selama 5 jam'",
"Kirim pesan suara dan katakan 'Aku naksir kamu, maukah kamu menjadi pacarku?' kepada orang acak dari grup (jika kamu perempuan, pilih nama laki-laki; jika kamu laki-laki, pilih nama perempuan)",
"Pukul pantatmu dengan keras dan kirim suara tamparan melalui pesan suara 😂",
"Sebutkan tipe pacarmu dan kirim fotonya di sini dengan keterangan 'Perempuan/laki-laki paling jelek di dunia'",
"Teriak 'bravooooooooo' dan kirimkan melalui pesan suara di sini",
"Ambil foto wajahmu dan kirim di sini",
"Kirim foto dirimu dengan keterangan 'Aku lesbian'",
"Teriak dengan menggunakan kata-kata kasar dan kirim melalui pesan suara",
"Teriak 'kamu bajingan' di depan ibu atau ayahmu",
"Ubah nama menjadi *aku bodoh selama 24 jam*",
"Pukul dirimu sendiri dengan mantap dan kirim suara pukulan melalui pesan suara 😂",
"Ucapkan 'aku cinta pemilik bot alya' melalui pesan suara",
"Kirim foto pacar atau gebetanmu di sini",
"Buat video tantangan tarian TikTok apa pun dan unggah sebagai status, kamu bisa menghapusnya setelah 5 jam",
"Putuskan pertemanan dengan sahabatmu selama 5 jam tanpa memberitahunya bahwa itu adalah tantangan",
"Katakan pada salah satu temanmu bahwa kamu mencintainya dan ingin menikahinya, tanpa memberitahunya bahwa itu adalah tantangan",
"Ucapkan 'aku cinta Depak Kalal' melalui pesan suara",
"Tulis 'aku merasa horny' dan unggah sebagai status, kamu hanya bisa menghapusnya setelah 5 jam",
"Tulis 'aku lesbian' dan unggah sebagai status, kamu hanya bisa menghapusnya setelah 5 jam",
"Cium ibu atau ayahmu dan katakan 'aku mencintaimu' 😌",
"Jadikan nama ayahmu sebagai status selama 5 jam",
"Kirim kata-kata kasar dalam grup manapun, kecuali grup ini, dan kirim bukti tangkapan layarnya di sini"
]
              const xeondare = dare[Math.floor(Math.random() * dare.length)]
              bufferdare = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
              satanic.sendMessage(from, { image: bufferdare, caption: '_You choose DARE_\n'+ xeondare }, {quoted:m})
              break
        break
       case 'truth':
              const truth =[
"Pernahkah kamu menyukai seseorang? Berapa lama?",
    "Jika kamu bisa atau jika kamu mau, grup obrolan atau grup di luar mana yang ingin kamu jadikan teman? (bisa berbeda/jenis yang sama)",
    "Apa ketakutan terbesar kamu?",
    "Pernahkah kamu menyukai seseorang dan merasa bahwa orang tersebut juga menyukaimu?",
    "Siapa nama mantan pacar temanmu yang dulu pernah kamu sukai diam-diam?",
    "Pernahkah kamu mengambil uang dari ayah atau ibumu? Alasannya?",
    "Apa yang membuatmu bahagia saat sedang sedih?",
    "Pernahkah kamu memiliki perasaan cinta satu arah? jika ya kepada siapa? bagaimana perasaannya, bro?",
    "Pernah menjadi selingkuhan seseorang?",
    "Hal paling ditakuti?",
    "Siapa orang yang paling berpengaruh dalam hidupmu?",
    "Prestasi apa yang berhasil kamu raih tahun ini?",
    "Siapa orang yang bisa membuatmu keren?",
    "Siapa orang yang pernah membuatmu sangat bahagia?",
    "Siapa yang paling mendekati tipe pasangan idamanmu di sini?",
    "Dengan siapa kamu suka bermain?",
    "Pernahkah kamu menolak seseorang? alasan mengapa?",
    "Sebutkan insiden yang pernah menyakiti perasaanmu yang masih kamu ingat",
    "Prestasi apa yang sudah kamu capai tahun ini?",
    "Kebiasaan terburukmu di sekolah?",
    "Lagu apa yang paling sering kamu nyanyikan di dalam kamar mandi?",
    "Pernahkah kamu mengalami pengalaman dekat dengan kematian?",
    "Kapan terakhir kali kamu sangat marah? Mengapa?",
    "Siapa orang terakhir yang meneleponmu?",
    "Apakah kamu memiliki bakat tersembunyi? Apa sajakah itu?",
    "Kata apa yang paling kamu benci?",
    "Video YouTube terakhir apa yang kamu tonton?",
    "Hal terakhir apa yang kamu cari di Google?",
    "Dalam grup ini, dengan siapa yang ingin kamu tukar kehidupan selama seminggu?",
    "Apa hal paling menakutkan yang pernah terjadi padamu?",
    "Pernahkah kamu kentut dan menyalahkannya kepada orang lain?",
    "Kapan terakhir kali kamu membuat orang lain menangis?",
    "Pernahkah kamu menghilangkan jejak dari seorang teman?",
    "Pernahkah kamu melihat mayat?",
    "Anggota keluargamu yang paling mengganggumu dan mengapa?",
    "Jika kamu harus menghapus satu aplikasi dari ponselmu, aplikasi mana yang akan kamu hapus?",
    "Aplikasi apa yang paling sering kamu buang-buang waktu di dalamnya?",
    "Pernahkah kamu berpura-pura sakit untuk pulang dari sekolah?",
    "Apa barang paling memalukan di dalam kamar kamarmu?",
    "Jika terdampar di pulau terpencil, lima barang apa yang akan kamu bawa?",
    "Pernahkah kamu tertawa begitu keras hingga pipismu basah?",
    "Apakah kamu mencium bau kentutmu sendiri?",
    "Pernahkah kamu kencing di tempat tidur saat tidur?",
    "Apa kesalahan terbesar yang pernah kamu buat?",
    "Pernahkah kamu mencontek dalam ujian?",
    "Apa hal terburuk yang pernah kamu lakukan?",
    "Kapan terakhir kali kamu menangis?",
    "Di antara orang tua kamu, siapa yang kamu cintai paling?",
    "Apakah kamu kadang-kadang memasukkan jari ke dalam lubang hidungmu?",
    "Siapa pujaan hati kamu saat masa sekolah dulu?",
    "Berbicara jujur, apakah kamu menyukai seorang anak laki-laki dalam grup ini?",
    "Pernahkah kamu menyukai seseorang? Berapa lama?",
    "Apakah kamu punya pacar? Apa ketakutan terbesarmu?",
    "Pernahkah kamu menyukai seseorang dan merasa bahwa orang tersebut juga menyukaimu?",
    "Siapa nama mantan pacar temanmu yang pernah kamu sukai diam-diam?",
    "Pernahkah kamu mengambil uang milik ibu atau ayahmu? Apa alasannya?",
    "Apa yang membuatmu bahagia saat sedang sedih?",
    "Apakah kamu menyukai seseorang dalam grup ini? Jika ya, siapa?",
    "Pernahkah kamu ditipu oleh seseorang?",
    "Siapa orang yang paling penting dalam hidupmu?",
    "Prestasi apa yang telah kamu capai tahun ini?",
    "Siapa orang yang bisa membuatmu bahagia saat sedang sedih?",
    "Siapa orang yang pernah membuatmu merasa tidak nyaman?",
    "Pernahkah kamu berbohong kepada orang tua?",
    "Apakah kamu masih menyukai mantan pacarmu?",
    "Siapa yang ingin kamu ajak bermain bersama?",
    "Pernahkah kamu mencuri sesuatu yang besar? Alasannya apa?",
    "Sebutkan insiden yang pernah membuatmu terluka dan masih kamu ingat?",
    "Prestasi apa yang sudah kamu raih tahun ini?",
    "Apa kebiasaan terburukmu saat di sekolah?",
    "Apakah kamu mencintai pencipta bot ini, Dani 😄",
    "Pernahkah kamu berpikir untuk membalas dendam pada guru?",
    "Apakah kamu menyukai perdana menteri saat ini di negaramu?",
    "Apakah kamu vegetarian atau non-vegetarian?",
    "Jika kamu bisa menjadi tak terlihat, apa yang pertama kali akan kamu lakukan?",
    "Apa rahasia yang kamu simpan dari orang tua kamu?",
    "Siapa pujaan hati rahasiamu?",
    "Siapa orang terakhir yang kamu intip di media sosial?",
    "Jika seorang jin memberimu tiga permintaan, apa yang akan kamu minta?",
    "Apa penyesalan terbesarmu?",
    "Hewan seperti apa menurutmu yang paling mirip denganmu?",
    "Berapa banyak foto selfie yang kamu ambil dalam sehari?",
    "Apa acara favoritmu saat masa kanak-kanak?",
    "Jika kamu bisa menjadi karakter fiksi dalam satu hari, siapa yang akan kamu pilih?",
    "Dengan siapa kamu paling sering mengirim pesan?",
    "Apa kebohongan terbesar yang pernah kamu ceritakan kepada orang tua kamu?",
    "Siapa selebriti yang menjadi pujaan hatimu?",
    "Mimpi paling aneh yang pernah kamu alami?",
    "Apakah kamu bermain PUBG? Jika ya, berikan nomor ID-mu."
]
              const alyaTruth = truth[Math.floor(Math.random() * truth.length)]
              buffertruth = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
              satanic.sendMessage(from, { image: buffertruth, caption: '_You choose TRUTH_\n'+ alyaTruth }, {quoted:m})
              break
case 'ceksifat':              
case 'checkme': {
    const bet = m.sender
    const name = m.pushname || 'User'

    // helper random persen
    const rand100 = () => Math.floor(Math.random() * 101)

    const sifat = [
        "Baik", "Tidak ramah", "pembangkang", "Chapri", "Nibba/Nibbi", "Mengganggu",
        "Rusak", "Orang marah", "Sopan", "Beban", "Hebat",
        "Cringe", "Pembohong"
    ]

    const hobi = [
        "Memasak","Menari","Bermain","Bermain game","Melukis",
        "Membantu Orang Lain","Menonton anime","Membaca",
        "Bersepeda","Bernyanyi", "maling","rampok","maling ayam","berak","begal","Berbincang-bincang",
        "Berbagi Meme","Menggambar","Menghabiskan Uang Orang Tua",
        "Bermain Truth or Dare","Menghabiskan Waktu Sendirian"
    ]

    const cakep = ["Ya", "Tidak", "Sangat jelek", "Sangat tampan"]

    const watak = [
        "Peduli","Murah hati","Pemarah","Tunduk","Baik",
        "Berhati baik","Sabar","UwU","Terbaik","Membantu"
    ]

    // random hasil
    const result = {
        sifat: sifat[Math.floor(Math.random() * sifat.length)],
        hobi: hobi[Math.floor(Math.random() * hobi.length)],
        bucin: rand100(),
        great: rand100(),
        ganteng: cakep[Math.floor(Math.random() * cakep.length)],
        watak: watak[Math.floor(Math.random() * watak.length)],
        baik: rand100(),
        buruk: rand100(),
        cerdas: rand100(),
        berani: rand100(),
        penakut: rand100()
    }

    // ambil PP user
    let ppuser
    try {
        ppuser = await satanic.profilePictureUrl(bet, 'image')
    } catch {
        ppuser = defaultpp // fallback kalau PP private
    }

    const profile = `*≡══《 Check @${bet.split('@')[0]} 》══≡*

*Nama :* ${name}
*Karakteristik :* ${result.sifat}
*Hobi :* ${result.hobi}
*Bucin :* ${result.bucin}%
*Great :* ${result.great}%
*Ganteng :* ${result.ganteng}
*Watak :* ${result.watak}
*Moral Baik :* ${result.baik}%
*Moral Buruk :* ${result.buruk}%
*Kecerdasan :* ${result.cerdas}%
*Keberanian :* ${result.berani}%
*Penakut :* ${result.penakut}%

*≡═══《 CHECK PROPERTIES 》═══≡*`

    satanic.sendMessage(
        from,
        {
            image: { url: ppuser },
            caption: profile,
            mentions: [bet]
        },
        { quoted: m }
    )
}
break   
case 'yatim':
case 'piatu':
case 'jomblo':
case 'waria':
case 'koruptor':
case 'psikopat':
case 'pedofil':
case 'miskin':
case 'tukangjajan':
case 'jelek':
case 'mokondo':
case 'penipu':
case 'tukangcopet':
case 'tukangbo':
case 'tukangcoli':
case 'tukangkawin':
case 'maling':
case 'pelakor':
case 'perampok':
case 'begal':
case 'wibu':
case 'janda':
case 'jodohku': {
    if (!m.isGroup) return reply('only group')
    
    let member = participants.map(u => u.id)
    let me = m.sender
    let jodoh = member[Math.floor(Math.random() * member.length)]
    while (jodoh === me) {
        jodoh = member[Math.floor(Math.random() * member.length)]
    }
    
    let text = ` Anjayy ${command}\n\n@${jodoh.split('@')[0]}\n\n`
    
    satanic.sendMessage(m.chat, {
        text: text,
        mentions: [jodoh]
    }, { quoted: m })
}
break
case 'cekyatim':
case 'cekjelek':
case 'cekjodoh':
case 'cekmiskin':
case 'cektolol':
case 'cekkaya':
case 'cekwibu': {

    if (!text && (!m.mentionedJid || m.mentionedJid.length === 0)) {
        return reply(`*CARA PAKAI:*\n\n${prefix}${command} @user\n${prefix}${command} nama orang\n\n*Contoh:*\n${prefix}${command} @${m.sender.split('@')[0]}\n${prefix}${command} budi`)
    }
    
    let target = 'kamu'
    let persen = Math.floor(Math.random()  * 100) + 1
    
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        return satanic.sendMessage(m.chat, {
            text: `*${persen}%*`,
            mentions: [m.mentionedJid[0]]
        }, { quoted: m })
    }
    
    if (text) {
        target = text
    }
    
    reply(`${target} *${persen}%*`)
}
break
case 'ceknamabapak':
case 'namabapak':
case 'cekbapak': {
    if (!text && (!m.mentionedJid || m.mentionedJid.length === 0)) {
        return reply(`*CARA PAKAI:*\n\n${prefix}${command} @user\n${prefix}${command} nama orang\n\n*Contoh:*\n${prefix}${command} @${m.sender.split('@')[0]}\n${prefix}${command} Budi`)
    }
    
    let target = ''
    let isMention = false
    let mentionId = ''
    
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = `@${m.mentionedJid[0].split('@')[0]}`
        isMention = true
        mentionId = m.mentionedJid[0]
    } else if (text) {
        target = text.trim()
    }
    
    let namaBapak = [
        'Paijo', 'Tukul', 'Ucup', 'Bambang', 'Sule', 'Komeng', 'udin', 'yatno', 'ucok', 'agus', 'bahlil',
        'Somad', 'Jarwo', 'Bejo', 'Kasino', 'Dono', 'Indro',
        'Rambo', 'Joni', 'Agus', 'Budi', 'Joko', 'Mamat'
    ]
    
    let namaRandom = namaBapak[Math.floor(Math.random() * namaBapak.length)]
    
    let hasil = `Bapaknya *${target}* namanya *${namaRandom}* 🤣`
    
    if (isMention) {
        satanic.sendMessage(m.chat, {
            text: hasil,
            mentions: [mentionId]
        }, { quoted: m })
    } else {
        reply(hasil)
    }
}
break
case 'cekkodam':
case 'kodam':
case 'cekkodamku': {
    let target = ''
    let isMention = false
    let mentionId = ''
    let persen = Math.floor(Math.random() * 100) + 1
    
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = `@${m.mentionedJid[0].split('@')[0]}`
        isMention = true
        mentionId = m.mentionedJid[0]
    } else if (text) {
        target = text.trim()
    } else {
        target = `@${m.sender.split('@')[0]}`
        isMention = true
        mentionId = m.sender
    }
    
    let kodam = [
        'Kodam Tuyul Ngamen', 'Kodam Tuyul London', 'Kodam Tuyul Dubai', 'Kodam Tuyul Jepang',
        'Kodam Genderuwo Baper', 'Kodam Genderuwo Galau', 'Kodam Genderuwo Mikir', 'Kodam Genderuwo Ngoding',
        'Kodam Pocong Kece', 'Kodam Pocong Badung', 'Kodam Pocong Gaul', 'Kodam Pocong Mewing',
        'Kodam Kuntilanak Cantik', 'Kodam Kuntilanak Modus', 'Kodam Kuntilanak Baper', 'Kodam Kuntilanak Jomblo',
        'Kodam Sundel Bolong Lari', 'Kodam Sundel Bolong Ngamen', 'Kodam Sundel Bolong Opo', 'Kodam Sundel Bolong Joget',
        'Kodam Leak Bali', 'Kodam Leak Sakti', 'Kodam Leak Ngamuk', 'Kodam Leak Nangis',
        'Kodam Wewe Gombel Jomblo', 'Kodam Wewe Gombel Galau', 'Kodam Wewe Gombel Baper', 'Kodam Wewe Gombel Mikir',
        'Kodam Jerangkong Ngegas', 'Kodam Jerangkong Baper', 'Kodam Jerangkong Ngopi', 'Kodam Jerangkong Nonton',
        'Kodam Hantu Boneka', 'Kodam Hantu TV', 'Kodam Hantu Kulkas', 'Kodam Hantu AC',
        'Kodam Pocong Merah', 'Kodam Pocong Hijau', 'Kodam Pocong Biru', 'Kodam Pocong Pink',
        'Kodam Kuyang Joget', 'Kodam Kuyang Ngamen', 'Kodam Kuyang Baper', 'Kodam Kuyang Nangis',
        'Kodam Sundel Galau', 'Kodam Sundel Baper', 'Kodam Sundel Mikir', 'Kodam Sundel Joget',
        'Kodam Genderuwo Opo', 'Kodam Genderuwo Wes', 'Kodam Genderuwo Kok', 'Kodam Genderuwo Lah',
        'Kodam Banaspati Ngamuk', 'Kodam Banaspati Galau', 'Kodam Banaspati Baper', 'Kodam Banaspati Mikir',
        'Kodam Tongkat Mbah', 'Kodam Tongkat Sakti', 'Kodam Tongkat Maut', 'Kodam Tongkat Petir',
        'Kodam Sapu Terbang', 'Kodam Sapu Lidi', 'Kodam Sapu Jagad', 'Kodam Sapu Tua',
        'Kodam Karpet Terbang', 'Kodam Karpet Sakti', 'Kodam Karpet Rusak', 'Kodam Karpet Basah',
        'Kodam Jubah Hitam', 'Kodam Jubah Putih', 'Kodam Jubah Sakti', 'Kodam Jubah Kotor',
        'Kodam Keris Pusaka', 'Kodam Keris Sakti', 'Kodam Keris Maut', 'Kodam Keris Tua',
        'Kodam Mustika Kecubung', 'Kodam Mustika Merah', 'Kodam Mustika Hitam', 'Kodam Mustika Putih',
        'Kodam Jimat Sakti', 'Kodam Jimat Maut', 'Kodam Jimat Tua', 'Kodam Jimat Pusaka',
        'Kodam Pelet Jawa', 'Kodam Pelet Sakti', 'Kodam Pelet Maut', 'Kodam Pelet Ampuh',
        'Kodam Susuk', 'Kodam Susuk Sakti', 'Kodam Susuk Maut', 'Kodam Susuk Emas',
        'Kodam Sendal Jepit', 'Kodam Sendal Swal', 'Kodam Sendal Hotel', 'Kodam Sendal Bolong',
        'Kodam Ember Bocor', 'Kodam Ember Plastik', 'Kodam Ember Besi', 'Kodam Ember Tua',
        'Kodam Gayung Nyleneh', 'Kodam Gayung Plastik', 'Kodam Gayung Besi', 'Kodam Gayung Tua',
        'Kodam Sapu Lidi', 'Kodam Sapu Ijuk', 'Kodam Sapu Tua', 'Kodam Sapu Baru',
        'Kodam Keset Muka', 'Kodam Keset Kaki', 'Kodam Keset Basah', 'Kodam Keset Kering',
        'Kodam Kipas Angin', 'Kodam Kipas Tangan', 'Kodam Kipas Rusak', 'Kodam Kipas Baru',
        'Kodam Lampu Bohlam', 'Kodam Lampu LED', 'Kodam Lampu Minyak', 'Kodam Lampu Petromak',
        'Kodam Kasur Busa', 'Kodam Kasur Kapuk', 'Kodam Kasur Bocor', 'Kodam Kasur Baru',
        'Kodam Bantal Guling', 'Kodam Bantal Busa', 'Kodam Bantal Kapuk', 'Kodam Bantal Bau',
        'Kodam Selimut', 'Kodam Selimut Basah', 'Kodam Selimut Kering', 'Kodam Selimut Baru',
        'Kodam Karpet', 'Kodam Karpet Basah', 'Kodam Karpet Kering', 'Kodam Karpet Baru',
        'Kodam Hape Jadul', 'Kodam Hape Batrey', 'Kodam Hape Error', 'Kodam Hape Lemot',
        'Kodam TV Tabung', 'Kodam TV Digital', 'Kodam TV Rusak', 'Kodam TV Butut'
    ]
    
    let randomKodam = kodam[Math.floor(Math.random() * kodam.length)]
    
    let hasil = `🔮 *CEK KODAM* 🔮\n\n👤 ${target}\n🎲 Kodam: ${randomKodam}\n📊 Level: ${persen}%\n\n🤣🤣🤣`
    
    if (isMention) {
        satanic.sendMessage(m.chat, {
            text: hasil,
            mentions: [mentionId]
        }, { quoted: m })
    } else {
        reply(hasil)
    }
}
break

case 'ulartangga': {
    if (!m.isGroup) return reply('❌ Hanya bisa digunakan di grup!')

class GameSession {
    constructor(id, sMsg) {
        this.id = id
        this.players = []
        this.game = new SnakeAndLadderGame(sMsg)
    }
}
class SnakeAndLadderGame {
    constructor(sMsg) {
        this.sendMsg = sMsg
        this.players = []
        this.boardSize = 100
        this.snakesAndLadders = [
            { start: 29, end: 7 }, { start: 24, end: 12 }, { start: 15, end: 37 },
            { start: 23, end: 41 }, { start: 72, end: 36 }, { start: 49, end: 86 },
            { start: 90, end: 56 }, { start: 75, end: 64 }, { start: 74, end: 95 },
            { start: 91, end: 72 }, { start: 97, end: 78 }
        ]
        this.currentPositions = {}
        this.currentPlayerIndex = 0
        this.bgImageUrl = 'https://i.pinimg.com/originals/2f/68/a7/2f68a7e1eee18556b055418f7305b3c0.jpg'
        this.player1ImageUrl = 'https://i.pinimg.com/originals/75/33/22/7533227c53f6c270a96d364b595d6dd5.jpg'
        this.player2ImageUrl = 'https://i.pinimg.com/originals/be/68/13/be6813a6086681070b0f886d33ca4df9.jpg'
        this.bgImage = null
        this.player1Image = null
        this.player2Image = null
        this.cellWidth = 40
        this.cellHeight = 40
        this.keyId = null
        this.started = false
    }

    initializeGame() {
        for (const player of this.players) {
            this.currentPositions[player] = 1
        }
        this.currentPlayerIndex = 0
        this.started = true
    }

    rollDice() {
        return Math.floor(Math.random() * 6) + 1
    }

    async movePlayer(player, steps) {
        if (this.players.length === 0) return
        const currentPosition = this.currentPositions[player]
        let newPosition = currentPosition + steps
        for (const otherPlayer of this.players) {
            if (otherPlayer !== player && this.currentPositions[otherPlayer] === newPosition) {
                const message = `😱 *Oh tidak!* ${player.split('@')[0]} *diinjak oleh* ${otherPlayer.split('@')[0]}.* Kembali ke awal cell.*`
                await m.reply(message)
                newPosition = 1
            }
        }
        const snakeOrLadder = this.snakesAndLadders.find(s => s.start === newPosition)
        if (snakeOrLadder) newPosition = snakeOrLadder.end
        newPosition = Math.min(newPosition, this.boardSize)
        this.currentPositions[player] = newPosition
    }

    async fetchImage(url) {
        try {
            const response = await axios.get(url, { responseType: 'arraybuffer' })
            return await jimp.read(Buffer.from(response.data, 'binary'))
        } catch (error) {
            console.error(`Error fetching image from ${url}:`, error)
            throw error
        }
    }

    async getBoardBuffer() {
        const board = new jimp(420, 420)
        this.bgImage.resize(420, 420)
        board.composite(this.bgImage, 0, 0)
        for (const player of this.players) {
            const playerPosition = this.currentPositions[player]
            const playerImage = player === this.players[0] ? this.player1Image : this.player2Image
            const playerX = ((playerPosition - 1) % 10) * this.cellWidth + 10
            const playerY = (9 - Math.floor((playerPosition - 1) / 10)) * this.cellHeight + 10
            board.composite(playerImage.clone().resize(this.cellWidth, this.cellHeight), playerX, playerY)
        }
        return board.getBufferAsync(jimp.MIME_PNG)
    }

    async startGame(m, player1Name, player2Name) {
        await m.reply(`🐍🎲 *Selamat datang di Permainan Ular Tangga!* 🎲🐍 \n\n${player1Name.split('@')[0]} vs ${player2Name.split('@')[0]}`)
        this.players = [player1Name, player2Name]
        this.initializeGame()
        if (!this.bgImage) this.bgImage = await this.fetchImage(this.bgImageUrl)
        if (!this.player1Image) this.player1Image = await this.fetchImage(this.player1ImageUrl)
        if (!this.player2Image) this.player2Image = await this.fetchImage(this.player2ImageUrl)
        const boardBuffer = await this.getBoardBuffer()
        const { key } = await satanic.sendMessage(m.chat, { image: boardBuffer }, { quoted: m })
        this.keyId = key
    }

    async playTurn(m, player) {
        if (!this.players.length) {
            await m.reply('🛑 *Tidak ada permainan aktif.* Gunakan ".ulartangga start" untuk memulai permainan baru.')
            return
        }
        if (player !== this.players[this.currentPlayerIndex]) {
            await m.reply(`🕒 *Bukan giliranmu.* \n\nSekarang giliran ${this.players[this.currentPlayerIndex].split('@')[0]}`)
            return
        }
        const diceRoll = this.rollDice()
        await m.reply(`🎲 ${player.split('@')[0]} *melempar dadu.*\n\n  - Dadu: *${diceRoll}*\n  - Dari kotak: *${this.currentPositions[player]}*\n  - Ke kotak: *${this.currentPositions[player] + diceRoll}*`)
        if (diceRoll !== 6) {
            this.movePlayer(player, diceRoll)
            const snakeOrLadder = this.snakesAndLadders.find(s => s.start === this.currentPositions[player])
            if (snakeOrLadder) {
                const action = snakeOrLadder.end < snakeOrLadder.start ? 'Mundur' : 'Maju'
                await m.reply(`🐍 ${player.split('@')[0]} menemukan ${action === 'Mundur' ? 'ular' : 'tangga'}! ${action} *ke kotak ${snakeOrLadder.end}.*`)
                this.currentPositions[player] = snakeOrLadder.end
            }
        }
        if (diceRoll !== 6) {
            this.switchPlayer()
        } else {
            await m.reply('🎲 Anda mendapat 6, jadi giliran Anda masih berlanjut.')
            this.movePlayer(player, diceRoll)
        }
        if (this.currentPositions[player] === this.boardSize) {
            await m.reply(`🎉 ${player.split('@')[0]} menang! Selamat!`)
            this.resetSession()
        }
        const boardBuffer = await this.getBoardBuffer()
        const sendMsg = this.sendMsg
        await sendMsg.sendMessage(m.chat, { delete: this.keyId })
        const { key } = await satanic.sendMessage(m.chat, { image: boardBuffer }, { quoted: m })
        this.keyId = key
        return
    }

    addPlayer(player) {
        if (this.players.length < 2 && !this.players.includes(player) && player !== '') {
            this.players.push(player)
            return true
        } else {
            return false
        }
    }

    switchPlayer() {
        this.currentPlayerIndex = 1 - this.currentPlayerIndex
    }

    resetSession() {
        this.players = []
        this.currentPositions = {}
        this.currentPlayerIndex = 0
        this.started = false
    }

    isGameStarted() {
        return this.started
    }
}
    // Inisialisasi objek game jika belum ada
    satanic.ulartangga = satanic.ulartangga || {}
    const sessions = satanic.ulartangga_ = satanic.ulartangga_ || {}
    const sessionId = m.chat
    const session = sessions[sessionId] || (sessions[sessionId] = new GameSession(sessionId, satanic))
    const game = session.game
    const { state } = satanic.ulartangga[m.chat] || { state: false }

    switch (args[0]) {
        case 'join':
            if (state) return reply('🛑 *Permainan sudah dimulai.* Tidak dapat bergabung.')
            const playerName = m.sender
            const joinSuccess = game.addPlayer(playerName)
            joinSuccess
                ? reply(`👋 ${playerName.split('@')[0]} *bergabung ke dalam permainan.*`)
                : reply('*Anda sudah bergabung atau permainan sudah penuh.* Tidak dapat bergabung.')
            break

        case 'start':
            if (state) return reply('🛑 *Permainan sudah dimulai.* Tidak dapat memulai ulang.')
            satanic.ulartangga[m.chat] = { ...satanic.ulartangga[m.chat], state: true }
            if (game.players.length === 2) {
                await game.startGame(m, game.players[0], game.players[1])
            } else {
                reply('👥 *Tidak cukup pemain untuk memulai permainan.* Diperlukan minimal 2 pemain.')
            }
            break

        case 'roll':
            if (!state) return reply('🛑 *Permainan belum dimulai.* Ketik ".ulartangga start" untuk memulai.')
            if (game.isGameStarted()) {
                const currentPlayer = game.players[game.currentPlayerIndex]
                if (m.sender !== currentPlayer) {
                    reply(`🕒 *Bukan giliranmu.* \n\nSekarang giliran ${currentPlayer.split('@')[0]}`)
                } else {
                    await game.playTurn(m, currentPlayer)
                }
            } else {
                reply('🛑 *Permainan belum dimulai.* Ketik ".ulartangga start" untuk memulai.')
            }
            break

        case 'reset':
            satanic.ulartangga[m.chat] = { ...satanic.ulartangga[m.chat], state: false }
            session.game.resetSession()
            delete sessions[sessionId]
            reply('🔄 *Sesi permainan direset.*')
            break

        case 'help':
            reply(`🎲🐍 *Permainan Ular Tangga* 🐍🎲\n\n*Commands:*\n- ${prefix + command} join : Bergabung ke dalam permainan.\n- ${prefix + command} start : Memulai permainan.\n- ${prefix + command} roll : Melempar dadu untuk bergerak.\n- ${prefix + command} reset : Mereset sesi permainan.`)
            break

        default:
            reply(`❓ *Perintah tidak valid.* Gunakan ${prefix + command} help untuk melihat daftar perintah.`)
    }
}
break;
case 'ttc': case 'ttt': case 'tictactoe': {
            let TicTacToe = require("./lib/tictactoe")
            this.game = this.game ? this.game : {}
            if (Object.values(this.game).find(room13 => room13.id.startsWith('tictactoe') && [room13.game.playerX, room13.game.playerO].includes(m.sender))) return reply(`You Are Still In The Game`)
            let room13 = Object.values(this.game).find(room13 => room13.state === 'WAITING' && (text ? room13.name === text : true))
            if (room13) {
            room13.o = m.chat
            room13.game.playerO = m.sender
            room13.state = 'PLAYING'
            let arr = room13.game.render().map(v => {
            return {
            X: '❌',
            O: '⭕',
            1: '1️⃣',
            2: '2️⃣',
            3: '3️⃣',
            4: '4️⃣',
            5: '5️⃣',
            6: '6️⃣',
            7: '7️⃣',
            8: '8️⃣',
            9: '9️⃣',
            }[v]
            })
            let str = `room13 ID: ${room13.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Waiting @${room13.game.currentTurn.split('@')[0]}

Type *surrender* to surrender and admit defeat`
            if (room13.x !== room13.o) await satanic.sendText(room13.x, str, m, { mentions: parseMention(str) } )
            await satanic.sendText(room13.o, str, m, { mentions: parseMention(str) } )
            } else {
            room13 = {
            id: 'tictactoe-' + (+new Date),
            x: m.chat,
            o: '',
            game: new TicTacToe(m.sender, 'o'),
            state: 'WAITING'
            }
            if (text) room13.name = text
            reply('Waiting For Partner' + (text ? ` Type The Command Below ${prefix}${command} ${text}` : ''))
            this.game[room13.id] = room13
            }
            }
            break
            case 'delttc': case 'delttt': {
            this.game = this.game ? this.game : {}
            try {
            if (this.game) {
            delete this.game
            satanic.sendText(m.chat, `Successfully deleted TicTacToe session`, m)
            } else if (!this.game) {
            reply(`Session TicTacToe🎮 does not exist`)
            } else throw '?'
            } catch (e) {
            reply('damaged')
            }
            }
            break
            case 'tebakbom': {
    if (!m.isGroup) return reply('❌ Hanya bisa digunakan di grup!')

    satanic.bomb = satanic.bomb || {}
    let id = m.chat
    let timeout = 180000

    // Cek apakah user kirim angka langsung atau nyerah saat game aktif
    if (id in satanic.bomb) {
        let body = args[0]
        let sender = m.sender.split('@')[0]
        
        // Cek nyerah
        let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(body)
        if (isSurrender) {
            reply(`🚩 ${sender} menyerah!`)
            clearTimeout(satanic.bomb[id][2])
            delete satanic.bomb[id]
            return
        }

        // Cek angka
        if (!isNaN(body)) {
            let pick = satanic.bomb[id][1].find(v => v.pos == Number(body))
            if (!pick) return reply('Kirim angka 1 - 9')

            if (pick.open)
                return reply(`Kotak ${pick.number} sudah dibuka`)

            pick.open = true
            let grids = satanic.bomb[id][1]

            let render = () => {
                let t = `乂  *B O M B*\n\n`
                for (let i = 0; i < grids.length; i += 3)
                    t += grids.slice(i, i + 3).map(v => v.open ? v.emot : v.number).join('') + '\n'
                return t
            }

            if (pick.emot === '💥') {
                let teks2 = render()
                teks2 += `\n\n💥 BOM MELEDAK!\n${sender} kalah!`

                reply(teks2)
                clearTimeout(satanic.bomb[id][2])
                delete satanic.bomb[id]
                return
            }

            let safeOpen = grids.filter(v => v.open && v.emot !== '💥').length
            if (safeOpen >= 8) {
                let teks2 = render()
                teks2 += `\n\n🎉 MENANG!\nSemua kotak aman terbuka!`

                reply(teks2)
                clearTimeout(satanic.bomb[id][2])
                delete satanic.bomb[id]
                return
            }

            let teks2 = render()
            teks2 += `\n\n✨ Aman! Lanjutkan!`

            reply(teks2)
            return
        }
    }

    // Command untuk start game
    if (id in satanic.bomb)
        return reply('*^ sesi ini belum selesai!*')

    const bom = ['💥','✅','✅','✅','✅','✅','✅','✅','✅']
        .sort(() => Math.random() - 0.5)

    const number = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣']

    const grid = bom.map((v, i) => ({
        emot: v,
        number: number[i],
        pos: i + 1,
        open: false
    }))

    let teks = `乂  *B O M B*\n\nKirim angka *1 - 9* untuk membuka kotak:\n\n`
    for (let i = 0; i < grid.length; i += 3)
        teks += grid.slice(i, i + 3).map(v => v.open ? v.emot : v.number).join('') + '\n'

    teks += `\n⏳ Timeout : ${timeout/60000} menit`
    teks += `\n💣 Jika kena bom, kamu kalah!`
    teks += `\n\nKetik .tebakbom nyerah untuk menyerah\n\n untuk membuka kotak bom ketik .tebakbom 1`

    let msg = await reply(teks)

    satanic.bomb[id] = [
        msg,
        grid,
        setTimeout(() => {
            let b = grid.find(v => v.emot === '💥')
            if (satanic.bomb[id])
                reply(`⏰ Waktu habis!\nBom di kotak ${b.pos}`, msg)
            delete satanic.bomb[id]
        }, timeout)
    ]
}
break
case 'alquran': {
    if (!text) return reply(`📖 *AL-QURAN*\n\nContoh:\n.alquran al-baqarah\n.alquran yasin\n.alquran al-baqarah 1-5\n.alquran yasin 1`)

    let query = text.replace(/^[.!?]alquran\s*/i, '').trim()
    if (!query) return reply(`📖 *AL-QURAN*\n\nContoh:\n.alquran al-baqarah\n.alquran yasin`)

    let [surahName, ayatRange] = query.split(/\s+(\d+[-–]\d+|\d+)/).filter(Boolean)

    try {
        const slug = surahName.toLowerCase().replace(/\s+/g, "-")
        const url = `https://quran.nu.or.id/${slug}`
        
        const res = await fetch(url)
        const html = await res.text()
        const $ = cheerio.load(html)

        const title = $("h1").first().text().trim()
        const info = $("h1").next("span").text().trim()

        const hasil = []

        $('div[id]').each((i, el) => {
            const id = $(el).attr('id')
            if (!/^\d+$/.test(id)) return

            const arab = $(el).find('[dir="rtl"]').first().text().trim()
            const latin = $(el).find('.text-primary-500').first().text().trim()
            const arti = $(el).find('.text-neutral-700').first().text().trim()

            if (arab && latin && arti) {
                hasil.push({ ayat: Number(id), arab, latin, arti })
            }
        })

        if (!hasil.length) return reply('❌ Surah tidak ditemukan!')

        let teks = `📖 *AL-QURAN*\n\n`
        teks += `📝 *${title}*\n`
        teks += `ℹ️ ${info}\n`
        teks += `📊 Total Ayat: ${hasil.length}\n\n`

        if (ayatRange) {
            if (ayatRange.includes('-') || ayatRange.includes('–')) {
                let [start, end] = ayatRange.split(/[-–]/).map(Number)
                hasil.filter(v => v.ayat >= start && v.ayat <= end).forEach(v => {
                    teks += `━━━━━━━━━━━━━━━\n`
                    teks += `🕌 *Ayat ${v.ayat}*\n\n`
                    teks += `${v.arab}\n\n`
                    teks += `🔤 ${v.latin}\n\n`
                    teks += `🇮🇩 ${v.arti}\n\n`
                })
            } else {
                let ayat = hasil.find(v => v.ayat == Number(ayatRange))
                if (!ayat) return reply('❌ Ayat tidak ditemukan!')
                teks += `${ayat.arab}\n\n`
                teks += `🔤 ${ayat.latin}\n\n`
                teks += `🇮🇩 ${ayat.arti}\n`
            }
        } else {
            hasil.forEach(v => {
                teks += `${v.arab}\n\n`
                teks += `🔤 ${v.latin}\n\n`
                teks += `🇮🇩 ${v.arti}\n\n`
                teks += `━━━━━━━━━━━━━━━\n\n`
            })
        }

        await reply(teks)

    } catch (error) {
        console.error(error)
        reply('❌ Gagal mengambil data. Coba lagi nanti.')
    }
}
break
case 'murotal': {
    if (!text) return reply(`📻 *MUROTAL*\n\nContoh:\n.murotal al-fatihah\n.murotal yasin\n.murotal al-baqarah`)

    let query = text.replace(/^[.!?]murotal\s*/i, '').trim()
    if (!query) return reply(`📻 *MUROTAL*\n\nContoh:\n.murotal al-fatihah\n.murotal yasin`)

    try {
        const res = await fetch("https://islamipedia.id/murottal/")
        const html = await res.text()
        const $ = cheerio.load(html)
        
        const data = $(".surah-item").map((i, el) => ({
            no: parseInt($(el).find("h5").text().split(".")[0]),
            surah: ($(el).attr("data-title") || "").toLowerCase(),
            arti: $(el).find("p").text().trim(),
            audio: $(el).attr("data-audio") || ""
        })).get()
        
        const q = query.toLowerCase()
        const find = data.find(v => v.surah.replace(/[^a-z0-9]/g, "").includes(q.replace(/[^a-z0-9]/g, "")))
        
        if (!find) return reply('❌ Surah tidak ditemukan!')
        
        await satanic.sendMessage(m.chat, { 
            audio: { url: find.audio }, 
            mimetype: "audio/mpeg",
            ptt: false
        }, { quoted: m })
        
    } catch (e) {
        console.error(e)
        reply('❌ Gagal mengambil murotal. Coba lagi nanti.')
    }
}
break
default:
if (budy.startsWith('vv')) {
if (!isCreator) return
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
}
                // Owner eval commands
                if (budy.startsWith('>/')) {
                    if (!isCreator) return;
                    try {
                        let evaled = await eval(budy.slice(2));
                        if (typeof evaled !== 'string') evaled = util.inspect(evaled);
                        await reply(evaled);
                    } catch (err) {
                        reply(String(err));
                    }
                }
                
                if (budy.startsWith('=>')) {
                    if (!isCreator) return;
                    let teks;
                    try {
                        teks = await eval(`(async () => { ${budy.slice(2)}})()`);
                    } catch (e) {
                        teks = e;
                    } finally {
                        await reply(util.format(teks));
                    }
                }
                break;
        }
    } catch (err) {
        console.error("Error:", err);
        console.log(util.format(err));
    }
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright(`Update ${__filename}`));
    delete require.cache[file];
    require(file);
});
