// =================================================================
// • الحقوق : 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 - مطور 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓
// • القناة : https://whatsapp.com/channel/0029VbDd8Iw5Ejxwlvjl3l1r
// • الوصف : أخبار كرة القدم العالمية - سكربت سريع ومترجم
// • الإصدار : v3.0 GOJO FIXED
// =================================================================
import axios from "axios";
import cheerio from "cheerio";

const DECO_TOP = `* ━ ╼╃ ⌬〔 ﷽ 〕⌬ ╄╾ ━ *`
const DECO_BOTTOM = `* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`

let lastIndex = 0

let handler = async (m, { conn }) => {
  await conn.sendMessage(m.chat, { react: { text: '⚽', key: m.key } })

  let articles = await fetchBeritaBola()
  if (!articles.length) return m.reply(`${DECO_TOP}\n\n> *❌┊فشل جلب الأخبار، جرب مرة أخرى*\n\n${DECO_BOTTOM}`)

  if (lastIndex >= articles.length) lastIndex = 0
  let article = articles[lastIndex++]

  // ترجمة سريعة بلا ما تعلق البوت
  let titleAr = await translate(article.title).catch(_ => article.title)

  let caption = `${DECO_TOP}

> *〔 أخبار الكرة┊ ⚽˹ ↶〕*

> *📰┊الخبر:*
> *${titleAr}*

> *📅┊التاريخ:* \`${article.date}\`
> *🏷️┊التصنيف:* \`${article.category || 'كرة قدم'}\`
> *🔗┊المصدر:* Vivagoal

${DECO_BOTTOM}
> *لقراءة المزيد اضغط الرابط:* ${article.url}`

  try {
    await conn.sendMessage(m.chat, {
      image: { url: article.image },
      caption: caption,
    }, { quoted: m })
  } catch {
    await conn.sendMessage(m.chat, { text: caption }, { quoted: m })
  }
}

handler.command = /^(beritabola|اخبار-كره|اخبار-كرة|الكورة)$/i
handler.tags = ["news"]
handler.help = ["اخبار-كرة"]
export default handler

async function fetchBeritaBola() {
  try {
    const { data: html } = await axios.get("https://vivagoal.com/category/berita-bola/", {
      timeout: 10000,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    })
    const $ = cheerio.load(html)
    let articles = []

    $("article,.post-item,.col-lg-4.mb-4").each((i, el) => {
      const url = $(el).find("a").first().attr("href")
      const image = $(el).find("img").attr("data-src") || $(el).find("img").attr("src")
      const title = $(el).find("h3 a,.entry-title a").text().trim()
      const date = $(el).find("time").attr("datetime")?.split('T')[0] || new Date().toLocaleDateString('ar-MA')
      const category = $(el).find(".cat-links a").first().text().trim()

      if (url && title && image && image.startsWith('http')) {
        articles.push({ url, image, title, date, category })
      }
    })

    if (articles.length === 0) throw 'empty'
    return articles
  } catch (e) {
    console.log('[NEWS ERROR]', e.message || e)
    return []
  }
}

async function translate(text) {
  if (!text) return text
  try {
    let url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=${encodeURIComponent(text)}`
    let { data } = await axios.get(url, { timeout: 5000 })
    return data[0]?.map(x => x[0]).join('') || text
  } catch {
    return text // إلا فشلت الترجمة رجع الأصلي
  }
}