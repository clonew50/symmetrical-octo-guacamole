let handler = async (m, { conn }) => {
    let isGroup = m.chat?.endsWith('@g.us') || m.isGroup || false
    if (!isGroup) {
        try { await conn.groupMetadata(m.chat); isGroup = true } catch { isGroup = false }
    }
    if (!isGroup) return conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 هـاد الأمـر خـاص بـالـمـجـمـوعـات فـقـط!*\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })

    try {
        let groupMetadata = await conn.groupMetadata(m.chat)
        let participants = groupMetadata.participants.map(v => v.id || v.jid || v)
        let users = participants.filter(v => v!== conn.user.jid && v!== conn.user.id)

        if (users.length < 2) return conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 خـاصـنـا عـلـى الاقـل 2 ديـال الاعـضـاء!*\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })

        let shuffled = users.sort(() => 0.5 - Math.random())
        let user1 = shuffled[0]
        let user2 = shuffled[1]

        let funnySentences = [
            "صـحـاب مـن الـصـغـر ولـكـن الـمـصـلـحـة كـتـجـمـعـهـم دابـا 😂",
            "هـادو هـمـا لـي كـيـتـفـاهـمـو حـتـى بـلا مـا يـهـضـرو 🤫",
            "واحـد فـيـهـم كـيـسـلـف والاخـر عـمـرو مـا كـيـرجـع 💸",
            "صـحـاب الـى الابـد حـتـى يـجـي الـويـفـي ويـفـرقـهـم 📵",
            "الـصـحـبـة الـصـالـحـة هـادو ولـكـن فـالـحـقـيـقـة غـيـر ديـال الـتـصـاور 🤳",
            "هـاد الـجـوج الا تـفـارقـو الـمـجـمـوعـة غـادي تـخـوى 👻",
            "صـحـاب الـمـقـاهـي والـقـهـوة الـبـاردة ☕",
            "واحـد كـيـخـطـط والاخـر كـيـنـفـذ الـمـصـائـب 😹",
            "صـحـبـة مـن ذهـب ولـكـن مـطـلـيـة غـيـر بـالـكـلام 🏯",
            "هـادو الا دخـلـو لـشـي مـشـروع غـادي يـفـلـس فـي نـهـارو 📉",
            "الـصـداقـة الـحـقـيـقـيـة هـنـا وبـاقـي الـمـجـمـوعـة غـيـر كـومـبـارس 🎬",
            "صـحـاب الـى الابـد والـى ان يـفـرغ الـرصـيـد 💳"
        ]

        let joke = funnySentences[Math.floor(Math.random() * funnySentences.length)]
        let imageUrl = 'https://files.catbox.moe/4fq300.jpg'

        let txt = `
* ━ ╼╃ ⌬〔🤝〕⌬ ╄╾ ━ *
*〔 ♛ 〕 رابـطـة الـصـداقـة 𝐆𝐎𝐉𝐎*
* ━ ╼╃ ⌬〔 🫂 〕⌬ ╄╾ ━ *

*〔 👤 〕 الـصـديـق الاول :* @${user1.split('@')[0]}
*〔 👤 〕 الـصـديـق الـثـانـي :* @${user2.split('@')[0]}

*〔 💖 〕 تـم اعـلانـكـم اصـحـاب لـلأبـد!*
*〔 🫶 〕 صـداقـتـكـم اسـطـوريـة ولا تـنـتـهـي*

*〔 😂 〕 تـعـلـيـق الـبـوت :*
*› ${joke}*

* ━ ╼╃ ⌬〔 📌 〕⌬ ╄╾ ━ *
*⚠️ تـنـبـيـه : هـادا الـكـود عـشـوائـي 100% لـلـتـرفـيـه فـقـط*
*الـصـداقـة الـحـقـيـقـيـة تـبـان فـي الـمـواقـف مـاشـي فـالـبـوت 😹*
* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️`.trim()

        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: txt,
            mentions: [user1, user2]
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, { text: '* ━ ╼╃ ⌬〔❌〕⌬ ╄╾ ━ *\n*〔 ♛ 〕 خـطـأ:* ' + e.message + '\n* ━ ╼╃ ⌬〔 🕷️ 〕⌬ ╄╾ ━ * ♛ 𝐆𝐎𝐉𝐎-𝐁𝐎𝐓 ⚜️' }, { quoted: m })
    }
}

handler.help = ['اصحاب']
handler.tags = ['fun']
handler.command = ['اصحاب', 'صحاب', 'صداقة']
handler.group = true

export default handler