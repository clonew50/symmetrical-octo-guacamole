import fs from 'fs';
import path from 'path';

function getRandomMediaUrl() {
  try {
    const filePath = path.join(process.cwd(), 'media-links.txt');
    const data = fs.readFileSync(filePath, 'utf-8');
    const links = data.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (links.length === 0) return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
    return links[Math.floor(Math.random() * links.length)];
  } catch (e) {
    console.error('تعذر قراءة media-links.txt:', e.message);
    return 'https://i.postimg.cc/C10z9Y0F/1761910775535.jpg';
  }
}

const handler = async (m, { conn }) => {

    const imageUrl = getRandomMediaUrl();

    const messageText = `

*╔══✦〘💻〙✦══╗*
  『 مـرحـبــاً بـك يـا ⌊ ${m.pushName} ⌉ 』
        فــي قـســم الـبـرمجــة
      داخـل بـوت *『 ⚡_KAISER_ 』*
*╚══✦〘💻〙✦══╝*

*⌝ قــســم الـبــرمجــة ┋💻⌞ ⇊*
*⎔ ⋅ ───━ •﹝🩸﹞• ━─── ⋅ ⎔*

*💻┊⇇ 『 إحــســب-الــحــروف 』*  
*📎┊⇇ 『 إخــتـصــار-إنــشــاء 』*  
*📎┊⇇ 『 إخــتـصــار 』*  
*🌐┊⇇ 『 أيــ-بــي 』*  
*📶┊⇇ 『 بــنــج 』*  
*📄┊⇇ 『 بــي-دي-اف 』*  
*✨┊⇇ 『 تــشــويــش 』*  
*🧪┊⇇ 『 دي-أن-أس 』*  
*🔍┊⇇ 『 فــحــص-الـمــوقــع 』*  
*🧾┊⇇ 『 هــيــدر 』*

*⎔ ⋅ ───━ •﹝🩸﹞• ━─── ⋅ ⎔*

> ⚡ بــوتــك مـع *『 ⚡_KAISER_ 』*  
> دائــمــاً فــي أمــان وخـدمــة 💻
    `.trim();

    await conn.sendMessage(m.chat, { text: "*_جــارٍ إرســال قــســم الــبــرمجــة... ⏳💻_*" }, { quoted: m });

    await conn.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: messageText
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '💻', key: m.key } });
};

handler.command = /^قسم-برمجه$/i;
handler.tags = ["جــيـ"];
handler.help = ["قسم-برمجه"];

export default handler;