/*
Info ff id
By : obito mr
channel : https://whatsapp.com/channel/0029Vb6dsyP3rZZgNJUD2F1A
Api : https://obito-mr-apis.vercel.app
*/

import axios from 'axios';

let handler = async (m, { text, command, usedPrefix}) => {
  if (!text || !/^\d+$/.test(text)) {
    return m.reply(`⚠️ يرجى إدخال ايدي صالح\nمثال: ${usedPrefix + command} 1010493740`);
  }

  try {
    const res = await axios.get(`https://obito-mr-apis.vercel.app/api/info/freefire?id=${text}`);
    const data = res.data;

    if (!data.success || !data.account) {
      return m.reply('❌ لم يتم العثور على معلومات الحساب.');
    }

    const info = data.account.Informations_Compte;

    let reply = `
🎮 *معلومات حساب فري فاير:*
━━━━━━━━━━━━━━
👤 *الاسم:* ${info.Nom}
🆔 *المعرف:* ${info.ID}
⭐ *المستوى:* ${info.Niveau}
📍 *المنطقة:* ${info.Région}
❤️ *الإعجابات:* ${info.J_aimes}
🎖️ *نقاط الشرف:* ${info.Points_Honneur}
🏆 *الحالة المشهورة:* ${info.Statut_Célébrité}
🧢 *اللقب:* ${info.Titre}
📂 *آخر إصدار:* ${info.Dernière_Version}
💳 *بطاقة بووياه:* ${info.Passe_Booyah}
🎗️ *شارات البطاقة:* ${info.Badges_BP}
⚔️ *رتبة باتل رويال:* ${info.Rang_BR}
🎯 *نقاط كلاش سكواد:* ${info.Points_CS}
📈 *أعلى نقاط كلاش:* ${info.Points_CS_Max}
📅 *تاريخ الإنشاء:* ${info.Date_Création}
🖼️ *ايدي الصورة:* ${info.ID_Avatar}
🎨 *ايدي البانر:* ${info.ID_Bannière}
🏅 *ايدي الشارة:* ${info.ID_Pin}
🎭 *المهارات المثبتة:* ${info.Compétences_Équipées}
🔫 *ايدي السلاح:* ${info.ID_Arme}
🏃 *ايدي الحركة:* ${info.ID_Animation}
🔄 *ايدي التحويل:* ${info.ID_Transformation}
━━━━━━━━━━━━━━
🐾 *معلومات الحيوان:*
🆔 *حيوان مثبت؟:* ${info.Animal_Équipé}
📛 *اسم الحيوان:* ${info.Nom_Animal}
🔰 *نوع الحيوان:* ${info.Type_Animal}
⭐ *خبرة الحيوان:* ${info.Exp_Animal}
📊 *مستوى الحيوان:* ${info.Niveau_Animal}
━━━━━━━━━━━━━━
👥 *معلومات النقابة:*
🏷️ *اسم النقابة:* ${info.Nom_Guilde}
🆔 *ايدي النقابة:* ${info.ID_Guilde}
📊 *مستوى النقابة:* ${info.Niveau_Guilde}
👥 *أعضاء النقابة:* ${info.Membres_Guilde}
━━━━━━━━━━━━━━
👑 *معلومات القائد:*
👤 *اسم القائد:* ${info.Nom_Chef}
🆔 *ايدي القائد:* ${info.ID_Chef}
⭐ *مستوى القائد:* ${info.Niveau_Chef}
📅 *تاريخ إنشاء القائد:* ${info.Date_Création_Chef}
🕒 *آخر دخول للقائد:* ${info.Dernière_Connexion_Chef}
🧢 *لقب القائد:* ${info.Titre_Chef}
🎗️ *شارات القائد:* ${info.Badges_Chef}
⚔️ *نقاط باتل رويال للقائد:* ${info.Points_BR_Chef}
🎯 *نقاط كلاش للقائد:* ${info.Points_CS_Chef}
━━━━━━━━━━━━━━
`;

    m.reply(reply);
  } catch (err) {
    console.error(err);
    m.reply('❌ حدث خطأ أثناء جلب المعلومات، حاول لاحقًا.');
  }
};

handler.help = ['obito_mr'];
handler.tags = ['obito_mr'];
handler.command = /^(freefire|فريفاير|infoff)$/i;

export default handler;