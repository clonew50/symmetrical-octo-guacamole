// plugins/adam-test-reply.js
import fetch from "node-fetch";

let handler = async (m, { conn }) => {

  const replyText = `≪  ❪ 💎 𝑻𝑯𝑬 𝑶𝑵𝑬 𝑨𝑩𝑶𝑽𝑬 𝑨𝑳𝑳 💎 ❫ ≫
       ❪ ⚡𝑮𝑬𝑶 ♦️ 𝑩𝑶𝑻 ❫
≪ ━ ❪ 🩸 𝑻𝑯𝑬 𝑨𝑩𝑺𝑶𝑳𝑼𝑻𝑬 🩸 ❫ ━ ≫
╟「 💎 」↬ GEO ✦ The Absolute Power ˖࣪⃟👑
╟「 ⛩️ 」↬ Through Heaven And Earth ˖࣪⃟🌌
╟「 👑 」↬ I Am The One Above All ˖࣪⃟⚡

╰─── ≪ ❪ 💎 👑 💎 ❫ ≫ ───╯
◜⏤͟͟͞͞ ⚡𝑮𝑬𝑶 ⚡ 𝑩𝑶𝑻 ˖࣪⃟💎 ◞`;

  const imageUrl = "https://i.ibb.co/xc340dG/adam-1784652829388.jpg";

  try {
    await conn.sendMessage(m.chat, {
      react: { text: "💎", key: m.key }
    });

    const res = await fetch(imageUrl, { timeout: 10_000 });
    if (!res.ok) throw new Error(`فشل تحميل الصورة: ${res.status}`);

    const imageBuffer = Buffer.from(await res.arrayBuffer());

    await conn.sendMessage(
      m.chat,
      {
        text: replyText,
        contextInfo: {
          externalAdReply: {
            title: "◜⏤͟͟͞͞ ⚡𝑮𝑬𝑶 ✦ 𝑻𝑯𝑬 ✦ 𝑨𝑩𝑺𝑶𝑳𝑼𝑻𝑬 ˖࣪⃟💎 ◞",
            body:  "˖࣪⃟👑 𝑲𝑰𝑵𝑮 ✦ 𝑶𝑭 ✦ 𝑷𝑶𝑾𝑬𝑹 👑˖࣪⃟",
            sourceUrl: "https://https://https://wa.me/9647882860837",
            thumbnail: imageBuffer,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      },
      { quoted: m }
    );

  } catch (err) {
    console.error("❌ adam-test-reply error:", err.message);
    await conn.sendMessage(
      m.chat,
      { text: replyText },
      { quoted: m }
    ).catch(e => console.error("❌ fallback failed:", e.message));
  }
};

handler.customPrefix = /^(تست|\.تست)$/i;
handler.command      = new RegExp();

export default handler;