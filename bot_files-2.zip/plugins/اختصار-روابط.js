// * ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
// > *〔 الـروابـط┊ ˼‏ 🔗˹ ↶〕* *𝐆𝐎𝐉𝐎* ──¤﹝نـظـام fars.ee اخـتـصـار وإنـشـاء ↶﹞*
// * ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *

import fetch from 'node-fetch'
import FormData from 'form-data'

async function اختصار_رابط(url) {
  let form = new FormData()
  form.append('c', url)
  let res = await fetch('https://fars.ee/u', { method: 'POST', body: form })
  let result = await res.text()
  let match = result.match(/url: (https:\/\/fars.ee\/\S+)/)
  return match? match[1] : null
}

async function انشاء_نص(content) {
  let form = new FormData()
  form.append('c', content)
  let res = await fetch('https://fars.ee/?u=1', { method: 'POST', body: form })
  return (await res.text()).trim()
}

let handler = async (m, { args, usedPrefix, command }) => {

  if (command === 'اختصار') {
    if (!args[0]) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❗ 〕أيـن الـرابـط ؟*

*🔗┊مـثـال:*
*${usedPrefix}اختصار https://google.com*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)

    let url = args[0]
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url
    await m.react('🕒')
    try {
      let result = await اختصار_رابط(url)
      if (!result) throw new Error()
      await m.react('✅')
      await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـرابـط┊ ˼‏ 🔗˹ ↶〕* *𝐆𝐎𝐉𝐎*

*🌐┊الأصـلـي:* ${url}
*✨┊الـمـخـتـصـر:* *${result}*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`)
    } catch { await m.react('❌'); m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕لـم يـتـمـكـن مـن اخـتـصـار الـرابـط*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`) }
  }

  if (command === 'انشاء') {
    if (!args[0]) return m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 ❗ 〕أيـن الـنـص ؟*

*📝┊مـثـال:*
*${usedPrefix}انشاء مرحبا بالعالم*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`)
    let text = args.join(' ')
    await m.react('🕒')
    try {
      let result = await انشاء_نص(text)
      await m.react('✅')
      await m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *
> *〔 الـنـص┊ ˼‏ 📝˹ ↶〕* *𝐆𝐎𝐉𝐎*

*✨┊تـم إنـشـاء الـرابـط:*
*${result}*

* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 | 𝐘𝐎𝐍𝐎 𝐃𝐄𝐕 〕⌬ ╄╾ ━ *`)
    } catch { await m.react('❌'); m.reply(`* ━ ╼╃ ⌬〔﷽〕⌬ ╄╾ ━ *\n> *〔 ❌ 〕تـعـذر الـنـشـر*\n* ━ ╼╃ ⌬〔 𝐆𝐎𝐉𝐎 〕⌬ ╄╾ ━ *`) }
  }
}

handler.help = ['اختصار', 'انشاء']
handler.tags = ['ادوات']
handler.command = ['اختصار', 'انشاء']

export default handler