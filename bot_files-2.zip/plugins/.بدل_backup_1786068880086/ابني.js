import fetch from "node-fetch";

let handler = async (m, { conn }) => {
  let name = conn.getName(m.sender);

  // 💬 الرد العشوائي
  let teks = `
${pickRandom([`*بـحـبـك بـابـا 🥹*`])}
`.trim();

  // 📂 إنشاء رسالة التوثيق
  const thumb = await (await fetch('https://files.catbox.moe/80dv0b.jpg')).buffer(); // الصورة نفسها المستخدمة
  const verifiedMessage = {
    key: {
      participants: "0@s.whatsapp.net",
      fromMe: false,
      id: "𝐢𝐭𝐚𝐜𝐡𝐢_VERIFIED"
    },
    message: {
      locationMessage: {
        name: "⚡_KAISER_ 𝑩𝑶𝑻  🩸",
        jpegThumbnail: thumb,
        vcard: `BEGIN:VCARD
VERSION:3.0
N:⚡_KAISER_ 𝑩𝑶𝑻 
FN:.⤹𝑴𝑨𝑬𝑺𝑻𝑹𝑶 𝑻𝑯𝑬 ⚡_KAISER_✨⤾.
ORG:𝐢𝐭𝐚𝐜𝐡𝐢 SYSTEM
TITLE:
item1.TEL;waid=/9647882860837:+9647882860837
item1.X-ABLabel:⚡_KAISER_ 𝑩𝑶𝑻 🪄
X-WA-BIZ-DESCRIPTION:Official ⚡_KAISER_ 𝑩𝑶𝑻🪄 Verified Service
X-WA-BIZ-NAME:⚡_KAISER_ 𝑩𝑶𝑻 🪄
END:VCARD`
      }
    },
    participant: "0@s.whatsapp.net"
  };

  // 📩 إرسال الرد مع التوثيق
  conn.reply(m.chat, teks, verifiedMessage, { mentions: { mentionedJid: [m.sender] } });
};

handler.customPrefix = /(ابني)/i;
handler.command = new RegExp;
handler.rowner = true;

export default handler;

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}